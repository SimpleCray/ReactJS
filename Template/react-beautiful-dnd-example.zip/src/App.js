import DragList from "./DragList";

function App() {
  return <DragList />;
}

export default App;

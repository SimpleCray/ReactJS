import { createApp } from 'vue'
import './style.css'
import DemoApp from './DemoApp.vue'

createApp(DemoApp).mount('#app')

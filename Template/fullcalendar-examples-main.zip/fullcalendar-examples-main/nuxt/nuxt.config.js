
module.exports = {
  // // for easier debugging
  // build: {
  //   extend(config) {
  //     config.devtool = 'source-map'
  //   }
  // }
};

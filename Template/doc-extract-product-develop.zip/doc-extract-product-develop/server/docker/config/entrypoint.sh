#!/bin/bash
cd /home/ubuntu/doc-extract-product/server && yarn install && yarn start && tail -f /dev/null

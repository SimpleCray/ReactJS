import { Router } from 'express';
import multer from 'multer';
import fs from 'fs';
import model from '~/shared/models';

const router = Router();

/**
 * Sample API to get doc file data
 * TODO: Re-Handle
 */

export default router;

/* eslint-disable no-useless-catch */
/* eslint-disable no-plusplus */
/* eslint-disable no-param-reassign */
/* eslint-disable no-restricted-syntax */
import fs from 'fs';
import { PDFDocument } from 'pdf-lib';
import { saveFileProc, checkAddFolderDoc } from '~/utils/commonFuncs';
import DocDataServices from '../docData/DocDataServices';
import CoreAdapterServices from '../coreAdapter/CoreAdapter';
import AppConstants from '../utils/constants';

export const createNewDocInfo = (latestDoc, docNm) => {
  const lastDocId = latestDoc ? latestDoc.doc_id : 0;
  const newDocId = (Number(lastDocId) + 1).toString();
  const newDocName = `${newDocId}_${docNm}`;
  return [newDocId, newDocName];
};

const writePdfBytesToFile = async (fileName, pdfBytes) => fs.promises.writeFile(fileName, pdfBytes);

const saveByteAsPdf = async (fileData, docName, folderLoc) => {
  try {
    await checkAddFolderDoc(folderLoc);
    await writePdfBytesToFile(
      `${AppConstants.LOCATION_DOC_FILE}/${folderLoc}/${docName}`,
      new Buffer.from(JSON.parse(fileData)),
    );
  } catch (err) {
    throw err;
  }
};

const savePdfTask = splitInfos => {
  const pdfSaveTask = [];
  for (const pdfInfo of splitInfos) {
    const { fileData, docNm, folderLoc } = pdfInfo;
    pdfSaveTask.push(saveByteAsPdf(fileData, docNm, folderLoc));
  }
  return Promise.all(pdfSaveTask);
};

const saveDexDocs = (splitDexDocs, usrId) => {
  const listSaveTask = [];
  for (const docInfo of splitDexDocs) {
    const dexDocInfo = {
      doc_id: docInfo.docId,
      doc_nm: docInfo.docNm,
      co_cd: docInfo.coCd,
      loc_id: docInfo.locId,
      loc_cd: docInfo.locCd,
      doc_tp_id: docInfo.docTpId,
      root_nm: docInfo.rootNm,
      cre_usr_id: usrId || 'no-user',
      file_sz: docInfo.fileSz,
    };
    listSaveTask.push(DocDataServices.addDexdoc(dexDocInfo));
  }
  return Promise.all(listSaveTask);
};

const makeSaveDocInfos = (splitInfos, fileName, currentDocId, coCd, locCd, usrId) => {
  const fileCount = splitInfos.length;
  for (let fileNum = 0; fileNum < fileCount; fileNum++) {
    const currentSplitInfo = splitInfos[fileNum];
    const newDocId = `${currentDocId + 1}`;
    currentSplitInfo.docId = newDocId;
    currentSplitInfo.rootNm = fileName;
    currentSplitInfo.docNm = `${newDocId}_${fileName}`;
    currentSplitInfo.fileLoc = `${currentSplitInfo.folderLoc}/${newDocId}_${fileName}`;
    currentSplitInfo.coCd = coCd;
    currentSplitInfo.locCd = locCd;
    currentSplitInfo.usrId = usrId;
    currentDocId += 1;
  }
  return splitInfos;
};

export const saveExtractDoc = async (splitInfos, fileName, coCd, locCd, usrId) => {
  try {
    const latestDoc = await DocDataServices.getLatestDexDoc();
    const currentDocId = Number(latestDoc.doc_id) || 0;
    makeSaveDocInfos(splitInfos, fileName, currentDocId, coCd, locCd, usrId);
    // Save to each document
    await savePdfTask(splitInfos);
    // If save without errors, save dex doc into the DB
    await saveDexDocs(splitInfos, usrId);
    return splitInfos;
  } catch (err) {
    throw err;
  }
};

const saveImgAsPdf = async (urlFolder, originalFileName, newDocName, fileExtension) => {
  const imgBytes = await fs.readFileSync(`${AppConstants.LOCATION_DOC_FILE}/${originalFileName}`);
  // Create a new PDFDocument
  const pdfDoc = await PDFDocument.create();

  // Embed the JPG image bytes and PNG image bytes
  let imgEmbed = null;
  if (fileExtension === 'png') {
    imgEmbed = await pdfDoc.embedPng(imgBytes);
  } else {
    imgEmbed = await pdfDoc.embedJpg(imgBytes);
  }
  // Add a blank page to the document
  const page = pdfDoc.addPage();

  const imgWidth = imgEmbed.width;
  const pageWidth = page.getWidth();
  const pageHeight = page.getHeight();

  const scaleVal = imgWidth > pageWidth ? pageWidth / imgWidth : 1;
  const imgScale = imgEmbed.scale(scaleVal);

  // Draw the JPG image in the center of the page
  page.drawImage(imgEmbed, {
    x: pageWidth / 2 - imgScale.width / 2,
    y: pageHeight / 2 - imgScale.height / 2,
    width: imgScale.width,
    height: imgScale.height,
  });
  // Serialize the PDFDocument to bytes (a Uint8Array)
  const pdfBytes = await pdfDoc.save();
  checkAddFolderDoc(urlFolder);
  await writePdfBytesToFile(`${AppConstants.LOCATION_DOC_FILE}/${urlFolder}/${newDocName}`, pdfBytes);
  fs.unlinkSync(`${AppConstants.LOCATION_DOC_FILE}/${originalFileName}`);
};

/**
 * This func help to save doc file into correct file location because multer just can save as static loc
 * This func also add to dex doc data
 */
export const uploadDocMethod = async (docData, originalFileName) => {
  try {
    const { urlFolder } = docData;
    const latestDoc = await DocDataServices.getLatestDexDoc();
    let [newDocId, newDocName] = createNewDocInfo(latestDoc, originalFileName);
    docData.doc_id = newDocId;
    const coreSystemName = await CoreAdapterServices.getCoreSystemName(docData.doc_tp_id);
    const fileExtension = originalFileName
      .split('.')
      .pop()
      .toLowerCase();
    if (coreSystemName === AppConstants.CORE_SYS_NAME.LABEL) {
      // Label core can upload image directly
      await saveFileProc(AppConstants.LOCATION_DOC_FILE, urlFolder, originalFileName, newDocName);
    } else {
      // Check originalFileName, if is image -> convert to pdf -> save to location
      if (AppConstants.FILE_TYPE_DOC_IMG.includes(fileExtension)) {
        newDocName = `${newDocId}_${originalFileName
          .split('.')
          .slice(0, -1)
          .join('.')}.pdf`;
        await saveImgAsPdf(urlFolder, originalFileName, newDocName, fileExtension);
      } else {
        await saveFileProc(AppConstants.LOCATION_DOC_FILE, urlFolder, originalFileName, newDocName);
      }
    }
    docData.doc_nm = newDocName;
    await DocDataServices.addDexdoc(docData);
    const servPath = `${process.env.REACT_APP_DOC_LOC}/${urlFolder}/${newDocName}`;
    return {
      sts_cd: 200,
      msg: 'Insert document successful',
      file_url: servPath,
      doc_id: newDocId,
      co_cd: docData.co_cd,
      loc_cd: docData.loc_cd,
      doc_type: docData.doc_tp_id,
      file_type: fileExtension,
      file_size: docData.file_sz,
      prnt_doc_id: docData.prnt_doc_id,
      doc_grp_id: docData.doc_grp_id,
    };
  } catch (err) {
    throw err;
  }
};

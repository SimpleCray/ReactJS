/* eslint-disable no-restricted-syntax */
import DocDataServices from '../docData/DocDataServices.js';
import TemplateServices from '../template/TemplateServices.js';
import AppConstants from '../utils/constants';
import { processRunBizRuleByDoc } from '../bizRule/index';
import { uploadDocMethod } from '../document/uploadDocMethod';
import { processRunExtrRuleByDoc } from '../extractionRule/index.js';
import CoreAdapterServices from '../coreAdapter/CoreAdapter';
import logger from '~/shared/logger';

const axios = require('axios');

export default class ExtractionServices {
  constructor() {
    this.dataRes = null;
  }

  static async updateMatchingForTmplt(matchingData, docTypeId, usrId) {
    let tmpId = matchingData.tmp_id;
    let tmpType = matchingData.tmp_type;
    try {
      if (tmpId) {
        // Update matching data for template ID
        await TemplateServices.updateTemplateMatching(tmpId, matchingData, usrId);
      } else {
        // Find template or create
        const templateInfo = await TemplateServices.getTmpltAfterGenerateNew(matchingData, docTypeId, usrId);
        tmpId = templateInfo.tmpltId;
        tmpType = templateInfo.tmpltType;
      }
    } catch (err) {
      logger.error(err);
      throw err;
    }
    return [tmpType, tmpId];
  }

  static async updateTemplateVersionForDoc(docId, tmpId, usrId) {
    try {
      const tmpltVersion = await TemplateServices.getTemplateVersion(tmpId);
      await DocDataServices.updateTemplateForDoc(docId, tmpId, tmpltVersion, usrId);
    } catch (err) {
      logger.error(err);
      throw err;
    }
    return true;
  }

  static async updateDocData(reExtract, docId, tmpId, status, usrId) {
    try {
      await DocDataServices.updateTemplateAndDocStatus(docId, tmpId, status, usrId);
      if (reExtract && (status === AppConstants.DOC_STATUS.EXTRACTED || status === AppConstants.DOC_STATUS.VERIFY)) {
        await this.updateTemplateVersionForDoc(docId, tmpId, usrId);
      }
    } catch (err) {
      logger.error(err);
      throw err;
    }
    return true;
  }

  /**
   * INPUT: fileData : {
   *  docId
   *  coCd
   *  locCd
   *  docTpId
   *  fileUrl || fileLoc
   * }
   * @param {*} fileData
   * @returns
   */
  static async extractDocument(fileData, reExtract = false, updateTmplt = false) {
    const { docId } = fileData;
    if (!fileData && !docId) throw new Error('Extract File Info wrong!!!');
    let tmpType = '';
    let tmpId = '';
    let status = AppConstants.DOC_STATUS.NEED_MATCHING;
    const fileUrl = fileData.fileUrl ? fileData.fileUrl : `${process.env.REACT_APP_DOC_LOC}${fileData.fileLoc}`;
    let coreErrMsg = '';
    let extractJson = null;
    const usrId = fileData.usrId || 'no-user';
    try {
      const reqCoreMatching = {
        doc_id: docId,
        file_url: fileUrl,
        co_cd: fileData.coCd,
        lo_cd: fileData.locCd,
        doc_tp_id: fileData.docTpId,
        grp_val: fileData.grpVal || '',
      };
      const matchingData = await CoreAdapterServices.runMatching(reqCoreMatching, fileData.docTpId).catch((err) => {
        coreErrMsg = err;
        throw new Error('Could not matching!');
      });
      /**
       * If matching failed => update status N for docId
       * If matching return file is not annotated, tmp_id is empty, update status N for docId
       * If matching return file is not annotated, tmp_id is have, update status A for docId
       *
       * If extraction done:
       * - In case of extraction ok => update status E for docId
       * - In case of extraction failed => update status F for docId
       */
      coreErrMsg = matchingData.msg;
      tmpId = matchingData.tmp_id;
      tmpType = matchingData.tmp_type;
      if (matchingData.is_annotated) {
        const reqCoreExtract = {
          file_url: fileUrl,
          doc_id: docId,
          tmp_type: tmpType,
          tmp_id: tmpId,
          doc_tp_id: fileData.docTpId,
        };
        const extractedData = await CoreAdapterServices.runExtract(reqCoreExtract, fileData.docTpId).catch((err) => {
          coreErrMsg = err;
          status = AppConstants.DOC_STATUS.FAILED;
          throw err;
        });
        const saveExtractRes = await DocDataServices.saveExtractionData(
          extractedData.data,
          fileData.docTpId,
          docId,
        ).catch(err => {
          coreErrMsg = 'Save Extraction Data Failed!';
          status = AppConstants.DOC_STATUS.FAILED;
          throw err;
        });
        if (saveExtractRes) {
          status = AppConstants.DOC_STATUS.EXTRACTED;
          const extractRuleRes = await processRunExtrRuleByDoc(docId);
          await DocDataServices.updateDocExtracData(docId, null, extractRuleRes, null);
          const bizRes = await processRunBizRuleByDoc(docId);
          await DocDataServices.updateBizData(docId, bizRes);
          if (fileData.smartLink) {
            const renderableData = await DocDataServices.getRenderableData(docId);
            extractJson = renderableData.extractedData.aft_biz_ctnt;
          }
        }
      } else if (updateTmplt) {
        [tmpType, tmpId] = await this.updateMatchingForTmplt(matchingData, fileData.docTpId, usrId);
      }
      await this.updateDocData(reExtract, docId, tmpId, status, usrId);
    } catch (error) {
      logger.error(error);
    }
    const annotateUrl = tmpId ? `${process.env.CLIENT_URL + AppConstants.CLIENT_URL.ANNOTATE}/${tmpType}/${tmpId}` : '';
    const viewExtUrl = process.env.CLIENT_URL + AppConstants.CLIENT_URL.VIEW_EXT;
    this.dataRes = {
      sts_cd: 200,
      extract_url: `${viewExtUrl}/${docId}`,
      annotate_url: annotateUrl,
      status,
      fileUrl,
      reason: coreErrMsg, // TODO: Define if need
      tmpltId: tmpId,
      tmpltType: tmpType,
      doc_id: docId,
      extractJson,
    };
    return this.dataRes;
  }

  static async extractDocList(docList, usrId) {
    const extractTask = [];
    for (const docInfo of docList) {
      docInfo.usrId = usrId;
      extractTask.push(this.extractDocument(docInfo));
    }
    const resultTask = await Promise.all(extractTask);
    return resultTask;
  }

  static async makeExtractDocData(saveDocInfo, usrId, isSmartLink = false) {
    const docExtractData = {
      docId: saveDocInfo.doc_id,
      fileUrl: saveDocInfo.file_url,
      coCd: saveDocInfo.co_cd,
      locCd: saveDocInfo.loc_cd,
      docTpId: saveDocInfo.doc_type,
      grpVal: saveDocInfo.grp_val || '',
      usrId,
    };
    if (isSmartLink) docExtractData.smartLink = true;
    return docExtractData;
  }

  static async saveExtractDocument(docData, originalFileName) {
    let extractedData = {};
    try {
      const saveDocData = await uploadDocMethod(docData, originalFileName);
      const usrId = docData.cre_usr_id;
      const docExtractData = await this.makeExtractDocData(saveDocData, usrId, true);
      // Calling matching -> extraction
      extractedData = await this.extractDocument(docExtractData, false, true);
    } catch (err) {
      logger.error(err);
      throw err;
    }
    return extractedData;
  }
}

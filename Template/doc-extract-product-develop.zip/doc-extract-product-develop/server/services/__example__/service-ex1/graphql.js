import typeDefs from './schema';
import resolvers from './resolver';

export default { typeDefs, resolvers };

import { Router } from 'express';
import MigrationServices from './MigrationServices';
import { customRes } from '~/utils/commonFuncs';

const router = Router();

router.post('/add-extr-default-to-template', async (req, res, next) => {
  const dataRes = await MigrationServices.addExtrTypeToTmplt().catch(err => next(err));
  customRes(req, res, next, dataRes);
});

export default router;

// TODO: server-sent events

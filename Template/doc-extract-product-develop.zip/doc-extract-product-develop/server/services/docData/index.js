import { Router } from 'express';
import DocDataServices from './DocDataServices';
import model from '~/shared/models';
import { customRes } from '~/utils/commonFuncs';
import logger from '~/shared/logger';

const router = Router();

router.get('/get-renderable-data/:docId', async (req, res, next) => {
  const { docId } = req.params;
  const dataRes = await DocDataServices.getRenderableData(docId).catch(err => next(err));
  customRes(req, res, next, dataRes);
});

router.get('/get-by-doc-name', async (req, res, next) => {
  const { docName } = req.query;
  const dataRes = await DocDataServices.getDocDataInfoByDocName(docName).catch(err => next(err));
  customRes(req, res, next, dataRes);
});

router.get('/latest-doc-by-tmpl-id', async (req, res, next) => {
  const { tmpltId } = req.query;
  const dataRes = await DocDataServices.getLatestDocByTmplId(tmpltId).catch(err => next(err));
  customRes(req, res, next, dataRes);
});

router.post('/update-tmpl-id-doc', async (req, res, next) => {
  const { docId, templateId, usrId } = req.body;
  console.log('Doc', docId, templateId);
  const dataRes = await DocDataServices.updateTemplateIdForDoc(docId, templateId, usrId).catch(err => next(err));
  customRes(req, res, next, dataRes);
});

/**
 * Sample API to get doc file data
 * TODO: Re-Handle
 */

router.get('/get-dex-doc', async (req, res, next) => {
  const dataRes = await DocDataServices.getExtractedDocList(req.query).catch(err => {
    logger.error(err);
    next(err);
  });
  customRes(req, res, next, dataRes);
});

router.post('/add-dex-doc', async (req, res, next) => {
  try {
    model.DexDoc.findAll({
      limit: 1,
      order: [['cre_dt', 'DESC']],
    }).then(async function(lastDoc) {
      const lastId = lastDoc.length > 0 ? lastDoc[0].doc_id : 0;
      let docId = Number(lastId) + 1;
      docId = docId.toString();
      req.body.doc.doc_id = docId;
      await DocDataServices.addDexdoc(req.body.doc);
      res.status(200).json({ docId, message: 'Insert document successful' });
    });
  } catch (error) {
    next(error);
  }
});

router.post('/update-biz-data', async (req, res, next) => {
  const { bizData } = req.body;
  const { docId } = req.query;
  const dataRes = await DocDataServices.updateBizData(docId, bizData).catch(err => next(err));
  customRes(req, res, next, dataRes);
});

router.get('/:docId', async (req, res, next) => {
  const { docId } = req.params;
  const dataRes = await DocDataServices.getDocDataInfo(docId).catch(err => next(err));
  if (dataRes) return res.status(200).json(dataRes);
  return next();
});

router.post('/update-doc-status', async (req, res, next) => {
  const { docId, status } = req.body;
  const dataRes = await DocDataServices.updateDocStatus(docId, status).catch(err => next(err));
  customRes(req, res, next, dataRes);
});

/**
 * This func is used to update status and issue for document
 * docId: String
 * status: String
 * issueList: array
 */
router.post('/update-issue-status', async (req, res, next) => {
  const { docId, status, issueList, replaceOldIssue, isBiz } = req.body;
  const dataRes = await DocDataServices.updateIssueStatusDoc(docId, status, issueList, replaceOldIssue, isBiz).catch(err => next(err));
  customRes(req, res, next, dataRes);
});

router.post('/update-extracted-data', async (req, res, next) => {
  const { docId, extractedData } = req.body;
  const dataRes = await DocDataServices.updateDocExtracData(docId, null, extractedData, null).catch(err => next(err));
  customRes(req, res, next, dataRes);
});

router.put('/save-extraction-data', async (req, res, next) => {
  const reqBody = req.body;
  const docId = reqBody ? reqBody.doc_id : null;
  const extractedData = reqBody ? reqBody.data : null;
  const docTypeId = reqBody ? reqBody.doc_tp_id : null;
  if (!docId || !extractedData || !docTypeId) {
    return res.status(500).json({ sts_cd: 500, msg: 'Invalid params' });
  }
  const dataRes = await DocDataServices.saveExtractionData(extractedData, docTypeId, docId).catch(err => next(err));
  customRes(req, res, next, dataRes);
});

export default router;

import logger from '~/shared/logger';
import model from '~/shared/models';
import { BadRequestError } from '../utils/errors';
import DocDataServices from '../docData/DocDataServices.js';
const { Op } = require('sequelize');

export default class OtherAPIServices {
  constructor() {
    this.dataRes = null;
  }

  static async getListDocInfos(comCd, locCd, docTypeId, usrId, fromDate, toDate) {
    const lastDate = `${toDate.split('T')[0]} 23:59:59`;
    const whereClause = {
      prnt_doc_id: null,
      cre_dt: { [Op.between]: [fromDate, lastDate] },
    };
    const whereClauseDexLoc = {};
    whereClauseDexLoc.loc_nm = locCd;
    whereClauseDexLoc.co_cd = comCd;
    whereClauseDexLoc.cre_usr_id = usrId;
    whereClauseDexLoc.doc_tp_id = docTypeId;
    const attributes = ['doc_id', 'sts_cd', 'aft_biz_ctnt'];
    await model.DexDoc.findAll({
      where: whereClause,
      order: [['upd_dt', 'DESC']],
      attributes,
    })
      .then(result => {
        let formatedListDoc = [];
        if (result) {
          formatedListDoc = result.map(res => ({
            doc_id: res.doc_id,
            status: res.sts_cd,
            data: res.aft_biz_ctnt,
          }));
        }
        const resObj = {
          list_doc: formatedListDoc,
        };
        this.dataRes = resObj || null;
      })
      .catch(err => {
        logger.error(err);
        throw new BadRequestError('Getting List Doc-Data From Date was failed!');
      });
    return this.dataRes;
  }

  static async getDocData(docId, lastestTransaction) {
    try {
      const resObj = {
        sts_cd: 200,
        status: null,
        extractJson: null,
      };
      const renderableData = await DocDataServices.getRenderableData(docId, lastestTransaction);
      if (renderableData) {
        resObj.status = renderableData.extractedData.sts_cd;
        resObj.extractJson = renderableData.extractedData.aft_biz_ctnt;
      }
      this.dataRes = resObj;
    } catch (err) {
      logger.error(err);
      throw new BadRequestError('Getting doc info failed!');
    }
    return this.dataRes;
  }
}

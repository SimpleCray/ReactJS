import { Router } from 'express';
import OtherAPIServices from './OtherAPIServices';
import ExtractionServices from '../extraction/ExtractionServices';
import { customRes } from '~/utils/commonFuncs';
const uploadDoc = require('../shared/middleWare/uploadDoc');

const router = Router();

router.get('/get-docs-from-date', async (req, res, next) => {
  const { date_from, date_to, co_cd, loc_cd, doc_tp_id, usr_id } = req.query;
  if (!co_cd || !loc_cd || !doc_tp_id || !usr_id || !date_from) next(new Error('Invalid Params!!!'));
  const dataRes = await OtherAPIServices.getListDocInfos(co_cd, loc_cd, doc_tp_id, usr_id, date_from, date_to).catch((err) => next(err));
  customRes(req, res, next, dataRes);
});

router.post('/upload-extract-doc', uploadDoc, async (req, res, next) => {
  const docData = req.body;
  try {
    const originalFileName = req.file.originalname;
    const dataRes = await ExtractionServices.saveExtractDocument(docData, originalFileName);
    customRes(req, res, next, dataRes);
  } catch (err) {
    next(err);
  }
});

router.get('/get-doc-data', async (req, res, next) => {
  const { docId, transaction_latest } = req.query;
  if (!docId) next(new Error('Invalid Params!!!'));
  const dataRes = await OtherAPIServices.getDocData(docId, transaction_latest).catch(err => next(err));
  customRes(req, res, next, dataRes);
});

export default router;

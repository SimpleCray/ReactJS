import { Router } from 'express';
import BPServices, { getOptionsHeaderBP } from './BPServices';
const router = Router();
const verify = require('../shared/middleWare/verifyToken');

const successStatus = 200;

router.get('/get-menu', verify, async (req, res, next) => {
  const reqOptions = getOptionsHeaderBP(req);
  const dataRes = await BPServices.getMenuAuth(reqOptions).catch(err => next(err));
  return res.status(successStatus).json(dataRes);
});

router.post('/get-btn', verify, async (req, res, next) => {
  const reqOptions = getOptionsHeaderBP(req);
  const { mnuPgmId } = req.body;
  const data = {
    mnuPgmId,
  };
  const dataRes = await BPServices.getBtnAuth(data, reqOptions).catch(err => next(err));
  return res.status(successStatus).json(dataRes);
});

router.get('/get-all-com', verify, async (req, res, next) => {
  const reqOptions = getOptionsHeaderBP(req);
  const dataRes = await BPServices.getAllCompanies(reqOptions).catch(err => next(err));
  return res.status(successStatus).json(dataRes);
});

router.get('/get-user-info', verify, async (req, res, next) => {
  const reqOptions = getOptionsHeaderBP(req);
  const dataRes = await BPServices.getUserInfo(reqOptions).catch(err => next(err));
  return res.status(successStatus).json(dataRes);
});

export default router;

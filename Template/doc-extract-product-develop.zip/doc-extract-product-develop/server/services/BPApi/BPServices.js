import { BadRequestError } from '../utils/errors';
import logger from '~/shared/logger';
import AppConstants from '../utils/constants';
const axios = require('axios');

const checkResBPServer = resData => {
  if (resData.status === 200 && resData.data) {
    return true;
  }
  return false;
};

export default class BPServices {
  constructor() {
    this.dataRes = {};
  }

  static async getBtnAuth(data, reqOptions) {
    const urlReq = process.env.BP_URL + AppConstants.BP_API.BTN_AUTH;
    await axios
      .post(urlReq, data, reqOptions)
      .then(result => {
        if (checkResBPServer(result)) {
          this.dataRes = {
            data: result.data,
            message: 'Getting BTN List from BP successfully',
          };
        }
      })
      .catch(error => {
        logger.error(error);
        throw new BadRequestError('Getting BTN List from BP failed');
      });

    return this.dataRes;
  }

  static async getMenuAuth(reqOptions) {
    const urlReq = process.env.BP_URL + AppConstants.BP_API.MENU_AUTH;
    await axios
      .get(urlReq, reqOptions)
      .then(result => {
        if (checkResBPServer(result)) {
          this.dataRes = {
            data: result.data,
            message: 'Getting Menu List from BP successfully',
          };
        }
      })
      .catch(error => {
        logger.error(error);
        throw new BadRequestError('Getting Menu List from BP failed');
      });

    return this.dataRes;
  }

  static async getAllCompanies(reqOptions) {
    const urlReq = process.env.BP_URL + AppConstants.BP_API.ALL_COM;
    await axios
      .get(urlReq, reqOptions)
      .then(result => {
        if (checkResBPServer(result)) {
          this.dataRes = {
            data: result.data,
            message: 'Getting Company List from BP successfully',
          };
        }
      })
      .catch(error => {
        logger.error(error);
        throw new BadRequestError('Getting Company List from BP failed');
      });

    return this.dataRes;
  }

  static async getUserInfo(reqOptions) {
    const urlReq = process.env.BP_URL + AppConstants.BP_API.USR_INFO;
    await axios
      .get(urlReq, reqOptions)
      .then(result => {
        if (checkResBPServer(result)) {
          this.dataRes = {
            data: result.data,
            message: 'Getting User Info from BP successfully',
          };
        }
      })
      .catch(error => {
        logger.error(error);
        throw new BadRequestError('Getting User Info from BP failed');
      });

    return this.dataRes;
  }
}

export const getOptionsHeaderBP = (req) => {
  const token = req.header('Authorization').split(' ')[1];
  return {
    headers: {
      Authorization: token,
    },
  };
};

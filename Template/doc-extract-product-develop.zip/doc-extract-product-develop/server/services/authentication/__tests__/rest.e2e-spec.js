// import request from 'supertest';

describe('authentication', () => {
  it('test', async () => {
    // const { statusCode } = await request(global.API_URL)
    //   .get('/authentication/profile')
    //   .set('token', 'eyJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6ImxpbmRhIiwiZXhwaXJlcyI6MTU1NDM4OTI2ODgzN30.C7xEwFpdo4B4VzQWHJ3cbIS_5Jv4mGwwrw9KtR6LyeU');

    // expect(statusCode).toBe(200);
  });
});

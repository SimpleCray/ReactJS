# Docker build command

```
cd {WORK_DIR_OF_DOCKER_FILE}
docker build . -t <docker_image_name>:<tag>

- Ex: docker build . -t shinev2_db

```
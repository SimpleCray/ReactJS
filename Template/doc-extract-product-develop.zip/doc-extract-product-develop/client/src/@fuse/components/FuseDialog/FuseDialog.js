import React from 'react';
import { Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Button } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import * as Actions from 'app/store/actions';

function FuseDialog(props) {
    const dispatch = useDispatch();
    const state = useSelector(({ fuse }) => fuse.dialog);

    return (
        <Dialog open={state.state} onClose={ev => dispatch(Actions.closeDialog())} aria-labelledby="fuse-dialog-title">
            <DialogTitle id="alert-dialog-title">{state.title}</DialogTitle>
            <DialogContent>
                <DialogContentText id="alert-dialog-description" style={{ whiteSpace: 'pre-line' }}>
                    {state.message}
                </DialogContentText>
            </DialogContent>
            <DialogActions>
                {(!state.type || state.type === 'Alert') && (
                    <Button onClick={() => dispatch(Actions.closeDialog())} color="primary">
                        Close
                    </Button>
                )}
                {state.type === 'Confirm' && (
                    <React.Fragment>
                        <Button
                            onClick={() => {
                                state.okFnc();
                                dispatch(Actions.closeDialog());
                            }}
                            color="primary"
                        >
                            OK
                        </Button>
                        <Button onClick={() => dispatch(Actions.closeDialog())} color="primary">
                            Cancel
                        </Button>
                    </React.Fragment>
                )}
            </DialogActions>
        </Dialog>
    );
}

export default FuseDialog;

export const OPEN_DIALOG = '[DIALOG] OPEN';
export const CLOSE_DIALOG = '[DIALOG] CLOSE';

export function closeDialog() {
    return {
        type: CLOSE_DIALOG,
    };
}

export function openDialog(message, title, modalType, okFnc) {
    return {
        type: OPEN_DIALOG,
        message,
        title,
        modalType: modalType || '',
        // eslint-disable-next-line no-unneeded-ternary
        okFnc: okFnc ? okFnc : () => { },
    };
}

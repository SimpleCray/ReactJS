export const GET_BUTTON_AUTH = 'GET_BUTTON_AUTH';


export function getButtonAuth(btnList) {
    return {
        type: GET_BUTTON_AUTH,
        btnList: btnList,
    };
}
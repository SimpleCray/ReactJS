import { combineReducers } from 'redux';
import auth from 'app/components/auth/store/reducers';
import fuse from './fuse';
import shared from './shared';

const createReducer = asyncReducers =>
    combineReducers({
        auth,
        fuse,
        shared,
        ...asyncReducers,
    });

export default createReducer;

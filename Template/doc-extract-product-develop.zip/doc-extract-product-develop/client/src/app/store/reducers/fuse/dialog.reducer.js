import * as Actions from 'app/store/actions/fuse';

const initialState = {
    state: false,
    options: {
        children: 'Hi',
    },
};

const dialog = function(state = initialState, action) {
    switch (action.type) {
        case Actions.OPEN_DIALOG: {
            return {
                ...state,
                state: true,
                message: action.message,
                title: action.title,
                type: action.modalType,
                okFnc: action.okFnc,
            };
        }
        case Actions.CLOSE_DIALOG: {
            return {
                ...state,
                state: false,
            };
        }
        default: {
            return state;
        }
    }
};

export default dialog;

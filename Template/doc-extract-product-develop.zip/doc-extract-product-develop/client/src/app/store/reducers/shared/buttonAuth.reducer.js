import * as Actions from '../../actions/shared/index';

const initialState = {
    btnList: [],
};

const buttonAuth = function (state = initialState, action) {
    switch (action.type) {
        
        case Actions.GET_BUTTON_AUTH: {
            return {
                ...state,
                btnList: action.btnList,
            };
        }

        default: {
            return state;
        }
    }
};

export default buttonAuth;
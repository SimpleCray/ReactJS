import { combineReducers } from 'redux';
import buttonAuth from './buttonAuth.reducer';

const sharedReducers = combineReducers({
    buttonAuth,
});

export default sharedReducers;

import React, { useEffect, useCallback } from 'react';
import {
    TextField,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    Icon,
    Typography,
    Toolbar,
    AppBar,
    Avatar,
    IconButton,
} from '@material-ui/core';
import { Close } from '@material-ui/icons';
import { useForm } from '@fuse/hooks';
import * as authActions from 'app/components/auth/store/actions';
import { useDispatch, useSelector } from 'react-redux';

const defaultFormState = {
    usrId: '',
    usrNm: '',
    usrEml: '',
    imgUrl: 'assets/images/avatars/profile.jpg',
    fullNm: '',
    usrTeam: '',
};

function ProfileDialog(props) {
    const dispatch = useDispatch();
    const contactDialog = useSelector(({ auth }) => auth.user.contactDialog);

    const { form, handleChange, setForm } = useForm(defaultFormState);

    const initDialog = useCallback(() => {
        /**
         * Dialog type: 'edit'
         */
        if (contactDialog.type === 'edit' && contactDialog.data) {
            setForm({ ...contactDialog.data });
        }
    }, [contactDialog.data, contactDialog.type, setForm]);

    useEffect(() => {
        /**
         * After Dialog Open
         */
        if (contactDialog.props.open) {
            initDialog();
        }
    }, [contactDialog.props.open, initDialog]);

    function closeComposeDialog() {
        dispatch(authActions.closeProfileDialog());
    }

    function canBeSubmitted() {
        return form.fullNm.length > 0;
    }

    function handleSubmit(event) {
        event.preventDefault();
        // dispatch(authActions.updateContact(form));
        closeComposeDialog();
    }

    return (
        <Dialog
            classes={{
                paper: 'm-24',
            }}
            {...contactDialog.props}
            onClose={closeComposeDialog}
            fullWidth
            maxWidth="xs"
        >
            <AppBar position="static" elevation={1}>
                <Toolbar className="flex flex-row w-full">
                    <div className="flex w-8/12 justify-start">
                        <Typography variant="subtitle1" color="inherit">
                            Profile
                        </Typography>
                    </div> 
                    <div className="flex w-4/12 justify-end">
                        <IconButton onClick={closeComposeDialog}>
                            <Close style={{ color: 'white'}} />
                        </IconButton>
                    </div>
                </Toolbar>
                <div className="flex flex-col items-center justify-center pb-24">
                    <Avatar
                        className="w-96 h-96"
                        alt="No Image"
                        src={`${process.env.REACT_APP_BP_AVT}${form.imgUrl}`}
                    />
                    {contactDialog.type === 'edit' && (
                        <Typography variant="h6" color="inherit" className="pt-8">
                            {form.usrNm}
                        </Typography>
                    )}
                </div>
            </AppBar>
            <form noValidate onSubmit={handleSubmit} className="flex flex-col overflow-hidden">
                <DialogContent classes={{ root: 'p-24' }}>
                    <div className="flex">
                        <div className="min-w-48 pt-16">
                            <Icon color="action">perm_identity</Icon>
                        </div>

                        <TextField
                            className="mb-24"
                            label="User ID"
                            autoFocus
                            id="usrId"
                            name="usrId"
                            value={form.usrId}
                            variant="outlined"
                            required
                            fullWidth
                            disabled
                        />
                    </div>

                    <div className="flex">
                        <div className="min-w-48 pt-16">
                            <Icon color="action">account_circle</Icon>
                        </div>
                        <TextField
                            className="mb-24"
                            label="User Name"
                            id="usrNm"
                            name="usrNm"
                            value={form.usrNm}
                            variant="outlined"
                            fullWidth
                            disabled
                        />
                    </div>

                    <div className="flex">
                        <div className="min-w-48 pt-16">
                            <Icon color="action">account_box</Icon>
                        </div>

                        <TextField
                            className="mb-24"
                            label="Full Name"
                            autoFocus
                            id="fullNm"
                            name="fullNm"
                            value={form.fullNm}
                            variant="outlined"
                            required
                            fullWidth
                            disabled
                        />
                    </div>

                    <div className="flex">
                        <div className="min-w-48 pt-16">
                            <Icon color="action">email</Icon>
                        </div>
                        <TextField
                            className="mb-24"
                            label="Email"
                            id="usrEml"
                            name="usrEml"
                            value={form.usrEml}
                            variant="outlined"
                            fullWidth
                            disabled
                        />
                    </div>

                    <div className="flex">
                        <div className="min-w-48 pt-16">
                            <Icon color="action">group</Icon>
                        </div>
                        <TextField
                            className="mb-24"
                            label="Team"
                            id="usrTeam"
                            name="usrTeam"
                            value={form.usrTeam}
                            variant="outlined"
                            fullWidth
                            disabled
                        />
                    </div>
                </DialogContent>

                {/* {contactDialog.type === 'new' ? (
                    <DialogActions className="justify-between pl-16">
                        <Button variant="contained" color="primary" type="submit" disabled={!canBeSubmitted()}>
                            Add
                        </Button>
                    </DialogActions>
                ) : (
                    <DialogActions className="justify-end pl-16">
                        <Button variant="contained" color="primary" type="submit" onClick={closeComposeDialog}>
                            Close
                        </Button>
                    </DialogActions>
                )} */}
            </form>
        </Dialog>
    );
}

export default ProfileDialog;

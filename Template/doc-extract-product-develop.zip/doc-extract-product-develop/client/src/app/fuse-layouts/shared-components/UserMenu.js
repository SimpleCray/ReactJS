import React, { useEffect, useState } from 'react';
import { Avatar, Button, Icon, ListItemIcon, ListItemText, Popover, MenuItem, Typography } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import * as authActions from 'app/components/auth/store/actions';
import { Link } from 'react-router-dom';
import ProfileDialog from "./ProfileDialog";
import history from "@history";
import AppConstants from 'app/utils/appConstants';

function UserMenu(props) {
    const dispatch = useDispatch();
    const user = useSelector(({ auth }) => auth.user);
    const userInfo = user.usrInfo;

    useEffect(() => {
        dispatch(authActions.getUserInfo());
    }, [dispatch]);

    const [userMenu, setUserMenu] = useState(null);

    const userMenuClick = event => {
        setUserMenu(event.currentTarget);
    };

    const userMenuClose = () => {
        setUserMenu(null);
    };

    const onLogoutUser = () => {
        localStorage.clear();
        history.push('/login');
    };

    const onAccountClick = () => {
        setUserMenu(null);
        dispatch(authActions.openProfileDialog(userInfo));
    }

    return (
        <React.Fragment>
            <Button className="h-52" onClick={userMenuClick}>
                {localStorage.getItem(AppConstants.BP_USER_INFO) ? (
                    <Avatar
                        className=""
                        alt="No Image"
                        src={
                            process.env.REACT_APP_BP_AVT +
                            JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO)).imgUrl
                        }
                    />
                ) : (
                    <Avatar className="" src="assets/images/avatars/profile.jpg" />
                )}
                <div className="hidden md:flex flex-col ml-12 items-start">
                    <Typography component="span" className="normal-case font-600 flex">
                        {localStorage.getItem(AppConstants.BP_USER_INFO)
                            ? JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO)).usrNm
                            : ''}
                    </Typography>
                    <Typography className="text-11 capitalize" color="textSecondary">
                        {user.role.toString()}
                    </Typography>
                </div>

                <Icon className="text-16 ml-12 hidden sm:flex" variant="action">
                    keyboard_arrow_down
                </Icon>
            </Button>

            <ProfileDialog />

            <Popover
                open={Boolean(userMenu)}
                anchorEl={userMenu}
                onClose={userMenuClose}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'center',
                }}
                transformOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                }}
                classes={{
                    paper: 'py-8',
                }}
            >
                {!user.role || user.role.length === 0 ? (
                    <React.Fragment>
                        <MenuItem onClick={onAccountClick}>
                            <ListItemIcon className="min-w-40">
                                <Icon>account_box</Icon>
                            </ListItemIcon>
                            <ListItemText className="pl-0" primary="Profile" />
                        </MenuItem>
                        <MenuItem onClick={() => onLogoutUser()}>
                            <ListItemIcon className="min-w-40">
                                <Icon>exit_to_app</Icon>
                            </ListItemIcon>
                            <ListItemText className="pl-0" primary="Logout" />
                        </MenuItem>
                    </React.Fragment>
                ) : (
                    <React.Fragment>
                        <MenuItem component={Link} to="/pages/profile" onClick={userMenuClose}>
                            <ListItemIcon className="min-w-40">
                                <Icon>account_circle</Icon>
                            </ListItemIcon>
                            <ListItemText className="pl-0" primary="My Profile" />
                        </MenuItem>
                        <MenuItem component={Link} to="/apps/mail" onClick={userMenuClose}>
                            <ListItemIcon className="min-w-40">
                                <Icon>mail</Icon>
                            </ListItemIcon>
                            <ListItemText className="pl-0" primary="Inbox" />
                        </MenuItem>
                        <MenuItem
                            onClick={() => {
                                dispatch(authActions.logoutUser());
                                userMenuClose();
                            }}
                        >
                            <ListItemIcon className="min-w-40">
                                <Icon>exit_to_app</Icon>
                            </ListItemIcon>
                            <ListItemText className="pl-0" primary="Logout" />
                        </MenuItem>
                    </React.Fragment>
                )}
            </Popover>
        </React.Fragment>
    );
}

export default UserMenu;

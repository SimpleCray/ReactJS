export function getMenuBpName(pathName) {
    const listUIWithPathParams = ['/location-management', '/biz-rule'];
    let routingPath = pathName;
    // View Result is children of View Doc, get btns from view doc
    if (routingPath.includes('info-extracted')) return '/extract/view-doc';
    listUIWithPathParams.forEach(UIWithPathParams => {
        if (routingPath.includes(UIWithPathParams)) {
            routingPath = UIWithPathParams;
        }
    });
    return routingPath;
}

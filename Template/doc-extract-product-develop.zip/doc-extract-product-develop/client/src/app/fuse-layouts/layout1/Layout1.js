import React, { useContext, useEffect, useState } from 'react';
import { renderRoutes } from 'react-router-config';
import { FuseScrollbars, FuseMessage, FuseDialog, FuseSuspense } from '@fuse';
import { makeStyles } from '@material-ui/styles';
import { useSelector, useDispatch } from 'react-redux';
import SettingsPanel from 'app/fuse-layouts/shared-components/SettingsPanel';
import clsx from 'clsx';
import AppContext from 'app/AppContext';
import { API_EP } from 'app/utils/commonAPI';
import * as Actions from 'app/store/actions';
import EndPointAPI from 'app/utils/endPointAPI';
import 'styles/scss/commons.scss';
import ToolbarLayout1 from './components/ToolbarLayout1';
import LeftSideLayout1 from './components/LeftSideLayout1';
import NavbarWrapperLayout1 from './components/NavbarWrapperLayout1';
import { getMenuBpName } from './Layout1Function';
import AppConstants from 'app/utils/appConstants';

const useStyles = makeStyles(theme => ({
    root: {
        position: 'relative',
        display: 'flex',
        flexDirection: 'row',
        width: '100%',
        height: '100%',
        overflow: 'hidden',
        backgroundColor: theme.palette.background.default,
        color: theme.palette.text.primary,
        '&.boxed': {
            maxWidth: 1280,
            margin: '0 auto',
            boxShadow: theme.shadows[3],
        },
        '&.scroll-body': {
            '& $wrapper': {
                height: 'auto',
                flex: '0 0 auto',
                overflow: 'auto',
            },
            '& $contentWrapper': {},
            '& $content': {},
        },
        '&.scroll-content': {
            '& $wrapper': {},
            '& $contentWrapper': {},
            '& $content': {},
        },
        '& .navigation': {
            '& .list-subheader-text, & .list-item-text, & .item-badge, & .arrow-icon': {
                transition: theme.transitions.create('opacity', {
                    duration: theme.transitions.duration.shortest,
                    easing: theme.transitions.easing.easeInOut,
                }),
            },
        },
    },
    wrapper: {
        display: 'flex',
        position: 'relative',
        width: '100%',
        height: '100%',
        flex: '1 1 auto',
    },
    contentWrapper: {
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        zIndex: 3,
        overflow: 'hidden',
        flex: '1 1 auto',
    },
    content: {
        position: 'relative',
        display: 'flex',
        overflow: 'auto',
        flex: '1 1 auto',
        flexDirection: 'column',
        width: '100%',
        '-webkit-overflow-scrolling': 'touch',
        zIndex: 2,
    },
}));

function buildMenuData(menuData, parentId) {
    const output = [];
    for (const menu of menuData) {
        if (menu.prntId === parentId) {
            const data = buildMenuData(menuData, menu.mnuPgmId);

            const menuObject = {
                id: menu.mnuPgmId,
                title: menu.mnuPgmNm,
                icon: menu.mnuIco,
                children: data.length > 0 ? data : undefined,
                url: menu.mnuPgmUrl,
                type: data.length > 0 ? 'collapse' : 'item',
            };

            output.push(menuObject);
        }
    }
    return output;
}

function Layout1(props) {
    const config = useSelector(({ fuse }) => fuse.settings.current.layout.config);
    const appContext = useContext(AppContext);
    const classes = useStyles(props);

    const { routes, getRoutingByRole } = appContext;
    const dispatch = useDispatch();
    const [routesByRole, setRoutesByRole] = useState(routes);

    // console.warn('FuseLayout:: rendered');
    // get menu data from BP
    useEffect(() => {
        if (localStorage.getItem(AppConstants.BP_USER_INFO)) {
            API_EP.get(EndPointAPI.ENDPOINT.BP.GET_MENU)
                .then(response => {
                    const menuData = response.data.data.menuList;
                    const navigationData = buildMenuData(menuData, '0');
                    const routing = getRoutingByRole(navigationData[0].children);
                    setRoutesByRole(routing);
                    dispatch(Actions.setNavigation(navigationData[0].children));
                })
                .catch(err => {
                    Actions.showMessage({
                        message: err, // text or html
                        variant: 'error', // success error info warning null
                    });
                });
            // The sub location menu page is not defined in BP, so we just get btn list from parent menu
            const routingPath = getMenuBpName(window.location.pathname);
            API_EP.post(EndPointAPI.ENDPOINT.BP.GET_BTN, { mnuPgmId: routingPath }).then(res => {
                dispatch(Actions.getButtonAuth(res.data.data));
            });
        }
    }, [window.location.href]);

    switch (config.scroll) {
        case 'body': {
            return (
                <div id="fuse-layout" className={clsx(classes.root, config.mode, `scroll-${config.scroll}`)}>
                    {config.leftSidePanel.display && <LeftSideLayout1 />}

                    <div className="flex flex-1 flex-col overflow-hidden relative">
                        {config.toolbar.display &&
                            config.toolbar.style === 'fixed' &&
                            config.toolbar.position === 'above' && <ToolbarLayout1 />}

                        <FuseScrollbars className="overflow-auto" scrollToTopOnChildChange>
                            {config.toolbar.display &&
                                config.toolbar.style !== 'fixed' &&
                                config.toolbar.position === 'above' && <ToolbarLayout1 />}

                            <div className={classes.wrapper}>
                                {config.navbar.display && config.navbar.position === 'left' && <NavbarWrapperLayout1 />}

                                <div className={classes.contentWrapper}>
                                    {config.toolbar.display && config.toolbar.position === 'below' && (
                                        <ToolbarLayout1 />
                                    )}

                                    <div className={classes.content}>
                                        <FuseDialog />
                                        <FuseSuspense>{renderRoutes(routesByRole)}</FuseSuspense>

                                        {props.children}
                                    </div>
                                    {/* <SettingsPanel /> */}
                                </div>

                                {config.navbar.display && config.navbar.position === 'right' && (
                                    <NavbarWrapperLayout1 />
                                )}
                            </div>
                        </FuseScrollbars>
                    </div>

                    <FuseMessage />
                </div>
            );
        }
        case 'content':
        default: {
            return (
                <div id="fuse-layout" className={clsx(classes.root, config.mode, `scroll-${config.scroll}`)}>
                    {config.leftSidePanel.display && <LeftSideLayout1 />}

                    <div className="flex flex-1 flex-col overflow-hidden relative">
                        {config.toolbar.display && config.toolbar.position === 'above' && <ToolbarLayout1 />}

                        <div className={classes.wrapper}>
                            {config.navbar.display && config.navbar.position === 'left' && <NavbarWrapperLayout1 />}

                            <div className={classes.contentWrapper}>
                                {config.toolbar.display &&
                                    config.toolbar.position === 'below' &&
                                    config.toolbar.style === 'fixed' && <ToolbarLayout1 />}

                                <FuseScrollbars className={classes.content} scrollToTopOnChildChange>
                                    {config.toolbar.display &&
                                        config.toolbar.position === 'below' &&
                                        config.toolbar.style !== 'fixed' && <ToolbarLayout1 />}

                                    <FuseDialog />

                                    <FuseSuspense>{renderRoutes(routesByRole)}</FuseSuspense>

                                    {props.children}
                                </FuseScrollbars>
                            </div>

                            {config.navbar.display && config.navbar.position === 'right' && <NavbarWrapperLayout1 />}
                        </div>
                    </div>

                    <FuseMessage />
                </div>
            );
        }
    }
}

export default Layout1;

import React from 'react';
import { AppBar, Hidden, Toolbar, Typography } from '@material-ui/core';
import { makeStyles, ThemeProvider } from '@material-ui/styles';
import NavbarMobileToggleButton from 'app/fuse-layouts/shared-components/NavbarMobileToggleButton';
import UserMenu from 'app/fuse-layouts/shared-components/UserMenu';
import { useSelector } from 'react-redux';

const useStyles = makeStyles(theme => ({
    separator: {
        width: 1,
        height: 52,
        backgroundColor: theme.palette.divider,
    },
    pageTitle: {
        left: 10,
        top: 16,
        position: 'absolute',
    },
}));

function ToolbarLayout1(props) {
    const config = useSelector(({ fuse }) => fuse.settings.current.layout.config);
    const toolbarTheme = useSelector(({ fuse }) => fuse.settings.toolbarTheme);

    const classes = useStyles(props);

    // Get Navigation List
    const navigations = useSelector(({ fuse }) => fuse.navigation);
    let pageName = '';
    const { location } = window;
    // Found in navigations to show Page Title
    navigations.forEach(page => {
        // Have sub menus
        if (page.children) {
            page.children.forEach(subPage => {
                if (subPage.url === location.pathname) {
                    pageName = subPage.title;
                }
            });
        } else if (page.url === location.pathname) {
            pageName = page.title;
        }
    });

    return (
        <ThemeProvider theme={toolbarTheme}>
            <AppBar id="fuse-toolbar" className="flex relative z-10 h-52" color="default">
                <Toolbar className="p-0" variant="dense">
                    {config.navbar.display && config.navbar.position === 'left' && (
                        <Hidden lgUp>
                            <NavbarMobileToggleButton className="w-52 h-52 p-0" />
                            <div className={classes.separator} />
                        </Hidden>
                    )}

                    <div className="flex flex-1">
                        {/* <Hidden mdDown>
                            <FuseShortcuts className="px-16"/>
                        </Hidden> */}
                    </div>

                    <div className="flex">
                        <Hidden lgUp>
                            <Typography
                                component="span"
                                className={`normal-case h3 font-600 absolute ${classes.pageTitle} ml-64`}
                            >
                                {pageName || ''}
                            </Typography>
                        </Hidden>
                        <Hidden mdDown>
                            <Typography
                                component="span"
                                className={`normal-case h3 font-600 absolute ${classes.pageTitle}`}
                            >
                                {pageName || ''}
                            </Typography>
                        </Hidden>
                        <UserMenu />

                        <div className={classes.separator} />

                        {/* <Hidden lgUp>

                            <div className={classes.separator}/>

                            <ChatPanelToggleButton/>
                        </Hidden> */}
                        <div className={classes.separator} />

                        {/* <QuickPanelToggleButton/> */}
                    </div>

                    {config.navbar.display && config.navbar.position === 'right' && (
                        <Hidden lgUp>
                            <NavbarMobileToggleButton />
                        </Hidden>
                    )}
                </Toolbar>
            </AppBar>
        </ThemeProvider>
    );
}

export default ToolbarLayout1;

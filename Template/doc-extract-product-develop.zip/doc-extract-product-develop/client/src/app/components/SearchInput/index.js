import React from 'react';
import Input from '@material-ui/core/Input';
import { withStyles } from '@material-ui/core/styles';

const styles = () => ({
    // Custom style for Custom SearchInput will be defined inside of root
    root: {
        margin: '0 6px 0 6px',
        background: '#FFF',
        borderRadius: '3px',
        color: '#000',
    },
});

/**
 * Usage:
 * import SearchInput from "app/components/SearchInput";
 * <SearchInput color="secondary">Custom using Secondary color</SearchInput>
 * <SearchInput className={classes.classCssName}>Custom using new classes</SearchInput>
 * <SearchInput onChange={...} placeholder="...">
 * Just need to add new custom props to SearchInput
 * @param {*} props
 */
const CustomSearchInput = props => <Input size="small" variant="outlined" {...props} />;

export default withStyles(styles)(CustomSearchInput);

import * as Actions from 'app/store/actions';
import { API_EP } from 'app/utils/commonAPI';
import { setUserData } from './user.actions';
import AppConstants from 'app/utils/appConstants';
import EndPointAPI from 'app/utils/endPointAPI';

export const LOGIN_ERROR = 'LOGIN_ERROR';
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';

export function loginWithBP(token, isEncrypted) {
    return dispatch =>
        API_EP.post(EndPointAPI.ENDPOINT.BP.BP_LOGIN_DECRYPT, { token, isEncrypted })
            .then(result => {
                const { data } = result;
                data.usrInfo.imgUrl = data.usrInfo.imgUrl.replace(/\\/g, '/');
                localStorage.clear();
                localStorage.setItem(AppConstants.BP_USER_INFO, JSON.stringify(data.usrInfo));
                localStorage.setItem(AppConstants.BP_USER_ROLE_NM, data.usrRoleNm);
                localStorage.setItem(AppConstants.BP_TOKEN_NAME, data.token);
                localStorage.setItem(AppConstants.BP_USER_ID, data.usrInfo.usrId);
                return dispatch({
                    type: LOGIN_SUCCESS,
                });
            })
            .catch(error => {
                localStorage.clear();
                return dispatch({
                    type: LOGIN_ERROR,
                    payload: error,
                });
            });
}

import history from '@history';
import { setDefaultSettings, setInitialSettings } from 'app/store/actions/fuse';
import _ from '@lodash';
import store from 'app/store';
import * as Actions from 'app/store/actions';
import { API_EP } from 'app/utils/commonAPI';
import AppConstants from 'app/utils/appConstants';
import EndPointAPI from 'app/utils/endPointAPI';

export const SET_USER_DATA = '[USER] SET DATA';
export const REMOVE_USER_DATA = '[USER] REMOVE DATA';
export const USER_LOGGED_OUT = '[USER] LOGGED OUT';

export const GET_USER_INFO = 'GET_USER_INFO';
export const OPEN_PROFILE_DIALOG = 'OPEN_PROFILE_DIALOG';
export const CLOSE_PROFILE_DIALOG = 'CLOSE_PROFILE_DIALOG';

export function getUserInfo() {
    const request = API_EP.get(EndPointAPI.ENDPOINT.BP.GET_USER_INFO);
    return dispatch =>
        request
            .then(response => {
                // Update the localStorage with new Data
                const userInfoData = response.data.data.usrInfo;
                userInfoData.imgUrl = userInfoData.imgUrl.replace(/\\/g, '/');
                localStorage.setItem(AppConstants.BP_USER_INFO, JSON.stringify(userInfoData));
                localStorage.setItem(AppConstants.BP_USER_ID, userInfoData.usrId);
                return dispatch({
                    type: GET_USER_INFO,
                    payload: response.data,
                });
            })
            .catch(err => {
                console.log('error', err);
            });
}

export function openProfileDialog(data) {
    return {
        type: OPEN_PROFILE_DIALOG,
        data: localStorage.getItem(AppConstants.BP_USER_INFO)
            ? JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO))
            : data,
    };
}

export function closeProfileDialog() {
    return {
        type: CLOSE_PROFILE_DIALOG,
    };
}

/**
 * Set user data from Auth0 token data
 */
export function setUserDataAuth0(tokenData) {
    const user = {
        role: ['admin'],
        from: 'auth0',
        data: {
            displayName: tokenData.username,
            photoURL: tokenData.picture,
            email: tokenData.email,
            settings:
                tokenData.user_metadata && tokenData.user_metadata.settings ? tokenData.user_metadata.settings : {},
            shortcuts:
                tokenData.user_metadata && tokenData.user_metadata.shortcuts ? tokenData.user_metadata.shortcuts : [],
        },
    };

    return setUserData(user);
}

/**
 * Set User Data
 */
export function setUserData(user) {
    return dispatch => {
        /*
        Set User Settings
         */
        dispatch(setDefaultSettings(user.data.settings));

        /*
        Set User Data
         */
        dispatch({
            type: SET_USER_DATA,
            payload: user,
        });
    };
}

/**
 * Update User Settings
 */
export function updateUserSettings(settings) {
    return (dispatch, getState) => {
        const oldUser = getState().auth.user;
        const user = _.merge({}, oldUser, { data: { settings } });

        updateUserData(user);

        return dispatch(setUserData(user));
    };
}

/**
 * Update User Shortcuts
 */
export function updateUserShortcuts(shortcuts) {
    return (dispatch, getState) => {
        const { user } = getState().auth;
        const newUser = {
            ...user,
            data: {
                ...user.data,
                shortcuts,
            },
        };

        updateUserData(newUser);

        return dispatch(setUserData(newUser));
    };
}

/**
 * Remove User Data
 */
export function removeUserData() {
    return {
        type: REMOVE_USER_DATA,
    };
}

/**
 * Logout
 */
export function logoutUser() {
    return (dispatch, getState) => {
        const { user } = getState().auth;

        if (!user.role || user.role.length === 0) {
            // is guest
            return null;
        }

        localStorage.clear();

        history.push({
            pathname: '/',
        });

        dispatch(setInitialSettings());

        dispatch({
            type: USER_LOGGED_OUT,
        });
    };
}

/**
 * Update User Data
 */
function updateUserData(user) {
    if (!user.role || user.role.length === 0) {
        // is guest
        return;
    }
}

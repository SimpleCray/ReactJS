import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as userActions from 'app/components/auth/store/actions';
import { bindActionCreators } from 'redux';
import * as Actions from 'app/store/actions';
import history from '@history';
import AppConstants from 'app/utils/appConstants';
import qs from 'qs';
class Auth extends Component {
    /* eslint-disable-next-line no-useless-constructor */
    constructor(props) {
        super(props);

        // Check for BluePrint userInfo
        this.userInfoCheck();
    }

    userInfoCheck = () => {
        const queryParams = qs.parse(window.location.href.split('?')[1], { ignoreQueryPrefix: true });
        if (
            !localStorage.getItem(AppConstants.BP_USER_INFO) &&
            !queryParams.hasOwnProperty(AppConstants.BP_TOKEN_PATTERN)
        ) {
            // logoutShine();
            history.push('/login');
        }
    };

    render() {
        const { children } = this.props;
        return <React.Fragment>{children}</React.Fragment>;
    }
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(
        {
            logout: userActions.logoutUser,
            setUserData: userActions.setUserData,
            setUserDataAuth0: userActions.setUserDataAuth0,
            getUserInfo: userActions.getUserInfo,
            showMessage: Actions.showMessage,
            hideMessage: Actions.hideMessage,
        },
        dispatch,
    );
}

export default connect(
    null,
    mapDispatchToProps,
)(Auth);

import React from 'react';
import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';

const styles = () => ({
    // Custom style for Custom Button will be defined inside of root
    root: {
        margin: 3,
    },
});

/**
 * Usage:
 * import Button from "app/components/Button";
 * <Button color="secondary">Custom using Secondary color</Button>
 * <Button className={classes.classCssName}>Custom using new classes</Button>
 * <Button onClick={...}>
 * Just need to add new custom props to Button
 * @param {*} props
 */
const CustomButton = props => <Button size="small" variant="contained" color="primary" {...props} />;

export default withStyles(styles)(CustomButton);

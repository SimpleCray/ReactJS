import React from 'react';
import TextField from '@material-ui/core/TextField';
import { withStyles } from '@material-ui/core/styles';

const styles = () => ({
    // Custom style for Custom SearchTextField will be defined inside of root
    root: {
        margin: 3,
        '& MuiOutlinedInput': {
            borderColor: 'white',
            border: '1px',
        },
        '& label': {
            color: 'white',
        },
        '& label.Mui-focused': {
            color: 'white',
        },
        '& .MuiInput-underline:after': {
            borderBottomColor: 'white',
        },

        minWidth: '20ch',
    },
});

/**
 * Usage:
 * import SearchTextField from "app/components/SearchTextField";
 * <SearchTextField color="secondary">Custom using Secondary color</SearchTextField>
 * <SearchTextField className={classes.classCssName}>Custom using new classes</SearchTextField>
 * <SearchTextField helperText={...}>
 * Just need to add new custom props to SearchTextField
 * @param {*} props
 */
const SearchTextField = props => <TextField size="small" variant="outlined" {...props} />;

export default withStyles(styles)(SearchTextField);

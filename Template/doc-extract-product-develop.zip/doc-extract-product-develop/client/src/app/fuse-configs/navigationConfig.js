import { authRoles } from 'app/components/auth';

const navigationConfig = [
    {
        id: 'dashboard',
        title: 'DashBoard',
        type: 'item',
        // 'auth': authRoles.admin, // Use auth with role to hide/show menu sidebar
        icon: 'dashboard',
        url: '/dashboard',
    },
    {
        id: 'docSetup',
        title: 'Document Settings',
        type: 'collapse',
        icon: 'assignment_returned',
        children: [
            {
                id: 'defineDocType',
                title: 'Define Document Type',
                type: 'item',
                icon: 'chrome_reader_mode',
                url: '/doc/setup-doc-type',
            },
            {
                id: 'setupComDoc',
                title: 'Setup Company Document',
                type: 'item',
                icon: 'kitchen',
                url: '/doc/setup-com-doc',
            },
            {
                id: 'setupTemplate',
                title: 'Setup Template',
                type: 'item',
                icon: 'filter_none',
                url: '/doc/setup-template',
            },
            {
                id: 'setupSRule',
                title: 'Setup Special Rule',
                type: 'item',
                icon: 'rule_folder',
                url: '/doc/setup-special-rule',
            },
        ],
    },
    {
        id: 'extractInf',
        title: 'Extraction Information',
        type: 'collapse',
        icon: 'ballot',
        children: [
            {
                id: 'viewDoc',
                title: 'View Documents',
                type: 'item',
                icon: 'chrome_reader_mode',
                url: '/extract/view-doc',
            },
            {
                id: 'viewAnnotation',
                title: 'Annotation',
                type: 'item',
                icon: 'kitchen',
                url: '/extract/view-annotation',
            },
            {
                id: 'setupTemplate',
                title: 'View Results',
                type: 'item',
                icon: 'filter_none',
                url: '/extract/view-extracted-result',
            },
        ],
    },
];

export default navigationConfig;

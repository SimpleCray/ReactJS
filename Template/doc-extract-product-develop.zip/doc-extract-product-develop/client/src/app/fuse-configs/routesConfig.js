import React from 'react';
import { Redirect } from 'react-router-dom';
import { FuseUtils } from '@fuse/index';
import { pagesConfigs } from 'app/main/pages/pagesConfigs';
import { LogoutConfig } from 'app/main/logout/LogoutConfig';
import AppConstants from 'app/utils/appConstants';

const customLayoutLoginLayout = {
    layout: {
        config: {
            navbar: {
                display: false,
            },
            toolbar: {
                display: false,
            },
            footer: {
                display: false,
            },
            leftSidePanel: {
                display: false,
            },
            rightSidePanel: {
                display: false,
            },
        },
    },
};

const BPRedirectRoute = [
    {
        routes: [
            {
                path: '/blueprint-redirect',
                component: React.lazy(() => import('app/pages/BPRedirect/BPRedirect')),
            },
        ],
    },
];

const CustomLoginRoute = [
    {
        settings: customLayoutLoginLayout,
        routes: [
            {
                path: '/login',
                component: React.lazy(() => import('app/pages/login/Login')),
            },
        ],
    },
];

const MainDashBoardRoute = [
    {
        routes: [
            {
                path: '/dashboard',
                component: React.lazy(() => import('app/pages/dashboard/DashBoard')),
            },
        ],
    },
];

const SetupDocTypeRoute = [
    {
        routes: [
            {
                path: '/doc/setup-doc-type',
                component: React.lazy(() => import('app/pages/document/DocumentPage')),
            },
        ],
    },
];

const SetupComDocRoute = [
    {
        routes: [
            {
                path: '/doc/setup-com-doc',
                component: React.lazy(() => import('app/pages/setupComDoc')),
            },
        ],
    },
];

const SetupTemplateRoute = [
    {
        routes: [
            {
                path: '/doc/setup-template',
                component: React.lazy(() => import('app/main/pages/coming-soon/ComingSoonPage')),
            },
        ],
    },
];

const ViewDocRoute = [
    {
        routes: [
            {
                path: '/info-extracted/:id',
                component: React.lazy(() => import('app/pages/InfoExtracted')),
            },
        ],
    },
];

const ViewExtracteduRoute = [
    {
        routes: [
            {
                path: AppConstants.VIEW_DOC_URL,
                component: React.lazy(() => import('app/pages/viewDoc')),
            },
        ],
    },
];

const TemplateManagement = [
    {
        routes: [
            {
                path: AppConstants.TEMPLATE_MANAGEMENT,
                component: React.lazy(() => import('app/pages/template-management')),
            },
        ],
    },
];

const ViewAnnotationRoute = [
    {
        routes: [
            {
                path: '/extract/view-annotation',
                component: React.lazy(() => import('app/main/pages/coming-soon/ComingSoonPage')),
            },
        ],
    },
];

const AnnotationRoute = [
    {
        routes: [
            {
                path: '/extract/annotation/:template_type/:template_id',
                component: React.lazy(() => import('app/pages/Annotate')),
            },
        ],
    },
];

const ViewExtractedResultRoute = [
    {
        routes: [
            {
                path: '/extract/view-extracted-result',
                component: React.lazy(() => import('app/main/pages/coming-soon/ComingSoonPage')),
            },
        ],
    },
];

const SplitDoc = [
    {
        routes: [
            {
                path: '/extract/view-doc/multi-doc',
                component: React.lazy(() => import('app/pages/viewDoc/splitDoc/MainSplitDoc')),
            },
        ],
    },
];

const SetupBizRule = [
    {
        routes: [
            {
                path: '/biz-rule',
                component: React.lazy(() => import('app/pages/BizRule/ruleField/MainRuleField')),
            },
        ],
    },
];

const SetupBizRuleAction = [
    {
        routes: [
            {
                path: '/biz-rule/:typePage/:bizRuleId?',
                component: React.lazy(() => import('app/pages/BizRule/bizRule/MainBizRule')),
            },
        ],
    },
];

const CommonDataRoute = [
    {
        routes: [
            {
                path: '/common-data',
                component: React.lazy(() => import('app/pages/CommonData/commonData')),
            },
        ],
    },
];

const SetupSRuleRoute = [
    {
        routes: [
            {
                path: '/doc/setup-special-rule',
                component: React.lazy(() => import('app/pages/specialRule/SetupSRule')),
            },
        ],
    },
];

const LocationManagementDetailRoute = [
    {
        routes: [
            {
                path: '/location-management/:locationId?/:typePage',
                component: React.lazy(() => import('app/pages/location-management/LocationDetail')),
            },
        ],
    },
];

const LocationManagementPagingRoute = [
    {
        routes: [
            {
                path: '/location-management',
                component: React.lazy(() => import('app/pages/location-management/Locations')),
            },
        ],
    },
];

const DynamicTypeRoute = [
    {
        routes: [
            {
                path: '/doc/setup-dynamic-type',
                component: React.lazy(() => import('app/pages/DynamicType')),
            },
        ],
    },
];

const ExtractionRuleRoute = [
    {
        routes: [
            {
                path: '/doc/extraction-rule',
                component: React.lazy(() => import('app/pages/ExtractionRule')),
            },
        ],
    },
];

const OpenBluePrint = [
    {
        routes: [
            {
                path: '/opn-blueprint',
                component: () => {
                    window.open(process.env.REACT_APP_BP, '_blank');
                    return <Redirect to={AppConstants.VIEW_DOC_URL} />;
                },
            },
        ],
    },
];

const routeConfigs = [
    ...CustomLoginRoute,
    ...BPRedirectRoute,
    ...MainDashBoardRoute,
    ...SetupDocTypeRoute,
    ...SetupComDocRoute,
    ...SetupTemplateRoute,
    ...SplitDoc,
    ...ViewDocRoute,
    ...TemplateManagement,
    ...AnnotationRoute,
    ...ViewAnnotationRoute,
    ...ViewExtracteduRoute,
    ...ViewExtractedResultRoute,
    ...SetupBizRuleAction,
    ...SetupBizRule,
    ...LocationManagementDetailRoute,
    ...LocationManagementPagingRoute,
    ...pagesConfigs,
    ...CommonDataRoute,
    ...SetupSRuleRoute,
    ...DynamicTypeRoute,
    ...ExtractionRuleRoute,
    ...OpenBluePrint,
    LogoutConfig,
];

// Get list of paths from BP's menu
const getURLs = menu => {
    let urls = [];
    menu.map(page => {
        if (page.url) urls.push(page.url);
        if (page.children) {
            const pathList = getURLs(page.children);
            urls = [...urls, ...pathList];
        }
    });
    return urls;
};

export const getRoutingByRole = menuList => {
    // Add common default routing for all roles
    const routeByRoles = [
        ...CustomLoginRoute,
        ...BPRedirectRoute,
        ...pagesConfigs,
        ...ViewDocRoute, // - info-extracted
        ...AnnotationRoute, // - extract/annotation
        ...ViewAnnotationRoute, // - extract/view-annotation
        ...ViewExtractedResultRoute, // - extract/view-extracted-result
        LogoutConfig,
    ];
    // Add specific routes for each role based on BP's menu
    if (menuList.length > 0) {
        const urls = getURLs(menuList);
        routeByRoles.push(...routeConfigs.filter(item => urls.some(el => item.routes[0].path.includes(el))));
    }
    // Return new routes
    return [
        ...FuseUtils.generateRoutesFromConfigs(routeByRoles),
        {
            component: () => <Redirect to={AppConstants.VIEW_DOC_URL} />,
        },
    ];
};

export const routes = [
    ...FuseUtils.generateRoutesFromConfigs(routeConfigs),
    {
        path: '/',
        exact: true,
        component: () => <Redirect to={AppConstants.VIEW_DOC_URL} />,
    },
    {
        component: () => <Redirect to="/pages/errors/error-404" />,
    },
];

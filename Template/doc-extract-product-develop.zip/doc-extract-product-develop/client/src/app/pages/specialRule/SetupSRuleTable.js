import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { useDispatch, useSelector } from 'react-redux';
import _ from '@lodash';
import { Table, TableBody, TableCell, TableRow, TablePagination, TableSortLabel, TableHead } from '@material-ui/core';
import { FuseAnimate } from '@fuse';
import buttons from 'app/utils/constants/buttonConstants.json';
import { showMessage } from 'app/store/actions/fuse';
import Button from '../../components/Button/index';
import * as TableFnc from 'app/utils/tableFunctions';
import * as Actions from './store/actions';

const columns = [
    {
        id: 'rule_nm',
        label: 'Rule Name',
        width: '30%',
        align: 'left',
        format: value => value.toLocaleString('en-US'),
        sort: true,
    },
    {
        id: 'rule_tp_val',
        label: 'Rule Type',
        width: '30%',
        align: 'left',
        format: value => value.toLocaleString('en-US'),
        sort: true,
    },
    {
        id: 'rule_desc',
        label: 'Description',
        width: '40%',
        align: 'left',
        format: value => value.toFixed(2),
        sort: true,
    },
];
const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    container: {
        maxHeight: 440,
    },
    cellHead: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
    button: {
        margin: theme.spacing(1),
    },
}));

export default function StickyHeadTable() {
    const classes = useStyles();
    const dispatch = useDispatch();
    const searchList = useSelector(({ specialRule }) => specialRule.specialRule.searchList);
    const rowSelected = useSelector(({ specialRule }) => specialRule.specialRule.rowSelected);
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const modifyFlg = useSelector(({ specialRule }) => specialRule.specialRule.modifyFlg);
    const selectedDefault = useSelector(({ specialRule }) => specialRule.specialRule.selectedDefault);
    const formSearch = useSelector(({ specialRule }) => specialRule.specialRule.formSearch);

    const page = useSelector(({ specialRule }) => specialRule.specialRule.page);
    const [rowsPerPage, setRowsPerPage] = React.useState(25);
    const [rows, setRows] = useState(searchList);
    const [order, setOrder] = useState({
        direction: 'asc',
        id: 'rule_id',
    });

    useEffect(() => {
        if (searchList.length > 0 && selectedDefault) {
            dispatch(Actions.setRowSelected(searchList[0]));
            dispatch(Actions.setModifyFlg('edit'));
            dispatch(Actions.setDisableBtnSave(false));
            dispatch(Actions.setSelectDefault(false));
        }
    }, [searchList]);
    useEffect(() => {
        setRows(searchList);
    }, [dispatch, searchList, modifyFlg]);

    function handleClick(row) {
        dispatch(Actions.setRowSelected(row));
        dispatch(Actions.setModifyFlg('edit'));
        dispatch(Actions.setDisableBtnSave(false));
    }

    const handleCreate = () => {
        dispatch(Actions.setModifyFlg('new'));
        dispatch(Actions.setRowSelected(''));
        dispatch(Actions.setDisableBtnSave(false));
    };
    const handleDelete = async () => {
        await dispatch(Actions.delRule(rowSelected.rule_id));
        await dispatch(Actions.setRowSelected(''));
        await dispatch(Actions.searchRule(formSearch));
        await dispatch(Actions.setModifyFlg(''));
        dispatch(
            showMessage({
                message: 'Delete Successfully!', // text or html
                autoHideDuration: 2000, // ms
                anchorOrigin: {
                    vertical: 'top', // top bottom
                    horizontal: 'center', // left center right
                },
                variant: 'success', // success error info warning null
            }),
        );
    };

    const createSortHandler = property => () => {
        const id = property;
        let direction = 'desc';

        if (order.id === property && order.direction === 'desc') {
            direction = 'asc';
        }

        setOrder({
            direction,
            id,
        });
    };
    return (
        <FuseAnimate animation="transition.slideUpIn" delay={300}>
            <div className="w-9/12 flex flex-col border-2 p-1 mb-2 mt-2 mr-1">
                <div className="flex-grow overflow-x-auto">
                    <Table stickyHeader aria-label="sticky table" size="small" className="w-full">
                        <TableHead>
                            <TableRow>
                                {columns.map(column => (
                                    <TableCell
                                        component="th"
                                        key={column.id}
                                        align={column.align}
                                        style={{ maxWidth: column.maxWidth, width: column.width }}
                                        className={classes.cellHead}
                                        sortDirection={order.id === column.id ? order.direction : false}
                                    >
                                        <TableSortLabel
                                            direction={order.direction}
                                            onClick={createSortHandler(column.id)}
                                        >
                                            {column.label}
                                        </TableSortLabel>
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {
                                _.orderBy(rows, [
                                    (o) => {
                                        switch (order.id) {
                                            case 'rule_nm':
                                                {
                                                    return o.rule_nm;
                                                }
                                            case 'rule_tp_val':
                                                {
                                                    return o.rule_tp_val;
                                                }
                                            case 'rule_desc':
                                                {
                                                    return o.rule_desc;
                                                }
                                            default:
                                                {
                                                    return o[order.id];
                                                }
                                        }
                                    }
                                ], [order.direction])
                                    .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                .map(row => {
                                    const isItemSelected = rowSelected.rule_id === row.rule_id;
                                    return (
                                        <TableRow
                                            hover
                                            role="checkbox"
                                            tabIndex={-1}
                                            key={row.rule_id}
                                            aria-checked={isItemSelected}
                                            selected={isItemSelected}
                                            onClick={() => handleClick(row)}
                                        >
                                            {columns.map(column => {
                                                const value =
                                                    row[column.id] !== null && row[column.id] !== ''
                                                        ? row[column.id].length > 31
                                                            ? column.id === 'rule_desc'
                                                                ? row[column.id].substr(0, 70) + '.....'
                                                                : row[column.id].substr(0, 30) + '.....'
                                                            : row[column.id]
                                                        : '';
                                                return (
                                                    <TableCell key={column.id} align={column.align}>
                                                        {column.format && typeof value === 'number'
                                                            ? column.format(value)
                                                            : value}
                                                    </TableCell>
                                                );
                                            })}
                                        </TableRow>
                                    );
                                })}
                        </TableBody>
                    </Table>
                </div>
                <div>
                    <TablePagination
                        rowsPerPageOptions={[10, 25, 50]}
                        component="div"
                        count={rows.length}
                        rowsPerPage={rowsPerPage}
                        page={page}
                        onChangePage={(event, page) => dispatch(Actions.setPage(page))}
                        onChangeRowsPerPage={ev =>
                            TableFnc.handleChangeRowsPerPage(
                                ev,
                                page,
                                rows,
                                pageNumber => dispatch(Actions.setPage(pageNumber)),
                                setRowsPerPage,
                            )
                        }
                        labelRowsPerPage=""
                        className="float-left"
                    />
                    <div className="flex flex-row pb-2 pl-2 float-right">
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_ADD) && (
                            <Button
                                size="small"
                                variant="contained"
                                color="primary"
                                disabled={modifyFlg === 'new'}
                                onClick={handleCreate}
                            >
                                NEW
                            </Button>
                        )}
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_DELETE) && (
                            <Button
                                size="small"
                                variant="contained"
                                color="primary"
                                disabled={modifyFlg === '' || modifyFlg === 'new'}
                                onClick={handleDelete}
                            >
                                DELETE
                            </Button>
                        )}
                    </div>
                </div>
            </div>
        </FuseAnimate>
    );
}

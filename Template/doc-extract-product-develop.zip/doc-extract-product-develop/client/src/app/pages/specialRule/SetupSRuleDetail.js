import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { useForm } from '@fuse/hooks';
import { useDispatch, useSelector } from 'react-redux';
import { TextField, MenuItem } from '@material-ui/core';
import buttons from 'app/utils/constants/buttonConstants.json';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import { showMessage } from 'app/store/actions/fuse';
import Modal from '@material-ui/core/Modal';
import Autocomplete from '@material-ui/lab/Autocomplete';
import Button from '../../components/Button/index';
import * as Actions from './store/actions';

const baseUrl = `${process.env.REACT_APP_DOC_LOC}/images/`;
const formDefault = { ruleName: '', ruleType: '' };
const ref = React.createRef();
const inputFocus = React.createRef();

const useStyles = makeStyles(theme => ({
    root: {
        margin: theme.spacing(2),
        textAlign: 'center',
    },
    upload: {
        '& > *': {
            margin: theme.spacing(1),
        },
        textAlign: 'center',
    },
    inputUpload: {
        display: 'none',
    },
    bottom: {
        display: 'flex',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
    },
    paper: {
        position: 'absolute',
        backgroundColor: theme.palette.background.paper,
        border: '2px solid #000',
        boxShadow: theme.shadows[5],
        padding: theme.spacing(2),
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    styleTextField: {
        margin: theme.spacing(2),
        display: 'flex',
        alignItems: 'center',
        marginLeft: theme.spacing(4),
    },
    styleBoxImg: {
        width: '90%',
        height: '255px',
        border: '1px solid #22292f',
        objectFit: 'contain',
        alignSelf: 'center',
    },
    imageContainer: {
        marginBottom: '10px',
        maxHeight: '80vh',
        overflow: 'scroll',
    },
    imageClass: {
        transformOrigin: '0 0',
        minWidth: '80vh',
    },
    buttonClass: {
        padding: '0px 15px 0px 15px',
        margin: '0px 8px 0px 8px',
        fontWeight: 'bold',
        fontSize: '25px',
        background: 'darkgray',
    },
}));

function getModalStyle() {
    const top = 50;
    const left = 50;

    return {
        top: `${top}%`,
        left: `${left}%`,
        transform: `translate(-${top}%, -${left}%)`,
        textAlign: 'center',
    };
}

export default function SetupSRuleTableDetail() {
    const classes = useStyles();
    const dispatch = useDispatch();
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const detailDefault = useSelector(({ specialRule }) => specialRule.specialRule.detailDefault);
    const modifyFlg = useSelector(({ specialRule }) => specialRule.specialRule.modifyFlg);
    const disableBtnSave = useSelector(({ specialRule }) => specialRule.specialRule.disableSave);
    const validateFormDefault = useSelector(({ specialRule }) => specialRule.specialRule.validateForm);
    const rowSelected = useSelector(({ specialRule }) => specialRule.specialRule.rowSelected);
    const documentTypes = useSelector(({ specialRule }) => specialRule.specialRule.documentTypes);
    const { form, setForm, resetForm } = useForm(detailDefault);
    const [validateForm, setValidateForm] = useState(validateFormDefault);
    const [fileData, setFileData] = useState(null);
    const listRuleType = ['Biz Logic', 'Matching Config'];
    const [stateScale, setStateScale] = useState(1);

    useEffect(() => {
        ref.current.value = '';
        if (rowSelected !== '' && modifyFlg === 'edit') {
            setForm(rowSelected);
            const arrDocTp = [];
            let docType = [];
            if (rowSelected.doc_tp_ctnt) {
                docType = JSON.parse(rowSelected.doc_tp_ctnt);
                docType.forEach(item => {
                    arrDocTp.push(item.doc_tp_id);
                });
            }
            const listDocInfo = [];
            documentTypes.forEach(docInfo => {
                if (arrDocTp && arrDocTp.includes(docInfo.doc_tp_id)) {
                    listDocInfo.push(docInfo);
                }
            });
            setForm(form => ({
                ...form,
                doc_tp_ctnt: docType,
                list_doc_info: listDocInfo,
            }));
            setValidateForm(validateFormDefault);
        } else {
            setForm(detailDefault);
            setValidateForm(validateFormDefault);
        }
        setForm(form => ({
            ...form,
            fileChange: '',
            img_url_tmp: '',
            fileInit: `${baseUrl}default.png`,
        }));
    }, [dispatch, rowSelected, modifyFlg]);

    useEffect(() => {
        if (validateForm.approve) {
            dispatch(Actions.setDisableBtnSave(false));
        } else {
            dispatch(Actions.setDisableBtnSave(true));
        }
    }, [dispatch, validateForm]);

    function handleChange(event) {
        event.preventDefault();
        switch (event.target.name) {
            case 'input_file':
                const reader = new FileReader();
                const file = event.target.files[0];
                setFileData(file);
                reader.onloadend = () => {
                    setForm(form => ({
                        ...form,
                        fileChange: reader.result,
                        img_url_tmp: file.name,
                    }));
                };
                reader.readAsDataURL(file);
                break;
            case 'rule_nm':
                setValidateForm(validateForm => ({
                    ...validateForm,
                    rule_nm: {
                        error:
                            event.target.value === '' || event.target.value === null
                                ? true
                                : event.target.value.length > 250,
                        text:
                            event.target.value === '' || event.target.value === null
                                ? 'Can not be empty.'
                                : event.target.value.length > 250
                                ? 'Can not be over 250 characters.'
                                : '',
                    },
                    approve:
                        event.target.value === '' || event.target.value === null
                            ? false
                            : !(event.target.value.length > 250),
                }));
                break;
            case 'rule_tp_val':
                setValidateForm(validateForm => ({
                    ...validateForm,
                    rule_tp_val: {
                        error: event.target.value.length > 20,
                        text: event.target.value.length > 20 ? 'Can not be over 20 characters.' : '',
                    },
                    approve: !(event.target.value.length > 20 || validateForm.rule_nm.error),
                }));
                break;
            case 'rule_desc':
                setValidateForm(validateForm => ({
                    ...validateForm,
                    rule_desc: {
                        error: event.target.value.length > 1000,
                        text: event.target.value.length > 1000 ? 'Can not be over 1000 characters.' : '',
                    },
                    approve: !(
                        event.target.value.length > 1000 ||
                        validateForm.rule_nm.error ||
                        validateForm.rule_tp_val.error
                    ),
                }));
                break;
            default:
                break;
        }
        setForm(form => ({
            ...form,
            [event.target.name]: event.target.value,
        }));
    }

    const onDocTypeChange = (e, value) => {
        const docTp = [];
        value.forEach(element => {
            docTp.push({ doc_tp_id: element.doc_tp_id });
        });
        setForm(form => ({
            ...form,
            doc_tp_ctnt: docTp,
            list_doc_info: value,
        }));
    };

    const handleAfterCreate = form => {
        if (form.rule_nm === null || form.rule_nm === '') {
            setValidateForm(validateForm => ({
                ...validateForm,
                rule_nm: {
                    error: form.rule_nm === '' || form.rule_nm === null ? true : form.rule_nm.length > 250,
                    text:
                        form.rule_nm === '' || form.rule_nm === null
                            ? 'Can not be empty.'
                            : form.rule_nm.length > 250
                            ? 'Can not be over 250 characters.'
                            : '',
                },
                approve: form.rule_nm === '' || form.rule_nm === null ? false : !(form.rule_nm.length > 250),
            }));
            return false;
        }
        return true;
    };

    const handleSave = async () => {
        const formData = new FormData();
        formData.append('myFile', fileData);
        formData.append('cre_dt', form.cre_dt);
        formData.append('delt_flg', form.delt_flg);
        formData.append('img_url', form.img_url);
        formData.append('img_nm', form.img_url_tmp);
        formData.append('rule_desc', form.rule_desc);
        formData.append('rule_id', form.rule_id);
        formData.append('rule_nm', form.rule_nm);
        formData.append('rule_tp_val', form.rule_tp_val);
        formData.append('upd_dt', form.upd_dt);
        formData.append('upd_usr_id', localStorage.getItem('userId_BP'));
        formData.append('doc_tp_ctnt', JSON.stringify(form.doc_tp_ctnt));
        // w);
        // localStorage.getItem('userId_BP')
        if (handleAfterCreate(form)) {
            if (validateForm.approve) {
                switch (modifyFlg) {
                    case 'new':
                        formData.append('cre_usr_id', localStorage.getItem('userId_BP'));
                        await dispatch(Actions.addRule(formData));
                        await dispatch(Actions.searchRule(formDefault));
                        await dispatch(Actions.setModifyFlg(''));
                        await resetForm();
                        break;
                    case 'edit':
                        formData.append('cre_usr_id', form.cre_usr_id);
                        await dispatch(Actions.update(formData));
                        await dispatch(Actions.searchRule(formDefault));
                        break;
                    default:
                        break;
                }
                setFileData(null);
                dispatch(
                    showMessage({
                        message: 'Save Successfully!', // text or html
                        autoHideDuration: 1000, // ms
                        anchorOrigin: {
                            vertical: 'top', // top bottom
                            horizontal: 'center', // left center right
                        },
                        variant: 'success', // success error info warning null
                    }),
                );
            }
        }
    };

    const [modalStyle] = React.useState(getModalStyle);
    const [open, setOpen] = React.useState(false);

    const handleOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setStateScale(1);
        setOpen(false);
    };

    const zoomIn = () => {
        setStateScale(stateScale + 0.1);
    };

    const zoomOut = () => {
        setStateScale(stateScale - 0.1);
    };

    return (
        <form className="w-3/12 border-1 p-1 mb-2 mt-2" noValidate onSubmit={handleSave}>
            <div className="h-full flex-grow overflow-y-auto overflow-x-hidden">
                <div className={classes.styleTextField}>
                    <TextField
                        id="rule_nm"
                        size="small"
                        name="rule_nm"
                        label="Rule name"
                        variant="outlined"
                        inputProps={{ maxLength: 250 }}
                        style={{
                            width: '95%',
                        }}
                        onChange={event => {
                            handleChange(event);
                        }}
                        value={form.rule_nm}
                        disabled={modifyFlg === ''}
                        required={form.rule_nm === '' && (modifyFlg === 'new' || modifyFlg === 'edit')}
                        error={validateForm.rule_nm.error}
                        helperText={validateForm.rule_nm.text}
                        ref={inputFocus}
                    />
                </div>
                <div className={classes.styleTextField}>
                    <TextField
                        id="rule_tp_val"
                        size="small"
                        name="rule_tp_val"
                        label="Rule Type"
                        variant="outlined"
                        inputProps={{ maxLength: 20 }}
                        style={{
                            width: '95%',
                        }}
                        onChange={event => {
                            handleChange(event);
                        }}
                        value={form.rule_tp_val}
                        disabled={modifyFlg === ''}
                        error={validateForm.rule_tp_val.error}
                        helperText={validateForm.rule_tp_val.text}
                        select
                    >
                        {listRuleType.map(rule => (
                            <MenuItem key={rule} value={rule}>
                                {rule}
                            </MenuItem>
                        ))}
                    </TextField>
                </div>
                <div className={classes.upload}>
                    <input
                        accept="*"
                        className={classes.inputUpload}
                        id="input_file"
                        name="input_file"
                        multiple
                        type="file"
                        onChange={event => {
                            handleChange(event);
                        }}
                        disabled={modifyFlg === ''}
                        ref={ref}
                    />
                    <label htmlFor="input_file">
                        <Button
                            variant="contained"
                            color="primary"
                            component="span"
                            size="small"
                            startIcon={<CloudUploadIcon />}
                            disabled={modifyFlg === ''}
                        >
                            Upload
                        </Button>
                    </label>
                </div>
                <div className={classes.root}>
                    <img
                        src={
                            form.fileChange === null || form.fileChange === ''
                                ? form.img_url === null || form.img_url === ''
                                    ? form.fileInit
                                    : form.img_url
                                : form.fileChange
                        }
                        className={classes.styleBoxImg}
                        alt=""
                        onChange={event => {
                            handleChange(event);
                        }}
                        onClick={handleOpen}
                    />
                </div>
                <div className={classes.root}>
                    <Modal open={open} onClose={handleClose}>
                        <div style={modalStyle} className={classes.paper}>
                            <div className="container">
                                <div className={classes.imageContainer}>
                                    <img
                                        src={
                                            form.fileChange === null || form.fileChange === ''
                                                ? form.img_url === null || form.img_url === ''
                                                    ? form.fileInit
                                                    : form.img_url
                                                : form.fileChange
                                        }
                                        style={{ transform: `scale(${stateScale})` }}
                                        className={classes.imageClass}
                                    />
                                </div>
                                <button className={classes.buttonClass} onClick={zoomIn}>
                                    +
                                </button>
                                <button className={classes.buttonClass} onClick={zoomOut}>
                                    -
                                </button>
                            </div>
                        </div>
                    </Modal>
                </div>
                <div className={classes.root}>
                    <TextField
                        name="rule_desc"
                        id="rule_desc"
                        label="Description"
                        multiline
                        rows={4}
                        inputProps={{ maxLength: 1000 }}
                        variant="outlined"
                        style={{
                            width: '90%',
                        }}
                        value={form.rule_desc}
                        onChange={event => {
                            handleChange(event);
                        }}
                        disabled={modifyFlg === ''}
                        error={validateForm.rule_desc.error}
                        helperText={validateForm.rule_desc.text}
                    />
                </div>
                <div className={classes.root}>
                    <Autocomplete
                        name="doc_tp_rule"
                        id="doc_tp_rule"
                        multiple
                        disableCloseOnSelect
                        options={documentTypes || []}
                        getOptionLabel={option => option.doc_nm || ''}
                        value={form.list_doc_info || []}
                        onChange={onDocTypeChange}
                        renderInput={params => (
                            <TextField
                                {...params}
                                disabled
                                variant="outlined"
                                label="Map to document name"
                                style={{
                                    width: '90%',
                                }}
                            />
                        )}
                    />
                </div>
                <div className={classes.bottom}>
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_SAVE) && (
                        <span>
                            <Button
                                size="small"
                                variant="contained"
                                color="primary"
                                disabled={
                                    !!(
                                        modifyFlg === '' ||
                                        modifyFlg === null ||
                                        (modifyFlg === 'edit' && disableBtnSave) ||
                                        (modifyFlg === 'new' && disableBtnSave)
                                    )
                                }
                                onClick={handleSave}
                            >
                                SAVE
                            </Button>
                        </span>
                    )}
                </div>
            </div>
        </form>
    );
}

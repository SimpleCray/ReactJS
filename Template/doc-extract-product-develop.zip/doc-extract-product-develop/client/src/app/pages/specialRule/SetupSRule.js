import React from 'react';
import { FusePageCarded } from '@fuse';
import SetupSRuleHeader from './SetupSRuleHeader';
import SetupSRuleTable from './SetupSRuleTable';
import SetupSRuleDetail from './SetupSRuleDetail';
import withReducer from 'app/store/withReducer';
import reducer from './store/reducers';

function SetupSRule() {
    return (
        <FusePageCarded
            classes={{
                content: "flex",
                header: "min-h-52 h-52 sm:h-52 sm:min-h-52",
                topBg: "min-h-52 h-52 sm:h-52 sm:min-h-52",
                contentWrapper: "pr-3 pl-3"
            }}
            header={
                <SetupSRuleHeader />
            }
            content={
                <>
                    <SetupSRuleTable />
                    <SetupSRuleDetail />
                </>
            }
            innerScroll
        />
    )
}

export default withReducer('specialRule', reducer)(SetupSRule);;

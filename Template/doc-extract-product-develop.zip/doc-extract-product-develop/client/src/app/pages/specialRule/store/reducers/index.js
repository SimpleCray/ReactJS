import { combineReducers } from 'redux';
import specialRule from './sRule.reducer';

const reducer = combineReducers({
    specialRule
});

export default reducer;

import React, { useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from '@fuse/hooks';
import * as Actions from './store/actions';
import buttons from 'app/utils/constants/buttonConstants.json';
import Button from '../../components/Button/index';
import SearchTextField from '../../components/SearchTextField';
import { MenuItem } from '@material-ui/core';
const formDefault = { ruleName: '', ruleType: '' };

const useStyles = makeStyles(theme => ({
    form: {
        margin: theme.spacing(0.5),
    },
}));
export default function SetupSRuleHeader() {
    const classes = useStyles();
    const dispatch = useDispatch();
    const { form, handleChange, setForm } = useForm(formDefault);
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const listRuleType = ['Biz Logic', 'Matching Config'];

    useEffect(() => {
        setForm(formDefault);
        dispatch(Actions.searchRule(form));
        dispatch(Actions.setFormSearch(form));
        dispatch(Actions.getAllDocType());
    }, [dispatch, formDefault]);

    function handleSubmit(event) {
        event.preventDefault();
        dispatch(Actions.searchRule(form));
        dispatch(Actions.setFormSearch(form));
        dispatch(Actions.setRowSelected(''));
        dispatch(Actions.setModifyFlg(''));
        dispatch(Actions.setSelectDefault(true));
        dispatch(Actions.setPage(0));
    }
    return (
        <form className={classes.form} noValidate onSubmit={handleSubmit}>
            <div className="flex flex-row">
                <div className="flex flex-1 items-center justify-center px-1">
                    <SearchTextField
                        id="ruleName"
                        size="small"
                        name="ruleName"
                        label="Rule name"
                        variant="outlined"
                        onChange={handleChange}
                        value={form.ruleName}
                    />
                </div>
                <div className="flex flex-1 items-center justify-center px-1">
                    <SearchTextField
                        id="ruleType"
                        size="small"
                        name="ruleType"
                        label="Rule Type"
                        variant="outlined"
                        onChange={handleChange}
                        value={form.ruleType}
                        select
                    >
                        <MenuItem value="all">All</MenuItem>
                        {listRuleType.map(rule => (
                            <MenuItem key={rule} value={rule}>
                                {rule}
                            </MenuItem>
                        ))}
                    </SearchTextField>
                </div>

                {btnList.some(btn => btn.BTN_NO === buttons.BTN_SEARCH) && (
                    <Button size="small" variant="contained" color="default" onClick={handleSubmit}>
                        <span className="hidden sm:flex">Search</span>
                    </Button>
                )}
            </div>
        </form>
    );
}

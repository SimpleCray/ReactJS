import HandleServerErrors from 'app/utils/handleServerErrors';
import { showError, checkResDataAPI } from 'app/utils/utils';
import { API_EP } from 'app/utils/commonAPI';
import EndPointAPI from 'app/utils/endPointAPI';
import { showMessage } from '../../../../store/actions/fuse';
export const SEARCH_RULE = '[SETUP SRULE] SEARCH RULE';
export const SET_ROW_SELECTED = '[SETUP SRULE] SET ROW SELECTED';
export const SET_MODIFY_FLG = '[SETUP SRULE] SET MODIFY FLAG';
export const DELETE_RULE = '[SETUP SRULE] DELETE RULE';
export const UPDATE_RULE = '[SETUP SRULE] UPDATE RULE';
export const ADD_RULE = '[SETUP SRULE] ADD RULE';
export const UPLOAD_FILE = '[SETUP SRULE] UPLOAD FILE';
export const READ_FILE = '[SETUP SRULE] READ FILE';
export const SET_DISABLE_BTN_SAVE = '[SETUP SRULE] SET DISABLE BTN SAVE';
export const SET_SELECT_DEFAULT = '[SETUP SRULE] SET SELECT DEFAULT';
export const SET_FORM_SEARCH = '[SETUP SRULE] SET FORM SEARCH';
export const SET_PAGE = 'SET_PAGE_SRULE';
export const GET_DEX_DOC_DOC_TYPE_SUCCESS = 'GET_DEX_DOC_DOC_TYPE_SUCCESS';

export function searchRule(form) {
    const requestUrl = `/setup-special-rule/search`;
    const request = API_EP.post(requestUrl, { form });
    return dispatch =>
        request
            .then(response =>
                dispatch({
                    type: SEARCH_RULE,
                    payload: response.data.result,
                }),
            )
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function setRowSelected(row) {
    return {
        type: SET_ROW_SELECTED,
        rowSelected: row,
    };
}

export function setModifyFlg(flg) {
    return {
        type: SET_MODIFY_FLG,
        modifyFlg: flg,
    };
}

export function delRule(rule_id) {
    const requestUrl = `/setup-special-rule/delete`;
    const request = API_EP.put(requestUrl, { rule_id });
    return dispatch =>
        request
            .then(response =>
                dispatch({
                    type: DELETE_RULE,
                    payload: response.data.result,
                }),
            )
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function update(formData) {
    const requestUrl = `/setup-special-rule/update`;
    const config = {
        headers: {
            'content-type': 'multipart/form-data',
        },
    };
    const request = API_EP.post(requestUrl, formData, config);
    return dispatch =>
        request
            .then(response =>
                dispatch({
                    type: UPDATE_RULE,
                    payload: response.data.result,
                }),
            )
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function addRule(formData) {
    const requestUrl = `/setup-special-rule/add`;
    const config = {
        headers: {
            'content-type': 'multipart/form-data',
        },
    };
    const request = API_EP.post(requestUrl, formData, config);
    return dispatch =>
        request
            .then(response =>
                dispatch({
                    type: ADD_RULE,
                    payload: response.data.result,
                }),
            )
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function uploadFile(file, name) {
    const requestUrl = `upload-file/upload`;
    const formData = new FormData();
    formData.append('file', file);
    formData.append('name', name);

    const request = API_EP.post(requestUrl, formData);
    return dispatch =>
        request
            .then(response =>
                dispatch({
                    type: UPLOAD_FILE,
                    payload: response.data.result,
                }),
            )
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function readFile(fileName) {
    const requestUrl = `upload-file/read/${fileName}`;

    const request = API_EP.get(requestUrl);
    return dispatch =>
        request
            .then(response =>
                dispatch({
                    type: READ_FILE,
                    payload: response.data.result,
                }),
            )
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function setDisableBtnSave(flg) {
    return {
        type: SET_DISABLE_BTN_SAVE,
        disableSave: flg,
    };
}

export function setSelectDefault(flg) {
    return {
        type: SET_SELECT_DEFAULT,
        selectedDefault: flg,
    };
}

export function setFormSearch(form) {
    return {
        type: SET_FORM_SEARCH,
        ruleName: form.ruleName,
        ruleType: form.ruleType,
    };
}

export function setPage(value) {
    return dispatch =>
        dispatch({
            type: SET_PAGE,
            page: value,
        });
}

export const getAllDocType = () => {
    const url = API_EP.get(EndPointAPI.ENDPOINT.DOC_SETTING.ALL_DOC_TP);

    return dispatch =>
        url
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_DEX_DOC_DOC_TYPE_SUCCESS,
                        payload: response.data.result,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
};

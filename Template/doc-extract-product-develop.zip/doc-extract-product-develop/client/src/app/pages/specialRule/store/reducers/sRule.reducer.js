import * as Actions from '../actions';
const initialState = {
    searchList: [],
    listRule: [],
    rowSelected: '',
    detailDefault: {
        rule_id: '',
        rule_nm: '',
        rule_tp_val: 'Biz Logic',
        rule_desc: '',
        img_url: '',
        cre_usr_id: '',
        upd_usr_id: '',
        delt_flg: '',
        img_url_tmp: '',
        fileInit: `${process.env.REACT_APP_END_POINT}/upload-file/read/default.png`,
        fileChange: '',
    },
    modifyFlg: '',
    disableSave: true,
    validateForm: {
        rule_nm: {
            error: false,
            text: '',
        },
        rule_tp_val: {
            error: false,
            text: '',
        },
        rule_desc: {
            error: false,
            text: '',
        },
        approve: true,
    },
    selectedDefault: true,
    formSearch: { ruleName: '', ruleType: '' },
    page: 0,
    documentTypes: [],
};

const specialRuleReducer = function(state = initialState, action) {
    switch (action.type) {
        case Actions.SEARCH_RULE: {
            return {
                ...state,
                searchList: action.payload,
            };
        }
        case Actions.SET_ROW_SELECTED: {
            return {
                ...state,
                rowSelected: action.rowSelected,
            };
        }
        case Actions.SET_MODIFY_FLG: {
            return {
                ...state,
                modifyFlg: action.modifyFlg,
            };
        }
        case Actions.SET_DISABLE_BTN_SAVE: {
            return {
                ...state,
                disableSave: action.disableSave,
            };
        }
        case Actions.SET_SELECT_DEFAULT: {
            return {
                ...state,
                selectedDefault: action.selectedDefault,
            };
        }
        case Actions.SET_FORM_SEARCH: {
            return {
                ...state,
                formSearch: { ruleName: action.ruleName, ruleType: action.ruleType },
            };
        }
        case Actions.SET_PAGE: {
            return {
                ...state,
                page: action.page,
            };
        }
        case Actions.GET_DEX_DOC_DOC_TYPE_SUCCESS: {
            const formatDocumentTypes =
                action.payload &&
                action.payload.map(item => ({
                    doc_tp_id: item.doc_tp_id,
                    doc_cd: item.doc_cd,
                    doc_nm: item.doc_nm,
                }));
            return {
                ...state,
                documentTypes: formatDocumentTypes,
            };
        }

        default: {
            return state;
        }
    }
};

export default specialRuleReducer;

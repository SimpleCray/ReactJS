import React from 'react';
import { TableHead, TableSortLabel, TableCell, TableRow } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import * as TableFnc from 'app/utils/tableFunctions';

const useStyles = makeStyles(theme => ({
    actionsButtonWrapper: {
        background: theme.palette.background.paper,
    },
    root: {
        width: '100%',
    },
    container: {
        maxHeight: 440,
    },
    cellHead: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
    button: {
        margin: theme.spacing(1),
    },
}));

function ViewDocTableHeader(props) {
    const rows = [
        {
            id: 'doc_id',
            label: 'Document ID',
            sort: true,
        },
        {
            id: 'co_nm',
            label: 'Company name',
            sort: false,
        },
        {
            id: 'dex_loc.loc_nm',
            label: 'Location name',
            sort: true,
        },
        {
            id: 'adm_doc_tp.doc_nm',
            label: 'Document name',
            sort: true,
        },
        {
            id: 'root_nm',
            label: 'File name',
            sort: true,
        },
        {
            id: 'file_sz',
            label: 'File Size (KB)',
            sort: true,
        },
        {
            id: 'sts_cd',
            label: 'Status',
            sort: false,
        },
        {
            id: 'cre_dt',
            label: 'Create date',
            sort: true,
        },
        {
            id: 'upd_dt',
            label: 'Update date',
            sort: true,
        },
        {
            id: 'upd_usr_id',
            label: 'Update user',
            sort: true,
        },
    ];

    const classes = useStyles();

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    // Hide column Company Name when login user
    if (props.userInfo.usrId !== 'admin') TableFnc.hideColComName(rows);

    return (
        <TableHead>
            <TableRow>
                {rows.map(row => (
                    <TableCell
                        key={row.id}
                        sortDirection={props.order.columnId === row.id ? props.order.direction : false}
                        className={classes.cellHead}
                    >
                        {row.sort ? (
                            <TableSortLabel direction={props.order.direction} onClick={createSortHandler(row.id)}>
                                {row.label}
                            </TableSortLabel>
                        ) : (
                            <TableSortLabel>{row.label}</TableSortLabel>
                        )}
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
}

export default ViewDocTableHeader;

/* eslint-disable no-unused-vars */
/* eslint-disable import/no-unresolved */
import { API_EP } from 'app/utils/commonAPI';
import EndPointAPI from 'app/utils/endPointAPI';
import { showError, checkResDataAPI } from 'app/utils/utils';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import AppConstants from 'app/utils/appConstants';
import { updateIssueStatusDoc } from '../../viewDocFuctions';

export const UPLOAD_FILE_SUCCESS = 'UPLOAD_FILE_SUCCESS';
export const UPLOAD_FILE_ERROR = 'UPLOAD_FILE_ERROR';
export const GET_DEX_DOC_COMPANIES = 'GET_DEX_DOC_COMPANIES';
export const UPDATE_ALL_STATUS = 'UPDATE_ALL_STATUS';
export const SET_SELECTED_DOC_TYPE_ID = 'SET_SELECTED_DOC_TYPE_ID';
export const GET_DEX_DOC = 'GET_DEX_DOC';
export const SET_DEX_DOC_NAME_SEARCH_TEXT = 'SET_DEX_DOC_NAME_SEARCH_TEXT';
export const GET_LOCATION_DATA = 'GET_LOCATION_DATA';
export const SET_FLAG_POPUP_UPLOAD = 'SET_FLAG_POPUP_UPLOAD';
export const GET_ALL_GROUP = 'GET_ALL_GROUP';
export const GET_ALL_GROUP_DEX_DOC = 'GET_ALL_GROUP_DEX_DOC';
export const GET_DOC_TYPE = 'GET_DOC_TYPE';
export const UPLOAD_FILE_DOCUMENT = 'UPLOAD_FILE_DOCUMENT';
export const GET_ALL_LOC_SUCCESS = 'GET_ALL_LOC_SUCCESS';
export const GET_DEX_DOC_DOC_TYPE_SUCCESS = 'GET_DEX_DOC_DOC_TYPE_SUCCESS';
export const EXTRACTION_ERROR = 'EXTRACTION_ERROR';
export const EXTRACTION_SUCCESS = 'EXTRACTION_SUCCESS';
export const MATCHING_ERROR = 'MATCHING_ERROR';
export const MATCHING_SUCCESS = 'MATCHING_SUCCESS';
export const INIT_UPLOAD_PROC = 'INIT_UPLOAD_PROC';
export const CHANGE_LOADING_STATUS = 'CHANGE_LOADING_STATUS';
export const UPDATE_TEMPLATE_INFO = 'UPDATE_TEMPLATE_INFO';
export const SAVE_UPLOADED_DATA = 'SAVE_UPLOADED_DATA';
export const INIT_UPLOADED_DATA = 'INIT_UPLOADED_DATA';
export const GET_DOC_DATA = 'GET_DOC_DATA';
export const GET_INIT_LOC_DATA = 'GET_INIT_LOC_DATA';
export const SAVE_MULTI_DOC = 'SAVE_MULTI_DOC';
export const SAVE_MULTI_DOC_SUCCESS = 'SAVE_MULTI_DOC_SUCCESS';
export const RESET_SPLITDOC_STATE = 'RESET_SPLITDOC_STATE';
export const SET_FILTER_PARAM = 'SET_FILTER_PARAM';

export const errorUploadDoc = error => dispatch => {
    console.log('Err', errorUploadDoc);
    dispatch(showError(error));
    dispatch(initUploadProc());
};

// TODO: All company should be called by API_EP
export function getCompanies() {
    const request = API_EP.get(EndPointAPI.ENDPOINT.BP.ALL_COM);

    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    const listDataCompany = response.data.data.comList;
                    dispatch({
                        type: GET_DEX_DOC_COMPANIES,
                        companyData: listDataCompany,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
}

/**
 * The returned data contains corresponding document data
 */
export const getLocationData = () => {
    const url = API_EP.get(EndPointAPI.ENDPOINT.LOCATION.ALL_LOC);

    return dispatch =>
        url
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_LOCATION_DATA,
                        locationData: response.data,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
};

export const getDexDoc = searchCondition => {
    const url = API_EP.get(EndPointAPI.ENDPOINT.DOC_DATA.DEX_DOC, {
        params: searchCondition,
    });
    return dispatch =>
        url
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_DEX_DOC,
                        payload: response.data,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
};

export const getAllGroupDoc = () => {
    const url = API_EP.get(EndPointAPI.ENDPOINT.DOC_SETTING.ALL_GRP);
    return dispatch =>
        url
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_ALL_GROUP,
                        payload: response.data,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
};

export const getAllGroupDexDoc = () => {
    const url = API_EP.get(EndPointAPI.ENDPOINT.DOC_SETTING.ALL_GRP_DEX_DOC);
    return dispatch =>
        url
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_ALL_GROUP_DEX_DOC,
                        groupDexDocs: response.data,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
};

export function setNameDexDoc(value) {
    return dispatch =>
        dispatch({
            type: SET_DEX_DOC_NAME_SEARCH_TEXT,
            searchText: value,
        });
}

export function addDexDocGrp(docNm, creUsrId, coCd, locId, locCd, docTpId) {
    const doc = {
        root_nm: docNm,
        doc_nm: docNm,
        cre_usr_id: creUsrId,
        co_cd: coCd,
        loc_id: locId,
        loc_cd: locCd,
        doc_tp_id: docTpId,
        sts_cd: 'E',
    };

    const request = API_EP.post(EndPointAPI.ENDPOINT.DOC_DATA.ADD_DEX_DOC, {
        doc,
    });

    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch(getAllGroupDexDoc());
                    dispatch(showMessage({ variant: 'success', message: response.data.message }));
                }
            })
            .catch(error => dispatch(showError(error)));
}

export function getDocType(docTpId) {
    const request = API_EP.get(`/doc-setting/${docTpId}/doc/`);
    return dispatch => {
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_DOC_TYPE,
                        payload: response.data.result,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
    };
}

export function uploadFileData(formData, config) {
    const request = API_EP.post(EndPointAPI.ENDPOINT.DOC_SETTING.UPLOAD_FILE, formData, config);
    return dispatch => {
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: UPLOAD_FILE_SUCCESS,
                        data: response.data,
                    });
                }
            })
            .catch(error => {
                showError(error);
                dispatch({
                    type: UPLOAD_FILE_ERROR,
                });
                initUploadedData();
            });
    };
}

export function reUploadFlow(resData) {
    return dispatch => {
        dispatch({
            type: UPLOAD_FILE_SUCCESS,
            data: resData,
        });
    };
}
export function setFlgUpload(value) {
    return dispatch =>
        dispatch({
            type: SET_FLAG_POPUP_UPLOAD,
            flgUploadDialog: value,
        });
}

export const getAllDocType = () => {
    const url = API_EP.get(EndPointAPI.ENDPOINT.DOC_SETTING.ALL_DOC_TP, {
        params: { allFlg: true },
    });
    return dispatch =>
        url
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_DEX_DOC_DOC_TYPE_SUCCESS,
                        payload: response.data.result,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
};

export function submitMatching(data) {
    const apiCalling = API_EP.post(EndPointAPI.CORE.MATCHING.SUBMIT, data);
    return dispatch =>
        apiCalling
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: MATCHING_SUCCESS,
                        data: response.data,
                    });
                }
            })
            .catch(error => {
                console.error('Error when matching: ', error);
                const issueList = [AppConstants.DOC_ISSUES_CODE.MF];
                const replaceOldIssue = true;
                updateIssueStatusDoc(data.doc_id, AppConstants.DOC_STATUS_CODE.F, issueList, replaceOldIssue);
                dispatch({
                    type: MATCHING_ERROR,
                });
                dispatch(errorUploadDoc('2000'));
            });
}

export function submitExtract(data) {
    const apiCalling = API_EP.post(EndPointAPI.CORE.EXTRACTION.SUBMIT, data);

    return dispatch =>
        apiCalling
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: EXTRACTION_SUCCESS,
                        data: response.data,
                    });
                }
            })
            .catch(error => {
                console.error('Error when extracting: ', error);
                const issueList = [AppConstants.DOC_ISSUES_CODE.EF];
                const replaceOldIssue = true;
                updateIssueStatusDoc(data.doc_id, AppConstants.DOC_STATUS_CODE.F, issueList, replaceOldIssue);
                dispatch({
                    type: EXTRACTION_ERROR,
                });
                dispatch(errorUploadDoc('2200'));
            });
}

export function initUploadProc() {
    return dispatch =>
        dispatch({
            type: INIT_UPLOAD_PROC,
        });
}

export const changeLoadingStatus = loadingStatus => dispatch =>
    dispatch({
        type: CHANGE_LOADING_STATUS,
        loadingStatus,
    });

export const updateTemplateInfo = (templateType, templateId) => dispatch =>
    dispatch({
        type: UPDATE_TEMPLATE_INFO,
        templateType,
        templateId,
    });

export const storeUploadedData = uploadedData => dispatch =>
    dispatch({
        type: SAVE_UPLOADED_DATA,
        uploadedData,
    });

export const initUploadedData = () => dispatch =>
    dispatch({
        type: INIT_UPLOADED_DATA,
    });

export function getInitLocData() {
    const request = API_EP.get(`/location-management/loc-data`);
    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_INIT_LOC_DATA,
                        payload: response.data ? response.data.result : [],
                    });
                }
            })
            .catch(err => dispatch(showError(err)));
}

export function setFilter(params) {
    return dispatch =>
        dispatch({
            type: SET_FILTER_PARAM,
            params,
        });
}

export const saveMultiDoc = data => async dispatch => {
    API_EP.post(EndPointAPI.ENDPOINT.DOCUMENT.SAVE_MULTI_DOC, data)
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch(changeLoadingStatus(false));
                dispatch({
                    type: SAVE_MULTI_DOC_SUCCESS,
                    data: response.data,
                });
            }
        })
        .catch(error => dispatch(errorUploadDoc(error)));
};

export function resetSplitDocState() {
    return dispatch =>
        dispatch({
            type: RESET_SPLITDOC_STATE,
        });
}

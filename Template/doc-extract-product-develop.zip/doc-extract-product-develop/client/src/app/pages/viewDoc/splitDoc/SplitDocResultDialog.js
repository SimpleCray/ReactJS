import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import { TableContainer, Table, TableHead, TableRow, TableCell, Paper, TableBody } from '@material-ui/core';
import * as Actions from '../store/actions/actions';
import CustomButton from '../../../components/Button';
import 'styles/scss/split-doc.scss';

export default function SplitDocResultDialog(props) {
    const dispatch = useDispatch();
    const saveSuccess = useSelector(({ viewDoc }) => viewDoc.saveSuccess);
    const [rows, setRows] = useState([]);
    const [openDialog, setOpenDialog] = useState(false);

    useEffect(() => {
        if (saveSuccess && props.rows.length > 0) {
            const resultRows = [];
            // Find the item in row data list
            saveSuccess.forEach(item => {
                const docName = item.fileUrl.split('/').pop();
                const currentRow = props.rows.find(item => item.doc_nm === docName);
                resultRows.push(currentRow);
            });
            setRows(resultRows);
            // Check if array has no undefined item then open dialog
            if (!resultRows.some(row => !row)) setOpenDialog(true);
        }
    }, [props.rows]);

    const handleClose = () => {
        setOpenDialog(false);
        dispatch(Actions.resetSplitDocState());
    };

    return (
        <div>
            <Dialog
                open={openDialog}
                fullWidth
                maxWidth="md"
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title">Split document result</DialogTitle>
                <DialogContent>
                    <TableContainer className="flex m-auto max-w-3xl" component={Paper}>
                        <Table aria-label="simple table">
                            <TableHead>
                                <TableRow className="output-header">
                                    <TableCell className="text-white" align="left">
                                        Document Id
                                    </TableCell>
                                    <TableCell className="text-white" align="left">
                                        Document name
                                    </TableCell>
                                    <TableCell className="text-white" align="left">
                                        File name
                                    </TableCell>
                                    <TableCell className="text-white" align="left">
                                        Status
                                    </TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {openDialog &&
                                    rows.map(doc => (
                                        <TableRow
                                            className="cursor-pointer"
                                            hover
                                            onDoubleClick={() => props.handleDoubleClick(doc)}
                                            key={doc.doc_id}
                                        >
                                            <TableCell align="left">{doc.doc_id}</TableCell>
                                            <TableCell align="left">{doc.adm_doc_tp.doc_nm}</TableCell>
                                            <TableCell align="left">{doc.doc_nm}</TableCell>
                                            <TableCell align="left">{doc.status}</TableCell>
                                        </TableRow>
                                    ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </DialogContent>
                <DialogActions>
                    <CustomButton className="float-right" onClick={handleClose}>
                        Close
                    </CustomButton>
                </DialogActions>
            </Dialog>
        </div>
    );
}

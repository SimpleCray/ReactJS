import React, { useEffect, useState } from 'react';
import history from '@history';
import {
    MenuItem,
    IconButton,
    Typography,
    Paper,
    Tooltip,
    InputLabel,
    Select,
    Checkbox,
    CircularProgress,
} from '@material-ui/core';
import { FuseAnimate, FuseAnimateGroup } from '@fuse';
import { RemoveCircle, AddCircle, CheckBoxOutlineBlank, CheckBox } from '@material-ui/icons';
import { FormControl } from '@material-ui/core';
import { OutlinedInput } from '@material-ui/core';
import { Autocomplete } from '@material-ui/lab';
import { TextField } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { showMessage } from 'app/store/actions';
import CustomButton from '../../../components/Button';
import withReducer from 'app/store/withReducer';
import reducer from '../store/reducers/reducers';
import { useStyles } from 'app/pages/Annotate/styles.js';
import 'styles/scss/split-doc.scss';
import * as Functions from './SplitDocFunctions';
import * as Actions from '../store/actions/actions';
import { getUserId } from 'app/utils/utils';

const initDocTypeDiv = { docTpId: '', pages: [], error: { docTpId: true, pages: true } };

function MainSplitDoc(props) {
    const classes = useStyles();
    const dispatch = useDispatch();
    const [docData, setDocData] = useState(null);
    const [allLoc, setAllLoc] = useState('');
    const [currentComCd, setCurrentComCd] = useState(null);
    const [currentLocCd, setCurrentLocCd] = useState(null);
    const [docInfoOfAllLoc, setDocInfoOfAllLoc] = useState(null);
    const [pagesData, setPagesData] = useState(null);
    const [allDocType, setAllDocType] = useState(null);
    const [docTypeDiv, setDocTypeDiv] = useState([initDocTypeDiv]);
    const [validateField, setValidateField] = useState(false);
    const loadingStatus = useSelector(({ viewDoc }) => viewDoc.loading);
    const saveSuccess = useSelector(({ viewDoc }) => viewDoc.saveSuccess);

    useEffect(async () => {
        // Prevent user access this site directly
        if (!props.location.state) {
            history.push('/extract/view-doc');
        } else {
            // Process split doc
            setDocData(props.location.state);
            const { comData, locsData, locCd, file } = props.location.state;
            setCurrentComCd(comData.coCd);
            setCurrentLocCd(locCd);
            const currentComLocInfo = [];
            const allLocs = [];
            if (comData.coCd !== '') {
                locsData
                    .filter(item => item.co_cd === comData.coCd)
                    .map(item => {
                        if (!allLocs.includes(item.loc_cd)) {
                            currentComLocInfo.push(item);
                            allLocs.push(item.loc_cd);
                        }
                    });
            }
            const allCurrentDocType = getAllDocTypes(comData.coCd, locCd, locsData);
            setAllLoc(currentComLocInfo);
            setAllDocType(allCurrentDocType);
            setDocInfoOfAllLoc(locsData);
            const pagesData = await Functions.splitDocToPages(file);
            setPagesData(pagesData);
        }
    }, [docData]);

    useEffect(() => {
        // After split doc success redirect to view doc
        if (saveSuccess) {
            history.push('/extract/view-doc');
        }
    }, [saveSuccess]);

    const getAllDocTypes = (coCd, locCd, locsData) => {
        const allLocOfCom = locsData.filter(
            item => item.co_cd === coCd && item.loc_cd === locCd && item.documents.delt_flg === 'N',
        );
        const allCurrentDocType = allLocOfCom.map(item => ({
            doc_tp_id: item.doc_tp_id,
            fol_loc_url: item.fol_loc_url,
            doc_nm: item.documents.doc_nm,
            loc_id: item.loc_id,
        }));
        return allCurrentDocType;
    };

    const handleAddDoc = () => {
        setDocTypeDiv([...docTypeDiv, initDocTypeDiv]);
    };

    const handleRemoveDoc = index => {
        const newDocTypeDiv = [...docTypeDiv];
        newDocTypeDiv.splice(index, 1);
        setDocTypeDiv(newDocTypeDiv);
    };

    const handleChangeLoc = e => {
        setDocTypeDiv([initDocTypeDiv]);
        const newLocCd = e.target.value;
        // Get and set all doc type with new location
        const newDocsType = getAllDocTypes(currentComCd, newLocCd, docInfoOfAllLoc);
        setAllDocType(newDocsType);
        setCurrentLocCd(newLocCd);
        setValidateField(false);
    };

    const handleChange = (property, index, value) => {
        const newDocTypeDiv = [...docTypeDiv];
        let currentDocTypeInfo = null;
        if (property === 'docTpId') {
            currentDocTypeInfo = allDocType.find(item => item.doc_tp_id === value);
            newDocTypeDiv[index] = {
                ...newDocTypeDiv[index],
                [property]: value,
                folderLoc: currentDocTypeInfo?.fol_loc_url + '/Output',
                locId: currentDocTypeInfo?.loc_id,
                error: {
                    ...newDocTypeDiv[index]['error'],
                    [property]: property === 'docTpId' ? value === '' : value.length === 0,
                },
            };
        } else {
            newDocTypeDiv[index] = {
                ...newDocTypeDiv[index],
                [property]: value,
                error: {
                    ...newDocTypeDiv[index]['error'],
                    [property]: property === 'docTpId' ? value === '' : value.length === 0,
                },
            };
        }
        setDocTypeDiv(newDocTypeDiv);
    };

    const saveDocuments = async () => {
        setValidateField(true);
        const saveValid = !docTypeDiv.some(item => item.error.docTpId || item.error.pages);
        if (saveValid) {
            const pdfDataArray = await Functions.mergePagesToDoc(pagesData, docTypeDiv);
            const data = {
                coCd: currentComCd,
                locCd: currentLocCd,
                fileName: docData.file.name,
                splitInfos: pdfDataArray,
                usrId: getUserId(),
            };
            dispatch(Actions.changeLoadingStatus(true));
            dispatch(Actions.saveMultiDoc(data));
        } else {
            dispatch(
                showMessage({
                    message: `Highlighted field(s) is required. Please fill out all fields before submitting!`,
                    variant: 'error',
                }),
            );
        }
    };
    const singplePageRenderer = (url, index) => (
        <div className="widget flex page-width p-12" key={`widget-${index}`}>
            <Paper className="w-full rounded-8 border-1">
                <div className="text-center p-12">
                    <iframe
                        id="iframe"
                        title={`page ${index}`}
                        className="iframe-prop"
                        src={url}
                        type="application/pdf"
                    />
                </div>
                <div className="flex items-center px-16 h-52 border-t-1" key={`typo-${index}`}>
                    <Typography className="text-15 flex w-full" color="textSecondary">
                        <span className="truncate">Page:</span>
                        <b className="pl-8">{index}</b>
                    </Typography>
                </div>
            </Paper>
        </div>
    );

    const docDivRenderer = (item, index) => (
        <div className="border-t-1 pt-24 w-full" key={`doc-div-${index}`}>
            <FormControl size="small" variant="outlined" className="w-2/3">
                <InputLabel
                    error={validateField && docTypeDiv[index].error.docTpId}
                >
                    Doc Type
                </InputLabel>
                <Select
                    label="docType"
                    value={docTypeDiv[index]?.docTpId}
                    onChange={e => handleChange('docTpId', index, e.target.value)}
                    size="small"
                    input={<OutlinedInput labelWidth={72} />}
                    error={validateField && docTypeDiv[index].error.docTpId}
                >
                    {allDocType.map(element => (
                        <MenuItem value={element.doc_tp_id} key={element.doc_tp_id}>
                            {element.doc_nm}
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>

            <FormControl size="small" variant="outlined" className="w-1/3 pb-12">
                <div className="absolute justify-end right-0 pb-5">
                    <Tooltip title="Add">
                        <IconButton aria-label="Add" onClick={handleAddDoc}>
                            <AddCircle />
                        </IconButton>
                    </Tooltip>
                    <Tooltip title="Remove">
                        <span>
                            <IconButton
                                aria-label="Remove"
                                id={index}
                                disabled={docTypeDiv.length === 1}
                                onClick={() => handleRemoveDoc(index)}
                            >
                                <RemoveCircle />
                            </IconButton>
                        </span>
                    </Tooltip>
                </div>
            </FormControl>

            <FormControl size="small" variant="outlined" className="w-full pt-12 pb-24">
                <Autocomplete
                    id="pages-multi-checkbox"
                    multiple
                    className="pt:24"
                    variant="outlined"
                    disableCloseOnSelect
                    options={pagesData ? pagesData.map(item => (item.pageIndex + 1).toString()) : []}
                    value={docTypeDiv[index].pages}
                    onChange={(e, value) => handleChange('pages', index, value)}
                    size="small"
                    renderOption={(option, state) => {
                        return (
                            <React.Fragment>
                                <Checkbox
                                    icon={<CheckBoxOutlineBlank fontSize="small" />}
                                    checkedIcon={<CheckBox fontSize="small" />}
                                    style={{ marginRight: 8 }}
                                    checked={state.selected}
                                />
                                Page {option}
                            </React.Fragment>
                        );
                    }}
                    renderInput={params => (
                        <TextField
                            {...params}
                            error={validateField && docTypeDiv[index].error.pages}
                            variant="outlined"
                            label="Select Pages"
                            placeholder="Page number"
                        />
                    )}
                />
            </FormControl>
        </div>
    );

    return loadingStatus ? (
        <div className={classes.circleloading}>
            <CircularProgress size={200} />
        </div>
    ) : (
        docData && (
            <div>
                <FuseAnimate animation="transition.slideUpIn" delay={200}>
                    <div className="relative h-screen inset-0 flex md:flex-row">
                        <div className="flex flex-1 flex-col flex-grow overflow-y-auto">
                            <FuseAnimate delay={600}>
                                <Typography className="p-16 pb-8 text-18 font-400">Pages In Document</Typography>
                            </FuseAnimate>

                            <FuseAnimateGroup
                                className="flex flex-wrap"
                                enter={{
                                    animation: 'transition.slideUpBigIn',
                                }}
                            >
                                {pagesData?.map(item =>
                                    singplePageRenderer(
                                        `${item.url}#toolbar=0&navpanes=0&scrollbar=0`,
                                        item.pageIndex + 1,
                                    ),
                                )}
                            </FuseAnimateGroup>
                        </div>

                        <div className="relative w-320 pt-16 mr-12 ml-12">
                            <div className="mb-32 w-full sm:w-full md:w-full">
                                <FuseAnimate delay={600}>
                                    <Typography className="px-16 pb-24 text-18 font-400">
                                        Select pages for each document
                                    </Typography>
                                </FuseAnimate>

                                <div className="w-full border-black pb-24">
                                    <FormControl size="small" variant="outlined" className="w-1/2">
                                        <InputLabel>Company</InputLabel>
                                        <Select
                                            label="company"
                                            value={currentComCd}
                                            disabled
                                            size="small"
                                            input={<OutlinedInput labelWidth={72} />}
                                        >
                                            <MenuItem value={currentComCd}>{docData.comData?.coNm}</MenuItem>
                                        </Select>
                                    </FormControl>
                                    <FormControl size="small" variant="outlined" className="w-1/2">
                                        <InputLabel>Location</InputLabel>
                                        <Select
                                            label="location"
                                            value={currentLocCd}
                                            size="small"
                                            input={<OutlinedInput labelWidth={72} />}
                                            onChange={e => handleChangeLoc(e)}
                                        >
                                            {allLoc.map(item => (
                                                <MenuItem key={item.loc_cd} value={item.loc_cd}>
                                                    {item.loc_nm}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </div>

                                {docTypeDiv.map((item, index) => docDivRenderer(item, index))}
                            </div>

                            <div className="absolute bottom-0.5 right-0">
                                <CustomButton variant="contained" color="primary" onClick={saveDocuments}>
                                    Save
                                </CustomButton>
                            </div>
                        </div>
                    </div>
                </FuseAnimate>
            </div>
        )
    );
}

export default withReducer('viewDoc', reducer)(MainSplitDoc);

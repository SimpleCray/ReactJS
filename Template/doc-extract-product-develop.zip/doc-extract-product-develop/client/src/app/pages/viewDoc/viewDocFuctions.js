import AppConstants from 'app/utils/appConstants';
import { API_EP } from 'app/utils/commonAPI';
import EndPointAPI from 'app/utils/endPointAPI';
import { removeIPandPort, getUserId } from 'app/utils/utils';
import MsgNotifications from 'app/utils/msgNotifications';
import * as Actions from './store/actions/actions';

export const makeMatchingProc = uploadProcData => dispatch => {
    const reqMatchingData = {
        doc_id: uploadProcData.doc_id,
        file_name: uploadProcData.file_name,
        file_url: uploadProcData.file_url,
        co_cd: uploadProcData.co_cd,
        lo_cd: uploadProcData.loc_cd,
        doc_tp_id: uploadProcData.doc_type,
        grp_val: '', // TODO: Re-check and handle grp_val
    };
    console.log('---- ON MATCHING ----');
    dispatch(Actions.submitMatching(reqMatchingData));
};

export const makeExtractProc = (uploadProcData, matchingData) => dispatch => {
    const reqExtractData = {
        file_url: uploadProcData.file_url,
        doc_id: uploadProcData.doc_id,
        tmp_type: matchingData.tmp_type,
        tmp_id: matchingData.tmp_id,
        doc_tp_id: uploadProcData.doc_type,
    };
    console.log('---- ON EXTRACTING ----');
    dispatch(Actions.submitExtract(reqExtractData));
};

export const getNotAnnotatedTemplate = async (groupId, templateType) => {
    const allTemplates = await API_EP.get(EndPointAPI.ENDPOINT.TEMPLATE.GET_ALL_TMP_NOT_ANNOTATED, {
        params: { groupId, templateType },
    });
    return allTemplates;
};

export const makeTemplateInfo = (matchingData, docTypeId) => dispatch => {
    // TODO: This groupID is already on DB, this is used for RnD, will handle later when re-work with CORE RnD
    const groupId = matchingData.grp_id || AppConstants.TEMPLATE.GROUPID_DEFAULT;
    // If grp_id is empty, check and save grp_val
    if (!matchingData.img_url && !matchingData.root_url) {
        dispatch(Actions.errorUploadDoc(new Error('IMG and ROOT pdf null !!!')));
    } else if (groupId) {
        // Query to get template id
        findOrCreateTemplateMatching(matchingData, docTypeId).then(res => {
            const [tmpltType, tmpltId] = res;
            dispatch(Actions.updateTemplateInfo(tmpltType, tmpltId));
        });
    } else {
        dispatch(Actions.errorUploadDoc(new Error('System error! Please contact admin to check !!!')));
    }
};

export function updateTemplateForDoc(docId, templateId) {
    const usrId = getUserId();
    API_EP.post(EndPointAPI.ENDPOINT.DOC_DATA.UPDATE_TEMPLATE_ID_DOC, { docId, templateId, usrId });
}

export const updateTemplateAfterMatching = async (templateId, matchingData) => {
    const templateData = makeTemplateMatchingData(matchingData);
    await API_EP.post(EndPointAPI.ENDPOINT.TEMPLATE.UPDATE_TMP_AFTER_MATCHING, {
        templateId,
        matchingData: templateData,
        usrId: getUserId(),
    });
};

export const updateTemplateInfo = (matchingData, docTypeId, docId) => dispatch => {
    const templateType = matchingData.tmp_type;
    const templateId = matchingData.tmp_id;
    updateStatusDoc(docId, AppConstants.DOC_STATUS_CODE.N);
    // If return data have grp_val, check in all grp, if not have -> create
    if (templateId && templateType) {
        if (!matchingData.img_url && !matchingData.root_url) {
            dispatch(Actions.errorUploadDoc(new Error('IMG and ROOT pdf null!!!')));
        } else {
            updateTemplateAfterMatching(templateId, matchingData);
            dispatch(Actions.updateTemplateInfo(templateType, templateId));
        }
    } else {
        dispatch(makeTemplateInfo(matchingData, docTypeId));
    }
};

export async function saveExtractedData(extractedData, docId, docTypeId) {
    try {
        await API_EP.put(EndPointAPI.ENDPOINT.DOC_DATA.SAVE_EXTRACTED_DATA, {
            data: extractedData,
            doc_id: docId,
            doc_tp_id: docTypeId,
        });
    } catch (err) {
        console.error('On err save Extracted Data', err);
        throw new Error(MsgNotifications.VIEW_DOC.SAVE_EXTR_DATA_FAILED);
    }
}

export const getBizData = async docId => {
    try {
        const bizData = await API_EP.get(EndPointAPI.ENDPOINT.BIZ.GET_BIZ_DATA, { params: { docId } });
        return bizData;
    } catch (err) {
        console.error('On err run Biz Process', err);
        throw new Error(MsgNotifications.ANNOTATE.BIZ_FAILED);
    }
};

export const saveBizData = async (docId, bizData) => {
    if (bizData) {
        try {
            await API_EP.post(EndPointAPI.ENDPOINT.BIZ.SAVE_BIZ, { bizData: bizData.data }, { params: { docId } });
            return true;
        } catch (err) {
            console.error('On err save Biz data', err);
            throw new Error(MsgNotifications.ANNOTATE.BIZ_FAILED);
        }
    }
    return false;
};

export const saveExtractAndRunBiz = async (docId, extractedData, docTypeId) => {
    await saveExtractedData(extractedData.data, docId, docTypeId);

    // Calling Extraction Rule service and update extracted data
    console.log('---- ON EXTRACTION RULE PROCESSING ----');
    const processedExtractRuleData = await getExtractRuleData(docId);
    await updateExtractedData(docId, processedExtractRuleData);

    // Calling Biz and apply biz logic
    console.log('---- ON BIZ PROCESSING ----');
    const processedBizData = await getBizData(docId);
    await saveBizData(docId, processedBizData);
};

export const makeTemplateMatchingData = matchingData => {
    const templateData = {};
    templateData.root_url = matchingData.root_url;
    templateData.img_url = matchingData.img_url;
    templateData.usrId = getUserId();
    templateData.coord_cal = matchingData.coord_cal;
    templateData.coord_value = matchingData.coord_value;
    templateData.coord_key = matchingData.coord_key;
    return templateData;
};

export const findOrCreateTemplateMatching = async (matchingData, docTypeId) => {
    let routingTmpType = '';
    let routingTmpId = '';
    const groupId = matchingData.grp_id || AppConstants.TEMPLATE.GROUPID_DEFAULT;
    const tmpltList = await getNotAnnotatedTemplate(groupId, matchingData.tmp_type);
    if (tmpltList) {
        const resData = tmpltList.data;
        const checkAnnotating = resData.some(tmpl => tmpl.sts_flg === AppConstants.TEMPLATE.STATUS.ANNOTATING);
        const latestTmpl = resData[0];
        const rootUrl = removeIPandPort(matchingData.root_url);
        const imgUrl = removeIPandPort(matchingData.img_url);
        if (!latestTmpl || checkAnnotating) {
            const templateData = {
                ...matchingData,
                doc_tp_id: docTypeId,
                img_url: imgUrl,
                root_url: rootUrl,
            };
            const dataTmpl = await createNewTemplate(templateData);
            if (dataTmpl) {
                const tmpltCreated = dataTmpl.data;
                routingTmpType = tmpltCreated.tp_val;
                routingTmpId = tmpltCreated.tmplt_id;
            }
        } else {
            routingTmpType = latestTmpl.tp_val;
            routingTmpId = latestTmpl.tmplt_id;
            updateTemplateAfterMatching(routingTmpId, matchingData);
        }
    }
    return [routingTmpType, routingTmpId];
};

export const createNewTemplate = async matchingData => {
    matchingData.usrId = getUserId(); // Add userId for create
    matchingData.co_cd = localStorage.getItem(AppConstants.BP_USER_INFO).coCd;
    const apiCalling = await API_EP.post(EndPointAPI.ENDPOINT.TEMPLATE.CREATE_NEW_TMP, matchingData);
    return apiCalling;
};

export const getTemplateVersion = async templateId => {
    let templateVersion = '';
    try {
        const templateVerRes = await API_EP.get(EndPointAPI.ENDPOINT.TEMPLATE.GET_TMP_VERSION, {
            params: { tmpltId: templateId },
        });
        templateVersion = templateVerRes.data;
    } catch (err) {
        console.log(err);
    }
    return templateVersion;
};

export const updateStatusDoc = async (docId, status) => {
    try {
        const apiCalling = await API_EP.post(EndPointAPI.ENDPOINT.DOC_DATA.UPDATE_DOC_STATUS, { docId, status });
        return apiCalling;
    } catch (error) {
        return null;
    }
};

export const updateIssueStatusDoc = async (docId, status, issueList, replaceOldIssue, isBiz = false) => {
    try {
        const apiCalling = await API_EP.post(EndPointAPI.ENDPOINT.DOC_DATA.UPDATE_ISSUE_STATUS_DOC, {
            docId,
            status,
            replaceOldIssue,
            issueList,
            isBiz,
        });
        return apiCalling;
    } catch (error) {
        return null;
    }
};

/**
 * Function that convert transaction data to the same format with extr_ctnt in dex_doc
 */
export const convertTransactionInfo = data => {
    const transactionInfo = { ...data };
    const { typeName } = data;
    if (typeName === AppConstants.TRANSACTION_STATUS.VERIFY) {
        // Return the origin format (keep format same with DexDoc)
        const transData = {};
        Object.keys(data.transactionContent.data).forEach(item => {
            if (item === 'normalTextData') {
                // item is text
                data.transactionContent.data[item].forEach(el => {
                    transData[el.fld_id] = { data: el.field_data };
                });
            } else {
                // item is table
                Object.keys(data.transactionContent.data[item]).forEach(table => {
                    data.transactionContent.data[item][table].forEach(el => {
                        transData[el.fld_id] = { data: el.col_data };
                    });
                });
            }
        });
        transactionInfo.transactionContent.data = transData;
    }
    return transactionInfo;
};

export const getExtractRuleData = async docId => {
    try {
        const extrRuleData = await API_EP.get(EndPointAPI.ENDPOINT.EXTRACT_RULE.GET_EXTRACT_RULE_DATA, {
            params: { docId },
        });
        return extrRuleData.data;
    } catch (err) {
        console.error('On err run Extraction Rule Process', err);
        throw new Error(MsgNotifications.ANNOTATE.EXTRACTION_RULE_FAILED);
    }
};

export const updateExtractedData = async (docId, extractedData) => {
    try {
        const updateResult = await API_EP.post(EndPointAPI.ENDPOINT.DOC_DATA.UPDATE_EXTRACTED_DATA, {
            docId,
            extractedData,
        });
        return updateResult;
    } catch (err) {
        return null;
    }
};

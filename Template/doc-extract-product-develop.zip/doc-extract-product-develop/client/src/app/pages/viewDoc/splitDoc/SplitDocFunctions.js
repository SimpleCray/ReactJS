/* eslint-disable no-restricted-syntax */
/* eslint-disable no-loop-func */
/* eslint-disable no-await-in-loop */
import { PDFDocument } from 'pdf-lib';

export const splitDocToPages = async pdfFile => {
    const pagesData = [];
    const pdfFileBuffer = await fetch(URL.createObjectURL(pdfFile)).then(res => res.arrayBuffer());
    const pdfDoc = await PDFDocument.load(pdfFileBuffer);
    const numberOfPages = pdfDoc.getPages().length;

    for (let i = 0; i < numberOfPages; i++) {
        let singlePageData = {};
        try {
            // Create a new "sub" document
            const subDocument = await PDFDocument.create();
            // copy the page at current index
            const [copiedPage] = await subDocument.copyPages(pdfDoc, [i]);
            subDocument.addPage(copiedPage);
            const pdfBytes = await subDocument.save();
            const docUrl = createPdfUrl(pdfBytes);
            singlePageData = { pageIndex: i, url: docUrl, pageBytes: pdfBytes };
        } catch (err) {
            singlePageData.splitError = err;
        }
        pagesData.push(singlePageData);
    }
    return pagesData;
};

export const mergePagesToDoc = async (pagesData, docsData) => {
    const pdfDataArray = [...docsData];
    for (let i = 0; i < pdfDataArray.length; i++) {
        const pdfDoc = await PDFDocument.create();

        for (const pageIndex of pdfDataArray[i].pages) {
            for (const page of pagesData) {
                if (pageIndex === (page.pageIndex + 1).toString()) {
                    try {
                        const pdf = await PDFDocument.load(page.pageBytes);
                        const pageIndices = Array.from(pdf.getPages().keys());
                        const [copiedPage] = await pdfDoc.copyPages(pdf, pageIndices);
                        pdfDoc.addPage(copiedPage);
                    } catch (err) {
                        pdfDataArray[i].mergeError = err;
                    }
                }
            }
        }
        const pdfBytes = await pdfDoc.save();
        pdfDataArray[i].fileData = JSON.stringify(Array.from(pdfBytes));
        const fileByteSize = new Blob([JSON.stringify(Array.from(pdfBytes))]).size;
        pdfDataArray[i].fileSz = (fileByteSize / 1000).toFixed(1);
    }
    return pdfDataArray;
};

export const createPdfUrl = pdf => {
    const bytes = new Uint8Array(pdf);
    const blob = new Blob([bytes], { type: 'application/pdf' });
    const docUrl = URL.createObjectURL(blob);
    return docUrl;
};

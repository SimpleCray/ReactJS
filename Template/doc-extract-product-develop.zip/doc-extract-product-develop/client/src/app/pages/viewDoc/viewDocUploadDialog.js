/* eslint-disable no-return-assign */
/* eslint-disable func-names */
import React, { useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from '@fuse/hooks';
import SearchTextField from 'app/components/SearchTextField';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useTheme, makeStyles } from '@material-ui/core/styles';
import { Typography, Toolbar, AppBar, TextField } from '@material-ui/core';
import IconButton from '@material-ui/core/IconButton';
import Icon from '@material-ui/core/Icon';
import MenuItem from '@material-ui/core/MenuItem';
import _ from '@lodash';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Input from '@material-ui/core/Input';
import InputAdornment from '@material-ui/core/InputAdornment';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import Button from 'app/components/Button';
import history from '@history';
import 'styles/scss/view-doc.scss';
import AppConstants from 'app/utils/appConstants';
import { formatDateTimeString } from 'app/utils/utils';
import * as Actions from './store/actions/actions';
import MsgNotifications from 'app/utils/msgNotifications';

const defaultFormState = {
    grp_flg: false,
    classGrp: 'hidden',
    classNmGrp: 'hidden',
    grpNm: '',
    grp_cd: '',
};

const useStyles = makeStyles({
    root: {
        padding: '4px 3px',
        fontSize: '1.15rem',
    },
    label: {
        fontSize: '1.5rem',
    },
});

function UploadDialog(props) {
    const dispatch = useDispatch();
    const { form, handleChange, setForm } = useForm(defaultFormState);
    const companies = useSelector(({ viewDoc }) => viewDoc.companyData);
    const groupDocs = useSelector(({ viewDoc }) => viewDoc.groupDocs);
    const groupDexDocs = useSelector(({ viewDoc }) => viewDoc.groupDexDocs);
    const data = useSelector(({ viewDoc }) => viewDoc.allDocTypeByLoc);
    const documents = useSelector(({ viewDoc }) => viewDoc.documentData);
    const docTypeofGroup = useSelector(({ viewDoc }) => viewDoc.docTypeOfGroup);
    const flgUploadDialog = useSelector(({ viewDoc }) => viewDoc.flgUploadDialog);
    const [openDialog, setOpenDialog] = useState(flgUploadDialog);
    const [currentCom, setCurrentCom] = useState('');
    const [allLoc, setAllLoc] = useState('');
    const [currentLoc, setCurrentLoc] = useState('');
    const [allGrpDoc, setAllGrpDoc] = useState([]);
    const [currentGrpDoc, setCurrentGrpDoc] = useState('');
    const [allGrpDexDoc, setAllGrpDexDoc] = useState([]);
    const [currentGrpDexDoc, setCurrentGrpDexDoc] = useState('');
    const [allDocType, setAllDocType] = useState([]);
    const [currentDocType, setCurrentDocType] = useState('');
    const inputFile = useRef(null);
    const classes = useStyles();
    const [fileData, setFileData] = useState(null);
    const [isMultiDoc, setIsMultiDoc] = useState(false);
    const theme = useTheme();
    const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
    const usrInfo = props.userInfo;
    useEffect(() => {
        dispatch(Actions.getAllDocType());
        dispatch(Actions.getAllGroupDoc());
        dispatch(Actions.getAllGroupDexDoc());
        if (usrInfo.isRoot === 'N') {
            setCurrentCom(usrInfo.coCd);
        }
    }, []);

    // Open Dialog
    useEffect(() => {
        setOpenDialog(flgUploadDialog);
    }, [flgUploadDialog]);

    // Load document Type and group doc when choose Location
    useEffect(() => {
        const grpAll = [];
        if (currentLoc && currentCom) {
            Object.keys(groupDocs).forEach(group => {
                const crrDexLoc = groupDocs[group].dex_loc;
                if (crrDexLoc) {
                    Object.keys(crrDexLoc).forEach(location => {
                        if (crrDexLoc[location].co_cd === currentCom && crrDexLoc[location].loc_cd === currentLoc) {
                            if (grpAll.length === 0) {
                                grpAll.push({
                                    doc_nm: groupDocs[group].doc_nm,
                                    doc_tp_id: groupDocs[group].doc_tp_id,
                                });
                            } else if (
                                grpAll.includes({
                                    doc_nm: groupDocs[group].doc_nm,
                                    doc_tp_id: groupDocs[group].doc_tp_id,
                                })
                            ) {
                                grpAll.push({
                                    doc_nm: groupDocs[group].doc_nm,
                                    doc_tp_id: groupDocs[group].doc_tp_id,
                                });
                            }
                        }
                    });
                }
            });
            const docType = [];
            data.filter(item => item.co_cd === currentCom)
                .filter(item => item.loc_cd === currentLoc)
                .map(item => {
                    docType.push(item.doc_tp_id);
                });
            const docTypeTmp = [];
            Object.keys(documents).forEach(keyDoc => {
                let flgExist = false;
                Object.keys(groupDocs).forEach(function (keyGrp) {
                    if (documents[keyDoc].doc_tp_id === groupDocs[keyGrp].doc_tp_id) {
                        flgExist = true;
                    }
                });
                if (!flgExist) {
                    docTypeTmp.push(documents[keyDoc]);
                }
            });
            const allDocNotGrp = docTypeTmp.filter(item => docType.includes(item.doc_tp_id));
            setAllDocType(allDocNotGrp);
        }
        setAllGrpDoc(grpAll);
    }, [currentLoc]);

    // Load Location when choose Company
    useEffect(() => {
        const locAll = [];
        const allLocs = [];
        if (currentCom !== '') {
            data.filter(item => item.co_cd === currentCom).map(item => {
                if (!allLocs.includes(item.loc_cd)) {
                    locAll.push(item);
                    allLocs.push(item.loc_cd);
                }
            });
        }
        setAllLoc(locAll);
        setAllDocType([]);
    }, [currentCom, data]);

    // Load group dex doc and doc type when choose group
    useEffect(() => {
        setCurrentGrpDexDoc('');
        const allDocName = [];
        if (currentLoc && currentCom && currentGrpDoc) {
            Object.keys(groupDexDocs).forEach(group => {
                if (groupDexDocs[group].doc_tp_id === currentGrpDoc) {
                    Object.keys(groupDexDocs[group].dex_doc).forEach(docType => {
                        if (
                            groupDexDocs[group].dex_doc[docType].loc_cd === currentLoc &&
                            groupDexDocs[group].dex_doc[docType].co_cd === currentCom
                        ) {
                            allDocName.push({
                                doc_id: groupDexDocs[group].dex_doc[docType].doc_id,
                                doc_nm: groupDexDocs[group].dex_doc[docType].doc_nm,
                            });
                        }
                    });
                }
            });
        }
        setAllGrpDexDoc(allDocName);
        setAllDocType(docTypeofGroup);
    }, [currentGrpDoc, groupDexDocs, docTypeofGroup]);

    const commonResetValue = () => {
        setCurrentLoc('');
        setCurrentGrpDoc('');
        setCurrentDocType('');
        setFileData(null);
    };

    const handleClose = () => {
        dispatch(Actions.setFlgUpload(false));
        setOpenDialog(false);
        setCurrentLoc('');
        setCurrentCom(usrInfo.isRoot === 'N' ? usrInfo.coCd : '');
        setCurrentGrpDexDoc('');
        commonResetValue();
    };

    const handleCompanyChange = event => {
        setCurrentCom(event);
        commonResetValue();
    };

    const handleChangeLoc = event => {
        setCurrentGrpDexDoc('');
        commonResetValue();
        setCurrentLoc(event);
    };

    const handleCheckGrp = event => {
        setCurrentDocType('');
        setFileData(null);
        setForm(form => ({
            ...form,
            grp_flg: event.target.checked,
            classGrp: event.target.checked ? '' : 'hidden',
        }));
        if (!event.target.checked) {
            setCurrentLoc('');
            setCurrentGrpDoc('');
            setCurrentGrpDexDoc('');
        }
    };

    const handleAdNm = () => {
        setCurrentDocType('');
        let locData = allLoc.find(loc => loc.loc_id === currentLoc);
        locData = locData ? { locId: locData.loc_id, locCd: locData.loc_cd } : {};
        if (form.grpNm && usrInfo.usrId && currentCom && locData && currentGrpDoc) {
            dispatch(
                Actions.addDexDocGrp(
                    form.grpNm,
                    usrInfo.usrId,
                    currentCom,
                    locData.locId,
                    locData.locCd,
                    currentGrpDoc,
                ),
            );
            setCurrentGrpDexDoc(form.grpNm);
        } else {
            showMessage({
                message: MsgNotifications.GENERAL,
                variant: 'error',
            });
        }
        setForm(form => ({
            ...form,
            grpNm: '',
            classNmGrp: form.classNmGrp ? '' : 'hidden',
        }));
    };

    const handleChgNm = event => {
        setForm(form => ({
            ...form,
            grpNm: event,
        }));
    };

    const handleChangeGrpDoc = event => {
        setCurrentGrpDoc(event);
        dispatch(Actions.getDocType(event));
        setCurrentGrpDexDoc('');
        setCurrentDocType('');
        setFileData(null);
    };

    const handleChangeGrpDocNm = event => {
        setCurrentGrpDexDoc(event);
        setCurrentDocType('');
        setFileData(null);
    };

    const handleChangeDoc = event => {
        setCurrentDocType(event.target.value);
        setFileData(null);
    };

    const handleChooseFile = event => {
        setFileData(event);
    };

    function chooseFile(event) {
        event.preventDefault();
        inputFile.current.click();
    }

    function handleUploadDoc() {
        // get url
        setOpenDialog(false);
        dispatch(Actions.setFlgUpload(false));
        if (isMultiDoc) {
            history.push({
                pathname: '/extract/view-doc/multi-doc',
                state: {
                    locsData: data,
                    comData: companies.filter(item => item.coCd === currentCom)[0],
                    locCd: currentLoc,
                    file: fileData,
                },
            });
        } else {
            let urlFolder = '';
            const docId = currentGrpDoc || currentDocType;
            data.filter(item => item.co_cd === currentCom)
                .filter(item => item.loc_cd === currentLoc)
                .filter(item => item.doc_tp_id === docId)
                .map(item => {
                    urlFolder = `${item.fol_loc_url.substring(1)}/Output`;
                });
            let locData = data.find(
                loc =>
                    loc.loc_cd === currentLoc && loc.doc_tp_id === currentDocType && loc.co_cd === currentCom,
            );
            locData = locData ? { locId: locData.loc_id, locCd: locData.loc_cd } : {};
            if (urlFolder) {
                const formData = new FormData();
                formData.append('myFile', fileData);
                formData.append('urlFolder', urlFolder);
                formData.append('cre_usr_id', usrInfo.usrId);
                formData.append('co_cd', currentCom);
                formData.append('loc_id', locData.locId);
                formData.append('loc_cd', locData.locCd);
                formData.append('doc_grp_id', currentGrpDoc);
                formData.append('prnt_doc_id', currentGrpDexDoc);
                formData.append('doc_tp_id', currentDocType);
                formData.append('root_nm', fileData.name);
                // fileSize is Kb
                formData.append('file_sz', (fileData.size / 1024).toFixed(1));
                const config = {
                    headers: {
                        'content-type': 'multipart/form-data',
                    },
                };
                dispatch(Actions.changeLoadingStatus(true));
                const currentTime = new Date();
                props.startUploadTime.current = currentTime.getTime();
                console.log(`Start upload file at: ${formatDateTimeString(currentTime)} - Document: ${fileData.name}`);
                dispatch(Actions.uploadFileData(formData, config));
            }
        }
    }

    return (
        <div>
            <Dialog
                open={openDialog}
                fullScreen={fullScreen}
                onClose={handleClose}
                aria-labelledby="responsive-dialog-title"
            >
                <AppBar position="static" elevation={1}>
                    <Toolbar className="flex w-full">
                        <Typography className="w-full" variant="subtitle1" color="inherit">
                            Upload Form
                        </Typography>
                        <IconButton className="float-right" onClick={handleClose}>
                            <Icon>close</Icon>
                        </IconButton>
                    </Toolbar>
                </AppBar>
                <DialogContent classes={{ root: 'pb-0 sm:p-24 text-black' }}>
                    <div className="flex flex-row w-full">
                        <SearchTextField
                            variant="outlined"
                            className="flex flex-1 pb-12 text-black border-gray-900 w-2/5"
                            onChange={e => handleCompanyChange(e.target.value)}
                            label="Company"
                            select
                            value={currentCom}
                            disabled={usrInfo.isRoot === 'N'}
                            InputLabelProps={{
                                className: 'test-label',
                            }}
                        >
                            {_.orderBy(companies, ['coCd'], ['asc']).map(item => (
                                <MenuItem key={item.coCd} value={item.coCd}>
                                    {item.coNm}
                                </MenuItem>
                            ))}
                        </SearchTextField>
                        <SearchTextField
                            variant="outlined"
                            className="flex flex-1 pb-12 text-black border-gray-900 w-2/5"
                            onChange={e => handleChangeLoc(e.target.value)}
                            label="Location"
                            select
                            value={currentLoc}
                            disabled={currentCom === '' || allLoc.length < 1}
                            InputLabelProps={{
                                className: 'test-label',
                            }}
                        >
                            {_.orderBy(allLoc, ['loc_cd'], ['asc']).map(item => (
                                <MenuItem key={item.loc_cd} value={item.loc_cd}>
                                    {item.loc_nm}
                                </MenuItem>
                            ))}
                        </SearchTextField>
                        <FormControlLabel
                            className="w-1/5"
                            label="Group"
                            control={
                                <Checkbox
                                    onChange={handleCheckGrp}
                                    name="grp_flg"
                                    color="secondary"
                                    checked={form.grp_flg}
                                />
                            }
                        />
                    </div>
                    <div className={`flex flex-row w-4/5 ${form.classGrp}`}>
                        <SearchTextField
                            className="flex flex-1 pb-12 w-full"
                            value={currentGrpDoc}
                            onChange={e => handleChangeGrpDoc(e.target.value)}
                            label="Group doc"
                            select
                            disabled={allGrpDoc.length < 1}
                            InputLabelProps={{
                                className: 'test-label',
                            }}
                        >
                            {_.orderBy(allGrpDoc, ['doc_nm'], ['asc']).map(item => (
                                <MenuItem key={item.doc_nm} value={item.doc_tp_id}>
                                    {item.doc_nm}
                                </MenuItem>
                            ))}
                        </SearchTextField>
                    </div>
                    <div className={`flex flex-row ${form.classGrp}`}>
                        <SearchTextField
                            className="flex flex-1 w-4/5"
                            onChange={e => handleChangeGrpDocNm(e.target.value)}
                            label="Name of group"
                            value={currentGrpDexDoc}
                            select
                            disabled={allGrpDexDoc.length < 1}
                            InputLabelProps={{
                                className: 'test-label',
                            }}
                        >
                            {_.orderBy(allGrpDexDoc, ['doc_nm'], ['asc']).map(item => (
                                <MenuItem key={item.doc_nm} value={item.doc_id}>
                                    {item.doc_nm}
                                </MenuItem>
                            ))}
                        </SearchTextField>
                        <div className="w-1/5">
                            <IconButton className="w-3/6" disabled={!currentGrpDoc} onClick={handleAdNm}>
                                <Icon>add_box</Icon>
                            </IconButton>
                        </div>
                    </div>
                    <div className={`flex flex-row ${form.classNmGrp}`}>
                        <Input
                            label="Add Name"
                            className="w-4/5"
                            color="primary"
                            value={form.grpNm}
                            onChange={e => handleChgNm(e.target.value)}
                            endAdornment={
                                <InputAdornment position="end">
                                    <IconButton onClick={handleAdNm}>
                                        <Icon>check</Icon>
                                    </IconButton>
                                </InputAdornment>
                            }
                        />
                    </div>

                    {/* process place */}
                    <div className="flex flex-row w-full">
                        <SearchTextField
                            className="flex-initital pb-12 -mr-1 w-4/5"
                            value={currentDocType}
                            onChange={handleChangeDoc}
                            label="Document type"
                            select
                            disabled={
                                (currentLoc === '' && !form.grp_flg) ||
                                (currentGrpDexDoc === '' && form.grp_flg) ||
                                allDocType.length < 1 ||
                                isMultiDoc
                            }
                            InputLabelProps={{
                                className: 'test-label',
                            }}
                        >
                            {_.orderBy(allDocType, ['doc_nm'], ['asc']).map(item => (
                                <MenuItem key={item.doc_nm} value={item.doc_tp_id}>
                                    {item.doc_nm}
                                </MenuItem>
                            ))}
                        </SearchTextField>
                        <FormControlLabel
                            className="flex-initital w-1/5 pl-2"
                            label="Multi doc"
                            control={
                                <Checkbox
                                    onChange={() => setIsMultiDoc(!isMultiDoc)}
                                    name="multi_doc"
                                    color="secondary"
                                    checked={isMultiDoc}
                                />
                            }
                        />
                    </div>

                    <div className="flex flex-row w-full">
                        <SearchTextField
                            className="flex flex-1 w-4/5"
                            label="File name"
                            autoFocus
                            id="fileName"
                            name="fileName"
                            value={fileData ? fileData.name : 'Document file'}
                            variant="outlined"
                            disabled
                            size="small"
                        />

                        <form encType="multipart/form-data" className="w-1/5">
                            <div className="py-2">
                                <input
                                    onChange={event => {
                                        event.preventDefault();
                                        handleChooseFile(event.target.files[0]);
                                    }}
                                    // eslint-disable-next-line no-param-reassign
                                    onClick={event => (event.target.value = null)}
                                    ref={inputFile}
                                    hidden
                                    accept={AppConstants.INCLUDE_FILE_TYPES}
                                    type="file"
                                    name="myFile"
                                    id="fileData"
                                />
                                <Button
                                    classes={{
                                        root: classes.root, // class name, e.g. `classes-nesting-root-x`
                                    }}
                                    onClick={event => {
                                        chooseFile(event);
                                    }}
                                    variant="contained"
                                    color="primary"
                                    disabled={!currentDocType && !(isMultiDoc && currentCom && currentLoc)}
                                >
                                    Choose File
                                </Button>
                            </div>
                        </form>
                    </div>
                    <div className="flex flex-row w-full pt-8">
                        <Button
                            classes={{
                                root: classes.label,
                            }}
                            disabled={!fileData}
                            className="w-full"
                            onClick={handleUploadDoc}
                            variant="contained"
                            color="primary"
                        >
                            UPLOAD
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
}

export default UploadDialog;

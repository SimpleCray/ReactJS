import React, { useEffect, useRef } from 'react';
import { FusePageCarded } from '@fuse';
import withReducer from 'app/store/withReducer';
import { useDispatch, useSelector } from 'react-redux';
import { CircularProgress } from '@material-ui/core';
import reducer from './store/reducers/reducers';
import ViewDocHeader from './viewDocHeader';
import ViewDocTable from './viewDocTable';
import 'styles/scss/commons.scss';
import * as CommonActions from 'app/store/actions';
import history from '@history';
import * as Actions from './store/actions/actions';
import * as Functions from './viewDocFuctions';
import { getTimingRangeMSec, sumOfArray } from 'app/utils/utils';
import AppConstants from 'app/utils/appConstants';
import MsgNotifications from 'app/utils/msgNotifications';

let loadingTimeOut = null;

// TODO: Need to add loading, error here
export const ViewDoc = () => {
    const dispatch = useDispatch();
    const loading = useSelector(({ viewDoc }) => viewDoc.loading);
    const uploadProc = useSelector(({ viewDoc }) => viewDoc.uploadProc);
    const matchingProc = useSelector(({ viewDoc }) => viewDoc.matchingProc);
    const extractProc = useSelector(({ viewDoc }) => viewDoc.extractProc);
    const uploadProcError = useSelector(({ viewDoc }) => viewDoc.error);
    const templateId = useSelector(({ viewDoc }) => viewDoc.templateId);
    const templateType = useSelector(({ viewDoc }) => viewDoc.templateType);
    const uploadedData = useSelector(({ viewDoc }) => viewDoc.uploadedData);
    const startUploadTime = useRef(new Date().getTime());
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));

    const showMsgViewDoc = (msg, msgType) => {
        dispatch(
            CommonActions.showMessage({
                message: msg,
                variant: msgType,
            }),
        );
    };

    useEffect(() => dispatch(Actions.initUploadProc()), []);

    useEffect(() => {
        if (uploadProcError) {
            showMsgViewDoc(MsgNotifications.VIEW_DOC.COULD_NOT_UPLOAD_FILE, 'error');
            dispatch(Actions.initUploadProc());
        }
    }, [uploadProcError]);

    /** *********** START UPLOAD PROCESS ************ */
    useEffect(() => {
        const uploadProcData = uploadProc.data;
        if (uploadProc.status && Object.keys(uploadProcData).length > 0) {
            const uploadedDataObj = {
                docTypeId: uploadProcData.doc_type,
                locCd: uploadProcData.loc_cd,
                comCd: uploadProcData.co_cd,
                docId: uploadProcData.doc_id,
                parentDocId: uploadProcData.prnt_doc_id,
                fileName: uploadProcData.file_url ? uploadProcData.file_url.split('/').pop() : '',
            };
            showMsgViewDoc(MsgNotifications.VIEW_DOC.ON_MATCHING_PROC, 'info');
            dispatch(Actions.storeUploadedData(uploadedDataObj));
            dispatch(Functions.makeMatchingProc(uploadProcData));
        }
    }, [uploadProc.status]);

    /**
     * If matching return annotated status true => View result
     * If matching return annotated status false => Check and getting templateId => Annotation
     */
    useEffect(() => {
        const matchingData = matchingProc.data;
        if (uploadProc.status && matchingProc.status && Object.keys(matchingData).length > 0) {
            const docId = uploadProc.data.doc_id;
            const currentDate = new Date();
            const endTime = currentDate.getTime();
            const totalTimeToExt = getTimingRangeMSec(endTime, startUploadTime.current);
            const matchingLog = `Matching success after: ${totalTimeToExt.minute} mins ${totalTimeToExt.sec} secs`;
            console.log(`OCR TIME Matching: ${sumOfArray(matchingData.ocr_time)}`);
            if (matchingData.is_annotated) {
                Functions.updateTemplateForDoc(docId, matchingData.tmp_id);
                showMsgViewDoc(MsgNotifications.VIEW_DOC.DOCUMENT_IS_BEING_EXTRACTED, 'info');
                dispatch(
                    Functions.makeExtractProc(
                        uploadProc.data,
                        matchingData,
                        uploadedData.locCd,
                        uploadedData.docTypeId,
                    ),
                );
            } else {
                dispatch(Functions.updateTemplateInfo(matchingData, uploadedData.docTypeId, docId));
            }
            startUploadTime.current = new Date().getTime();
            console.log(`${!matchingData.is_annotated ? 'Not ' : ''}Annotated - ${matchingLog}`);
        }
    }, [matchingProc.status]);

    // This func is used to redirect to annotation page
    useEffect(() => {
        if (matchingProc.status && templateType && templateId) {
            // Update template type, id into dex_doc before open annotation
            // Update root_url, img_url...
            dispatch(Actions.initUploadProc());
            Functions.updateTemplateForDoc(uploadProc.data.doc_id, templateId);
            const url = `/extract/annotation/${templateType}/${templateId}`;
            dispatch(
                CommonActions.showMessage({
                    message: MsgNotifications.VIEW_DOC.ON_OPEN_ANNOTATE_UI,
                    variant: 'info',
                }),
            );
            setTimeout(() => {
                history.push(url);
            }, 300);
        }
    }, [templateType, templateId]);

    useEffect(async () => {
        const extractedData = extractProc.data;
        if (uploadProc.status && extractProc.status && Object.keys(extractedData).length > 0) {
            try {
                const docId = uploadProc.data.doc_id;
                const tmpltVer = await Functions.getTemplateVersion(matchingProc.data.tmp_id);
                extractedData.data.tmplt_ver_val = tmpltVer;
                await Functions.saveExtractAndRunBiz(docId, extractedData, uploadedData.docTypeId);
                // Calling view Result
                dispatch(Actions.initUploadProc());
                const currentDate = new Date();
                const endTime = currentDate.getTime();
                const totalTimeToExt = getTimingRangeMSec(endTime, startUploadTime.current);
                console.log(
                    `Extracted - Extracted succesfull after: ${totalTimeToExt.minute} mins ${totalTimeToExt.sec} secs`,
                );
                console.log(`OCR TIME Extraction: ${sumOfArray(extractedData.ocr_time)}`);
                dispatch(Actions.changeLoadingStatus(false));
                if (uploadedData.parentDocId) {
                    history.push(`/info-extracted/${uploadedData.parentDocId}`);
                } else {
                    history.push(`/info-extracted/${docId}`);
                }
            } catch (err) {
                const issueList = [AppConstants.DOC_ISSUES_CODE.SYS];
                const replaceOldIssue = true;
                Functions.updateIssueStatusDoc(
                    uploadProc.data.doc_id,
                    AppConstants.DOC_STATUS_CODE.F,
                    issueList,
                    replaceOldIssue,
                );
                dispatch(Actions.changeLoadingStatus(false));
                dispatch(Actions.initUploadProc());
                dispatch(CommonActions.openDialog(err.message, 'Error', 'Alert'));
            }
        }
    }, [extractProc.status]);
    /** *********** END UPLOAD PROCESS ************ */

    // If loading is over 2 mins 30 secs, close loading, show error -> routing
    useEffect(() => {
        if (loading) {
            // count time
            loadingTimeOut = setTimeout(() => {
                clearTimeout(loadingTimeOut);
                dispatch(
                    CommonActions.showMessage({
                        message: MsgNotifications.GENERAL,
                        variant: 'error',
                    }),
                );
                dispatch(Actions.initUploadProc());
            }, AppConstants.TIMEOUT_LOADING);
        } else {
            clearTimeout(loadingTimeOut);
        }
    }, [loading]);

    return !loading ? (
        <FusePageCarded
            classes={{
                content: 'flex',
                header: 'h-auto min-h-0 max-h-full',
                contentWrapper: 'pr-0 pl-0',
            }}
            header={<ViewDocHeader userInfo={userInfo} />}
            content={<ViewDocTable startUploadTime={startUploadTime} userInfo={userInfo} />}
            innerScroll
        />
    ) : (
        <div className="circleloading">
            <CircularProgress size={200} />
        </div>
    );
};

export default withReducer('viewDoc', reducer)(ViewDoc);

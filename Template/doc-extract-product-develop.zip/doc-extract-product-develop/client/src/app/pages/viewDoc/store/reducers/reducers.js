/* eslint-disable func-names */
import * as Actions from '../actions/actions';

const initialState = {
    loading: false,
    companyData: [],
    locationData: [],
    documentData: [],
    uploadProc: {
        status: null,
        data: {},
    },
    matchingProc: {
        status: null,
        data: {},
    },
    extractProc: {
        status: null,
        data: {},
    },
    selectedFileName: '', // Used for save file name in store => annotation
    allDocTypeByLoc: [],
    documentTypeId: '',
    selectedLocId: '',
    selectedComId: '',
    dexDocData: [],
    searchText: '',
    flgUploadDialog: false,
    groupDocumentData: [],
    docTypeOfGroup: [],
    groupDocs: [],
    groupDexDocs: [],
    error: false,
    templateType: '',
    templateId: '',
    uploadedData: {
        docTypeId: '',
        locCd: '',
        comCd: '',
        docId: '',
        parentDocId: '',
        fileUrl: '',
        fileName: '',
        locId: '',
    },
    initLocData: [],
    saveSuccess: null,
    countDocument: 0,
    filterParams: {
        co_cd: '',
        loc_nm: 'All',
        doc_tp_id: 'All',
        sts_cd: 'All',
        from_date: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toLocaleDateString('en-CA'),
        to_date: new Date().toLocaleDateString('en-CA'),
        extend_search: '',
        match_exactly: false,
        page_number: 0,
        row_per_page: 25,
    },
};

export default function viewDocReducer(state = initialState, action) {
    switch (action.type) {
        case Actions.GET_DEX_DOC_COMPANIES: {
            return {
                ...state,
                companyData: action.companyData,
                loading: false,
            };
        }
        case Actions.GET_LOCATION_DATA: {
            return {
                ...state,
                allDocTypeByLoc: action.locationData,
            };
        }
        case Actions.GET_DEX_DOC: {
            return {
                ...state,
                dexDocData: action.payload.rows,
                countDocument: action.payload.count,
                loading: false,
            };
        }
        case Actions.UPLOAD_FILE_SUCCESS: {
            // file_url: newFullPath, file_id: docId, file_type: fileType, file_size: req.body.file_sz
            return {
                ...state,
                uploadProc: {
                    status: true,
                    data: action.data,
                },
            };
        }
        case Actions.UPLOAD_FILE_ERROR: {
            return {
                ...state,
                loading: false,
                uploadProc: {
                    status: false,
                    data: {},
                },
                error: true,
            };
        }
        case Actions.SET_DEX_DOC_NAME_SEARCH_TEXT: {
            return {
                ...state,
                searchText: action.searchText,
            };
        }
        case Actions.SET_FLAG_POPUP_UPLOAD: {
            return {
                ...state,
                flgUploadDialog: action.flgUploadDialog,
            };
        }

        case Actions.GET_ALL_GROUP: {
            return {
                ...state,
                groupDocs: action.payload,
            };
        }
        case Actions.GET_ALL_GROUP_DEX_DOC: {
            return {
                ...state,
                groupDexDocs: action.groupDexDocs,
            };
        }
        case Actions.GET_DOC_TYPE: {
            return {
                ...state,
                docTypeOfGroup: action.payload,
            };
        }
        case Actions.GET_DEX_DOC_DOC_TYPE_SUCCESS: {
            return {
                ...state,
                documentData: action.payload,
            };
        }

        case Actions.MATCHING_SUCCESS: {
            console.log('---- MATCHING SUCCESS ----');
            return {
                ...state,
                matchingProc: {
                    status: true,
                    data: action.data,
                },
            };
        }
        case Actions.MATCHING_ERROR: {
            console.log('---- MATCHING ERROR ----');
            return {
                ...state,
                matchingProc: {
                    status: false,
                    data: {},
                },
                error: true,
                loading: false,
            };
        }
        case Actions.EXTRACTION_SUCCESS: {
            console.log('---- EXTRACT SUCCESS ----');
            return {
                ...state,
                extractProc: {
                    status: true,
                    data: action.data,
                },
                loading: true,
            };
        }
        case Actions.EXTRACTION_ERROR: {
            console.log('---- EXTRACT ERROR ----');
            return {
                ...state,
                extractProc: {
                    status: false,
                    data: {},
                },
                error: true,
                loading: false,
            };
        }
        case Actions.INIT_UPLOAD_PROC: {
            return {
                ...state,
                error: false,
                loading: false,
                extractProc: {
                    status: null,
                    data: {},
                },
                matchingProc: {
                    status: null,
                    data: {},
                },
                uploadProc: {
                    status: null,
                    data: {},
                },
                templateType: '',
                templateId: '',
            };
        }
        case Actions.CHANGE_LOADING_STATUS: {
            return {
                ...state,
                loading: action.loadingStatus,
            };
        }
        case Actions.UPDATE_TEMPLATE_INFO: {
            return {
                ...state,
                templateType: action.templateType,
                templateId: action.templateId,
            };
        }
        case Actions.SAVE_UPLOADED_DATA: {
            const { uploadedData } = action;
            return {
                ...state,
                uploadedData: {
                    docTypeId: uploadedData.docTypeId,
                    locCd: uploadedData.locCd,
                    comCd: uploadedData.comCd,
                    docId: uploadedData.docId,
                    parentDocId: uploadedData.parentDocId,
                    fileName: uploadedData.fileName,
                    locId: uploadedData.locId,
                },
            };
        }
        case Actions.INIT_UPLOADED_DATA: {
            return {
                ...state,
                uploadedData: {
                    docTypeId: '',
                    locCd: '',
                    comCd: '',
                    docId: '',
                    parentDocId: '',
                    fileName: '',
                },
            };
        }
        case Actions.GET_INIT_LOC_DATA: {
            return {
                ...state,
                initLocData: action.payload,
            };
        }
        case Actions.SET_FILTER_PARAM: {
            return {
                ...state,
                filterParams: action.params,
            };
        }
        case Actions.SAVE_MULTI_DOC_SUCCESS: {
            return {
                ...state,
                saveSuccess: action.data,
            };
        }
        case Actions.RESET_SPLITDOC_STATE: {
            return {
                ...state,
                saveSuccess: null,
            };
        }
        default: {
            return state;
        }
    }
}

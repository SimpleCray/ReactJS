import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { IconButton, FormControl, Tooltip, Checkbox, FormControlLabel } from '@material-ui/core';
import { CloudUpload } from '@material-ui/icons';
import { makeStyles } from '@material-ui/styles';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import Autocomplete from '@material-ui/lab/Autocomplete';
import CustomButton from 'app/components/Button';
import TextField from 'app/components/SearchTextField';
import AppConstants from 'app/utils/appConstants';
import DateFnsUtils from '@date-io/date-fns';
import _ from '@lodash';

import * as Actions from './store/actions/actions';

const useStyles = makeStyles({
    searchBar: {
        width: '20ch',
        margin: 3,
    },
    searchInput: {
        width: '250px',
    },
});

function ViewDocHeader(props) {
    const classes = useStyles();
    const dispatch = useDispatch();

    const companies = useSelector(({ viewDoc }) => viewDoc.companyData);
    const documents = useSelector(({ viewDoc }) => viewDoc.documentData);
    const locations = useSelector(({ viewDoc }) => viewDoc.initLocData);
    const filterParams = useSelector(({ viewDoc }) => viewDoc.filterParams);

    const renderCompany = () => {
        if (companies && Array.isArray(companies)) {
            const parseCompanies = companies.map(item => ({ co_cd: item.coCd, co_nm: item.coNm }));
            return [{ co_cd: 'All', co_nm: 'All' }, ...parseCompanies];
        }
        return [{ co_cd: 'All', co_nm: 'All' }];
    };

    const renderLocation = () => {
        if (locations && Array.isArray(locations)) {
            const parseLocation = locations.flatMap(item => {
                const matchCompany =
                    !filterParams.co_cd || filterParams.co_cd === 'All' || filterParams.co_cd === item.co_cd;
                return matchCompany ? { loc_id: item.loc_id, loc_nm: item.loc_nm } : [];
            });
            return _.uniqBy([{ loc_id: 'All', loc_nm: 'All' }, ...parseLocation], 'loc_nm');
        }
        return [{ loc_id: 'All', loc_nm: 'All' }];
    };

    const renderDocument = () => {
        if (documents && Array.isArray(documents)) {
            const getByCondition = locations.flatMap(item => {
                const matchCompany =
                    !filterParams.co_cd || filterParams.co_cd === 'All' || filterParams.co_cd === item.co_cd;
                const matchLocation =
                    !filterParams.loc_nm || filterParams.loc_nm === 'All' || filterParams.loc_nm === item.loc_nm;
                return matchCompany && matchLocation ? item.doc_tp_id : [];
            });
            const parseDocument = documents.flatMap(item =>
                getByCondition.includes(item.doc_tp_id) ? { doc_tp_id: item.doc_tp_id, doc_nm: item.doc_nm } : [],
            );
            return [{ doc_tp_id: 'All', doc_nm: 'All' }, ...parseDocument];
        }
        return [{ doc_tp_id: 'All', doc_nm: 'All' }];
    };

    const renderStatus = () => {
        const statusList = Object.keys(AppConstants.DOC_STATUS).map(item => ({
            sts_cd: item,
            sts_nm: AppConstants.DOC_STATUS[item],
        }));
        return [{ sts_cd: 'All', sts_nm: 'All' }, ...statusList.slice(0, -1)];
    };

    useEffect(() => {
        dispatch(Actions.getCompanies());
        dispatch(Actions.getLocationData());
        dispatch(Actions.getInitLocData());
    }, [dispatch]);

    useEffect(() => {
        if (
            props.userInfo &&
            (!filterParams.co_cd || (props.userInfo.coCd !== filterParams.co_cd && props.userInfo.usrId !== 'admin'))
        ) {
            const initialFilter = {
                co_cd: props.userInfo.usrId === 'admin' ? 'All' : props.userInfo.coCd,
                loc_nm: 'All',
                doc_tp_id: 'All',
                sts_cd: 'All',
                from_date: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toLocaleDateString('en-CA'),
                to_date: new Date().toLocaleDateString('en-CA'),
                extend_search: '',
                match_exactly: false,
                page_number: 0,
                row_per_page: 25,
            };
            dispatch(Actions.getDexDoc(initialFilter));
            dispatch(Actions.setFilter(initialFilter));
        }
    }, [dispatch]);

    const handleSearch = () => {
        const updateFilter = { ...filterParams, page_number: 0 };
        dispatch(Actions.getDexDoc(updateFilter));
        dispatch(Actions.setFilter(updateFilter));
    };

    return (
        <div className="flex w-full items-center">
            <div className="flex w-full items-center flex-wrap py-10 sm:p-9 md:p-7 lg:py-5 xl:py-2">
                <div className="flex-none px-15">
                    <Autocomplete
                        className={classes.searchBar}
                        size="small"
                        options={renderCompany()}
                        getOptionLabel={option => option.co_nm || ''}
                        value={
                            renderCompany()?.find(item => item.co_cd === filterParams.co_cd) || {
                                co_cd: 'All',
                                co_nm: 'All',
                            }
                        }
                        renderInput={params => <TextField {...params} label="Company Name" variant="outlined" />}
                        disabled={props.userInfo.usrId !== 'admin'}
                        onChange={(e, value) =>
                            dispatch(
                                Actions.setFilter({
                                    ...filterParams,
                                    co_cd: value?.co_cd ? value.co_cd : 'All',
                                    loc_nm: 'All',
                                    doc_tp_id: 'All',
                                }),
                            )
                        }
                    />
                </div>

                <div className="flex-none px-15">
                    <Autocomplete
                        className={classes.searchBar}
                        size="small"
                        options={renderLocation()}
                        getOptionLabel={option => option.loc_nm || ''}
                        value={
                            renderLocation()?.find(item => item.loc_nm === filterParams.loc_nm) || {
                                loc_id: 'All',
                                loc_nm: 'All',
                            }
                        }
                        renderInput={params => <TextField {...params} label="Location Name" variant="outlined" />}
                        onChange={(e, value) =>
                            dispatch(
                                Actions.setFilter({
                                    ...filterParams,
                                    loc_nm: value?.loc_nm ? value.loc_nm : 'All',
                                    doc_tp_id: 'All',
                                }),
                            )
                        }
                    />
                </div>

                <div className="flex-none px-15">
                    <Autocomplete
                        className={classes.searchBar}
                        size="small"
                        options={renderDocument()}
                        getOptionLabel={option => option.doc_nm || ''}
                        value={
                            renderDocument()?.find(item => item.doc_tp_id === filterParams.doc_tp_id) || {
                                doc_tp_id: 'All',
                                doc_nm: 'All',
                            }
                        }
                        renderInput={params => <TextField {...params} label="Document Name" variant="outlined" />}
                        onChange={(e, value) =>
                            dispatch(
                                Actions.setFilter({
                                    ...filterParams,
                                    doc_tp_id: value?.doc_tp_id ? value.doc_tp_id : 'All',
                                }),
                            )
                        }
                    />
                </div>

                <div className="flex-none px-15">
                    <Autocomplete
                        className={classes.searchBar}
                        size="small"
                        options={renderStatus()}
                        getOptionLabel={option => option.sts_nm || ''}
                        value={
                            renderStatus()?.find(item => item.sts_cd === filterParams.sts_cd) || {
                                sts_cd: 'All',
                                sts_nm: 'All',
                            }
                        }
                        renderInput={params => <TextField {...params} label="Document Status" variant="outlined" />}
                        onChange={(e, value) =>
                            dispatch(
                                Actions.setFilter({ ...filterParams, sts_cd: value?.sts_cd ? value.sts_cd : 'All' }),
                            )
                        }
                    />
                </div>

                <div className="flex-none px-15">
                    <FormControl
                        size="small"
                        variant="outlined"
                        className={`${classes.searchBar} ${classes.formControl}`}
                    >
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <KeyboardDatePicker
                                disableToolbar
                                size="small"
                                label="From Date"
                                value={filterParams?.from_date}
                                onChange={val => dispatch(Actions.setFilter({ ...filterParams, from_date: val }))}
                                format="dd/MM/yyyy"
                                variant="inline"
                                inputVariant="outlined"
                                KeyboardButtonProps={{
                                    'aria-label': 'change date',
                                }}
                            />
                        </MuiPickersUtilsProvider>
                    </FormControl>
                    <FormControl size="small" variant="outlined" className={classes.searchBar}>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <KeyboardDatePicker
                                disableToolbar
                                size="small"
                                label="To Date"
                                value={filterParams?.to_date}
                                onChange={val => dispatch(Actions.setFilter({ ...filterParams, to_date: val }))}
                                format="dd/MM/yyyy"
                                variant="inline"
                                inputVariant="outlined"
                                KeyboardButtonProps={{
                                    'aria-label': 'change date',
                                }}
                            />
                        </MuiPickersUtilsProvider>
                    </FormControl>
                </div>

                <div className="flex-none px-15">
                    <TextField
                        fullWidth
                        className={`flex flex-1 ${classes.searchInput}`}
                        label="Doc ID / File name / Update user id"
                        size="small"
                        variant="outlined"
                        value={filterParams?.extend_search || ''}
                        onChange={e => dispatch(Actions.setFilter({ ...filterParams, extend_search: e.target.value }))}
                        InputLabelProps={{
                            shrink: true,
                        }}
                    />
                </div>

                <div className="flex-none px-15">
                    <FormControlLabel
                        control={
                            <Checkbox
                                size="small"
                                onChange={e =>
                                    dispatch(
                                        Actions.setFilter({
                                            ...filterParams,
                                            match_exactly: e.target.checked,
                                        }),
                                    )
                                }
                                checked={filterParams.match_exactly}
                            />
                        }
                        label="Exact match"
                    />
                </div>

                <div className="flex-none px-15">
                    <CustomButton className="whitespace-no-wrap" color="default" onClick={handleSearch}>
                        Search
                    </CustomButton>
                </div>
            </div>

            <div className="w-auto height-full flex items-center justify-center pr-3">
                <Tooltip title="Open Upload Form" style={{ alignItems: 'right' }}>
                    <IconButton color="secondary" component="span" onClick={() => dispatch(Actions.setFlgUpload(true))}>
                        <CloudUpload fontSize="large" />
                    </IconButton>
                </Tooltip>
            </div>
        </div>
    );
}

export default ViewDocHeader;

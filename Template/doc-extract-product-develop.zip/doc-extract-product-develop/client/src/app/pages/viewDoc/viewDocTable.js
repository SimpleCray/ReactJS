/* eslint-disable no-param-reassign */
/* eslint-disable default-case */
/* eslint-disable no-shadow */
/* eslint-disable react/prop-types */
/* eslint-disable no-unused-expressions */
/* eslint-disable import/no-unresolved */
import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TablePagination, TableRow, Tooltip, Typography } from '@material-ui/core';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import { FuseScrollbars } from '@fuse';
import { withRouter } from 'react-router-dom';
import _ from '@lodash';
import { useSelector, useDispatch } from 'react-redux';
import * as TableFnc from 'app/utils/tableFunctions';
import MsgNotifications from 'app/utils/msgNotifications';
import AppConstants from 'app/utils/appConstants';
import * as FuseAction from 'app/store/actions/fuse';
import moment from 'moment';
import 'styles/scss/view-doc.scss';
import { withStyles } from '@material-ui/core/styles';
import * as Actions from './store/actions/actions';
import ViewDocTableHeader from './viewDocTableHeader';
import ViewDocUploadDialog from './viewDocUploadDialog';
import SplitDocResultDialog from './splitDoc/SplitDocResultDialog';

const IssueToolTip = withStyles(theme => ({
    tooltip: {
        backgroundColor: '#F2EFEA',
        color: '#f16464',
        maxWidth: 300,
        fontSize: theme.typography.pxToRem(13),
        border: '1px solid #dadde9',
        padding: '7px',
    },
}))(Tooltip);

function ViewDocTable(props) {
    const dispatch = useDispatch();
    const dexDoc = useSelector(({ viewDoc }) => viewDoc.dexDocData);
    const searchText = useSelector(({ viewDoc }) => viewDoc.searchText);
    const locData = useSelector(({ viewDoc }) => viewDoc.initLocData);
    const companies = useSelector(({ viewDoc }) => viewDoc.companyData);
    const countDocument = useSelector(({ viewDoc }) => viewDoc.countDocument);
    const filterParams = useSelector(({ viewDoc }) => viewDoc.filterParams);

    const [selected, setSelected] = useState('');
    const [data, setData] = useState([]);
    const [order, setOrder] = useState({
        direction: 'asc',
        columnId: null,
    });
    const { userInfo } = props;

    useEffect(() => {
        if (dexDoc && locData && companies) {
            updateDetailTableDatas();
        }
    }, [dexDoc, locData, companies]);

    const updateDetailTableDatas = () => {
        Object.keys(dexDoc).forEach(keyDoc => {
            // Map company name
            const foundComData = companies.find(element => element.coCd === dexDoc[keyDoc].co_cd);
            if (foundComData) dexDoc[keyDoc].coNm = foundComData.coNm;
            else dexDoc[keyDoc].coNm = 'Undefined';
            // Update doc status
            if (dexDoc[keyDoc].sts_cd in AppConstants.DOC_STATUS) {
                dexDoc[keyDoc].status = AppConstants.DOC_STATUS[dexDoc[keyDoc].sts_cd];
            } else {
                dexDoc[keyDoc].status = dexDoc[keyDoc].sts_cd;
            }
            // Update doc issues
            if (dexDoc[keyDoc].doc_iss_cd && dexDoc[keyDoc].doc_iss_cd !== '[]') {
                const docIssList = JSON.parse(dexDoc[keyDoc].doc_iss_cd);
                dexDoc[keyDoc].issueList = [...new Set(docIssList)];
            }
        });
    };

    const getIssueToolTip = colData => {
        if (
            (colData.sts_cd === AppConstants.DOC_STATUS_CODE.E || colData.sts_cd === AppConstants.DOC_STATUS_CODE.F) &&
            colData.issueList
        ) {
            return (
                <IssueToolTip
                    title={
                        colData.issueList &&
                        colData.issueList.length > 0 && (
                            <React.Fragment>
                                <Typography color="inherit" fontSize="13px">
                                    Extracted Issues:
                                </Typography>
                                {colData.issueList.map(issue => {
                                    if (AppConstants.DOC_ISSUES[issue]) {
                                        return <li>{AppConstants.DOC_ISSUES[issue]}</li>;
                                    }
                                })}
                            </React.Fragment>
                        )
                    }
                    enterDelay={300}
                    placement="bottom-end"
                >
                    <ErrorOutlineIcon className="icon-doc-issue" />
                </IssueToolTip>
            );
        }
        return null;
    };

    useEffect(() => {
        const filterDexDocName =
            searchText.length > 0
                ? _.filter(dexDoc, item => {
                      const acceptDocumentName = item.doc_nm.toLowerCase().includes(searchText.toLowerCase());
                      const acceptupdateUserId = item.upd_usr_id.toLowerCase().includes(searchText.toLowerCase());
                      return acceptupdateUserId || acceptDocumentName;
                  })
                : dexDoc;
        setData(filterDexDocName);
    }, [dexDoc, searchText]);

    function handleDoubleClick(row) {
        if (row.sts_cd === AppConstants.DOC_STATUS_CODE.F) {
            dispatch(
                FuseAction.showMessage({
                    message: MsgNotifications.VIEW_DOC.DOCUMENT_EXTRACT_FAILED,
                    variant: 'error',
                }),
            );
        } else {
            const fileInfo = {
                docTypeId: row.doc_tp_id,
                locCd: row.loc_cd,
                comCd: row.co_cd,
                docId: row.doc_id,
                parentDocId: row.prnt_doc_id,
                fileName: row.doc_nm,
                locId: row.loc_id,
            };
            dispatch(Actions.storeUploadedData(fileInfo));
            if (row.sts_cd === AppConstants.DOC_STATUS_CODE.A || row.sts_cd === AppConstants.DOC_STATUS_CODE.N) {
                dispatch(Actions.changeLoadingStatus(true));
                const uploadProcData = {
                    doc_id: row.doc_id,
                    file_url: `${process.env.REACT_APP_DOC_LOC}/${row.co_cd}/${row.loc_cd}/${
                        row.adm_doc_tp.doc_cd
                    }/Output/${row.doc_nm}`,
                    co_cd: row.co_cd,
                    loc_cd: row.loc_cd,
                    doc_type: row.doc_tp_id,
                    file_size: row.file_sz,
                    prnt_doc_id: row.prnt_doc_id,
                };
                dispatch(Actions.reUploadFlow(uploadProcData));
            } else props.history.push(`/info-extracted/${row.doc_id}`);
        }
    }

    const getStatusColor = stsCd => {
        if (!stsCd) return null;
        if (stsCd in AppConstants.DOC_STATUS) {
            return `status-${stsCd}`;
        }
        return null;
    };

    const onRequestSort = (event, columnId) => {
        const sortDetail = {
            direction: order.direction === 'asc' || columnId !== order.columnId ? 'desc' : 'asc',
            columnId: columnId,
        };
        const updateFilter = { ...filterParams, page_number: 0 };
        dispatch(
            Actions.getDexDoc({
                ...updateFilter,
                sort_column_id: sortDetail.columnId,
                sort_direction: sortDetail.direction,
            }),
        );
        dispatch(Actions.setFilter(updateFilter));
        setOrder(sortDetail);
    };

    const onChangePage = (env, page) => {
        const updateFilter = { ...filterParams, page_number: page };
        dispatch(Actions.getDexDoc(updateFilter));
        dispatch(Actions.setFilter(updateFilter));
    };

    const onChangeRowsPerPage = ev => {
        TableFnc.handleChangeRowsPerPage(
            ev,
            filterParams.page_number,
            data,
            pageNumber => dispatch(Actions.setFilter({ ...filterParams, page_number: pageNumber })),
            rowPerPageParam => {
                const updateFilter = { ...filterParams, page_number: 0, row_per_page: rowPerPageParam };
                dispatch(Actions.getDexDoc(updateFilter));
                dispatch(Actions.setFilter(updateFilter));
            },
        );
    };

    useEffect(() => {
        const filterDexDocName =
            searchText.length > 0
                ? _.filter(dexDoc, item => {
                      const acceptDocumentName = item.doc_nm.toLowerCase().includes(searchText.toLowerCase());
                      const acceptupdateUserId = item.upd_usr_id.toLowerCase().includes(searchText.toLowerCase());
                      return acceptupdateUserId || acceptDocumentName;
                  })
                : dexDoc;
        setData(filterDexDocName);
    }, [dexDoc, searchText]);

    return (
        <div className="w-full flex flex-col border-2 p-1 mb-2 mt-2 mr-1 ml-1">
            <FuseScrollbars className="flex-grow overflow-x-auto">
                <div className="w-full h-full overflow-auto">
                    <Table stickyHeader size="small" className="w-full" aria-labelledby="tableTitle">
                        <ViewDocTableHeader
                            numSelected={selected.length}
                            order={order}
                            onRequestSort={onRequestSort}
                            rowCount={data.length}
                            userInfo={props.userInfo}
                        />

                        <TableBody>
                            {data.map(n => {
                                const isSelected = selected.includes(n.doc_id);
                                return (
                                    <TableRow
                                        className="cursor-pointer"
                                        hover
                                        aria-checked={isSelected}
                                        tabIndex={-1}
                                        selected={isSelected}
                                        key={n.doc_id}
                                        onClick={() => setSelected([n.doc_id])}
                                        onDoubleClick={() => handleDoubleClick(n)}
                                    >
                                        <TableCell component="th" scope="row">
                                            {n.doc_id}
                                        </TableCell>
                                        {props.userInfo.usrId === 'admin' ? (
                                            <TableCell component="th" scope="row">
                                                <div className="textSubContainer" title={n.coNm}>
                                                    {n.coNm}
                                                </div>
                                            </TableCell>
                                        ) : (
                                            <></>
                                        )}
                                        <TableCell component="th" scope="row">
                                            {n.dex_loc.loc_nm}
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            {n.adm_doc_tp.doc_nm}
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            <div className="textContainer" title={n.root_nm}>
                                                {n.root_nm}
                                            </div>
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            {n.file_sz}
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            <p className={`custom-status ${getStatusColor(n.sts_cd)}`}>{n.status}</p>
                                            {getIssueToolTip(n)}
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            {`${moment(moment.utc(n.cre_dt).toDate()).format('YYYY-MM-DD HH:mm:ss')} `}
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            {`${moment(moment.utc(n.upd_dt).toDate()).format('YYYY-MM-DD HH:mm:ss')} `}
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            {n.upd_usr_id}
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                        </TableBody>
                    </Table>
                </div>
            </FuseScrollbars>
            <div className="w-full flex flex-row items-center">
                <div className="w-8/12 justify-start flex">
                    <TablePagination
                        component="div"
                        labelRowsPerPage=""
                        rowsPerPageOptions={[25, 50, 100]}
                        count={countDocument}
                        rowsPerPage={filterParams.row_per_page}
                        page={filterParams.page_number}
                        backIconButtonProps={{
                            'aria-label': 'Previous Page',
                        }}
                        nextIconButtonProps={{
                            'aria-label': 'Next Page',
                        }}
                        onChangePage={onChangePage}
                        onChangeRowsPerPage={onChangeRowsPerPage}
                    />
                </div>
            </div>
            <ViewDocUploadDialog startUploadTime={props.startUploadTime} userInfo={props.userInfo} />
            {/* The props rows and handleDoubleClick are used for doubleClick behavior on popup */}
            <SplitDocResultDialog rows={data} handleDoubleClick={handleDoubleClick} />
        </div>
    );
}

export default withRouter(ViewDocTable);

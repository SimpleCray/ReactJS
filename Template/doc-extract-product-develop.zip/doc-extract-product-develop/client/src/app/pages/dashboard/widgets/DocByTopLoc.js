import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Typography, Paper } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import { Bar } from 'react-chartjs-2';
import { FuseAnimate } from '@fuse';
import * as Actions from '../store/actions';
import _ from '@lodash';
import ChartConfig from '../configs/ChartConfig';

const useStyles = makeStyles(theme => ({
    year_disabled: {
        color: '#C0C0C0',
    },
    year_enable: {
        color: '#000000',
    },
}));

const initChart = () => {
    return {
        data: [45982, 25843, 21634, 11236, 17933, 31235],
        backgroundColor: [
            'rgb(249, 65, 68)',
            'rgb(243, 114, 44)',
            'rgb(248, 150, 30)',
            'rgb(249, 199, 79)',
            'rgb(144, 190, 109)',
            'rgb(67, 170, 139)',
        ],
        hoverBackgroundColor: [
            'rgb(249, 65, 68, 0.7)',
            'rgb(243, 114, 44, 0.7)',
            'rgb(248, 150, 30, 0.7)',
            'rgb(249, 199, 79, 0.7)',
            'rgb(144, 190, 109, 0.7)',
            'rgb(67, 170, 139, 0.7)',
        ],
    };
};

function DocByTopCom(props) {
    const dispatch = useDispatch();
    const docsByLoc = useSelector(({ dashboard }) => dashboard.dashboard.docsByLoc);
    const lastThreeYears = useSelector(({ dashboard }) => dashboard.dashboard.lastThreeYears);
    const classes = useStyles(props);

    const [year, setYear] = useState(new Date().getFullYear());
    // const [barData, setBarData] = useState(_.merge({}, barChart));
    const [dataset, setDataset] = useState({});

    const chartParams = _.merge({}, props.params);

    useEffect(() => {
        dispatch(Actions.getLastThreeYears());
    }, []);

    useEffect(() => {
        if (docsByLoc) {
            const { loc_cd, co_cd, data } = docsByLoc;
            let newData = [0, 0, 0, 0, 0];
            let newLabels = ['', '', '', '', '']; // format: loc_cd (co_cd)
            if (data) newData = data;
            if (co_cd)
                newLabels = co_cd.map((coCd, index) => {
                    return `${loc_cd[index]} (${coCd})`;
                });
            // combine
            const newDataset = {
                labels: newLabels,
                datasets: [initChart()],
            };
            newDataset.datasets[0].data = newData;
            setDataset(newDataset);
        }
    }, [docsByLoc]);

    useEffect(() => {
        chartParams.year = year;
        dispatch(Actions.getAllDocsByLoc(chartParams));
    }, [year]);

    const handleYearChange = key => {
        setYear(key);
    };

    return (
        <Paper className="w-full rounded-8 shadow-none border-3">
            <div className="flex items-center justify-between px-16 h-64 border-b-1">
                <FuseAnimate delay={100}>
                    <div className="flex-col">
                        <Typography className="text-16">Document by Top Locations</Typography>
                    </div>
                </FuseAnimate>

                <div className="flex flex-row items-center">
                    {lastThreeYears.map(key => (
                        <Button
                            key={key}
                            className={`py-8 px-12 ${year === key ? classes.year_enable : classes.year_disabled}`}
                            size="small"
                            onClick={() => handleYearChange(key)}
                        >
                            {key}
                        </Button>
                    ))}
                </div>
            </div>
            <div className="w-full p-16">
                <Bar height={280} data={dataset} options={ChartConfig.BAR_CHART.options} />
            </div>
        </Paper>
    );
}

export default React.memo(DocByTopCom);

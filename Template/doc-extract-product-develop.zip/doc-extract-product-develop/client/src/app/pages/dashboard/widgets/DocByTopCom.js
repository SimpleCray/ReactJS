import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Typography, Paper } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import { Bar } from 'react-chartjs-2';
import { FuseAnimate } from '@fuse';
import * as Actions from '../store/actions';
import _ from '@lodash';
import chartConfig from '../configs/ChartConfig';

const useStyles = makeStyles(theme => ({
    year_disabled: {
        color: '#C0C0C0',
    },
    year_enable: {
        color: '#000000',
    },
}));

const initChart = () => {
    return {
        data: [45982, 25843, 21634, 11236, 17933, 31235],
        backgroundColor: [
            'rgb(249, 65, 68)',
            'rgb(243, 114, 44)',
            'rgb(248, 150, 30)',
            'rgb(249, 199, 79)',
            'rgb(144, 190, 109)',
            'rgb(67, 170, 139)',
        ],
        hoverBackgroundColor: [
            'rgb(249, 65, 68, 0.7)',
            'rgb(243, 114, 44, 0.7)',
            'rgb(248, 150, 30, 0.7)',
            'rgb(249, 199, 79, 0.7)',
            'rgb(144, 190, 109, 0.7)',
            'rgb(67, 170, 139, 0.7)',
        ],
    };
};

function DocByTopCom(props) {
    const dispatch = useDispatch();
    const docsByComp = useSelector(({ dashboard }) => dashboard.dashboard.docsByComp);
    const lastThreeYears = useSelector(({ dashboard }) => dashboard.dashboard.lastThreeYears);
    const classes = useStyles(props);

    const [year, setYear] = useState(new Date().getFullYear());
    const [dataset, setDataset] = useState({});

    let chartParams = _.pick(props.params, ['limit', 'year']);
    const roleName = _.pick(props.params, ['role_name']).role_name;
    const height = props.height;

    useEffect(() => {
        dispatch(Actions.getLastThreeYears());
    }, []);

    useEffect(() => {
        if (docsByComp) {
            const { co_cd, data } = docsByComp;
            let newData = [0, 0, 0, 0, 0];
            let newLabels = ['', '', '', '', ''];
            if (data) newData = data;
            if (co_cd) newLabels = co_cd;
            // combine
            const newDataset = {
                labels: newLabels,
                datasets: [initChart()],
            };
            newDataset.datasets[0].data = newData;

            setDataset(newDataset);
        }
    }, [docsByComp]);

    useEffect(() => {
        chartParams = { ...chartParams, year };
        dispatch(Actions.getAllDocsByComp(chartParams));
    }, [year]);

    const handleYearChange = key => {
        setYear(key);
    };

    return (
        <Paper className="w-full rounded-8 shadow-none border-3">
            <div className="flex items-center justify-between px-16 h-64 border-b-1">
                <FuseAnimate delay={100}>
                    <div className="flex-col">
                        <Typography className="text-16">Document by Top Companies</Typography>
                    </div>
                </FuseAnimate>

                <div className="flex flex-row items-center">
                    {lastThreeYears.map(key => (
                        <Button
                            key={key}
                            className={`py-8 px-12 ${year === key ? classes.year_enable : classes.year_disabled}`}
                            size="small"
                            onClick={() => handleYearChange(key)}
                        >
                            {key}
                        </Button>
                    ))}
                </div>
            </div>
            <div className="w-full p-16">
                <Bar
                    height={height}
                    data={dataset}
                    // data={state}
                    options={chartConfig.BAR_CHART.options}
                />
            </div>
        </Paper>
    );
}

export default React.memo(DocByTopCom);

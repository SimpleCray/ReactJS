import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Paper, Typography, FormControl } from '@material-ui/core';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import { Bar } from 'react-chartjs-2';
import _ from 'lodash';
import useStyles from '../utils/styles';
import * as Actions from '../store/actions';
import ChartConfig from '../configs/ChartConfig';
import { getMonthsArray } from '../utils/commonFuncs';

const initChart = () => {
    return {
        label: 'No data', // doc name
        data: [0, 0, 0, 0, 0], // Number of docs by each location
        backgroundColor: 'rgb(244, 67, 54)',
        hoverBackgroundColor: 'rgb(244, 67, 54, 0.7)',
        borderWidth: 1,
        stack: 'docByLoc',
    };
};

function DocByLoc(props) {
    const dispatch = useDispatch();
    const totalDocProced = useSelector(({ dashboard }) => dashboard.dashboard.totalDocProced);
    const { data } = props;
    const classes = useStyles();
    const [searchCond, setSearchCond] = useState({
        from_date: '2021/01',
        to_date: `${new Date().getFullYear()}/${new Date().getMonth() + 1}`,
    });
    const chartParams = props.params;
    const [locations, setLocations] = useState([]);
    const [dataset, setDataset] = useState([initChart()]);

    useEffect(() => {
        if (!_.isEmpty(totalDocProced)) {
            const newDataset = [];
            const labels = Object.keys(totalDocProced); // locations
            Object.keys(totalDocProced).map(loc => {
                let docByLocation = {};
                // Init dataset with each doc name
                // Get doc from each location
                const docNames = Object.keys(totalDocProced[loc]);
                if (docNames) {
                    docNames.map((docNm, index) => {
                        docByLocation = {
                            ...initChart(),
                            label: docNm,
                        }
                        docByLocation.data[index] = totalDocProced[loc][docNm];
                    });
                }
                if (!_.isEmpty(docByLocation)) newDataset.push(docByLocation);
            });

            setLocations(labels);
            setDataset(newDataset);
        }
    }, [totalDocProced]);

    useEffect(() => {
        chartParams.from_date = searchCond.from_date;
        chartParams.to_date = searchCond.to_date;
        dispatch(Actions.getAllDocProcessed(chartParams));
    }, [searchCond]);

    const handleChange = (field_name, value) => {
        setSearchCond(searchCond => ({
            ...searchCond,
            [field_name]: value,
        }));
    };

    return (
        <Paper className="w-full rounded-8 shadow-none border-1">
            <div className="flex items-center justify-between px-16 py-16 border-b-1">
                <Typography className="text-16">Document by Location</Typography>
                <div className="flex w-3/4">
                    <FormControl size="small" variant="outlined" className={classes.formControl}>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <KeyboardDatePicker
                                name="from_date"
                                size="small"
                                label="From Date"
                                value={searchCond.from_date}
                                onChange={val => handleChange('from_date', val)}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                format="MM/yyyy"
                                variant="inline"
                                inputVariant="outlined"
                            />
                        </MuiPickersUtilsProvider>
                    </FormControl>
                    <FormControl size="small" variant="outlined" className={classes.formControl}>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <KeyboardDatePicker
                                name="to_date"
                                size="small"
                                label="To Date"
                                value={searchCond.to_date}
                                onChange={val => handleChange('to_date', val)}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                format="MM/yyyy"
                                variant="inline"
                                inputVariant="outlined"
                            />
                        </MuiPickersUtilsProvider>
                    </FormControl>
                </div>
            </div>
            <div>
                <Bar
                    type="bar"
                    height={150}
                    data={{
                        labels: locations,
                        datasets: dataset,
                    }}
                    options={ChartConfig.DOC_BY_LOC.options}
                />
            </div>
        </Paper>
    );
}

export default React.memo(DocByLoc);

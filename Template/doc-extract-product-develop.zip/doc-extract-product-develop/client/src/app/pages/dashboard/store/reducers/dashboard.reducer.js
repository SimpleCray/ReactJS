import * as Actions from '../actions';
import * as ActionsLocation from '../../../location-management/store/actions';
import _ from '@lodash';

const initialState = {
    nbTemps: '',
    nbLocs: '',
    nbDocs: '',
    docProcMonth: {},
    lastThreeYears: [],
    docsByComp: {},
    docsByLoc: {},
    distriDocs: {},
    distriDocsDtls: {},
    docPgProcessed: {},
    totalDocProced: '',
    totalPageProced: '',
    docByStatus: {},
    docsSuccess: '',
    procTimeAvg: '',
    annotateTimeAvg: '',
    procTimeAvgByMonth: {},
    annotateTimeAvgByMonth: {},
    avgProcTime: '',
    companyData: [],
    locationData: [],
    listError: [],
};

const dashboardReducer = function(state = initialState, action) {
    switch (action.type) {
        case Actions.GET_ALL_TEMPS:
            return {
                ...state,
                nbTemps: action.payload,
            };
        case Actions.GET_ALL_LOCS:
            return {
                ...state,
                nbLocs: action.payload,
            };
        case Actions.GET_DOC_PROC_MONTH:
            return {
                ...state,
                docProcMonth: action.payload,
            };
        case Actions.GET_DOCS_BY_COM:
            return {
                ...state,
                docsByComp: action.payload,
            };
        case Actions.GET_DOCS_BY_LOC:
            return {
                ...state,
                docsByLoc: action.payload,
            };
        case Actions.GET_DISTRI_DOC:
            return {
                ...state,
                distriDocs: action.payload,
            };
        case Actions.GET_DISTRI_DOC_DETAILS:
            return {
                ...state,
                distriDocsDtls: action.payload,
            };
        case Actions.GET_DOC_PAGES_PROCESS:
            return {
                ...state,
                docPgProcessed: action.payload,
            };
        case Actions.GET_TOTAL_DOC_PROCESSED:
            return {
                ...state,
                totalDocProced: action.payload,
            };
        case Actions.GET_TOTAL_PAGE_PROCESSED:
            return {
                ...state,
                totalPageProced: action.payload,
            };
        case Actions.GET_DOC_BY_STATUS:
            return {
                ...state,
                docByStatus: action.payload,
            };
        case Actions.GET_DOC_SUCCESS:
            return {
                ...state,
                docsSuccess: action.payload,
            };
        case Actions.GET_PROCESS_TIME_AVG:
            return {
                ...state,
                procTimeAvg: action.payload,
            };
        case Actions.GET_ANNOTATE_TIME_AVG:
            return {
                ...state,
                annotateTimeAvg: action.payload,
            };
        case Actions.GET_PROCESS_TIME_AVG_MON:
            return {
                ...state,
                procTimeAvgByMonth: action.payload,
            };
        case Actions.GET_ANNOTATE_TIME_AVG_MON:
            return {
                ...state,
                annotateTimeAvgByMonth: action.payload,
            };
        case Actions.GET_DOC_FOR_THREE_YEARS:
            return {
                ...state,
                lastThreeYears: action.payload,
            };
        case Actions.CATCH_ERROR_DASHBOARD:
            return {
                ...state,
                listError: !state.listError.includes(action.payload)
                    ? [...state.listError, action.payload]
                    : state.listError,
            };
        case ActionsLocation.GET_COMPANIES:
            return {
                ...state,
                companyData: action.payload,
            };
        case ActionsLocation.GET_INIT_LOC_DATA:
            return {
                ...state,
                locationData: action.payload,
            };
        default:
            return state;
    }
};

export default dashboardReducer;

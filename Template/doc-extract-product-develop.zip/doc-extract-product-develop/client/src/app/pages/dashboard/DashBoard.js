/* eslint-disable no-nested-ternary */
import React, { useRef, useState, useEffect } from 'react';
import * as Actions from './store/actions';
import * as ActionsLocation from '../location-management/store/actions';
import { logoutShine } from 'app/utils/utils';
import { Tab, Tabs, Typography, TextField, Grid } from '@material-ui/core';
import { Autocomplete } from '@material-ui/lab';
import { useSelector, useDispatch } from 'react-redux';
import AppConstants from 'app/utils/appConstants';
import withReducer from 'app/store/withReducer';
import reducer from './store/reducers';
import { FuseAnimateGroup, FusePageSimple } from '@fuse';
import useStyles from './utils/styles';
import _ from '@lodash';

// import charts
import DocByMonth from './widgets/DocByMonth';
import TotalWidget from './widgets/TotalWidget';
import DocByStatus from './widgets/DocByStatus';
import DocumentTypeDistribution from './widgets/DocumentTypeDistribution';
import DocumentDistributionDetail from './widgets/DocumentDistributionDetail';
import DocByLoc from './widgets/DocByLoc';
import SuccessRatio from './widgets/SuccessRatio';
import DocByTopCom from './widgets/DocByTopCom';
import DocByTopLoc from './widgets/DocByTopLoc';
import WidgetConst from './widgets/WidgetConst';
import ExtTimeByTime from './widgets/ExtTimeByTime';
import AnnotateTimeByTime from './widgets/AnnotateTimeByTime';
import DocPageProc from './widgets/DocPageProc';
import { openDialog } from 'app/store/actions/fuse/dialog.actions';

import { uniqueArray, setParamByUserRole, isMasterAdmin, isShineAdmin, isShineUser } from './utils/commonFuncs';

const DELT_FLAG = 'N';

function DashBoard(props) {
    const classes = useStyles();
    const pageLayout = useRef(null);
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO)) || null;
    const userRole = localStorage.getItem(AppConstants.BP_USER_ROLE_NM) || null;
    // Initialize chart params with userInfo and roles.
    const initParams = setParamByUserRole(userInfo, userRole);

    // For charts filter
    const companies = useSelector(({ dashboard }) => dashboard.dashboard.companyData); // all companies data from BP
    const locations = useSelector(({ dashboard }) => dashboard.dashboard.locationData); // all locations
    const dispatch = useDispatch();

    // If not have information, logging out
    useEffect(() => {
        // window.location.reload(); // Re-getting menu and auth from layout1
        if (!localStorage.getItem(AppConstants.BP_USER_INFO)) logoutShine();
        // For filter/search
        dispatch(ActionsLocation.getInitLocData());
        dispatch(ActionsLocation.getCompanyData()); // Total Company
    }, []);

    // Total charts
    const nbTemps = useSelector(({ dashboard }) => dashboard.dashboard.nbTemps);
    const nbComps = companies.length; // total companies from BP
    const nbLocs = useSelector(({ dashboard }) => dashboard.dashboard.nbLocs);

    const totalDocProced = useSelector(({ dashboard }) => dashboard.dashboard.totalDocProced);
    const totalPageProced = useSelector(({ dashboard }) => dashboard.dashboard.totalPageProced);

    const procTimeAvg = useSelector(({ dashboard }) => dashboard.dashboard.procTimeAvg);
    const annotateTimeAvg = useSelector(({ dashboard }) => dashboard.dashboard.annotateTimeAvg);
    const listError = useSelector(({ dashboard }) => dashboard.dashboard.listError);

    // tab: 0: summary, 1: distribution
    const [tabValue, setTabValue] = useState(0);

    // Default value for filter
    const defaultValues = {
        company: isMasterAdmin(userRole) ? { coCd: 'All', coNm: 'All' } : { coCd: userInfo.coCd, coNm: userInfo.coCd },
        location: { loc_nm: 'All' },
    };

    const [currentCompany, setCurrentCompany] = useState(defaultValues.company);
    const [currentLocation, setCurrentLocation] = useState(defaultValues.location);
    const [searchCompany, setSearchCompany] = useState([defaultValues.company]);
    const [searchLocation, setSearchLocation] = useState([defaultValues.location]);

    const [params, setParams] = useState(initParams);

    useEffect(() => {
        // Summary charts
        dispatch(Actions.getDocsProByMonth(params));
        dispatch(Actions.getAllTemplates(params)); // Total Template
        dispatch(Actions.getAllLocs(_.pick(params, ['co_cd']))); // Total Location
        dispatch(Actions.getAllPageProcessed(_.pick(params, ['co_cd', 'usr_id']))); // Total Pages
        dispatch(Actions.getAllDocProcessed(_.pick(params, ['co_cd', 'usr_id']))); // Document Received
        dispatch(Actions.getProcessTimeAvg(_.pick(params, ['co_cd']))); // Avg process time
        dispatch(Actions.getAnnotateTimeAvg(_.pick(params, ['co_cd', 'usr_id']))); // Annotation Time
        dispatch(Actions.getAllDocsByLoc(_.pick(params, ['limit', 'co_cd', 'year']))); // Top 5 doc by loc
        dispatch(Actions.getDocsSuccess(_.pick(params, ['co_cd', 'year']))); // Doc success
        dispatch(Actions.getDocByStatus(_.pick(params, ['co_cd', 'year', 'usr_id']))); // Doc status

        // Distribution charts
        dispatch(Actions.getDistributeOfDoc(_.pick(params, ['co_cd'])));
        dispatch(Actions.getDistributeOfDocDetails(_.pick(params, ['co_cd'])));
        dispatch(Actions.getDocPageProc(_.pick(params, ['co_cd', 'loc_cd', 'year', 'usr_id']))); //  Document Pages Processed
        dispatch(Actions.getProcessTimeAvgByMonth(_.pick(params, ['co_cd', 'loc_cd', 'year']))); // Extraction Time
        dispatch(Actions.getAnnotateTimeAvgByMonth(_.pick(params, ['co_cd', 'loc_cd', 'year', 'usr_id']))); // Annotation Time
    }, [params]);

    useEffect(() => {
        if (listError.length > 0) {
            dispatch(
                openDialog(
                    listError.reduce((errorMessage, error) => `${errorMessage + error}\n`, ''),
                    'Error(s) when load data',
                ),
            );
        }
    }, [listError]);

    useEffect(() => {
        if (companies && companies.length > 0) {
            const companiesCopy = companies;
            const filtedCompany = companiesCopy.filter(item => item.deltFlg === DELT_FLAG);
            filtedCompany.unshift(defaultValues.company);
            setSearchCompany(filtedCompany);
        }
    }, [companies]);

    useEffect(() => {
        if (locations && locations.length > 0) {
            const locationsCopy = locations;
            const filtedLocation = uniqueArray(
                locationsCopy.filter(item => item.co_cd === currentCompany.coCd && item.delt_flg === DELT_FLAG),
                'loc_cd',
            );
            filtedLocation.unshift(defaultValues.location);
            if (userInfo.locCd && filtedLocation.filter(item => item.loc_cd === userInfo.locCd).length === 0) {
                filtedLocation.unshift({ loc_nm: userInfo.locCd, loc_cd: userInfo.locCd });
            }
            setSearchLocation(filtedLocation);
        }
    }, [currentCompany, locations]);

    useEffect(() => {
        if (userInfo.locCd) {
            const userLocation = searchLocation.filter(item => item.loc_cd === userInfo.locCd);
            if (userLocation.length === 0) {
                setCurrentLocation({ loc_nm: userInfo.locCd });
            } else setCurrentLocation(userLocation[0]);
        }
    }, [searchLocation]);

    const handleDataChange = (key, value) => {
        const currentYear = new Date().getFullYear();
        switch (key) {
            case 'company':
                setParams(prevState => ({
                    ...prevState,
                    co_cd: value.coCd !== 'All' ? value.coCd : null,
                    loc_cd: null,
                    year: currentYear,
                }));
                setCurrentCompany(value);
                setCurrentLocation({ loc_nm: 'All' });
                break;
            case 'location':
                setParams(prevState => ({
                    ...prevState,
                    loc_cd: value.loc_cd,
                    year: currentYear,
                }));
                setCurrentLocation(value);
                break;
            default:
                break;
        }
    };

    const handleChangeTab = (event, tabValue) => setTabValue(tabValue);

    return (
        <FusePageSimple
            classes={{
                header: 'min-h-130 h-130',
                toolbar: 'min-h-48 h-48',
                rightSidebar: 'w-288',
                content: classes.content,
            }}
            content={
                <React.Fragment>
                    <div className={classes.tabContainer}>
                        <div className={classes.welcomeContainer}>
                            <Typography variant="h4" className="py-0 sm:py-24">
                                Welcome back, {userInfo.usrNm}!
                            </Typography>
                        </div>
                        <div className={classes.subTabContainer}>
                            <Tabs
                                value={tabValue}
                                onChange={handleChangeTab}
                                indicatorColor="secondary"
                                textColor="secondary"
                                variant="scrollable"
                                scrollButtons="off"
                                className="w-full px-24"
                            >
                                <Tab className="text-14 font-600 normal-case" label="Summary" />
                                <Tab className="text-14 font-600 normal-case" label="Distribution" />
                            </Tabs>

                            {isMasterAdmin(userRole) && (
                                <div className="flex-none px-12 mt-2">
                                    <Autocomplete
                                        className={classes.searchBar}
                                        options={searchCompany || []}
                                        getOptionLabel={option => option.coNm || ''}
                                        size="small"
                                        value={currentCompany}
                                        renderInput={params => (
                                            <TextField
                                                {...params}
                                                label="Company Name"
                                                name="coCd"
                                                variant="outlined"
                                            />
                                        )}
                                        onChange={(event, value) => handleDataChange('company', value)}
                                        disableClearable
                                    />
                                </div>
                            )}
                            <div className="flex-none px-12 mt-2">
                                <Autocomplete
                                    className={classes.searchBar}
                                    options={searchLocation || []}
                                    getOptionLabel={option => option.loc_nm || ''}
                                    size="small"
                                    value={currentLocation}
                                    renderInput={params => (
                                        <TextField {...params} label="Location Name" name="loc" variant="outlined" />
                                    )}
                                    onChange={(e, value) => handleDataChange('location', value)}
                                    disabled={_.isEmpty(currentCompany)}
                                    disableClearable
                                />
                            </div>
                        </div>
                    </div>

                    <div className={classes.contentContainer}>
                        {tabValue === 0 && (
                            <div>
                                {!isShineUser(userRole) && <DocByMonth params={params} />}
                                <br />
                                <FuseAnimateGroup
                                    className={classes.totalContainer}
                                    enter={{
                                        animation: 'transition.slideUpBigIn',
                                    }}
                                >
                                    <Grid container spacing={2}>
                                        {!isShineUser(userRole) && [
                                            isMasterAdmin(userRole) && (
                                                <Grid item xs={4}>
                                                    <TotalWidget
                                                        count={nbComps || 0}
                                                        label={WidgetConst.TotalCompany.label}
                                                        title={WidgetConst.TotalCompany.title}
                                                        textColor="blue"
                                                    />
                                                </Grid>
                                            ),
                                            <Grid item xs={isMasterAdmin(userRole) ? 4 : 6}>
                                                <TotalWidget
                                                    count={nbTemps || 0}
                                                    label={WidgetConst.TotalTemp.label}
                                                    title={WidgetConst.TotalTemp.title}
                                                    textColor="green"
                                                />
                                            </Grid>,
                                            <Grid item xs={isMasterAdmin(userRole) ? 4 : 6}>
                                                <TotalWidget
                                                    count={nbLocs || 0}
                                                    label={WidgetConst.TotalLocation.label}
                                                    title={WidgetConst.TotalLocation.title}
                                                    textColor="orange"
                                                />
                                            </Grid>,
                                        ]}
                                        <Grid item xs={isShineUser(userRole) ? 4 : 3}>
                                            <TotalWidget
                                                count={totalDocProced || 0}
                                                label={WidgetConst.TotalDocProcessed.label}
                                                title={WidgetConst.TotalDocProcessed.title}
                                                textColor="teal"
                                            />
                                        </Grid>
                                        <Grid item xs={isShineUser(userRole) ? 4 : 3}>
                                            <TotalWidget
                                                count={totalPageProced || 0}
                                                label={WidgetConst.TotalPageProcessed.label}
                                                title={WidgetConst.TotalPageProcessed.title}
                                                textColor="red"
                                            />
                                        </Grid>
                                        {!isShineUser(userRole) && (
                                            <Grid item xs={3}>
                                                <TotalWidget
                                                    count={procTimeAvg || 0}
                                                    label={WidgetConst.AvgProcessTime.label}
                                                    title={WidgetConst.AvgProcessTime.title}
                                                    textColor="indigo"
                                                />
                                            </Grid>
                                        )}
                                        <Grid item xs={isShineUser(userRole) ? 4 : 3}>
                                            <TotalWidget
                                                count={annotateTimeAvg || 0}
                                                label={WidgetConst.AvgAnnotateTime.label}
                                                title={WidgetConst.AvgAnnotateTime.title}
                                                textColor="purple"
                                            />
                                        </Grid>
                                        {!isShineUser(userRole) && (
                                            <Grid item xs={6}>
                                                <DocByTopLoc params={params} />
                                            </Grid>
                                        )}
                                        {isMasterAdmin(userRole) && (
                                            <Grid item xs={6}>
                                                <DocByTopCom params={params} height={280} />
                                            </Grid>
                                        )}
                                        <Grid item xs={isShineAdmin(userRole) ? 3 : isMasterAdmin(userRole) ? 6 : 12}>
                                            <DocByStatus params={params} />
                                        </Grid>
                                        {!isShineUser(userRole) && (
                                            <Grid item xs={isShineAdmin(userRole) ? 3 : 6}>
                                                <SuccessRatio params={params} />
                                            </Grid>
                                        )}
                                    </Grid>
                                </FuseAnimateGroup>
                            </div>
                        )}
                        {tabValue === 1 && (
                            <FuseAnimateGroup
                                className={classes.totalContainer}
                                enter={{
                                    animation: 'transition.slideUpBigIn',
                                }}
                            >
                                <Grid container spacing={2}>
                                    {!isShineUser(userRole) && [
                                        <Grid item xs={4}>
                                            <DocumentTypeDistribution params={params} />
                                        </Grid>,
                                        <Grid item xs={8}>
                                            <DocumentDistributionDetail params={params} />
                                        </Grid>,
                                    ]}
                                    {/* {!isShineUser(userRole) && (
                                        <Grid item xs={6}>
                                            <DocByLoc params={params} />
                                        </Grid>
                                    )} */}
                                    <Grid item xs={isShineUser(userRole) ? 6 : 4}>
                                        <DocPageProc params={params} height={150} />
                                    </Grid>
                                    {!isShineUser(userRole) && (
                                        <Grid item xs={4}>
                                            <ExtTimeByTime params={params} />
                                        </Grid>
                                    )}
                                    <Grid item xs={isShineUser(userRole) ? 6 : 4}>
                                        <AnnotateTimeByTime params={params} />
                                    </Grid>
                                </Grid>
                            </FuseAnimateGroup>
                        )}
                    </div>
                </React.Fragment>
            }
            ref={pageLayout}
        />
    );
}

export default withReducer('dashboard', reducer)(DashBoard);

import { API_EP } from 'app/utils/commonAPI';
import { checkResDataAPI, showError } from 'app/utils/utils';
import _ from '@lodash';
import HandleServerErrors from 'app/utils/handleServerErrors';

export const GET_ALL_TEMPS = 'GET_ALL_TEMPS';
export const GET_ALL_LOCS = 'GET_ALL_LOCS';
export const GET_ALL_DOCS = 'GET_ALL_DOCS';
export const GET_DOC_PROC_MONTH = 'GET_DOC_PROC_MONTH';
export const GET_DOCS_BY_COM = 'GET_DOCS_BY_COM';
export const GET_DOCS_BY_LOC = 'GET_DOCS_BY_LOC';
export const GET_DISTRI_DOC = 'GET_DISTRI_DOC';
export const GET_DISTRI_DOC_DETAILS = 'GET_DISTRI_DOC_DETAILS';
export const GET_DOC_PAGES_PROCESS = 'GET_DOC_PAGES_PROCESS';
export const GET_TOTAL_DOC_PROCESSED = 'GET_TOTAL_DOC_PROCESSED';
export const GET_TOTAL_PAGE_PROCESSED = 'GET_TOTAL_PAGE_PROCESSED';
export const GET_DOC_BY_STATUS = 'GET_DOC_BY_STATUS';
export const GET_DOC_SUCCESS = 'GET_DOC_SUCCESS';
export const GET_PROCESS_TIME_AVG = 'GET_PROCESS_TIME_AVG';
export const GET_ANNOTATE_TIME_AVG = 'GET_ANNOTATE_TIME_AVG';
export const GET_PROCESS_TIME_AVG_MON = 'GET_PROCESS_TIME_AVG_MON';
export const GET_ANNOTATE_TIME_AVG_MON = 'GET_ANNOTATE_TIME_AVG_MON';
export const GET_DOC_FOR_THREE_YEARS = 'GET_DOC_FOR_THREE_YEARS';
export const GET_AVG_PROC_TIME = 'GET_AVG_PROC_TIME';
export const CATCH_ERROR_DASHBOARD = 'CATCH_ERROR_DASHBOARD';

export const handleResponseData = (dispatch, typeDispatch, request, msg) =>
    request
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: typeDispatch,
                    payload: response.data,
                });
            }
        })
        .catch(error =>
            dispatch({
                type: CATCH_ERROR_DASHBOARD,
                payload: `${HandleServerErrors.getServerErrorMessage(error)} ${msg}`,
            }),
        );

export function getLastThreeYears() {
    const request = API_EP.get(`/dashboard/get-last-three-years`);
    return dispatch => handleResponseData(dispatch, GET_DOC_FOR_THREE_YEARS, request, 'last three years!');
}

export function getAllTemplates(conditions) {
    const request = API_EP.get(`/dashboard/all-templates`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_ALL_TEMPS, request, 'templates data!');
}

export function getAllLocs(conditions) {
    const request = API_EP.get(`/dashboard/all-locs`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_ALL_LOCS, request, 'locations data!');
}

export function getDocsProByMonth(conditions) {
    const request = API_EP.get(`/dashboard/doc-proc-month`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_DOC_PROC_MONTH, request, 'processed documents by months!');
}

export function getAllDocsByComp(conditions) {
    const request = API_EP.get(`/dashboard/docs-by-comp`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_DOCS_BY_COM, request, 'documents by companies!');
}

export function getAllDocsByLoc(conditions) {
    const request = API_EP.get(`/dashboard/docs-by-loc`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_DOCS_BY_LOC, request, 'documents by locations!');
}

export function getDistributeOfDoc(conditions) {
    const request = API_EP.get(`/dashboard/distri-docs`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_DISTRI_DOC, request, 'distribution of documents!');
}

export function getDistributeOfDocDetails(conditions) {
    const request = API_EP.get(`/dashboard/distri-docs-details`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_DISTRI_DOC_DETAILS, request, 'detail distribution of documents!');
}

export function getDocPageProc(conditions) {
    const request = API_EP.get(`/dashboard/doc-pages-process`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_DOC_PAGES_PROCESS, request, 'processed pages of documents!');
}

export function getAllDocProcessed(conditions) {
    const request = API_EP.get(`/dashboard/total-doc-processed`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_TOTAL_DOC_PROCESSED, request, 'processed document!');
}

export function getAllPageProcessed(conditions) {
    const request = API_EP.get(`/dashboard/total-page-processed`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_TOTAL_PAGE_PROCESSED, request, 'total processed pages!');
}

export function getDocByStatus(conditions) {
    const request = API_EP.get(`/dashboard/doc-by-status`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_DOC_BY_STATUS, request, 'documents by status!');
}

export function getDocsSuccess(conditions) {
    const request = API_EP.get(`/dashboard/docs-success`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_DOC_SUCCESS, request, 'document success ratio!');
}

export function getProcessTimeAvg(conditions) {
    const request = API_EP.get(`/dashboard/process-time-avg`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_PROCESS_TIME_AVG, request, 'average process time!');
}

export function getAnnotateTimeAvg(conditions) {
    const request = API_EP.get(`/dashboard/annotate-time-avg`, { params: conditions });
    return dispatch => handleResponseData(dispatch, GET_ANNOTATE_TIME_AVG, request, 'average annotation time!');
}

export function getProcessTimeAvgByMonth(conditions) {
    const request = API_EP.get(`/dashboard/process-time-avg-month`, { params: conditions });
    return dispatch =>
        handleResponseData(dispatch, GET_PROCESS_TIME_AVG_MON, request, 'average process time by months!');
}

export function getAnnotateTimeAvgByMonth(conditions) {
    const request = API_EP.get(`/dashboard/annotate-time-avg-month`, { params: conditions });
    return dispatch =>
        handleResponseData(dispatch, GET_ANNOTATE_TIME_AVG_MON, request, 'average annotation time by months!');
}
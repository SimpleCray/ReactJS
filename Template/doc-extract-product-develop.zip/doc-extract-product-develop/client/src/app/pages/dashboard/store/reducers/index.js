import { combineReducers } from 'redux';
import dashboard from './dashboard.reducer';

const reducer = combineReducers({
    dashboard,
});

export default reducer;

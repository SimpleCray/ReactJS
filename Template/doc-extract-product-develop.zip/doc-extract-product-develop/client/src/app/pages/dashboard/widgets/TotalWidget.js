import React from 'react';
import { Icon, Typography, Paper, IconButton } from '@material-ui/core';
import _ from '@lodash';

function TotalWidget(props) {
    const { title, label, count, textColor } = props;
    // const data = _.merge({}, props.data);

    return (
        <Paper className="h-full rounded-8 shadow-none border-3">
            <div className="flex items-center justify-between pr-4 pl-16 pt-4">
                <Typography className="text-16">{title}</Typography>
            </div>
            <div className="text-center pt-12 pb-28">
                <Typography className={'text-72 leading-none text-' + textColor}>{count}</Typography>
                <Typography className="text-16" color="textSecondary">
                    {label}
                </Typography>
            </div>
        </Paper>
    );
}

export default React.memo(TotalWidget);

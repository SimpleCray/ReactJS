/* eslint-disable no-plusplus */
/* eslint-disable no-restricted-globals */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { TableContainer, Table, TableHead, TableCell, TableRow, Typography, Paper, TableBody } from '@material-ui/core';
import clsx from 'clsx';
import ChartConfig from '../configs/ChartConfig';
import * as TableFnc from '../../../utils/tableFunctions';

function DocumentDistributionDetail(props) {
    const distriDocsDtls = useSelector(({ dashboard }) => dashboard.dashboard.distriDocsDtls);
    const [dataset, setDataset] = useState([]);

    const getDataDistributionDetails = data => {
        const rows = [];
        if (data && data.doc_name) {
            for (let i = 0; i < data.doc_name.length; i++) {
                const successRatio = TableFnc.parseAndFixedFloatNumber(
                    data[ChartConfig.DOC_TYPE_DISTR_DETAILS.columns[2].id][i],
                    2,
                    100,
                );
                const notAnnotatedRatio = TableFnc.parseAndFixedFloatNumber(
                    data[ChartConfig.DOC_TYPE_DISTR_DETAILS.columns[3].id][i],
                    2,
                    100,
                );
                const failedRatio = TableFnc.parseAndFixedFloatNumber(
                    data[ChartConfig.DOC_TYPE_DISTR_DETAILS.columns[4].id][i],
                    2,
                    100,
                );
                rows.push({
                    id: i + 1,
                    cells: [
                        {
                            id: ChartConfig.DOC_TYPE_DISTR_DETAILS.columns[0].id,
                            value: data[ChartConfig.DOC_TYPE_DISTR_DETAILS.columns[0].id][i],
                            classes: ChartConfig.DOC_TYPE_DISTR_DETAILS.textColors[i],
                        },
                        {
                            id: ChartConfig.DOC_TYPE_DISTR_DETAILS.columns[1].id,
                            value: data[ChartConfig.DOC_TYPE_DISTR_DETAILS.columns[1].id][i],
                            classes: 'font-bold',
                        },
                        {
                            id: ChartConfig.DOC_TYPE_DISTR_DETAILS.columns[2].id,
                            value: `${isNaN(successRatio) ? 0 : successRatio}%`,
                            classes: 'text-green',
                        },
                        {
                            id: ChartConfig.DOC_TYPE_DISTR_DETAILS.columns[3].id,
                            value: `${isNaN(notAnnotatedRatio) ? 0 : notAnnotatedRatio}%`,
                            classes: 'text-orange',
                        },
                        {
                            id: ChartConfig.DOC_TYPE_DISTR_DETAILS.columns[4].id,
                            value: `${isNaN(failedRatio) ? 0 : failedRatio}%`,
                            classes: 'text-red',
                        },
                    ],
                });
            }
        }
        return rows;
    };

    useEffect(() => {
        if (distriDocsDtls) {
            const newDataset = getDataDistributionDetails(distriDocsDtls);
            setDataset(newDataset);
        }
    }, [distriDocsDtls]);
    return (
        <Paper className="w-full rounded-8 shadow-none border-1">
            <div className="flex items-center justify-between px-16 h-64 border-b-1">
                <Typography className="text-16">{ChartConfig.DOC_TYPE_DISTR_DETAILS.title}</Typography>
            </div>
            <div className="table-responsive">
                <TableContainer style={{ maxHeight: 400 }}>
                    <Table className="w-full min-w-full">
                        <TableHead>
                            <TableRow>
                                {ChartConfig.DOC_TYPE_DISTR_DETAILS.columns.map(column => (
                                    <TableCell key={column.id} className="whitespace-no-wrap">
                                        {column.title}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {dataset.map(row => (
                                <TableRow key={row.id}>
                                    {row.cells.map(cell => {
                                        switch (cell.id) {
                                            case 'doc_name': {
                                                return (
                                                    <TableCell key={cell.id} component="th" scope="row">
                                                        <Typography
                                                            className={clsx(
                                                                cell.classes,
                                                                'inline text-11 font-500 px-8 py-4 rounded-4',
                                                            )}
                                                        >
                                                            {cell.value}
                                                        </Typography>
                                                    </TableCell>
                                                );
                                            }
                                            default: {
                                                return (
                                                    <TableCell key={cell.id} component="th" scope="row">
                                                        <Typography className={cell.classes}>{cell.value}</Typography>
                                                    </TableCell>
                                                );
                                            }
                                        }
                                    })}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </div>
        </Paper>
    );
}

export default React.memo(DocumentDistributionDetail);

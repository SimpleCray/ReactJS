import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
        marginTop: theme.spacing(3),
    },
    margin: {
        margin: theme.spacing(1),
    },
    paper: {
        width: '100%',
        marginBottom: theme.spacing(2),
    },
    tableRow: {
        height: 43,
    },
    cellHead: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
    formControl: {
        marginLeft: '5px',
        marginBottom: '5px',
        marginTop: '10px',
        width: '100%',
    },
    searchBar: {
        width: '24ch',
        margin: 3,
    },
    tabContainer: {
        position: 'fixed',
        top: 52,
        left: 0,
        zIndex: 2,
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: 'white',
        width: '100%',
        minHeight: 200,
        paddingTop: 0,
        paddingBottom: 10,
        paddingLeft: 48,
        paddingRight: 10,
    },
    subTabContainer: {
        display: 'flex',
        flexDirection: 'row',
    },
    contentContainer: {
        paddingTop: 10,
        paddingBottom: 10,
        paddingLeft: 10,
        paddingRight: 10,
        marginTop: 200,
    },
    welcomeContainer: {
        paddingLeft: 40,
        paddingRight: 40,
        paddingBottom: 20,
        paddingTop: 40,
        backgroundColor: '#373c4b',
        color: 'white',
    },
    totalContainer: {
        flexGrow: 1,
    }
}));
export default useStyles;

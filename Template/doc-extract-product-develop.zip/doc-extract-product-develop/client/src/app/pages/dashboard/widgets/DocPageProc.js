/* eslint-disable react/prop-types */
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Paper, Typography, FormControl } from '@material-ui/core';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import { Line } from 'react-chartjs-2';
import _ from 'lodash';
import * as Actions from '../store/actions';
import useStyles from '../utils/styles';
import ChartConfig from '../configs/ChartConfig';

const initChart = () => {
    return {
        label: 'No data',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        borderColor: 'rgb(0, 204, 0)',
        backgroundColor: 'rgb(0, 204, 0)',
        fill: false,
    };
};

function DocPageProc(props) {
    const dispatch = useDispatch();
    const docPgProcessed = useSelector(({ dashboard }) => dashboard.dashboard.docPgProcessed);

    const classes = useStyles();
    const [year, setYear] = useState(`${new Date().getFullYear()}`);
    const [dataset, setDataset] = useState([initChart()]);
    const chartParams = props.params;
    const { height } = props;

    const handleChange = key => {
        setYear(`${key.getFullYear()}`);
    };

    useEffect(() => {
        chartParams.year = year;
        dispatch(Actions.getDocPageProc(chartParams));
    }, [year]);

    useEffect(() => {
        if (docPgProcessed) {
            const newDataset = [];
            Object.keys(docPgProcessed).map((docName, idx) => {
                let tmpChart = _.merge({}, initChart());
                // data by month
                const dataByMonth = _.pick(docPgProcessed[docName], ChartConfig.TIME_LINE_CHART.labels);
                tmpChart = {
                    ...tmpChart,
                    label: docName,
                    data: Object.values(dataByMonth).map(item => parseFloat(item)),
                    borderColor: ChartConfig.TIME_LINE_CHART.BORDER_COLORS[idx],
                    backgroundColor: ChartConfig.TIME_LINE_CHART.BACKGROUND_COLOR[idx],
                };
                newDataset.push(tmpChart);
            });
            setDataset(newDataset);
        }
    }, [docPgProcessed]);

    return (
        <Paper className="w-full rounded-8 shadow-none border-1">
            <div className="flex items-center justify-between px-16 py-16 border-b-1">
                <Typography className="text-16">Document Pages Processed</Typography>
                <div className="flex w-2/4">
                    <FormControl size="small" variant="outlined" className={classes.formControl}>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <KeyboardDatePicker
                                disableToolbar
                                size="small"
                                views={['year']}
                                label="Year"
                                value={year}
                                type="year"
                                onChange={val => handleChange(val)}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                format="yyyy"
                                variant="inline"
                                inputVariant="outlined"
                            />
                        </MuiPickersUtilsProvider>
                    </FormControl>
                </div>
            </div>
            <div>
                <Line
                    height={height}
                    data={{
                        labels: ChartConfig.DOC_PAGE_PROC.labels,
                        datasets: dataset,
                    }}
                    options={ChartConfig.DOC_PAGE_PROC.options}
                />
            </div>
        </Paper>
    );
}

export default React.memo(DocPageProc);

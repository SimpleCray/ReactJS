import React, { useEffect, useState } from 'react';
import { Button, Typography } from '@material-ui/core';
import { makeStyles, useTheme, ThemeProvider } from '@material-ui/styles';
import { FuseAnimate } from '@fuse';
import { useDispatch, useSelector } from 'react-redux';
import { Line } from 'react-chartjs-2';
import * as Actions from '../store/actions';
import _ from '@lodash';
import ChartConfig from '../configs/ChartConfig';

const useStyles = makeStyles(theme => ({
    root: {
        background:
            'linear-gradient(to right, ' + theme.palette.primary.dark + ' 0%, ' + theme.palette.primary.main + ' 100%)',
    },
    year_disabled: {
        color: '#666666',
    },
    year_enable: {
        color: '#FFFFFF',
    },
}));

const initChart = theme => {
    return {
        label: 'Documents',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        fill: 'start',
        borderColor: theme.palette.secondary.main,
        backgroundColor: theme.palette.secondary.main,
        pointBackgroundColor: theme.palette.secondary.dark,
        pointHoverBackgroundColor: theme.palette.secondary.main,
        pointBorderColor: theme.palette.secondary.contrastText,
        pointHoverBorderColor: theme.palette.secondary.contrastText,
    };
};

function DocByMonth(props) {
    const dispatch = useDispatch();
    const mainThemeDark = useSelector(({ fuse }) => fuse.settings.mainThemeDark);
    const lastThreeYears = useSelector(({ dashboard }) => dashboard.dashboard.lastThreeYears);
    const docProcMonth = useSelector(({ dashboard }) => dashboard.dashboard.docProcMonth);

    const classes = useStyles(props);
    const theme = useTheme();

    const [dataset, setDataset] = useState(initChart(theme));
    const chartParam = props.params;
    const [year, setYear] = useState(chartParam.year);

    useEffect(() => {
        dispatch(Actions.getLastThreeYears());
    }, []);

    useEffect(() => {
        if (chartParam !== year) {
            setYear(chartParam.year);
        }
        if (docProcMonth && docProcMonth.month && docProcMonth.data) {
            const dataOfChart = getChartData();
            setDataset(dataOfChart);
        }
    }, [docProcMonth]);

    useEffect(() => {
        chartParam.year = year;
        dispatch(Actions.getDocsProByMonth(chartParam));
    }, [year]);

    const getChartData = () => {
        const datasetCopy = initChart(theme);
        if (docProcMonth.month && docProcMonth.data && docProcMonth.month.length === docProcMonth.data.length) {
            docProcMonth.month.map((m, mnthIdx) => {
                // month_idx == data_idx
                const idxMonth = ChartConfig.LINE_CHART.labels.indexOf(m);
                const numDoc = docProcMonth.data[mnthIdx];
                datasetCopy.data[idxMonth] = numDoc;
            });
        }
        return datasetCopy;
    };

    const updateChart = key => {
        setYear(key);
    };

    return (
        <ThemeProvider theme={mainThemeDark}>
            <div className={classes.root}>
                <div className="container relative p-16 sm:p-24 flex flex-row justify-between items-center">
                    <FuseAnimate delay={100}>
                        <div className="flex-col">
                            <Typography className="h2" color="textPrimary">
                                Documents
                            </Typography>
                            <Typography className="h5" color="textSecondary">
                                Documents received by month
                            </Typography>
                        </div>
                    </FuseAnimate>

                    <div className="flex flex-row items-center">
                        {lastThreeYears.map(key => (
                            <Button
                                key={key}
                                className={`py-8 px-12 ${year === key ? classes.year_enable : classes.year_disabled}`}
                                size="small"
                                onClick={() => updateChart(key)}
                            >
                                {key}
                            </Button>
                        ))}
                    </div>
                </div>
                <div className="container relative h-200 sm:h-256 pb-16">
                    <Line
                        data={{
                            labels: ChartConfig.LINE_CHART.labels,
                            datasets: [dataset],
                        }}
                        options={ChartConfig.LINE_CHART.options}
                    />
                </div>
            </div>
        </ThemeProvider>
    );
}

export default React.memo(DocByMonth);

const ChartConfig = {
    PIE_CHART: {
        labels: ['Success', 'Out of Scope'],
        options: {
            cutoutPercentage: 70,
            spanGaps: false,
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    padding: 16,
                    usePointStyle: true,
                },
            },
            maintainAspectRatio: false,
            tooltips: {
                callbacks: {
                    label: function(tooltipItem, data) {
                        let label = data.labels[tooltipItem.index];
                        let value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                        return label + ': ' + value + '%';
                    },
                },
            },
        },
    },
    BAR_CHART: {
        options: {
            legend: {
                display: false,
            },
            maintainAspectRatio: false,
            tooltips: {
                mode: 'label',
            },
            scales: {
                xAxes: [
                    {
                        stacked: false,
                    },
                ],
                yAxes: [
                    {
                        type: 'linear',
                        position: 'left',
                        scaleLabel: {
                            display: true,
                        },
                        ticks: {
                            //format y axis label
                            min: 0,
                        },
                        suggestedMin: 50,
                        suggestedMax: 500,
                    },
                ],
            },
        },
    },
    LINE_CHART: {
        chartType: 'line',
        labels: ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
        options: {
            spanGaps: false,
            legend: {
                display: false,
            },
            maintainAspectRatio: false,
            layout: {
                padding: {
                    top: 32,
                    left: 32,
                    right: 32,
                },
            },
            elements: {
                point: {
                    radius: 4,
                    borderWidth: 2,
                    hoverRadius: 4,
                    hoverBorderWidth: 2,
                },
                line: {
                    tension: 0,
                },
            },
            scales: {
                xAxes: [
                    {
                        gridLines: {
                            display: false,
                            drawBorder: false,
                            tickMarkLength: 18,
                        },
                        ticks: {
                            fontColor: '#ffffff',
                        },
                    },
                ],
                yAxes: [
                    {
                        display: false,
                        ticks: {
                            min: 0,
                            // max: 5,
                            // stepSize: 0.5,
                        },
                    },
                ],
            },
            plugins: {
                filler: {
                    propagate: false,
                },
                xLabelsOnTop: {
                    active: true,
                },
            },
        },
    },
    DOC_TYPE_DISTR_DETAILS: {
        title: 'Document Distribution Details',
        columns: [
            {
                id: 'doc_name',
                title: 'Document Name',
            },
            {
                id: 'total_docs',
                title: 'Total Document',
            },
            {
                id: 'success_ratio',
                title: 'Success Ratio (%)',
            },
            {
                id: 'not_annotated',
                title: 'Not Annotated Ratio (%)',
            },
            {
                id: 'failed',
                title: 'Failed Ratio (%)',
            },
        ],
        textColors: [
            'bg-blue text-white',
            'bg-green text-white',
            'bg-yellow-dark text-white',
            'bg-purple text-white',
            'bg-pink text-white',
            'bg-indigo text-white',
            'bg-red text-white',
            'bg-blue text-white',
            'bg-orange text-white',
            'bg-green text-white',
            'bg-purple text-white',
            'bg-pink text-white',
            'bg-indigo text-white',
            'bg-red text-white',
            'bg-blue text-white',
            'bg-orange text-white',
            'bg-green text-white',
            'bg-purple text-white',
            'bg-pink text-white',
            'bg-indigo text-white',
            'bg-red text-white',
            'bg-blue text-white',
            'bg-orange text-white',
            'bg-green text-white',
            'bg-purple text-white',
            'bg-pink text-white',
            'bg-indigo text-white',
            'bg-red text-white',
            'bg-blue text-white',
        ],
    },
    // stack bar
    DOC_BY_LOC: {
        options: {
            maintainAspectRatio: true,
            tooltips: {
                mode: 'label',
            },
            responsive: true,
            scales: {
                xAxes: [
                    {
                        barPercentage: 0.5,
                    },
                ],
                yAxes: [
                    {
                        type: 'linear',
                        position: 'left',
                        scaleLabel: {
                            display: true,
                        },
                        ticks: {
                            //format y axis label
                            min: 0,
                        },
                    },
                ],
            },
        },
    },
    // Document type distribution (Pie Chart)
    DOC_TYPE_DISTR: {
        title: 'Document Distribution',
        mainChart: {
            labels: ['No data'],
            datasets: [
                {
                    data: [0],
                    backgroundColor: [
                        '#3490DC',
                        '#38C172',
                        '#F2D024',
                        '#9561E2',
                        '#F66D9B',
                        '#6574CD',
                        'rgb(141,41,115)',
                        'rgb(219,127,194)',
                        'rgb(253,4,143)',
                        'rgb(97,59,79)',
                        'rgb(227,19,238)',
                        'rgb(13,243,143)',
                        'rgb(124,68,14)',
                        'rgb(252,183,144)',
                        'rgb(144,14,8)',
                        'rgb(254,143,6)',
                        'rgb(242,66,25)',
                        'rgb(51,162,126)',
                        'rgb(10,79,78)',
                        'rgb(126,232,192)',
                        'rgb(107,151,170)',
                        'rgb(167,220,249)',
                        'rgb(141,41,115)',
                        'rgb(219,127,194)',
                        'rgb(253,4,143)',
                        'rgb(97,59,79)',
                        'rgb(227,19,238)',
                        'rgb(13,243,143)',
                        'rgb(124,68,14)',
                        'rgb(252,183,144)',
                        'rgb(144,14,8)',
                        'rgb(254,143,6)',
                    ],
                },
            ],
            options: {
                cutoutPercentage: 0,
                spanGaps: false,
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        padding: 16,
                        usePointStyle: true,
                    },
                },
                maintainAspectRatio: false,
                tooltips: {
                    callbacks: {
                        label: function(tooltipItem, data) {
                            let label = data.labels[tooltipItem.index];
                            let value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                            return label + ': ' + value + '%';
                        },
                    },
                },
            },
        },
    },
    DOC_BY_LOC: {
        // stackBar chart
        labels: ['NA', 'SEAS', 'CN', 'AF', 'SAS'],
        datasets: [
            {
                label: 'SI',
                data: [3412, 3774, 3164, 3572, 3213],
                backgroundColor: 'rgb(244, 67, 54)',
                hoverBackgroundColor: 'rgb(244, 67, 54, 0.7)',
                borderWidth: 1,
                stack: 'docByLoc',
                maxBarThickness: 20,
            },
            {
                label: 'BL',
                data: [1482, 1289, 1126, 1276, 1223],
                backgroundColor: 'rgb(3, 169, 244)',
                hoverBackgroundColor: 'rgb(3, 169, 244, 0.7)',
                borderWidth: 1,
                stack: 'docByLoc',
                maxBarThickness: 20,
            },
            {
                label: 'VP',
                data: [1235, 1231, 1451, 1235, 1124],
                backgroundColor: 'rgb(255, 193, 7)',
                hoverBackgroundColor: 'rgb(255, 193, 7, 0.7)',
                borderWidth: 1,
                stack: 'docByLoc',
                maxBarThickness: 20,
            },
            {
                label: 'Other',
                data: [2236, 1736, 2313, 2452, 2012],
                backgroundColor: 'rgb(0, 204, 0)',
                hoverBackgroundColor: 'rgb(0, 204, 0, 0.7)',
                borderWidth: 1,
                stack: 'docByLoc',
                maxBarThickness: 20,
            },
        ],
        options: {
            maintainAspectRatio: true,
            tooltips: {
                mode: 'label',
            },
            responsive: true,
            scales: {
                xAxes: [{}],
                yAxes: [
                    {
                        type: 'linear',
                        position: 'left',
                        scaleLabel: {
                            display: true,
                        },
                        ticks: {
                            //format y axis label
                            min: 0,
                        },
                    },
                ],
            },
        },
    },
    DOC_PAGE_PROC: {
        labels: ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
        options: {
            tooltips: {
                mode: 'label',
            },
            maintainAspectRatio: true,
            scales: {
                yAxes: [
                    {
                        // type: 'linear',
                        position: 'left',
                        scaleLabel: {
                            display: true,
                        },
                        ticks: {
                            //format y axis label
                            min: 0,
                        },
                    },
                ],
            },
            // Straight line
            elements: {
                // point: {
                //     radius: 0,
                // },
                line: {
                    tension: 0,
                },
            },
        },
    },
    TIME_LINE_CHART: {
        BORDER_COLORS: [
            'rgb(244, 67, 54)',
            'rgb(3, 169, 244)',
            'rgb(255, 193, 7)',
            'rgb(0, 204, 0)',
            'rgb(149, 97, 226)',
            // update more color later
        ],
        BACKGROUND_COLOR: [
            'rgb(244, 67, 54)',
            'rgb(3, 169, 244)',
            'rgb(255, 193, 7)',
            'rgb(0, 204, 0)',
            'rgb(149, 97, 226)',
            // update more color later
        ],
        labels: ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
        datasets: [
            {
                label: 'SI',
                data: [142, 156, 132, 137, 125, 142, 156, 132, 137, 125, 100, 100],
                borderColor: 'rgb(244, 67, 54)',
                backgroundColor: 'rgb(244, 67, 54)',
                borderWidth: 2,
                fill: false,
            },
        ],
        options: {
            tooltips: {
                mode: 'label',
            },
            scales: {
                yAxes: [
                    {
                        type: 'linear',
                        position: 'left',
                        scaleLabel: {
                            display: true,
                        },
                        ticks: {
                            //format y axis label
                            min: 0,
                        },
                    },
                ],
            },
            // Straight line
            elements: {
                point: {
                    radius: 1,
                },
                line: {
                    tension: 0,
                },
            },
        },
    },
};

export default ChartConfig;

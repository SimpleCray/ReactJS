/* eslint-disable react/prop-types */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Typography, Paper } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import { Doughnut } from 'react-chartjs-2';
import { FuseAnimate } from '@fuse';
import _ from '@lodash';
import * as Actions from '../store/actions';
import ChartConfig from '../configs/ChartConfig';
import * as TableFnc from '../../../utils/tableFunctions';

const useStyles = makeStyles(theme => ({
    year_disabled: {
        color: '#C0C0C0',
    },
    year_enable: {
        color: '#000000',
    },
}));

const initChart = () => {
    return {
        data: [0, 0],
        backgroundColor: ['#f94144', '#808080'],
        hoverBackgroundColor: ['#f45a4d', '#303030'],
        borderWidth: 1,
    };
};

function SuccessRatio(props) {
    const dispatch = useDispatch();
    const docsSuccess = useSelector(({ dashboard }) => dashboard.dashboard.docsSuccess);
    const lastThreeYears = useSelector(({ dashboard }) => dashboard.dashboard.lastThreeYears);
    const chartParams = props.params;
    const classes = useStyles(props);

    const [dataset, setDataset] = useState(initChart());
    const [year, setYear] = useState(new Date().getFullYear());

    useEffect(() => {
        dispatch(Actions.getLastThreeYears());
    }, []);

    useEffect(() => {
        const datasetCopy = _.merge({}, dataset);
        if (docsSuccess > 0) {
            const successRate = TableFnc.parseAndFixedFloatNumber(docsSuccess, 2, 100);
            datasetCopy.data = [successRate, 100.0 - successRate];
        }
        if (docsSuccess === 0) {
            datasetCopy.data = [0.0, 0.0];
        }
        setDataset(datasetCopy);
    }, [docsSuccess]);

    useEffect(() => {
        chartParams.year = year;
        dispatch(Actions.getDocsSuccess(chartParams));
    }, [year]);

    const handleYearChange = key => {
        setYear(key);
    };

    return (
        <Paper className="w-full rounded-8 shadow-none border-3">
            <div className="flex items-center justify-between px-16 h-64 border-b-1">
                <FuseAnimate delay={100}>
                    <div className="flex-col">
                        <Typography className="text-16">Success Ratio</Typography>
                    </div>
                </FuseAnimate>

                <div className="flex flex-row items-center">
                    {lastThreeYears.map(key => (
                        <Button
                            key={key}
                            className={`py-8 px-12 ${year === key ? classes.year_enable : classes.year_disabled}`}
                            size="small"
                            onClick={() => handleYearChange(key)}
                        >
                            {key}
                        </Button>
                    ))}
                </div>
            </div>
            <div className="w-full p-16">
                <Doughnut
                    height={280}
                    data={{
                        labels: ChartConfig.PIE_CHART.labels,
                        datasets: [dataset],
                    }}
                    options={ChartConfig.PIE_CHART.options}
                />
            </div>
        </Paper>
    );
}

export default React.memo(SuccessRatio);

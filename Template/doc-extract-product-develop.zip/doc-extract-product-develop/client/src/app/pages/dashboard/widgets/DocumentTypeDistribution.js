/* eslint-disable no-return-assign */
import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Typography, Paper } from '@material-ui/core';
import { Doughnut } from 'react-chartjs-2';
import _ from '@lodash';
import ChartConfig from '../configs/ChartConfig';
import * as TableFnc from '../../../utils/tableFunctions';

function DocumentTypeDistribution(props) {
    const distriDocs = useSelector(({ dashboard }) => dashboard.dashboard.distriDocs);
    const [dataset, setDataset] = useState(_.merge({}, ChartConfig.DOC_TYPE_DISTR));

    useEffect(() => {
        const datasetCopy = _.merge({}, dataset);
        if (!_.isEmpty(distriDocs)) {
            // reset data
            datasetCopy.mainChart.labels = _.merge([], distriDocs.doc_name);
            const newData = [];
            datasetCopy.mainChart.datasets.forEach(item => {
                newData.push(
                    _.pick({ ...item, data: getPercentageDocDistr(distriDocs.data) }, [
                        'backgroundColor',
                        'data',
                        'hoverBackgroundColor',
                    ]),
                );
            });
            datasetCopy.mainChart.datasets = newData;
        }
        setDataset(datasetCopy);
    }, [distriDocs]);

    const sumArray = dataArray => {
        return dataArray.reduce((acc, val) => {
            return acc + val;
        }, 0);
    };

    const getPercentageDocDistr = data => {
        const result = [];
        const sumOfDoc = sumArray(data);
        data.map(val => result.push(TableFnc.parseAndFixedFloatNumber(val / sumOfDoc, 2, 100)));
        return result;
    };

    return (
        <Paper className="w-full rounded-8 shadow-none border-1">
            <div className="flex items-center justify-between px-16 h-64 border-b-1">
                <Typography className="text-16">{dataset.title}</Typography>
            </div>
            <div className="w-full h-400 p-32">
                <Doughnut
                    data={{
                        labels: dataset.mainChart.labels,
                        datasets: dataset.mainChart.datasets,
                    }}
                    options={dataset.mainChart.options}
                />
            </div>
        </Paper>
    );
}

export default React.memo(DocumentTypeDistribution);

const WidgetConst = {
    TotalTemp: {
        title: 'Total Template',
        label: 'Templates',
    },
    TotalCompany: {
        title: 'Total Company',
        label: 'Companies',
    },
    TotalLocation: {
        title: 'Total Location',
        label: 'Locations',
    },
    TotalDocProcessed: {
        title: 'Document Received',
        label: 'Documents',
    },
    TotalPageProcessed: {
        title: 'Total page',
        label: 'Pages',
    },
    AvgProcessTime: {
        title: 'Average Processing Time',
        label: 'Seconds',
    },
    AvgAnnotateTime: {
        title: 'Average Annotation Time',
        label: 'Seconds',
    },
    ComDoc: {
        title: 'Document by Top Company',
    },
    paletteColor: ['#003f5c', '#2f4b7c', '#665191', '#a05195', '#d45087'],
    hoverBackgroundColor: []
};

export default WidgetConst;

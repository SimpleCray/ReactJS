/* eslint-disable react/prop-types */
/* eslint-disable no-plusplus */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Card, Paper, Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import { FuseAnimate } from '@fuse';
import * as Actions from '../store/actions';
import AppConstants from 'app/utils/appConstants';
import _ from '@lodash';

const useStyles = makeStyles(theme => ({
    year_disabled: {
        color: '#C0C0C0',
    },
    year_enable: {
        color: '#000000',
    },
}));

const statusConfig = {
    rows: [
        {
            status: AppConstants.DOC_STATUS.A,
            total: 0,
        },
        {
            status: AppConstants.DOC_STATUS.V,
            total: 0,
        },
        {
            status: AppConstants.DOC_STATUS.E,
            total: 0,
        },
        {
            status: AppConstants.DOC_STATUS.F,
            total: 0,
        },
    ],
};

function DocByStatus(props) {
    const dispatch = useDispatch();
    const docByStatus = useSelector(({ dashboard }) => dashboard.dashboard.docByStatus);
    const lastThreeYears = useSelector(({ dashboard }) => dashboard.dashboard.lastThreeYears);
    const chartParams = props.params;
    const [dataset, setDataset] = useState(_.merge({}, statusConfig));
    const [year, setYear] = useState(new Date().getFullYear());
    const classes = useStyles(props);

    useEffect(() => {
        dispatch(Actions.getLastThreeYears());
    }, []);

    useEffect(() => {
        chartParams.year = year;
        dispatch(Actions.getDocByStatus(chartParams));
    }, [year]);

    const handleYearChange = key => {
        setYear(key);
    };

    useEffect(() => {
        if (docByStatus) {
            const datasetCopy = _.merge({}, statusConfig);
            // sts_cd is all status doc
            const { sts_cd, count } = docByStatus;
            if (sts_cd && count) {
                for (let idx = 0; idx < sts_cd.length; idx++) {
                    const countOfSts = parseInt(count[idx], 10);
                    switch (sts_cd[idx]) {
                        case AppConstants.DOC_STATUS_CODE.A:
                            datasetCopy.rows[0].total += countOfSts;
                            break;
                        case AppConstants.DOC_STATUS_CODE.N:
                            datasetCopy.rows[0].total += countOfSts;
                            break;
                        case AppConstants.DOC_STATUS_CODE.V:
                            datasetCopy.rows[1].total += countOfSts;
                            break;
                        case AppConstants.DOC_STATUS_CODE.E:
                            datasetCopy.rows[2].total += countOfSts;
                            break;
                        default:
                            datasetCopy.rows[3].total += countOfSts;
                    }
                }
                setDataset(datasetCopy);
            }
        }
    }, [docByStatus]);

    return (
        <Paper className="w-full h-full rounded-8 shadow-none border-3" variant="outlined">
            <div className="flex items-center justify-between px-16 h-64 border-b-1">
                <FuseAnimate delay={100}>
                    <div className="flex-col">
                        <Typography className="text-16">Documents by status</Typography>
                    </div>
                </FuseAnimate>

                <div className="flex flex-row items-center">
                    {lastThreeYears.map(key => (
                        <Button
                            key={key}
                            className={`py-8 px-12 ${year === key ? classes.year_enable : classes.year_disabled}`}
                            size="small"
                            onClick={() => handleYearChange(key)}
                        >
                            {key}
                        </Button>
                    ))}
                </div>
            </div>

            <div className="w-full p-16">
                <Card className="w-full rounded-8 shadow-none">
                    <table className="simple">
                        <thead>
                            <tr>
                                <th className="text-left">
                                    <b>Status</b>
                                </th>
                                <th className="text-right">
                                    <b>Total</b>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {dataset.rows.map(row => (
                                <tr key={row.status}>
                                    <td>{row.status}</td>
                                    <td className="text-right">{row.total}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </Card>
            </div>
        </Paper>
    );
}

export default React.memo(DocByStatus);

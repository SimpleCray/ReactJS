/* eslint-disable react/prop-types */
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Paper, Typography, FormControl } from '@material-ui/core';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import { Line } from 'react-chartjs-2';
import _ from 'lodash';
import useStyles from '../utils/styles';
import ChartConfig from '../configs/ChartConfig';
import * as Actions from '../store/actions';
import { getMonthsArray } from '../utils/commonFuncs';

const initChart = () => {
    return {
        label: 'No data',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        borderColor: 'rgb(244, 67, 54)',
        backgroundColor: 'rgb(244, 67, 54)',
        borderWidth: 3,
        fill: false,
    };
};

function AnnotateTimeByTime(props) {
    const dispatch = useDispatch();
    const annotateTimeAvgByMonth = useSelector(({ dashboard }) => dashboard.dashboard.annotateTimeAvgByMonth);

    const classes = useStyles();
    const [year, setYear] = useState(`${new Date().getFullYear()}`);
    const [dataset, setDataset] = useState([initChart()]);
    const chartParams = props.params;

    useEffect(() => {
        if (annotateTimeAvgByMonth) {
            const newDataset = [];
            Object.keys(annotateTimeAvgByMonth).map((docName, idx) => {
                let tmpChart = _.merge({}, initChart());
                // data by month
                const dataByMonth = _.pick(annotateTimeAvgByMonth[docName], ChartConfig.TIME_LINE_CHART.labels);
                tmpChart = {
                    ...tmpChart,
                    label: docName,
                    data: Object.values(dataByMonth).map(item => parseFloat(item)),
                    borderColor: ChartConfig.TIME_LINE_CHART.BORDER_COLORS[idx],
                    backgroundColor: ChartConfig.TIME_LINE_CHART.BACKGROUND_COLOR[idx],
                };
                newDataset.push(tmpChart);
            });
            setDataset(newDataset);
        }
    }, [annotateTimeAvgByMonth]);

    useEffect(() => {
        chartParams.year = year;
        dispatch(Actions.getAnnotateTimeAvgByMonth(chartParams));
    }, [year]);

    const handleChange = key => {
        setYear(`${key.getFullYear()}`);
    };
    return (
        <Paper className="w-full rounded-8 shadow-none border-1">
            <div className="flex items-center justify-between px-16 py-16 border-b-1">
                <Typography className="text-16">Average Annotation Time By Month</Typography>
                <div className="flex w-2/4">
                    <FormControl size="small" variant="outlined" className={classes.formControl}>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <KeyboardDatePicker
                                disableToolbar
                                size="small"
                                views={['year']}
                                label="Year"
                                value={year}
                                type="year"
                                onChange={val => handleChange(val)}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                format="yyyy"
                                variant="inline"
                                inputVariant="outlined"
                            />
                        </MuiPickersUtilsProvider>
                    </FormControl>
                </div>
            </div>
            <div>
                <Line
                    height={150}
                    data={{
                        labels: ChartConfig.TIME_LINE_CHART.labels,
                        datasets: dataset,
                    }}
                    options={ChartConfig.TIME_LINE_CHART.options}
                />
            </div>
        </Paper>
    );
}

export default React.memo(AnnotateTimeByTime);

import AppConstants from 'app/utils/appConstants';

const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

// Find only unique value in array
export const uniqueArray = (arrayParam, fieldParam) => {
    const returnArray = [];
    arrayParam.forEach(item => {
        const isExsited = returnArray.some(el => el[fieldParam] === item[fieldParam]);
        if (!isExsited) returnArray.push(item);
    });

    return returnArray;
};

export const isMasterAdmin = role => role === AppConstants.USER_ROLES.MASTER_ADMIN;

export const isShineAdmin = role => role === AppConstants.USER_ROLES.SHINE_ADMIN;

export const isShineUser = role => role === AppConstants.USER_ROLES.SHINE_USER;

export const setParamByUserRole = (userInfo, userRole) => {
    const currentMonth = month2digits(new Date().getMonth() + 1);
    const currentYear = new Date().getFullYear();
    return {
        co_cd: isShineAdmin(userRole) || isShineUser(userRole) ? userInfo.coCd : null,
        loc_cd: userInfo.locCd ? userInfo.locCd : null,
        usr_id: isShineUser(userRole) ? userInfo.usrId : null,
        year: currentYear,
        limit: 5,
        month: currentMonth,
        role_name: userRole || null,
    };
};

// month with 2 digits (e.g. 2 -> 02)
export const month2digits = n => {
    return n < 10 ? `0${n}` : `${n}`;
};

// get range of months
export const getMonthsArray = (start, end) => {
    const startMonth = start.getMonth(); // JAN = 0
    const endMonth = end.getMonth();
    const months = MONTHS.slice(startMonth, endMonth + 1);
    return months;
};

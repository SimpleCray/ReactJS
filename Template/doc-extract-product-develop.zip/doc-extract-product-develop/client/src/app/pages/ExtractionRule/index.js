import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { FusePageCarded } from '@fuse';
import PanelGroup from 'react-panelgroup';
import _ from '@lodash';

import withReducer from '../../store/withReducer';
import reducer from './store/reducers';

import ExtractionContent from './ExtractionContent';
import ExtractionTree from './ExtractionTree';
import ExtractionHeader from './ExtractionHeader';

import * as Actions from './store/actions';

const ExtractionRule = () => {
    const dispatch = useDispatch();

    const [search, setSearch] = useState('');

    const onSearchChange = event => setSearch(event.target.value);

    // Get data from server database
    useEffect(() => {
        dispatch(Actions.getCommonData());
        dispatch(Actions.getDocDefine());
    }, [dispatch]);

    return (
        <FusePageCarded
            classes={{
                content: 'flex',
                header: 'min-h-60 h-60 sm:h-60 sm:min-h-60',
                topBg: 'min-h-60 h-60 sm:h-60 sm:min-h-60',
                contentWrapper: 'pr-0 pl-0',
            }}
            header={<ExtractionHeader search={search} onSearchChange={onSearchChange} />}
            content={
                <PanelGroup
                    panelWidths={[
                        {
                            size: (document.documentElement.clientWidth - 73) / 3,
                            minSize: 100,
                            resize: 'dynamic',
                        },
                        {
                            size: ((document.documentElement.clientWidth - 73) * 2) / 3,
                            minSize: 100,
                            resize: 'dynamic',
                        },
                    ]}
                >
                    <ExtractionTree search={search} />
                    <ExtractionContent />
                </PanelGroup>
            }
            innerScroll
        />
    );
};

export default withReducer('extractionRule', reducer)(ExtractionRule);

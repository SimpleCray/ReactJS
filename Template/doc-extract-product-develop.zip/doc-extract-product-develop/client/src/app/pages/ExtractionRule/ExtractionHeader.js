import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ThemeProvider } from '@material-ui/styles';
import { Paper, Input, TextField, FormControlLabel, Checkbox } from '@material-ui/core';
import { Search } from '@material-ui/icons';
import { Autocomplete } from '@material-ui/lab';

import CustomButton from '../../components/Button';

import * as Functions from './ExtractionFunction';
import * as Actions from './store/actions';

const ExtractionHeader = props => {
    const classes = Functions.useStyles();
    const dispatch = useDispatch();

    const mainTheme = useSelector(({ fuse }) => fuse.settings.mainTheme);
    const documentDefine = useSelector(({ extractionRule }) => extractionRule.extractionRule.documentDefine);
    const currentDocument = useSelector(({ extractionRule }) => extractionRule.extractionRule.currentDocument);
    const currentDeleteFlag = useSelector(({ extractionRule }) => extractionRule.extractionRule.currentDeleteFlag);

    const onDeleteCheckboxChange = event => dispatch(Actions.setDeleteFlag(event.target.checked ? 'Y' : 'N'));

    const onDocumentChange = (e, value) => {
        dispatch(Actions.setCurrentDocument(value));
        dispatch(Actions.setStatusAction('none'));
        dispatch(Actions.setCurrentExtractionRule({}));
        dispatch(Actions.getDocumentField(value.doc_tp_id));
        dispatch(Actions.getExtractionRule(value.doc_tp_id));
    };

    useEffect(() => {
        if (documentDefine && documentDefine.length) {
            dispatch(Actions.setCurrentDocument(documentDefine[0]));
            dispatch(Actions.getDocumentField(documentDefine[0].doc_tp_id));
            dispatch(Actions.getExtractionRule(documentDefine[0].doc_tp_id));
        }
    }, [documentDefine]);

    return (
        <div className="flex w-full items-center px-5">
            <div className={classes.textFieldWidth}>
                <Autocomplete
                    {...Functions.autoCompleteProps}
                    disableClearable
                    options={documentDefine || []}
                    getOptionLabel={option => option.doc_nm || ''}
                    renderInput={params => <TextField {...params} label="Document name" variant="outlined" />}
                    onChange={onDocumentChange}
                    value={currentDocument || ''}
                />
            </div>

            {/* <div className="flex-none px-15 ml-3">
                <CustomButton color="default">Search</CustomButton>
            </div> */}

            <div className="flex-none px-15 mx-3">
                <ThemeProvider theme={mainTheme}>
                    <Paper className="flex items-center max-w-600 px-8 py-4 ml-2 rounded-8" elevation={1}>
                        <Search className="mr-8" color="action" />
                        <Input
                            placeholder="Search extraction field"
                            className="flex flex-1"
                            disableUnderline
                            fullWidth
                            onChange={props.onSearchChange}
                            value={props.search}
                        />
                    </Paper>
                </ThemeProvider>
            </div>
            <FormControlLabel
                label="Deleted"
                control={<Checkbox color="secondary" checked={currentDeleteFlag === 'Y'} />}
                onChange={onDeleteCheckboxChange}
            />
        </div>
    );
};

export default ExtractionHeader;

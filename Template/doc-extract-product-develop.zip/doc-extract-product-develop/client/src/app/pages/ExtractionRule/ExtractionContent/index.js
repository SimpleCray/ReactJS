import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { TextField, Paper, FormControlLabel, Checkbox, Typography } from '@material-ui/core';
import { NotInterestedOutlined } from '@material-ui/icons';
import { Autocomplete } from '@material-ui/lab';

import CustomButton from '../../../components/Button';
import { openDialog } from '../../../store/actions/fuse/dialog.actions';
import { showMessage } from '../../../store/actions/fuse/message.actions';

import ExtractionRegex from './ExtractionRegex';

import * as Functions from '../ExtractionFunction';
import * as Actions from '../store/actions';

const ExtractionRuleNotFound = () => {
    return (
        <div className="w-full h-full flex flex-col border-2 items-center justify-center">
            <NotInterestedOutlined color="action" />
            <Typography color="textSecondary" variant="subtitle1">
                Not found any extraction rule data.
            </Typography>
        </div>
    );
};

const ExtractionContent = props => {
    const classes = Functions.useStyles();
    const dispatch = useDispatch();

    const listExtractionRule = useSelector(({ extractionRule }) => extractionRule.extractionRule.extractionRule);
    const documentField = useSelector(({ extractionRule }) => extractionRule.extractionRule.documentField);
    const statusAction = useSelector(({ extractionRule }) => extractionRule.extractionRule.statusAction);
    const currentDocument = useSelector(({ extractionRule }) => extractionRule.extractionRule.currentDocument);
    const currentDeleteFlag = useSelector(({ extractionRule }) => extractionRule.extractionRule.currentDeleteFlag);
    const currentValidateFlag = useSelector(({ extractionRule }) => extractionRule.extractionRule.currentValidateFlag);
    const ouputPreview = useSelector(({ extractionRule }) => extractionRule.extractionRule.ouputPreview);
    const currentExtractionRule = useSelector(
        ({ extractionRule }) => extractionRule.extractionRule.currentExtractionRule,
    );

    const [fieldName, setFieldName] = useState(null);
    const [listField, setListField] = useState(null);
    const [checkActive, setCheckActive] = useState(null);
    const [inputValue, setInputValue] = useState('');
    const [outputValue, setOutputValue] = useState('');
    const [inputError, setInputError] = useState(false);
    const [dataNotFound, setDataNotFound] = useState(false);
    const [fieldOrder, setFieldOrder] = useState('');
    const [showFieldOrder, setShowFieldOrder] = useState(false);

    const onFieldNameChange = (e, value) => {
        const selectExtractionRule = listExtractionRule.find(item => item.doc_fld_id === value.doc_fld_id);
        const alignNode = Functions.alignNodeBeforeUpdate(selectExtractionRule);
        dispatch(Actions.setCurrentExtractionRule(alignNode));
    };

    const onActiveChange = e => {
        if (currentExtractionRule?.dex_extr_rule?.length) {
            const parseFlag = e.target.checked ? 'N' : 'Y';
            const updateDexExtrRule = { ...currentExtractionRule.dex_extr_rule[0], delt_flg: parseFlag };
            const updateCurrentExtractionRule = { ...currentExtractionRule, dex_extr_rule: [updateDexExtrRule] };
            if (statusAction !== 'new') dispatch(Actions.setStatusAction('update'));
            dispatch(Actions.setCurrentExtractionRule(updateCurrentExtractionRule));
        }
    };

    const onOrderChange = e => {
        if (currentExtractionRule?.dex_extr_rule?.length) {
            const updateExtractionRuleData = {
                ...currentExtractionRule.dex_extr_rule[0].extr_rule_ctnt,
                ord_no: e.target.value,
            };
            const updateDexExtrRule = {
                ...currentExtractionRule.dex_extr_rule[0],
                extr_rule_ctnt: updateExtractionRuleData,
            };
            const updateCurrentExtractionRule = { ...currentExtractionRule, dex_extr_rule: [updateDexExtrRule] };
            if (statusAction !== 'new') dispatch(Actions.setStatusAction('update'));
            dispatch(Actions.setCurrentExtractionRule(updateCurrentExtractionRule));
        }
    };

    const onCancelClick = () => {
        if (statusAction !== 'none') {
            return dispatch(
                openDialog('Leave without save your extraction rule?', 'You have unsaved changes', 'Confirm', () => {
                    dispatch(Actions.setValidateFlag('valid'));
                    dispatch(Actions.setStatusAction('none'));

                    if (statusAction === 'new') {
                        dispatch(Actions.setCurrentExtractionRule({}));
                        dispatch(Actions.getExtractionRule(currentDocument.doc_tp_id));
                    } else {
                        const refreshCurrentExtractionRule = listExtractionRule.find(
                            item => item.doc_fld_id === currentExtractionRule.doc_fld_id,
                        );
                        let updateCurrentExtractionRule = refreshCurrentExtractionRule;
                        if (!updateCurrentExtractionRule) {
                            const listLeafNode = listExtractionRule.flatMap(item => item.child_fields || []);
                            updateCurrentExtractionRule = listLeafNode.find(
                                item => item.doc_fld_id === currentExtractionRule.doc_fld_id,
                            );
                        }

                        const alignNode = Functions.alignNodeBeforeUpdate(updateCurrentExtractionRule);
                        dispatch(Actions.setCurrentExtractionRule(alignNode));
                    }
                }),
            );
        }
    };

    const saveValidate = (extractionRuleData, action) => {
        const regexListData = extractionRuleData.reg_expr_val;
        const paramListData = extractionRuleData.src_val;

        const emptyRegexListError = !regexListData.length || regexListData.some(item => !item.action || !item.regex);
        const emptyParamListError = paramListData.some(item => !item.param || !item.com_dat_id || !item.col_nm);

        const regexListError = regexListData.flatMap((item, index) => {
            const removeParam = item.regex.replace(/\{{[\w!@#$%^&*!-=+,./]*\}}/g, '');
            try {
                new RegExp(removeParam, 'g');
                return [];
            } catch (error) {
                return [index];
            }
        });

        const isValid = !emptyRegexListError && !emptyParamListError && !regexListError.length;

        if (!isValid) {
            dispatch(Actions.setValidateFlag(action));

            if (emptyRegexListError || emptyParamListError)
                dispatch(
                    showMessage({
                        message: emptyRegexListError
                            ? 'Regex define not allow empty!'
                            : 'Param define not allow empty!',
                        variant: 'error',
                    }),
                );
            else if (regexListError.length) {
                dispatch(
                    showMessage({
                        message: 'Please check invalid regex!',
                        variant: 'error',
                    }),
                );
                dispatch(Actions.setValidateFlag(regexListError));
            }
        } else dispatch(Actions.setValidateFlag('valid'));

        return isValid;
    };

    const onSaveClick = () => {
        if (
            currentExtractionRule?.dex_extr_rule &&
            currentExtractionRule?.dex_extr_rule.length &&
            currentExtractionRule?.dex_extr_rule[0].extr_rule_ctnt
        ) {
            const extractionRuleData = currentExtractionRule.dex_extr_rule[0].extr_rule_ctnt;
            const needOrderNo = !showFieldOrder || extractionRuleData.ord_no;
            const saveValid = saveValidate(extractionRuleData, 'save_error') && needOrderNo;
            if (!needOrderNo) {
                dispatch(
                    showMessage({
                        message: 'Order nonot allow empty!',
                        variant: 'error',
                    }),
                );
                dispatch(Actions.setValidateFlag('save_error'));
            }
            if (saveValid || currentExtractionRule?.child_fields?.length) {
                dispatch(Actions.setStatusAction('none'));
                dispatch(Actions.setValidateFlag('valid'));

                if (!currentExtractionRule.dex_extr_rule[0].extr_rule_id) {
                    dispatch(
                        Actions.createExtractionRule({
                            extr_rule_ctnt: JSON.stringify(extractionRuleData),
                            doc_fld_id: currentExtractionRule.doc_fld_id,
                            cre_usr_id: JSON.parse(localStorage.getItem('userInfo')).usrId,
                            upd_usr_id: JSON.parse(localStorage.getItem('userInfo')).usrId,
                        }),
                    );
                } else {
                    dispatch(
                        Actions.updateExtractionRule({
                            ...currentExtractionRule.dex_extr_rule[0],
                            extr_rule_ctnt: JSON.stringify(extractionRuleData),
                            upd_usr_id: JSON.parse(localStorage.getItem('userInfo')).usrId,
                        }),
                    );
                }
            }
        }
    };

    const onRunClick = () => {
        setInputError(!inputValue.length);

        if (currentExtractionRule?.child_fields?.length && inputValue.length) {
            return dispatch(
                Actions.runMultipleExtractionRule({
                    input: inputValue,
                    extrRule: currentExtractionRule,
                }),
            );
        }

        if (
            currentExtractionRule?.dex_extr_rule &&
            currentExtractionRule?.dex_extr_rule.length &&
            currentExtractionRule?.dex_extr_rule[0].extr_rule_ctnt
        ) {
            const extractionRuleData = currentExtractionRule.dex_extr_rule[0].extr_rule_ctnt;
            const saveValid = saveValidate(extractionRuleData, 'run_error');

            if (inputValue.length && saveValid) {
                dispatch(Actions.setValidateFlag('valid'));

                dispatch(
                    Actions.runSignleExtractionRule({
                        input: inputValue,
                        extrRule: currentExtractionRule,
                    }),
                );
            }
        }
    };

    useEffect(() => {
        if (currentExtractionRule && documentField) {
            setInputValue('');
            setOutputValue('');
            setInputError(false);

            const fieldDetail = documentField.find(
                item => currentExtractionRule.doc_fld_id && item.doc_fld_id === currentExtractionRule.doc_fld_id,
            );
            setFieldName(fieldDetail);

            const currentChecked =
                !currentExtractionRule?.dex_extr_rule?.length ||
                !currentExtractionRule.dex_extr_rule[0].delt_flg ||
                currentExtractionRule.dex_extr_rule[0].delt_flg === 'N';
            setCheckActive(currentChecked);

            // Set show order
            setShowFieldOrder(!!fieldDetail?.fld_grp_id);

            // Set field order setFieldOrder

            console.log(currentExtractionRule.dex_extr_rule);

            const order =
                currentExtractionRule?.dex_extr_rule?.length &&
                currentExtractionRule.dex_extr_rule[0].extr_rule_ctnt?.ord_no
                    ? currentExtractionRule.dex_extr_rule[0].extr_rule_ctnt.ord_no
                    : '';
            setFieldOrder(order);
        }
    }, [currentExtractionRule]);

    useEffect(() => {
        if (documentField && listExtractionRule) {
            const parrentFieldDetail = documentField.filter(item =>
                listExtractionRule.some(el => !el?.dex_extr_rule?.length && item.doc_fld_id === el.doc_fld_id),
            );
            setListField(parrentFieldDetail);

            const alignTreeData = listExtractionRule.filter(
                item => item.dex_extr_rule.length && item.dex_extr_rule[0].delt_flg === currentDeleteFlag,
            );
            setDataNotFound(alignTreeData.length === 0 && statusAction !== 'new');
        }
    }, [documentField, listExtractionRule, statusAction]);

    useEffect(() => {
        const alignTreeData = listExtractionRule.filter(
            item => item.dex_extr_rule.length && item.dex_extr_rule[0].delt_flg === currentDeleteFlag,
        );
        setDataNotFound(alignTreeData.length === 0 && statusAction !== 'new');
        if (alignTreeData.length > 0) {
            const alignNode = Functions.alignNodeBeforeUpdate(alignTreeData[0]);
            dispatch(Actions.setCurrentExtractionRule(alignNode));
        }
    }, [currentDeleteFlag]);

    // Reload ouput preview when recieve respone from server
    useEffect(() => {
        if (ouputPreview && currentExtractionRule) {
            if (typeof ouputPreview === 'string' || Array.isArray(ouputPreview))
                setOutputValue(JSON.stringify(ouputPreview).replace(/[]+/g, ''));
            else if (currentExtractionRule.child_fields) {
                // Replace field id by field name
                const ouputReplaceKey = Object.keys(ouputPreview).reduce((obj, key) => {
                    const findFieldName = currentExtractionRule.child_fields.find(item => item.doc_fld_id === key);
                    return { ...obj, [findFieldName.fld_nm]: ouputPreview[key] };
                }, {});
                const prettyOutput = JSON.stringify(ouputReplaceKey).includes(']')
                    ? JSON.stringify(ouputReplaceKey).replace(/(],)+/g, ']\n')
                    : JSON.stringify(ouputReplaceKey).replace(/(",)+/g, ']\n');
                setOutputValue(prettyOutput.replace(/[{}]+/g, ' ').trim());
            }
        }
    }, [ouputPreview]);

    return (
        <React.Fragment>
            {dataNotFound ? (
                <ExtractionRuleNotFound />
            ) : (
                <div className="w-full flex flex-col border-2 p-3 my-2 mx-1 column relative">
                    <div className="flex flex-row my-5">
                        <Autocomplete
                            {...Functions.autoCompleteProps}
                            disableClearable
                            className="w-6/12 mr-5"
                            options={listField || []}
                            getOptionLabel={option => option.fld_nm || ''}
                            renderInput={params => <TextField {...params} label="Field name" variant="outlined" />}
                            value={fieldName || ''}
                            onChange={onFieldNameChange}
                            disabled={statusAction !== 'new'}
                        />
                        {showFieldOrder && (
                            <TextField
                                {...Functions.textFieldCommonProps}
                                className="w-2/12 mr-5"
                                label="Order no"
                                type="number"
                                value={fieldOrder || ''}
                                onChange={onOrderChange}
                                error={currentValidateFlag === 'save_error' && !fieldOrder?.length}
                            />
                        )}
                        <FormControlLabel
                            label="Active"
                            control={<Checkbox color="secondary" checked={checkActive} />}
                            disabled={statusAction === 'new'}
                            onChange={onActiveChange}
                        />
                    </div>

                    {!currentExtractionRule?.child_fields?.length && currentExtractionRule?.doc_fld_id && (
                        <ExtractionRegex />
                    )}

                    <div className="w-full">
                        <TextField
                            label="Input preview"
                            {...Functions.textFieldCommonProps}
                            multiline
                            rows={3}
                            rowsMax={6}
                            error={inputError && !inputValue.length}
                            onChange={e => setInputValue(e.target.value)}
                            value={inputValue}
                        />
                    </div>
                    <div className="w-full mt-5">
                        <TextField
                            label="Output preview"
                            {...Functions.textFieldCommonProps}
                            multiline
                            rows={3}
                            rowsMax={6}
                            value={outputValue || ''}
                        />
                    </div>

                    <Paper elevation={0} className={classes.saveContainer}>
                        <CustomButton
                            {...Functions.buttonCommonProps}
                            disabled={!currentExtractionRule?.doc_fld_id}
                            onClick={onRunClick}
                        >
                            RUN
                        </CustomButton>
                        <CustomButton {...Functions.buttonCommonProps} onClick={onCancelClick}>
                            CANCEL
                        </CustomButton>
                        <CustomButton {...Functions.buttonCommonProps} onClick={onSaveClick}>
                            SAVE
                        </CustomButton>
                    </Paper>
                </div>
            )}
        </React.Fragment>
    );
};

export default ExtractionContent;

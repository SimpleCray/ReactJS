import * as Actions from '../actions';
import * as Functions from '../../ExtractionFunction';

const initialState = {
    extractionRule: [],
    commonData: [],
    documentDefine: [],
    documentField: [],
    currentExtractionRule: {},
    saveDynamicCallback: {},
    statusAction: 'none', // VALUES: [none, update, new]
    ouputPreview: '',
    currentDocument: {},
    currentDeleteFlag: 'N', // VALUES: [Y, N]
    currentValidateFlag: 'valid', //VALUES: [valid, run_error, save_error, [index of invalid regex]]
};

const extractionRule = (state = initialState, action) => {
    switch (action.type) {
        case Actions.COMMON_DATA:
            return {
                ...state,
                commonData: action.payload,
            };

        case Actions.DOCUMENT_DEFINE:
            return {
                ...state,
                documentDefine: action.payload.result,
            };

        case Actions.CURRENT_EXTRACTION_RULE:
            return {
                ...state,
                currentExtractionRule: action.extractionRule,
            };

        case Actions.EXTRACTION_RULES: {
            const parseExtractionDatta = action.payload ? Functions.parseData(action.payload) : [];
            return {
                ...state,
                extractionRule: parseExtractionDatta,
            };
        }

        case Actions.FORCE_EXTRACTION_RULES:
            return {
                ...state,
                extractionRule: action.listExtractionRule,
            };

        case Actions.DOCUMENT_FIELD:
            return {
                ...state,
                documentField: action.payload.result,
            };

        case Actions.STATUS_ACTION:
            return {
                ...state,
                statusAction: action.status,
            };

        case Actions.CURRENT_DOCUMENT:
            return {
                ...state,
                currentDocument: action.document,
            };

        case Actions.MODIFY_EXTRACTION_RULE:
            return {
                ...state,
                saveDynamicCallback: action.payload,
            };

        case Actions.OUPUT_RULE_PREVIEW:
            return {
                ...state,
                ouputPreview: action.payload,
            };

        case Actions.DELETE_FLAG:
            return {
                ...state,
                currentDeleteFlag: action.deleteFlag,
            };

        case Actions.VALIDATE_FLAG:
            return {
                ...state,
                currentValidateFlag: action.validateFlag,
            };

        default:
            return state;
    }
};
export default extractionRule;

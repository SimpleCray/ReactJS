import { makeStyles } from '@material-ui/styles';

export const buttonCommonProps = {
    className: 'whitespace-no-wrap h-32',
    variant: 'contained',
    color: 'primary',
};

export const sourceHeader = [
    {
        id: 'param',
        align: 'left',
        disablePadding: false,
        label: 'Params',
        sort: true,
    },
    {
        id: 'source',
        align: 'left',
        disablePadding: false,
        label: 'Common data reference',
        sort: true,
    },
    {
        id: 'colNm',
        align: 'left',
        disablePadding: false,
        label: 'Column name',
        sort: true,
    },
];

export const useStyles = makeStyles({
    treeview: {
        width: '100%',
        height: 'calc(100vh - 210px)',
        overflow: 'auto',
        marginTop: 5,
    },
    treeviewItem: {
        height: 20,
    },
    paramContainer: {
        width: '100%',
        maxHeight: '30vh',
        overflow: 'auto',
        marginTop: 10,
    },
    saveContainer: {
        width: '100%',
        height: 50,
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
        position: 'absolute',
        bottom: 0,
        right: 0,
        paddingBottom: 5,
        paddingRight: 5,
    },
    backgroundIcon: {
        backgroundColor: 'transparent',
    },
    textFieldWidth: {
        width: '200px',
    },
    regexContainer: {
        width: '100%',
        maxHeight: '20vh',
        overflow: 'auto',
    },
});

export const textFieldCommonProps = {
    fullWidth: true,
    size: 'small',
    autoComplete: 'off',
    variant: 'outlined',
};

export const autoCompleteProps = {
    fullWidth: true,
    className: 'flex flex-1',
    size: 'small',
};

export const parseDexExtrRuleMethod = data =>
    data.extr_rule_ctnt && data.extr_rule_ctnt.length
        ? { ...data, extr_rule_ctnt: JSON.parse(data.extr_rule_ctnt) }
        : data;

export const parseData = data => {
    return data.map(root => {
        // Parse root rule
        const parseDexExtrRule =
            root.dex_extr_rule && root.dex_extr_rule.length ? [parseDexExtrRuleMethod(root.dex_extr_rule[0])] : [];
        // Parse leaf rule
        const parseChildFields =
            root.child_fields && root.child_fields.length
                ? root.child_fields.map(leaf => ({
                      ...leaf,
                      dex_extr_rule:
                          leaf.dex_extr_rule && leaf.dex_extr_rule.length
                              ? [parseDexExtrRuleMethod(leaf.dex_extr_rule[0])]
                              : [],
                  }))
                : [];
        return {
            ...root,
            child_fields: parseChildFields,
            dex_extr_rule: parseDexExtrRule,
        };
    });
};

export const alignNodeBeforeUpdate = node => {
    // If node not has any regex, add default regex
    const emptyExtractionRule = {
        reg_expr_val: [
            {
                regex: '',
                action: '',
            },
        ],
        src_val: [],
    };
    return node && !node.dex_extr_rule?.length
        ? { ...node, dex_extr_rule: [{ extr_rule_ctnt: emptyExtractionRule }] }
        : node;
};

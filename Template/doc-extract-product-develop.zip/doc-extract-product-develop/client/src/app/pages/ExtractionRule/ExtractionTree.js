import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    TableCell,
    TableRow,
    TableHead,
    Table,
    TableBody,
    ListItem,
    ListItemText,
    Paper,
    ListItemSecondaryAction,
} from '@material-ui/core';
import { ExpandMore, ChevronRight } from '@material-ui/icons';
import { TreeView, TreeItem } from '@material-ui/lab';
import { withStyles } from '@material-ui/core/styles';
import { openDialog } from '../../store/actions/fuse/dialog.actions';

import CustomButton from '../../components/Button';
import _ from '@lodash';

import * as Functions from './ExtractionFunction';
import * as Actions from './store/actions';

const StyledTableCell = withStyles(theme => ({
    head: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
}))(TableCell);

const ExtractionTree = props => {
    const classes = Functions.useStyles();
    const dispatch = useDispatch();

    const listExtractionRule = useSelector(({ extractionRule }) => extractionRule.extractionRule.extractionRule);
    const statusAction = useSelector(({ extractionRule }) => extractionRule.extractionRule.statusAction);
    const saveDynamicCallback = useSelector(({ extractionRule }) => extractionRule.extractionRule.saveDynamicCallback);
    const currentDocument = useSelector(({ extractionRule }) => extractionRule.extractionRule.currentDocument);
    const currentDeleteFlag = useSelector(({ extractionRule }) => extractionRule.extractionRule.currentDeleteFlag);
    const currentExtractionRule = useSelector(
        ({ extractionRule }) => extractionRule.extractionRule.currentExtractionRule,
    );

    const [treeNodeSet, setTreeNodeSet] = useState([]);
    const [expanded, setExpanded] = useState([]);
    const [selected, setSelected] = useState([]);

    const onRuleClick = node => {
        if (node.child_fields && node.child_fields.length) {
            const rootNodeId = `root-${node.doc_fld_id}`;
            const isNodeExpanded = expanded.includes(rootNodeId);
            const updateExpaned = isNodeExpanded
                ? expanded.filter(item => item !== rootNodeId)
                : [...expanded, rootNodeId];
            setExpanded(updateExpaned);
        }
        if (node?.doc_fld_id !== currentExtractionRule?.doc_fld_id) {
            if (statusAction !== 'none') {
                return dispatch(
                    openDialog(
                        'Leave without save your extraction rule?',
                        'You have unsaved changes',
                        'Confirm',
                        () => {
                            const alignNode = Functions.alignNodeBeforeUpdate(node);
                            dispatch(Actions.setCurrentExtractionRule(alignNode));

                            dispatch(Actions.setStatusAction('none'));
                            dispatch(Actions.setValidateFlag('valid'));
                        },
                    ),
                );
            } else {
                const alignNode = Functions.alignNodeBeforeUpdate(node);
                dispatch(Actions.setCurrentExtractionRule(alignNode));

                dispatch(Actions.setValidateFlag('valid'));
            }
        }
    };

    const onAddRoot = () => {
        if (listExtractionRule) {
            const newExtractionRuleRoot = {
                doc_fld_id: '',
                child_fields: [],
                dex_extr_rule: [],
            };
            const updateListTree = [...listExtractionRule, newExtractionRuleRoot];
            dispatch(Actions.setCurrentExtractionRule(newExtractionRuleRoot));
            dispatch(Actions.setListExtractionRule(updateListTree));
            dispatch(Actions.setStatusAction('new'));
        }
    };

    useEffect(() => {
        if (listExtractionRule) {
            const alignTreeData = listExtractionRule.filter(
                item => item.dex_extr_rule.length && item.dex_extr_rule[0].delt_flg === currentDeleteFlag,
            );
            const orderTreeData = alignTreeData.map(field => {
                if (field.child_fields.length) {
                    field.child_fields.sort((a, b) => {
                        const currentExtrRule = a.dex_extr_rule[0]?.extr_rule_ctnt;
                        const nextExtrRule = b.dex_extr_rule[0]?.extr_rule_ctnt;
                        return currentExtrRule && nextExtrRule
                            ? Number(currentExtrRule.ord_no) - Number(nextExtrRule.ord_no)
                            : -1;
                    });
                }
                return field;
            });
            setTreeNodeSet(orderTreeData);

            // if dex_extr_rule is empty
            // fill data for sync render
            if (_.isEmpty(currentExtractionRule) && orderTreeData[0]) {
                dispatch(Actions.setCurrentExtractionRule(orderTreeData[0]));
                if (orderTreeData[0].child_fields.length) setExpanded([`root-${orderTreeData[0].doc_fld_id}`]);
            }
        }
    }, [listExtractionRule, currentDeleteFlag]);

    useEffect(() => {
        if (currentExtractionRule) {
            if (currentExtractionRule.child_fields?.length) {
                const nodeId = `root-${currentExtractionRule.doc_fld_id}`;
                setSelected([nodeId]);
            } else {
                const hasParrent = listExtractionRule.find(item =>
                    item.child_fields.some(el => el.doc_fld_id === currentExtractionRule.doc_fld_id),
                );
                const nodeId = hasParrent
                    ? `leaf-${hasParrent.doc_fld_id}-${currentExtractionRule.doc_fld_id}`
                    : `root-${currentExtractionRule.doc_fld_id}`;

                setSelected([nodeId]);
            }
        }
    }, [currentExtractionRule]);

    useEffect(() => {
        if (saveDynamicCallback && saveDynamicCallback.doc_fld_id) {
            const isFirstLevelNode = listExtractionRule.some(
                item => item.doc_fld_id === saveDynamicCallback.doc_fld_id,
            );
            if (saveDynamicCallback.delt_flg === currentDeleteFlag || !isFirstLevelNode) {
                const updateCurrentExtractionRule = {
                    ...currentExtractionRule,
                    dex_extr_rule: [
                        {
                            ...saveDynamicCallback,
                            extr_rule_ctnt: JSON.parse(saveDynamicCallback.extr_rule_ctnt),
                        },
                    ],
                };
                dispatch(Actions.setCurrentExtractionRule(updateCurrentExtractionRule));
                dispatch(Actions.getExtractionRule(currentDocument.doc_tp_id));
            } else {
                const alignTreeData = listExtractionRule.filter(
                    item =>
                        item.dex_extr_rule.length &&
                        item.doc_fld_id !== saveDynamicCallback.doc_fld_id &&
                        item.dex_extr_rule[0].delt_flg === currentDeleteFlag,
                );
                if (alignTreeData.length) {
                    const alignNode = Functions.alignNodeBeforeUpdate(alignTreeData[0]);
                    dispatch(Actions.setCurrentExtractionRule(alignNode));
                } else dispatch(Actions.setCurrentExtractionRule({}));

                dispatch(Actions.getExtractionRule(currentDocument.doc_tp_id));
            }
        }
    }, [saveDynamicCallback]);

    return (
        <div className="w-full border-2 p-1 my-2 mx-1">
            <Table stickyHeader className="w-full" size="small">
                <TableHead>
                    <TableRow>
                        <StyledTableCell className="text-left table-cell">
                            <div className="w-full flex flex-row">
                                <div className="w-6/12 flex">Extraction rule and group</div>
                                <div className="w-6/12 flex justify-end items-end">Child field order</div>
                            </div>
                        </StyledTableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    <TreeView
                        className={classes.treeview}
                        defaultCollapseIcon={<ExpandMore />}
                        defaultExpandIcon={<ChevronRight />}
                        expanded={expanded}
                        selected={selected}
                    >
                        {treeNodeSet
                            .filter(item => {
                                const rootName = item?.fld_nm?.toLowerCase().includes(props.search.toLowerCase());
                                const leafName = item?.child_fields?.some(el =>
                                    el?.fld_nm?.toLowerCase().includes(props.search.toLowerCase()),
                                );
                                return !props.search || rootName || leafName;
                            })
                            .map(root => {
                                return (
                                    <TreeItem
                                        label={
                                            <ListItem dense onClick={() => onRuleClick(root)}>
                                                <ListItemText primary={root.fld_nm} />
                                            </ListItem>
                                        }
                                        nodeId={`root-${root.doc_fld_id}`}
                                        onIconClick={() => onRuleClick(root)}
                                    >
                                        {root.child_fields.map(leaf => {
                                            return (
                                                <TreeItem
                                                    label={
                                                        <ListItem dense onClick={() => onRuleClick(leaf)}>
                                                            <ListItemText primary={leaf.fld_nm} />
                                                            <ListItemSecondaryAction>
                                                                {leaf.dex_extr_rule.length
                                                                    ? leaf.dex_extr_rule[0].extr_rule_ctnt.ord_no
                                                                    : 'NaN'}
                                                            </ListItemSecondaryAction>
                                                        </ListItem>
                                                    }
                                                    nodeId={`leaf-${root.doc_fld_id}-${leaf.doc_fld_id}`}
                                                />
                                            );
                                        })}
                                    </TreeItem>
                                );
                            })}
                    </TreeView>
                </TableBody>
            </Table>

            <Paper elevation={0} className="w-full flex justify-end items-end pr-1">
                <CustomButton
                    {...Functions.buttonCommonProps}
                    disabled={statusAction === 'new' || currentDeleteFlag === 'Y'}
                    onClick={onAddRoot}
                >
                    ADD
                </CustomButton>
            </Paper>
        </div>
    );
};

export default ExtractionTree;

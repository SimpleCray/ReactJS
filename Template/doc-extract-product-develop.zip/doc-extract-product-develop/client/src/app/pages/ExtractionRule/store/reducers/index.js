import { combineReducers } from 'redux';
import extractionRule from './reducer';

const reducer = combineReducers({
    extractionRule,
});

export default reducer;

import { API_EP } from '../../../../utils/commonAPI';
import { showMessage } from '../../../../store/actions/fuse/message.actions';
import { showError, checkResDataAPI } from '../../../../utils/utils';

export const CURRENT_EXTRACTION_RULE = 'CURRENT_EXTRACTION_RULE';
export const COMMON_DATA = 'COMMON_DATA';
export const MODIFY_EXTRACTION_RULE = 'MODIFY_EXTRACTION_RULE';
export const UPDATE_DYNAMIC_TYPE = 'UPDATE_DYNAMIC_TYPE';
export const DOCUMENT_DEFINE = 'DOCUMENT_DEFINE';
export const DOCUMENT_FIELD = 'DOCUMENT_FIELD';
export const EXTRACTION_RULES = 'EXTRACTION_RULES';
export const STATUS_ACTION = 'STATUS_ACTION';
export const OUPUT_RULE_PREVIEW = 'OUPUT_RULE_PREVIEW';
export const FORCE_EXTRACTION_RULES = 'FORCE_EXTRACTION_RULES';
export const CURRENT_DOCUMENT = 'CURRENT_DOCUMENT';
export const DELETE_FLAG = 'DELETE_FLAG';
export const VALIDATE_FLAG = 'VALIDATE_FLAG';

export const callBackFunction = (dispatch, typeParam, urlParam, messageParam) =>
    urlParam
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: typeParam,
                    payload: response.data,
                });
                if (messageParam)
                    dispatch(
                        showMessage({
                            message: messageParam,
                            variant: 'success',
                        }),
                    );
            }
        })
        .catch(error => dispatch(showError(error)));

export const getCommonData = () => {
    const url = API_EP.post('/common-data/common-data-by-code');
    return dispatch => callBackFunction(dispatch, COMMON_DATA, url);
};

export const getDocDefine = () => {
    const url = API_EP.get('/doc-setting');
    return dispatch => callBackFunction(dispatch, DOCUMENT_DEFINE, url);
};

export const getDocumentField = docTpId => {
    const url = API_EP.get(`/doc-setting/${docTpId}/fields`);
    return dispatch => callBackFunction(dispatch, DOCUMENT_FIELD, url);
};

export const getExtractionRule = docTpId => {
    const url = API_EP.get(`/doc-field/parent-child/${docTpId}`);
    return dispatch => callBackFunction(dispatch, EXTRACTION_RULES, url);
};

export const createExtractionRule = body => {
    const url = API_EP.post('/extr-rule/create-extr-rule', body);
    return dispatch => callBackFunction(dispatch, MODIFY_EXTRACTION_RULE, url, 'Save successful!');
};

export const updateExtractionRule = body => {
    const url = API_EP.put('/extr-rule/update-extr-rule', body);
    return dispatch => callBackFunction(dispatch, MODIFY_EXTRACTION_RULE, url, 'Save successful!');
};

export const runSignleExtractionRule = body => {
    const url = API_EP.put('/extr-rule/run-single-extr-rule', body);
    return dispatch => callBackFunction(dispatch, OUPUT_RULE_PREVIEW, url);
};

export const runMultipleExtractionRule = body => {
    const url = API_EP.put('/extr-rule/run-multi-extr-rule', body);
    return dispatch => callBackFunction(dispatch, OUPUT_RULE_PREVIEW, url);
};

export const setCurrentExtractionRule = extractionRule => dispatch =>
    dispatch({
        type: CURRENT_EXTRACTION_RULE,
        extractionRule,
    });

export const setListExtractionRule = listExtractionRule => dispatch =>
    dispatch({
        type: FORCE_EXTRACTION_RULES,
        listExtractionRule,
    });

export const setStatusAction = status => dispatch =>
    dispatch({
        type: STATUS_ACTION,
        status,
    });

export const setCurrentDocument = document => dispatch =>
    dispatch({
        type: CURRENT_DOCUMENT,
        document,
    });

export const setDeleteFlag = deleteFlag => dispatch =>
    dispatch({
        type: DELETE_FLAG,
        deleteFlag,
    });

export const setValidateFlag = validateFlag => dispatch =>
    dispatch({
        type: VALIDATE_FLAG,
        validateFlag,
    });

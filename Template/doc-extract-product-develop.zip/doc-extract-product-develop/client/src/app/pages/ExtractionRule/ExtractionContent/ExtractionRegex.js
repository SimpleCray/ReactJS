import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Table, TableBody, TableCell, TableRow, TableHead, TextField, MenuItem, IconButton } from '@material-ui/core';
import { Autocomplete } from '@material-ui/lab';
import { RemoveCircle, AddCircle } from '@material-ui/icons';
import { withStyles } from '@material-ui/core/styles';
import AppConstants from 'app/utils/appConstants';

import * as Functions from '../ExtractionFunction';
import * as CommonDataFunctions from 'app/pages/CommonData/commonDataFunction';
import * as Actions from '../store/actions';

const StyledTableCell = withStyles(theme => ({
    head: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
}))(TableCell);

const headerConstraint = Functions.sourceHeader;

const ExtractionRegex = () => {
    const classes = Functions.useStyles();
    const dispatch = useDispatch();

    const commonData = useSelector(({ extractionRule }) => extractionRule.extractionRule.commonData);
    const statusAction = useSelector(({ extractionRule }) => extractionRule.extractionRule.statusAction);
    const currentValidateFlag = useSelector(({ extractionRule }) => extractionRule.extractionRule.currentValidateFlag);
    const currentExtractionRule = useSelector(
        ({ extractionRule }) => extractionRule.extractionRule.currentExtractionRule,
    );
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));

    const [paramTableData, setParamTableData] = useState([]);
    const [regexListData, setRegexListData] = useState([]);

    const updateCurrentExtractionRule = (keySet, valueSet) => {
        // PARAM: keySet = [reg_expr_val, src_val] valueSet = [value1, value2]
        // Update current extraction rule data common function
        const updateExtractionRuleData = keySet.reduce((obj, key, index) => ({ ...obj, [key]: valueSet[index] }), {
            ...currentExtractionRule.dex_extr_rule[0]?.extr_rule_ctnt,
        });

        const updateDexExtractionRule = [
            { ...currentExtractionRule.dex_extr_rule[0], extr_rule_ctnt: updateExtractionRuleData },
        ];
        const updateCurrentExtractionRule = { ...currentExtractionRule, dex_extr_rule: updateDexExtractionRule };
        if (statusAction !== 'new') dispatch(Actions.setStatusAction('update'));
        dispatch(Actions.setCurrentExtractionRule(updateCurrentExtractionRule));
    };

    const refreshParam = (valueChange, positionIndex) => {
        // Find regex pattern params
        const regexDefine = new RegExp('\\{{[\\w!@#$%^&*!-=+,.//]*\\}}', 'g');
        const cleanParam = regexListData.flatMap((regex, index) => {
            const matchParam =
                index === positionIndex ? valueChange.match(regexDefine) : regex.regex.match(regexDefine);
            return matchParam ? matchParam.map(item => item.replace(/[\{\}]/g, '')) : [];
        });
        const uniqueParam = [...new Set(cleanParam)];
        const mapToSource = uniqueParam.map(item => {
            const findOldCommon = paramTableData.find(common => common.param === item);
            return {
                param: item,
                com_dat_id: findOldCommon ? findOldCommon.com_dat_id : '',
                col_nm: findOldCommon ? findOldCommon.col_nm : '',
            };
        });
        return mapToSource;
    };

    const onRegexChange = (valueChange, positionIndex) => {
        const mapToSource = refreshParam(valueChange, positionIndex);

        // Find and update regex value
        const updateRegexValue = regexListData.map((item, index) =>
            index === positionIndex ? { ...item, regex: valueChange } : { ...item },
        );

        updateCurrentExtractionRule(['reg_expr_val', 'src_val'], [updateRegexValue, mapToSource]);
    };

    const onActionRegexChange = (event, positionIndex) => {
        const updateRegexAction = regexListData.map((item, index) =>
            index === positionIndex ? { ...item, action: event.target.value } : { ...item },
        );

        updateCurrentExtractionRule(['reg_expr_val'], [updateRegexAction]);
    };

    const onRowChange = (value, rowIndexParam, key) => {
        const changedRow = {
            ...paramTableData[rowIndexParam],
            [key]: value,
        };
        const updateTableData = paramTableData.map((item, index) =>
            index === rowIndexParam ? { ...changedRow } : { ...item },
        );

        updateCurrentExtractionRule(['src_val'], [updateTableData]);
    };

    const onRemoveRegex = positionIndex => {
        const updateParam = refreshParam('', positionIndex);
        const updateRegex = regexListData.filter((item, index) => index !== positionIndex);
        updateCurrentExtractionRule(['reg_expr_val', 'src_val'], [updateRegex, updateParam]);
    };

    const onAddRegex = positionIndex => {
        const newRegexObject = { regex: '', action: '' };
        const updateRegex = [
            ...regexListData.slice(0, positionIndex + 1),
            newRegexObject,
            ...regexListData.slice(positionIndex + 1),
        ];
        updateCurrentExtractionRule(['reg_expr_val'], [updateRegex]);
    };

    useEffect(() => {
        if (currentExtractionRule?.dex_extr_rule?.length && currentExtractionRule.dex_extr_rule[0].extr_rule_ctnt) {
            const extractionRuleData = currentExtractionRule.dex_extr_rule[0].extr_rule_ctnt;
            setParamTableData(extractionRuleData.src_val);
            setRegexListData(extractionRuleData.reg_expr_val);
        } else {
            setParamTableData([]);
            setRegexListData([]);
        }
    }, [currentExtractionRule]);

    return (
        <div className="w-full mb-10">
            <div className={classes.regexContainer}>
                {currentExtractionRule?.dex_extr_rule?.length &&
                    currentExtractionRule.dex_extr_rule[0].extr_rule_ctnt?.reg_expr_val.map((regex, index) => {
                        return (
                            <div className="w-full flex flex-row items-center py-2">
                                <div className="w-2/12">
                                    <TextField
                                        select
                                        label="Action"
                                        {...Functions.textFieldCommonProps}
                                        value={regex.action || ''}
                                        onChange={e => onActionRegexChange(e, index)}
                                        error={
                                            !Array.isArray(currentValidateFlag) &&
                                            currentValidateFlag !== 'valid' &&
                                            !regex?.action?.length
                                        }
                                    >
                                        <MenuItem keys="SD" value="SD">
                                            Select and delete
                                        </MenuItem>
                                        <MenuItem keys="S" value="S">
                                            Select
                                        </MenuItem>
                                        <MenuItem keys="D" value="D">
                                            Delete
                                        </MenuItem>
                                    </TextField>
                                </div>
                                <div className="w-8/12 px-5">
                                    <TextField
                                        label="With regex"
                                        {...Functions.textFieldCommonProps}
                                        value={regex.regex || ''}
                                        onChange={e => onRegexChange(e.target.value, index)}
                                        error={
                                            !Array.isArray(currentValidateFlag)
                                                ? currentValidateFlag !== 'valid' && !regex?.regex?.length
                                                : currentValidateFlag.includes(index)
                                        }
                                        helperText={currentValidateFlag.includes(index) ? 'Regex is invalid' : null}
                                    />
                                </div>
                                <div className="w-2/12 flex flex-row items-center justify-end px-5">
                                    <IconButton onClick={() => onAddRegex(index)}>
                                        <AddCircle color="action" size="small" />
                                    </IconButton>
                                    <IconButton
                                        onClick={() => onRemoveRegex(index)}
                                        disabled={regexListData && regexListData.length <= 1}
                                    >
                                        <RemoveCircle
                                            color={regexListData && regexListData.length > 1 ? 'action' : 'disabled'}
                                            size="small"
                                        />
                                    </IconButton>
                                </div>
                            </div>
                        );
                    })}
            </div>

            <div className={classes.paramContainer}>
                <Table stickyHeader className="w-full" size="small">
                    <TableHead>
                        <TableRow>
                            {headerConstraint.map(headerItem => (
                                <StyledTableCell key={headerItem.id} className="text-left table-cell ">
                                    {headerItem.label}
                                </StyledTableCell>
                            ))}
                        </TableRow>
                    </TableHead>

                    <TableBody>
                        {currentExtractionRule?.dex_extr_rule?.length &&
                            currentExtractionRule.dex_extr_rule[0].extr_rule_ctnt?.src_val.map((row, index) => {
                                return (
                                    <TableRow>
                                        {headerConstraint.map(cell => {
                                            if (cell.id === 'source') {
                                                const filterCommonByRole = CommonDataFunctions.getCommonByRole(
                                                    commonData,
                                                    userInfo,
                                                );

                                                const commonDetail = filterCommonByRole.find(
                                                    item => item.com_dat_id === row.com_dat_id,
                                                );

                                                return (
                                                    <TableCell className="text-left table-cell w-5/12">
                                                        <Autocomplete
                                                            {...Functions.autoCompleteProps}
                                                            disableClearable
                                                            options={filterCommonByRole || []}
                                                            getOptionLabel={option => option.com_dat_nm || ''}
                                                            renderInput={params => (
                                                                <TextField
                                                                    {...params}
                                                                    variant="outlined"
                                                                    error={
                                                                        !Array.isArray(currentValidateFlag) &&
                                                                        currentValidateFlag !== 'valid' &&
                                                                        !commonDetail?.com_dat_id?.length
                                                                    }
                                                                />
                                                            )}
                                                            value={commonDetail || ''}
                                                            onChange={(e, value) =>
                                                                onRowChange(value.com_dat_id, index, 'com_dat_id')
                                                            }
                                                        />
                                                    </TableCell>
                                                );
                                            }

                                            if (cell.id === 'colNm') {
                                                const commonDetail = commonData.find(
                                                    item => item.com_dat_id && item.com_dat_id === row.com_dat_id,
                                                );

                                                const columnList = commonDetail ? commonDetail.com_dat_val.header : [];
                                                return (
                                                    <TableCell className="text-left table-cell w-5/12">
                                                        <TextField
                                                            {...Functions.textFieldCommonProps}
                                                            select
                                                            value={row.col_nm}
                                                            onChange={e => onRowChange(e.target.value, index, 'col_nm')}
                                                            error={
                                                                !Array.isArray(currentValidateFlag) &&
                                                                currentValidateFlag !== 'valid' &&
                                                                !row?.col_nm?.length
                                                            }
                                                        >
                                                            {columnList.slice(0, -1).map(columnName => (
                                                                <MenuItem key={columnName} value={columnName}>
                                                                    {columnName}
                                                                </MenuItem>
                                                            ))}
                                                        </TextField>
                                                    </TableCell>
                                                );
                                            }

                                            return (
                                                <TableCell className="text-left table-cell w-3/12">
                                                    {row.param}
                                                </TableCell>
                                            );
                                        })}
                                    </TableRow>
                                );
                            })}
                    </TableBody>
                </Table>
            </div>
        </div>
    );
};

export default ExtractionRegex;

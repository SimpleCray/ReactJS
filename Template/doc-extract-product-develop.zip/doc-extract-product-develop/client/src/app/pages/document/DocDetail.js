import React, { useCallback, useEffect, useState } from 'react';
import {
    Icon,
    OutlinedInput,
    Typography,
    IconButton,
    Checkbox,
    FormControlLabel,
    InputLabel,
    Select,
    MenuItem,
    FormControl,
    TextField,
} from '@material-ui/core';
import {
    CheckBoxOutlineBlank,
    EditOutlined,
    DeleteOutlined,
    CheckOutlined,
    CloseOutlined,
    AddBoxOutlined,
} from '@material-ui/icons';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { FuseAnimate } from '@fuse';
import { useSelector, useDispatch } from 'react-redux';
import Button from 'app/components/Button';
import { useForm } from '@fuse/hooks';
import buttons from '../../utils/constants/buttonConstants.json';
import * as Actions from './store/actions';
import AppConstants from 'app/utils/appConstants';
import useStyles from './styles';
import arrayMove from 'array-move';
import _ from '@lodash';
import { showMessage } from '../../store/actions/fuse';
import { openDialog } from '../../store/actions/fuse/dialog.actions';
import 'styles/scss/commons.scss';

import { sortableContainer, sortableElement, sortableHandle } from 'react-sortable-hoc';

const defaultFormState = {
    doc_nm: '',
    doc_cd: '',
    active_flg: 'Y',
    delt_flg: 'N',
    tmplt_ftr_id: '',
    mtch_tp_cd: 'T',
    grp_doc_id: '',
    grp_flg: false,
    grp_nm: 'Group Name',
    userId: JSON.parse(localStorage.getItem('userInfo')).usrId,
    dyn_tp_val: [],
    core_sys_nm: '',
};

let backupDynamicState = [];
let dynamicCreating = false;

function DocDetail(props) {
    const dispatch = useDispatch();
    const docDetailSidebar = useSelector(({ document }) => document.docs.docSidebar);
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const searchForm = useSelector(({ document }) => document.docs.searchForm);
    const fields = useSelector(({ document }) => document.fields.fieldList);
    const docs = useSelector(({ document }) => document.docs.docList);
    const mtchTp = useSelector(({ document }) => document.docs.mtchTpList);
    const dynamicTypes = useSelector(({ document }) => document.docs.dynamicTypes);
    const locationData = useSelector(({ document }) => document.docs.locationData);
    const { form, handleChange, setForm } = useForm(defaultFormState);

    const [templateGroupName, setTemplateGroupName] = useState([]);
    const [templateFiterList, setTemplateFiterList] = useState([]);
    const [isModify, setIsModify] = useState(false);
    const [disableCheckGroup, setDisableCheckGroup] = useState(false);
    const [dynamicItemEdit, setDynamicItemEdit] = useState({});

    const initForm = useCallback(() => {
        /**
         * Sidebar type: 'edit'
         */
        backupDynamicState = [];
        dynamicCreating = false;
        setDynamicItemEdit({});
        if (docDetailSidebar.type === 'edit' && docDetailSidebar.data && locationData) {
            setDisableCheckGroup(false);
            const parseDynamiCdata = docDetailSidebar.data.dyn_tp_val
                ? JSON.parse(docDetailSidebar.data.dyn_tp_val)
                : null;
            setForm({
                ...docDetailSidebar.data,
                active_flg: docDetailSidebar.data.delt_flg === 'N',
                delt_flg: docDetailSidebar.data.delt_flg === 'Y',
                doc_cd: docDetailSidebar.data.doc_cd ? docDetailSidebar.data.doc_cd : '',
                grp_flg: docDetailSidebar.data.grp_flg === 'Y',
                grp_nm: docDetailSidebar.data.grp_nm ? docDetailSidebar.data.grp_nm : 'None',
                userId: defaultFormState.userId ? defaultFormState.userId : '',
                dyn_tp_val: parseDynamiCdata ? Object.values(parseDynamiCdata) : [],
            });
            locationData.map(item => {
                if (item.doc_tp_id === docDetailSidebar.data.doc_tp_id) {
                    setDisableCheckGroup(true);
                }
            });
        }
        /**
         * Sidebar type: 'new'
         */
        if (docDetailSidebar.type === 'new') {
            setForm({
                ...defaultFormState,
            });
        }
    }, [docDetailSidebar.data, docDetailSidebar.type, setForm, locationData]);

    useEffect(() => {
        initForm();
        setIsModify(false);
    }, [docDetailSidebar.isActive, initForm]);

    useEffect(() => {
        const fiterList = [];
        if (fields != null) {
            Object.keys(fields).forEach(function(key) {
                fiterList.push({
                    tmplt_ftr_id: fields[key].doc_fld_id,
                    tmplt_ftr_nm: fields[key].fld_nm,
                    delt_flg: fields[key].delt_flg,
                });
            });
        }
        setTemplateFiterList(fiterList.filter(item => item.delt_flg === 'N'));
    }, [fields]);

    useEffect(() => {
        const groupName = [];
        if (docs != null && docDetailSidebar.data) {
            Object.keys(docs).forEach(function(key) {
                if (docs[key].grp_flg === 'Y' && docs[key].doc_tp_id !== docDetailSidebar.data.doc_tp_id) {
                    groupName.push({
                        doc_tp_id: docs[key].doc_tp_id,
                        doc_nm: docs[key].doc_nm,
                    });
                }
            });
        }
        setTemplateGroupName(groupName);
    }, [docs, docDetailSidebar]);

    const classes = useStyles();

    function handleSubmit(event) {
        event.preventDefault();
        setIsModify(true);
        if (!validate(form)) {
            const parseDynamicArrayToObject = form.dyn_tp_val.reduce(
                (obj, crr, index) => ({ ...obj, [index]: crr }),
                {},
            );
            const parseDynamicData = JSON.stringify(parseDynamicArrayToObject);
            const saveForm = { ...form, dyn_tp_val: parseDynamicData };
            if (docDetailSidebar.type === 'edit') dispatch(Actions.checkUpdateDoc(saveForm, docs, fields));
            else dispatch(Actions.addDoc(saveForm));
        }
    }

    function closeSideBar(event) {
        dispatch(Actions.closeDocDetailSideBar());
    }

    function handleChangeText(event) {
        handleChange(event);
        setIsModify(true);
    }
    function handleChangeGroupName(event) {
        form.grp_flg = false;
        handleChange(event);
        setIsModify(true);
    }
    function handleChangeMtchTp(event) {
        handleChange(event);
        setForm(form => ({
            ...form,
            tmplt_ftr_id: null,
        }));
        setIsModify(true);
    }
    function handleChangeCheckGroup(event) {
        form.grp_doc_id = '';
        handleChange(event);
        setIsModify(true);
    }

    function handleChangeCode(event) {
        event.persist();
        setForm(form => ({
            ...form,
            doc_cd: event.target.value.toUpperCase(),
        }));
        setIsModify(true);
    }

    function handleChangeActFlg(event) {
        event.persist();
        setForm(form => ({
            ...form,
            active_flg: event.target.checked,
            delt_flg: !event.target.checked,
        }));
        setIsModify(true);
    }

    const handleChangeCoreSysNm = (e) => {
        handleChange(e);
        setForm(form => ({
            ...form,
            core_sys_nm: e.target.value,
        }));
        setIsModify(true);
    };

    const validate = form => {
        if (form.doc_nm.length === 0 || form.doc_nm === '') {
            return true;
        }
        return false;
    };

    const onDynamicTypeChange = (e, value, flag) => {
        const updateValue =
            flag === 'autocomplete'
                ? { ...dynamicItemEdit, dyn_id: value.dyn_id, dyn_nm: value.dyn_nm }
                : { ...dynamicItemEdit, allow_autogen: e.target.checked };
        const updateDynamicForm = form.dyn_tp_val.map(item =>
            dynamicItemEdit.dyn_id === item.dyn_id ? { ...updateValue } : item,
        );
        setDynamicItemEdit(updateValue);
        setForm(preState => ({
            ...preState,
            dyn_tp_val: updateDynamicForm,
        }));
    };

    const onAddClick = () => {
        if (form.dyn_tp_val.length < dynamicTypes.length) {
            const dynamicKeyGen = new Date().getTime();
            const newDynamic = { dyn_id: dynamicKeyGen, dyn_nm: '', allow_autogen: false };
            const updateDynamicForm = [...form.dyn_tp_val, newDynamic];
            backupDynamicState = form.dyn_tp_val.map(item => ({ ...item }));
            dynamicCreating = true;
            setForm(preState => ({
                ...preState,
                dyn_tp_val: updateDynamicForm,
            }));
            setDynamicItemEdit(newDynamic);
        } else
            dispatch(
                showMessage({
                    message: 'Dynamic type is overfill. Please contact with admin for more detail!',
                    variant: 'warning',
                }),
            );
    };

    const onEditClick = value => {
        setDynamicItemEdit(value);
        backupDynamicState = form.dyn_tp_val.map(item => ({ ...item }));
    };

    const onRemoveClick = value =>
        dispatch(
            openDialog('Do you want remove this dynamic type?', '', 'Confirm', () => {
                const removeDynamicType = form.dyn_tp_val.filter(item => item.dyn_id !== value.dyn_id);
                setForm(preState => ({
                    ...preState,
                    dyn_tp_val: removeDynamicType,
                }));
            }),
        );

    const onConfirmClick = () => {
        const validate = form.dyn_tp_val.some(item => !item.dyn_nm || !item.dyn_nm.length);
        if (!validate) {
            setDynamicItemEdit({});
            backupDynamicState = [];
            dynamicCreating = false;
        } else
            dispatch(
                showMessage({
                    message: 'Please choose dynamic type.',
                    variant: 'warning',
                }),
            );
    };

    const onCancelClick = () => {
        setForm(preState => ({ ...preState, dyn_tp_val: backupDynamicState }));
        setDynamicItemEdit({});
        backupDynamicState = [];
        dynamicCreating = false;
    };

    const getOptionDynamicType = () => dynamicTypes.filter(item => item.delt_flg === 'N');

    const getOptionLabelDynamicType = option => dynamicTypes.find(item => item.dyn_id === option.dyn_id);

    const getOptionDisabled = option =>
        form.dyn_tp_val.some(item => item.dyn_id === option.dyn_id && item.dyn_id !== dynamicItemEdit.dyn_id);

    const onSortEnd = ({ oldIndex, newIndex }) => {
        setForm(preState => ({
            ...preState,
            dyn_tp_val: arrayMove(preState.dyn_tp_val, oldIndex, newIndex),
        }));
    };

    const SortableContainer = sortableContainer(({ children }) => <ul className="m-0 p-0">{children}</ul>);

    const DragHandle = sortableHandle(({ value }) => {
        const getValue = getOptionLabelDynamicType(value) || {};
        return (
            <div className={classes.dynamicContent}>
                {dynamicItemEdit.dyn_id === value.dyn_id ? (
                    <Autocomplete
                        size="small"
                        fullWidth
                        freeSolo // make blank for autocomplete (remove uness => normal input component)
                        disableClearable
                        options={getOptionDynamicType() || []}
                        getOptionLabel={option => option.dyn_nm || ''}
                        getOptionDisabled={option => getOptionDisabled(option)}
                        value={getValue || {}}
                        onChange={(e, val) => onDynamicTypeChange(e, val, 'autocomplete')}
                        renderInput={params => <TextField {...params} variant="outlined" />}
                    />
                ) : (
                    <Typography color="textSecondary" variant="body2">
                        {getValue.dyn_nm}
                    </Typography>
                )}
            </div>
        );
    });

    const SortableItem = sortableElement(({ value }) => (
        <div className={classes.dynamicTypeContainer}>
            <DragHandle value={value} />
            <div className={classes.dynamicCheckbox}>
                <Checkbox
                    icon={<CheckBoxOutlineBlank fontSize="small" />}
                    checkedIcon={<CheckBoxIcon fontSize="small" />}
                    checked={value.allow_autogen}
                    onChange={e => onDynamicTypeChange(e, value, 'checkbox')}
                    disabled={dynamicItemEdit.dyn_id !== value.dyn_id}
                />
            </div>
            <FormControl className={classes.dynamicAction}>
                {dynamicItemEdit.dyn_id === value.dyn_id && [
                    <IconButton className={classes.iconButton} onClick={onConfirmClick}>
                        <CheckOutlined fontSize="small" color="action" />
                    </IconButton>,
                    <IconButton className={classes.iconButton} onClick={onCancelClick}>
                        <CloseOutlined fontSize="small" color="action" />
                    </IconButton>,
                ]}
                {_.isEmpty(dynamicItemEdit) && [
                    <IconButton className={classes.iconButton} onClick={() => onEditClick(value)}>
                        <EditOutlined fontSize="small" color="action" />
                    </IconButton>,
                    <IconButton className={classes.iconButton} onClick={() => onRemoveClick(value)}>
                        <DeleteOutlined fontSize="small" color="action" />
                    </IconButton>,
                ]}
            </FormControl>
        </div>
    ));

    return (
        <FuseAnimate animation="transition.slideUpIn" delay={300}>
            <div className=" p-8 sm:p-8 h-full">
                <IconButton className="float-right" onClick={closeSideBar}>
                    <Icon>close</Icon>
                </IconButton>
                <Typography variant="subtitle1" className="my-5">
                    Document Detail
                </Typography>
                <form noValidate onSubmit={handleSubmit}>
                    <TextField
                        id="docNm"
                        name="doc_nm"
                        label="Document Name"
                        variant="outlined"
                        size="small"
                        value={form.doc_nm}
                        inputProps={{ maxLength: 50 }}
                        className={classes.formControl}
                        onChange={handleChangeText}
                        required={form.doc_nm === '' && isModify}
                        error={form.doc_nm === '' && isModify}
                        helperText={form.doc_nm === '' && isModify ? 'Document Name can not be empty!' : ''}
                    />
                    <TextField
                        id="docCd"
                        name="doc_cd"
                        label="Doc Code"
                        variant="outlined"
                        size="small"
                        value={form.doc_cd}
                        inputProps={{ maxLength: 20 }}
                        className={classes.formControl}
                        onChange={handleChangeCode}
                        required={form.doc_cd === '' && isModify}
                        error={form.doc_cd === '' && isModify}
                        helperText={form.doc_cd === '' && isModify ? 'Document code can not be empty!' : ''}
                        disabled={docDetailSidebar.type === 'edit'}
                    />
                    <FormControl
                        size="small"
                        variant="outlined"
                        style={{ textTransform: 'capitalize' }}
                        className={classes.formControl}
                        disabled
                    >
                        <InputLabel>Core System Name</InputLabel>
                        <Select
                            className="doctype--core-sys-nm"
                            onChange={handleChangeCoreSysNm}
                            size="small"
                            label="Core System Name"
                            value={form.core_sys_nm}
                            input={<OutlinedInput labelWidth={92} name="core_sys_nm" />}
                        >
                            <MenuItem
                                className="doctype--core-sys-nm__item"
                                value={AppConstants.CORE_SYS_NM.MAIN}
                                key={AppConstants.CORE_SYS_NM.MAIN}
                            >
                                {AppConstants.CORE_SYS_NM.MAIN}
                            </MenuItem>
                            <MenuItem
                                className="doctype--core-sys-nm__item"
                                value={AppConstants.CORE_SYS_NM.LABEL}
                                key={AppConstants.CORE_SYS_NM.LABEL}
                            >
                                {AppConstants.CORE_SYS_NM.LABEL}
                            </MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl size="small" variant="outlined" className={classes.formControl}>
                        <InputLabel>Matching Type</InputLabel>
                        <Select
                            onChange={handleChangeMtchTp}
                            size="small"
                            label="Matching Type"
                            value={form.mtch_tp_cd}
                            input={<OutlinedInput labelWidth={92} name="mtch_tp_cd" />}
                        >
                            {mtchTp.map(item => (
                                <MenuItem value={item.code} key={item.code}>
                                    {item.name}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <FormControl size="small" variant="outlined" className={classes.formControl}>
                        <InputLabel>Template Filter</InputLabel>
                        <Select
                            value={form.tmplt_ftr_id}
                            onChange={handleChangeText}
                            size="small"
                            label="Template Filter"
                            input={<OutlinedInput labelWidth={92} name="tmplt_ftr_id" id="tmpltFtrId" />}
                            disabled={form.mtch_tp_cd !== 'T'}
                        >
                            <MenuItem>
                                <em>None</em>
                            </MenuItem>
                            {templateFiterList.map(item => (
                                <MenuItem value={item.tmplt_ftr_id} key={item.tmplt_ftr_id}>
                                    {item.tmplt_ftr_nm}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <FormControl size="small" variant="outlined" className={classes.formControl}>
                        <InputLabel>Group Document</InputLabel>
                        <Select
                            value={form.grp_doc_id}
                            onChange={handleChangeGroupName}
                            size="small"
                            label="Group Name"
                            disabled={form.grp_flg}
                            input={<OutlinedInput labelWidth={92} name="grp_doc_id" id="tmpltFtrId" />}
                        >
                            <MenuItem value="">
                                <em>None</em>
                            </MenuItem>
                            {templateGroupName.map(item => (
                                <MenuItem value={item.doc_tp_id} key={item.doc_tp_id}>
                                    {item.doc_nm}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <FormControlLabel
                        control={
                            <Checkbox
                                onChange={handleChangeCheckGroup}
                                name="grp_flg"
                                color="secondary"
                                checked={form.grp_flg}
                                disabled={disableCheckGroup}
                            />
                        }
                        label="Group"
                    />
                    <div className="flex flex-row mb-1">
                        <div className="w-6/12 flex justify-start items-end">
                            <Typography color="textSecondary" variant="caption">
                                Dynamic type
                            </Typography>
                        </div>
                        <div className="w-3/12 flex justify-start items-end">
                            <Typography color="textSecondary" variant="caption">
                                Autogen
                            </Typography>
                        </div>
                        <div className="w-3/12 flex justify-end items-end">
                            <IconButton className={classes.iconButton} onClick={onAddClick}>
                                <AddBoxOutlined color="action" />
                            </IconButton>
                        </div>
                    </div>
                    {form.dyn_tp_val.length > 0 && (
                        <div className="flex flex-col overflow-auto border-t border box-attr mt-1 px-3 pb-5">
                            <SortableContainer onSortEnd={onSortEnd} useDragHandle>
                                {form.dyn_tp_val.map((value, index) => (
                                    <SortableItem key={value.dyn_id} index={index} value={value} />
                                ))}
                            </SortableContainer>
                        </div>
                    )}

                    <FormControlLabel
                        control={
                            <Checkbox
                                onChange={handleChangeActFlg}
                                name="active_flg"
                                color="secondary"
                                checked={form.active_flg}
                            />
                        }
                        label="Active Flag"
                        hidden={docDetailSidebar.type === 'new' || !searchForm.deltFlg}
                    />
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_SAVE) && (
                        <div className="w-full flex items-end justify-end absolute bottom-0 p-5">
                            <Button onClick={handleSubmit} disabled={backupDynamicState.length || dynamicCreating}>
                                Save
                            </Button>
                        </div>
                    )}
                </form>
            </div>
        </FuseAnimate>
    );
}

export default DocDetail;

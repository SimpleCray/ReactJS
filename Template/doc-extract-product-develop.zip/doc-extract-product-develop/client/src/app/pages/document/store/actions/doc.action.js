import HandleServerErrors from 'app/utils/handleServerErrors';
import EndPointAPI from 'app/utils/endPointAPI';
import { closeFieldDetailSidebar, getDocFields, removeField } from './field.action';
import { showMessage } from '../../../../store/actions/fuse';
import { showError, checkResDataAPI } from '../../../../utils/utils';
import { API_EP } from 'app/utils/commonAPI';
import _ from '@lodash';

export const GET_DOCS = 'GET_DOCS';
export const GET_DOC_DETAIL = 'GET_DOC_DETAIL';
export const ADD_DOC = 'ADD_DOC';
export const UPDATE_DOC = 'UPDATE_DOC';
export const REMOVE_DOC = 'REMOVE_DOC';
export const EDIT_DOC_TYPE = 'EDIT_DOC_TYPE';
export const NEW_DOC_TYPE = 'NEW_DOC_TYPE';
export const CLOSE_DOC_DETAIL = 'CLOSE_DOC_DETAIL';
export const OPEN_DOC_GROUP_DIALOG = 'OPEN_DOC_GROUP_DIALOG';
export const CLOSE_DOC_GROUP_DIALOG = 'CLOSE_DOC_GROUP_DIALOG';
export const UPDATE_DOC_GROUP = 'UPDATE_DOC_GROUP';
export const ADD_DOC_GROUP = 'ADD_DOC_GROUP';
export const REMOVE_DOC_GROUP = 'REMOVE_DOC_GROUP';
export const GET_DOC_GROUP = 'GET_DOC_GROUP';
export const ADDED_FIELD_GROUP = 'ADDED_FIELD_GROUP';
export const SET_SELECTED_DOC = 'SET_SELECTED_DOC';
export const GET_MTCH_TYPE = 'GET_MTCH_TYPE';
export const DYNAMIC_TYPES = 'DYNAMIC_TYPES';
export const GET_LOCATION_DATA = 'GET_LOCATION_DATA';
export const SET_PAGE = 'SET_PAGE_DOC_DEFINE';

export function getDocs(searchCond) {
    const request = API_EP.get(`/doc-setting`, { params: searchCond });
    return dispatch =>
        request
            .then(response => {
                dispatch({
                    type: GET_DOCS,
                    payload: response.data.result,
                    searchCond,
                });
            })
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function getMatchingType() {
    const request = API_EP.get(`/common-data/mtch-tp`);
    return dispatch =>
        request
            .then(response => {
                dispatch({
                    type: GET_MTCH_TYPE,
                    payload: response.data.result,
                });
            })
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function editDocSidebar(data) {
    return dispatch => {
        dispatch({
            type: EDIT_DOC_TYPE,
            data,
        });
    };
}
export function newDocSidebar() {
    return dispatch => {
        dispatch({
            type: NEW_DOC_TYPE,
        });
    };
}
export function closeDocDetailSideBar() {
    return {
        type: CLOSE_DOC_DETAIL,
    };
}

export function addDoc(doc) {
    const searchCond = {
        docNm: '',
        deltFlg: false,
    };

    return dispatch => {
        const request = API_EP.post(`/doc-setting/add`, {
            doc,
        });
        return request
            .then(response => {
                dispatch({
                    type: ADD_DOC,
                });
                dispatch(getDocs(searchCond));
                dispatch(closeDocDetailSideBar());
                dispatch(newDocSidebar());
                const option = {
                    message: response.data.message,
                    variant: 'success',
                };
                dispatch(showMessage(option));
            })
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
    };
}

export function checkUpdateDoc(form, docs, fieldList) {
    if (form.grp_flg === false) {
        // remove grp_doc_id for sub doc
        Object.keys(docs).forEach(function(key) {
            if (docs[key].grp_doc_id === form.doc_tp_id) {
                docs[key].delt_flg = docs[key].delt_flg === 'Y';
                docs[key].grp_flg = docs[key].grp_flg === 'Y';
                docs[key].grp_doc_id = '';
                try {
                    updateSubDoc(docs[key], form.userId);
                } catch (error) {
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(error),
                        variant: 'error',
                    });
                }
            }
        });
    } else {
        Object.keys(fieldList).forEach(function(key) {
            try {
                removeField(fieldList[key].doc_fld_id, form.userId);
            } catch (error) {
                showMessage({
                    message: HandleServerErrors.getServerErrorMessage(error),
                    variant: 'error',
                });
            }
        });
    }
    return updateDoc(form);
}
export function updateSubDoc(doc, userId) {
    doc.userId = userId;
    const request = API_EP.put(`/doc-setting/update`, {
        doc,
    });
    return dispatch =>
        request
            .then(response => {
                dispatch({
                    type: UPDATE_DOC,
                    payload: response.data.result,
                });
            })
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function updateDoc(doc) {
    const searchCond = {
        docNm: '',
        deltFlg: false,
    };

    return dispatch => {
        const request = API_EP.put(`/doc-setting/update`, {
            doc,
        });
        return request.then(response =>
            Promise.all([
                dispatch({
                    type: UPDATE_DOC,
                }),
            ])
                .then(() => {
                    dispatch(getDocs(searchCond));
                    const option = {
                        message: response.data.message,
                        variant: 'success',
                    };
                    dispatch(showMessage(option));
                    dispatch(getDocFields(doc.doc_tp_id));
                })
                .catch(err => {
                    dispatch(
                        showMessage({
                            message: HandleServerErrors.getServerErrorMessage(err),
                            variant: 'error',
                        }),
                    );
                }),
        );
    };
}

export function checkDocRemove(selectedDoc, docs) {
    const userId = JSON.parse(localStorage.getItem('userInfo')).usrId;
    if (selectedDoc.grp_flg === 'Y') {
        Object.keys(docs).forEach(function(key) {
            // remove grp_doc_id for sub doc
            if (docs[key].grp_doc_id === selectedDoc.doc_tp_id) {
                try {
                    removeSubDoc(docs[key].doc_tp_id, userId);
                } catch (error) {
                    return error;
                }
            }
        });
    }
    return removeDoc(selectedDoc.doc_tp_id, userId);
}

export function removeSubDoc(docTpId, userId) {
    const removeInfo = {
        doc_tp_id: docTpId,
        upd_usr_id: userId,
    };
    const request = API_EP.put(`/doc-setting/remove`, {
        removeInfo,
    });
    return dispatch =>
        request
            .then(response => {
                dispatch({
                    type: REMOVE_DOC,
                    payload: response.data.result,
                });
            })
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function removeDoc(docTpId, userId) {
    const searchCond = {
        docNm: '',
        deltFlg: false,
    };
    const removeInfo = {
        doc_tp_id: docTpId,
        upd_usr_id: userId,
    };
    return dispatch => {
        const request = API_EP.put(`/doc-setting/remove`, {
            removeInfo,
        });

        return request
            .then(response =>
                Promise.all([
                    dispatch({
                        type: REMOVE_DOC,
                    }),
                ])
                    .then(() => {
                        dispatch(getDocs(searchCond));
                        dispatch(setSelectedDoc(null));
                        dispatch(getDocFields(null));
                        dispatch(closeFieldDetailSidebar());
                        dispatch(newDocSidebar());
                        const option = {
                            message: response.data.message,
                            variant: 'success',
                        };
                        dispatch(showMessage(option));
                    })
                    .catch(err => {
                        dispatch(
                            showMessage({
                                message: HandleServerErrors.getServerErrorMessage(err),
                                variant: 'error',
                            }),
                        );
                    }),
            )
            .catch(err => {
                if (err.response.status === 409) {
                    const requestBP = API_EP.get(EndPointAPI.ENDPOINT.BP.ALL_COM);
                    const coCdList = err.response.data.usedDoc;
                    const coNmList = [];
                    requestBP
                        .then(response => {
                            if (response.status === 200) {
                                const listDataCompany = _.keyBy(response.data.data.comList, 'coCd');
                                Object.keys(coCdList).forEach(function(key) {
                                    coNmList.push(listDataCompany[coCdList[key].co_cd].coNm);
                                });
                            } else {
                                const option = {
                                    message: 'Could not get company',
                                    variant: 'error',
                                };
                                dispatch(showMessage(option));
                            }
                        })
                        .then(() => {
                            const option = {
                                message: `This document cannot be deleted because the companies are using: ${coNmList}`,
                                variant: 'error',
                            };
                            dispatch(showMessage(option));
                        });
                }
                throw err;
            });
    };
}

export function getDynamicType() {
    const url = API_EP.get('/dynamic-type/get-dynamic-type');
    return dispatch =>
        url
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: DYNAMIC_TYPES,
                        payload: response.data,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
}

export function setSelectedDoc(data) {
    return {
        type: SET_SELECTED_DOC,
        payload: data,
    };
}

export function setPage(value) {
    return dispatch =>
        dispatch({
            type: SET_PAGE,
            page: value,
        });
}

export const getLocationData = () => {
    const url = API_EP.get(EndPointAPI.ENDPOINT.LOCATION.ALL_LOC);
    return dispatch =>
        url
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_LOCATION_DATA,
                        locationData: response.data,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
};

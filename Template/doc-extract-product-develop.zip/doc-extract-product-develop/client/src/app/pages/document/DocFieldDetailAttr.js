/* eslint-disable no-unused-expressions */
import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/styles';
import { useDispatch, useSelector } from 'react-redux';
import { TextField, Tooltip, IconButton } from '@material-ui/core';
import AddCircleIcon from '@material-ui/icons/AddCircle';
import RemoveCircleIcon from '@material-ui/icons/RemoveCircle';
import * as Actions from './store/actions/field.action';

function DocFieldDetailAttr(props) {
    const classes = useStyles();
    const dispatch = useDispatch();

    const docFieldDetailAttrs = useSelector(({ document }) => document.fields.fieldDetailAttrs);

    const handleAddAttr = () => {
        props.onChangeAttrs();
        const newAction = { attribute: '', value: '' };
        const afterAddAttr = handleAddToArray(docFieldDetailAttrs, newAction, props.index + 1);
        dispatch(Actions.addFieldDetailAttr(afterAddAttr));
    };

    const handleRemoveAttr = () => {
        props.onChangeAttrs();
        if (docFieldDetailAttrs.length === 1) {
            dispatch(Actions.addFieldDetailAttr([{ attribute: '', value: '' }]));
        } else {
            const afterRemoveAction = handleRemoveToArray(docFieldDetailAttrs, props.index);
            dispatch(Actions.addFieldDetailAttr(afterRemoveAction));
        }
    };

    const handleAddToArray = (array, item, index) => [...array.slice(0, index), item, ...array.slice(index)];

    const handleRemoveToArray = (array, index) => [...array.slice(0, index), ...array.slice(index + 1)];

    const handleChange = async (index, value, flag) => {
        if (docFieldDetailAttrs.length === 1 && value.trim() === '') {
            props.onChangeAttrs();
        }
        if (flag === 'attribute') {
            props.onChangeValue(index);
        }
        const updateAttrs = docFieldDetailAttrs.map(item => ({ ...item }));
        for (let i = 0; i < docFieldDetailAttrs.length; i++) {
            if (i === index) {
                if (flag === 'attribute') updateAttrs[i].attribute = value;
                else updateAttrs[i].value = value;
                break;
            }
        }
        await dispatch(Actions.addFieldDetailAttr(updateAttrs));
    };

    function checkError() {
        if (docFieldDetailAttrs[props.index] && props.isModify) {
            if (
                (docFieldDetailAttrs.length !== 1 && !docFieldDetailAttrs[props.index].value.trim()) ||
                (docFieldDetailAttrs.length !== 1 &&
                    props.indexDuplicateAttr &&
                    props.indexDuplicateAttr.includes(props.index)) ||
                (!docFieldDetailAttrs[props.index].attribute.trim() && docFieldDetailAttrs[props.index].value.trim()) ||
                (docFieldDetailAttrs[props.index].attribute.trim() && !docFieldDetailAttrs[props.index].value.trim())
            ) {
                return true;
            }
        }

        return false;
    }

    return (
        <div className="flex flex-row">
            <div className="flex w-4/12">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="Key"
                    id={`attr_${props.index}`}
                    name={`attr_${props.index}`}
                    variant="outlined"
                    fullWidth
                    value={docFieldDetailAttrs[props.index] && docFieldDetailAttrs[props.index].attribute}
                    onChange={e => handleChange(props.index, e.target.value, 'attribute')}
                    size="small"
                    required
                    error={checkError()}
                />
            </div>

            <div className="flex w-4/12">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="Value"
                    id={`value_${props.index}`}
                    name={`value_${props.index}`}
                    variant="outlined"
                    fullWidth
                    required
                    value={docFieldDetailAttrs[props.index] && docFieldDetailAttrs[props.index].value}
                    onChange={e => handleChange(props.index, e.target.value, 'value')}
                    size="small"
                    error={checkError()}
                />
            </div>

            <div className="absolute right-0 flex justify-end">
                <Tooltip title="Add" onClick={handleAddAttr}>
                    <IconButton size="small" aria-label="Add">
                        <AddCircleIcon fontSize="small"/>
                    </IconButton>
                </Tooltip>
                <Tooltip
                    title="Remove"
                    disabled={
                        docFieldDetailAttrs.length === 1 &&
                        !docFieldDetailAttrs[0].attribute &&
                        !docFieldDetailAttrs[0].value
                    }
                    onClick={handleRemoveAttr}
                >
                    <IconButton size="small" aria-label="Remove">
                        <RemoveCircleIcon fontSize="small"/>
                    </IconButton>
                </Tooltip>
            </div>
        </div>
    );
}

const useStyles = makeStyles({
    styleTextField: {
        marginRight: 5,
    },
});

export default DocFieldDetailAttr;

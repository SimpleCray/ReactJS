import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
        marginTop: theme.spacing(3),
    },
    margin: {
        margin: theme.spacing(1),
    },
    paper: {
        width: '100%',
        marginBottom: theme.spacing(2),
    },
    tableRow: {
        height: 43,
    },
    cellHead: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
    formControl: {
        marginBottom: '5px',
        marginTop: '10px',
        width: '100%',
    },
    dynamicTypeContainer: {
        width: '100%',
        display: 'flex',
        flexDirection: 'row',
        marginTop: 8,
    },
    dynamicContent: {
        width: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-start',
        cursor: 'pointer',
        minHeight: 38,
    },
    dynamicCheckbox: {
        width: '25%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    dynamicAction: {
        width: '25%',
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    iconButton: {
        '&:hover': {
            backgroundColor: 'transparent',
        },
        margin: 0,
        marginRight: 5,
        padding: 0,
    },
}));
export default useStyles;

import React, { useEffect, useState } from 'react';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import { Icon, Input, Paper } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import Button from 'app/components/Button';
import { ThemeProvider } from '@material-ui/styles';
import * as Actions from './store/actions';
import buttons from '../../utils/constants/buttonConstants.json';
import SearchTextField from '../../components/SearchTextField';
import { FuseAnimate } from '../../../@fuse';

function DocSearch(props) {
    const dispatch = useDispatch();
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const searchField = useSelector(({ document }) => document.fields.searchField);
    const mainTheme = useSelector(({ fuse }) => fuse.settings.mainTheme);
    const [searchCond, setSearchCond] = useState({
        docNm: '',
        deltFlg: false,
        fieldName: '',
        fieldDeltFlg: false,
    });

    useEffect(() => {
        dispatch(Actions.getDocs(searchCond));
    }, [dispatch]);

    useEffect(() => {
        dispatch(Actions.searchDocField(searchCond));
    }, [searchCond]);

    const handleChange = event => {
        event.persist();
        setSearchCond(searchCond => ({
            ...searchCond,
            [event.target.name]: event.target.type === 'checkbox' ? event.target.checked : event.target.value,
        }));
    };

    const handleSearch = async event => {
        event.preventDefault();
        dispatch(Actions.setSelectedDoc(null));
        dispatch(Actions.setSelectedField(null));
        dispatch(Actions.closeDocDetailSideBar());
        dispatch(Actions.closeFieldDetailSidebar());
        dispatch(Actions.getDocs(searchCond));
        dispatch(Actions.getDocFields(null));
        dispatch(Actions.setPage(0));
    };

    return (
        <div className="flex w-full items-center">
            <div className="w-1/2 flex items-center">
                <div className="flex-none ">
                    <SearchTextField
                        id="docNm"
                        name="docNm"
                        label="Document Name"
                        value={searchCond.docNm}
                        size="small"
                        onChange={handleChange}
                    />
                </div>

                <div className="flex-none pl-4">
                    <FormControlLabel
                        control={<Checkbox onChange={handleChange} name="deltFlg" color="secondary" />}
                        label="Deleted"
                    />
                </div>
                {btnList.some(btn => btn.BTN_NO === buttons.BTN_SAVE) && (
                    <div className="flex-none">
                        <Button className="whitespace-no-wrap" color="default" onClick={handleSearch}>
                            <span className="hidden sm:flex">Search</span>
                        </Button>
                    </div>
                )}
            </div>
            <div className="w-1/2 flex items-center px-12">
                <ThemeProvider theme={mainTheme}>
                    <FuseAnimate animation="transition.slideDownIn" delay={300}>
                        <Paper className="flex w-1/2 max-w-600 px-8 py-4 rounded-8 items-center" elevation={1}>
                            <Icon className="mr-8" color="action">
                                search
                            </Icon>
                            <Input
                                placeholder="Search field name"
                                disableUnderline
                                name="fieldName"
                                value={searchCond.fieldName}
                                inputProps={{
                                    'aria-label': 'Search',
                                }}
                                onChange={handleChange}
                            />
                        </Paper>
                    </FuseAnimate>
                </ThemeProvider>
                <FormControlLabel
                    control={<Checkbox onChange={handleChange} name="fieldDeltFlg" color="secondary" />}
                    label="Deleted"
                    className="pl-8"
                />
            </div>
        </div>
    );
}

export default DocSearch;

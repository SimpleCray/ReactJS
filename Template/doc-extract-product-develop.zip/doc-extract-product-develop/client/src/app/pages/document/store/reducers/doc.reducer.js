import * as Actions from '../actions';
import _ from '@lodash';

const initialState = {
    docList: [],
    groupList: [],
    docSidebar: {
        type: 'new',
        data: null,
        isActive: false,
    },
    searchForm: {
        docNm: '',
        deltFlg: false,
    },
    isAddedGroup: false,
    selectedDoc: null,
    mtchTpList: [],
    page: 0,
    dynamicTypes: [],
    locationData: [],
};

const docsReducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.GET_DOCS:
            return {
                ...state,
                docList: _.keyBy(action.payload, 'doc_tp_id'),
                searchForm: {
                    docNm: action.searchCond.docNm,
                    deltFlg: action.searchCond.deltFlg,
                },
            };
        case Actions.GET_DOC_GROUP:
            return {
                ...state,
                groupList: _.keyBy(action.payload, 'fld_grp_id'),
            };
        case Actions.GET_MTCH_TYPE:
            return {
                ...state,
                mtchTpList: action.payload,
            };
        case Actions.ADDED_FIELD_GROUP: {
            return {
                ...state,
                isAddedGroup: action.isAdded,
            };
        }
        case Actions.EDIT_DOC_TYPE: {
            return {
                ...state,
                docSidebar: {
                    type: 'edit',
                    data: action.data,
                    isActive: true,
                },
            };
        }
        case Actions.NEW_DOC_TYPE: {
            return {
                ...state,
                docSidebar: {
                    type: 'new',
                    data: null,
                    isActive: true,
                },
            };
        }
        case Actions.CLOSE_DOC_DETAIL: {
            return {
                ...state,
                docSidebar: {
                    type: 'new',
                    data: null,
                    isActive: false,
                },
            };
        }
        case Actions.SET_SELECTED_DOC: {
            return {
                ...state,
                selectedDoc: action.payload,
            };
        }
        case Actions.SET_PAGE: {
            return {
                ...state,
                page: action.page,
            };
        }
        case Actions.DYNAMIC_TYPES:
            return {
                ...state,
                dynamicTypes: action.payload,
            };
        case Actions.GET_LOCATION_DATA:
            return {
                ...state,
                locationData: action.locationData,
            };
        default:
            return state;
    }
};

export default docsReducer;

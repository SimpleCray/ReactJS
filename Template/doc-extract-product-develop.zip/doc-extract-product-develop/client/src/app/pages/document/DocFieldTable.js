import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import { useDispatch, useSelector } from 'react-redux';
import Button from 'app/components/Button';
import * as TableFnc from 'app/utils/tableFunctions';
import useStyles from './styles';
import { FuseAnimate } from '../../../@fuse';
import buttons from '../../utils/constants/buttonConstants.json';
import {
    closeDocDetailSideBar,
    closeFieldDetailSidebar,
    editDocFieldSidebar,
    getCommonData,
    newDocFieldSidebar,
    removeDocField,
    setSelectedField,
} from './store/actions';
import _ from '../../../@lodash';
import * as DialogAction from '../../store/actions/fuse';

const headRows = [
    { id: 'fld_nm', numeric: false, disablePadding: true, label: 'Field Name' },
    { id: 'ord_no', numeric: false, disablePadding: true, label: 'Display Order' },
    { id: 'grp_nm', numeric: false, disablePadding: true, label: 'Group field' },
];

function DocFieldTableHead(props) {
    const classes = useStyles();
    const { order, onRequestSort } = props;
    const createSortHandler = property => event => {
        onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className={classes.tableRow}>
                {headRows.map(row => (
                    <TableCell
                        key={row.id}
                        align={row.numeric ? 'right' : 'left'}
                        sortDirection={order.columnId === row.id ? order.direction : false}
                        className={classes.cellHead}
                    >
                        <TableSortLabel
                            active={order.columnId === row.id}
                            direction={order.direction}
                            onClick={createSortHandler(row.id)}
                        >
                            {row.label}
                        </TableSortLabel>
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
}

function DocFieldTable() {
    const [order, setOrder] = React.useState({
        direction: 'asc',
        columnId: null,
    });
    const [selected, setSelected] = React.useState([]);
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(25);
    const fields = useSelector(({ document }) => document.fields.fieldList);
    const searchField = useSelector(({ document }) => document.fields.searchField);
    const deltFlg = useSelector(({ document }) => document.fields.fieldDeltFlg);
    const selectedDoc = useSelector(({ document }) => document.docs.selectedDoc);
    const selectedField = useSelector(({ document }) => document.fields.selectedField);
    const searchForm = useSelector(({ document }) => document.docs.searchForm);
    const dispatch = useDispatch();
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const fieldDetailSidebar = useSelector(({ document }) => document.fields.fieldSidebar);

    const [rows, setRows] = React.useState([]);
    useEffect(() => {
        if (fields) {
            const mappingField = Object.values(fields).flatMap(item => {
                const filterCondition =
                    item.fld_nm.toLowerCase().includes(searchField.toLowerCase()) && item.delt_flg === deltFlg;
                const groupName = item.fld_grp_id ? fields[item.fld_grp_id].fld_nm : '';
                return filterCondition ? [{ ...item, grp_nm: groupName }] : [];
            });
            setRows(mappingField);
        }
        setPage(0);
    }, [fields, searchField, deltFlg]);

    function canBeAdded() {
        if (selectedDoc != null) {
            if (selectedDoc.grp_flg === 'Y') {
                return null;
            }
        }
        return selectedDoc != null;
    }

    function canBeDeleted() {
        return selectedField != null && fieldDetailSidebar.data?.delt_flg === 'N';
    }

    function handleClick(event, row) {
        dispatch(editDocFieldSidebar(row));
        dispatch(getCommonData());
        setSelected(row.doc_fld_id);
    }

    async function handleAdd(event) {
        dispatch(setSelectedField(null));
        dispatch(getCommonData());
        dispatch(closeDocDetailSideBar());
        await dispatch(closeFieldDetailSidebar());
        await dispatch(newDocFieldSidebar());
    }

    const isSelected = name => selected.indexOf(name) !== -1;

    function handleRemoveField() {
        dispatch(removeDocField(selectedField, selectedDoc.doc_tp_id));
    }
    return (
        <FuseAnimate animation="transition.slideUpIn" delay={300}>
            <div className="w-1/2 flex flex-col border-1 p-1 mb-2 mt-2 mr-2">
                <div className="flex-grow overflow-x-auto">
                    <Table
                        stickyHeader
                        key="Table-Field"
                        aria-label="sticky table"
                        className="w-full"
                        size="small"
                        aria-labelledby="tableTitle"
                    >
                        <DocFieldTableHead
                            order={order}
                            onRequestSort={(event, property) =>
                                TableFnc.handleRequestSort(event, property, order, setOrder)
                            }
                        />
                        <TableBody>
                            {_.orderBy(
                                rows,
                                [item => TableFnc.handleOrderType(item, order.columnId)],
                                [order.direction],
                            )
                                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                .map((row, index) => {
                                    const isItemSelected = isSelected(row.doc_fld_id);
                                    const labelId = `enhanced-table-checkbox-${index}`;

                                    return (
                                        <TableRow
                                            hover
                                            onClick={ev => handleClick(ev, row)}
                                            aria-checked={isItemSelected}
                                            tabIndex={-1}
                                            key={row.doc_fld_id}
                                            selected={isItemSelected}
                                        >
                                            <TableCell component="th" id={labelId} scope="row">
                                                {row.fld_nm}
                                            </TableCell>
                                            <TableCell component="th" id={labelId} scope="row">
                                                {row.ord_no}
                                            </TableCell>
                                            <TableCell component="th" id={labelId} scope="row">
                                                {row.grp_nm}
                                            </TableCell>
                                        </TableRow>
                                    );
                                })}
                        </TableBody>
                    </Table>
                </div>
                <div className="w-full flex flex-row items-center">
                    <div className="w-8/12 justify-start flex">
                        <TablePagination
                            rowsPerPageOptions={[10, 25, 50]}
                            component="div"
                            count={rows.length}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            backIconButtonProps={{
                                'aria-label': 'Previous Page',
                            }}
                            nextIconButtonProps={{
                                'aria-label': 'Next Page',
                            }}
                            onChangePage={(ev, page) => TableFnc.handleChangePage(ev, page, setPage)}
                            onChangeRowsPerPage={ev =>
                                TableFnc.handleChangeRowsPerPage(ev, page, rows, setPage, setRowsPerPage)
                            }
                            labelRowsPerPage=""
                        />
                    </div>
                    <div className="w-4/12 justify-end flex">
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_ADD) && (
                            <Button onClick={handleAdd} disabled={!canBeAdded()} className="whitespace-no-wrap px-13">
                                <span className="hidden sm:flex">New</span>
                            </Button>
                        )}
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_DELETE) && (
                            <Button
                                onClick={ev =>
                                    dispatch(
                                        DialogAction.openDialog(
                                            'Warning. You are breaking up group relations and it may affects extraction rule. Are you sure you want to proceed?',
                                            `Are you sure to delete field ${
                                                fieldDetailSidebar.data ? fieldDetailSidebar.data.fld_nm : null
                                            }`,
                                            'Confirm',
                                            handleRemoveField,
                                        ),
                                    )
                                }
                                disabled={!canBeDeleted()}
                                className="whitespace-no-wrap px-13"
                            >
                                <span className="hidden sm:flex">Delete</span>
                            </Button>
                        )}
                    </div>
                </div>
            </div>
        </FuseAnimate>
    );
}
export default DocFieldTable;

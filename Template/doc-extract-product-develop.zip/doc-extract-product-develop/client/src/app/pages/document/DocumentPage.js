import React, { useRef, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import withReducer from 'app/store/withReducer';
import reducer from './store/reducers';
import DocFieldTable from './DocFieldTable';
import DocTable from './DocTable';
import DocFieldDetail from './DocFieldDetail';
import FusePageCarded from '../../../@fuse/components/FusePageLayouts/carded/FusePageCarded';
import DocDetail from './DocDetail';
import DocSearch from './DocSearch';

import * as Actions from './store/actions';

function Document() {
    const dispatch = useDispatch();

    const docDetailSidebar = useSelector(({ document }) => document.docs.docSidebar);
    const fieldDetailSidebar = useSelector(({ document }) => document.fields.fieldSidebar);
    const pageLayout = useRef(null);

    useEffect(() => {
        dispatch(Actions.getDynamicType());
        dispatch(Actions.getLocationData());
    }, [dispatch]);

    return (
        <FusePageCarded
            classes={{
                content: 'flex',
                header: 'min-h-52 h-52 sm:h52 sm:min-h-52',
                topBg: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
                sidebarWrapper: 'w-2/12',
                rightSidebar: 'w-full px-3',
                sidebarHeader: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
                contentWrapper: 'pr-3 pl-3',
            }}
            header={<DocSearch />}
            content={
                <>
                    <DocTable />
                    <DocFieldTable />
                </>
            }
            {...(docDetailSidebar.isActive ? { rightSidebarHeader: <> </>, rightSidebarContent: <DocDetail /> } : {})}
            {...(fieldDetailSidebar.isActive
                ? { rightSidebarHeader: <> </>, rightSidebarContent: <DocFieldDetail /> }
                : {})}
            ref={pageLayout}
            innerScroll
        />
    );
}

export default withReducer('document', reducer)(Document);

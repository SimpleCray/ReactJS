/* eslint-disable import/extensions */
import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import { useDispatch, useSelector } from 'react-redux';
import _ from '@lodash';
import Button from 'app/components/Button';
import buttons from 'app/utils/constants/buttonConstants.json';
import * as TableFnc from 'app/utils/tableFunctions';
import * as Actions from './store/actions';
import { FuseAnimate } from '../../../@fuse';
import useStyles from './styles';
import * as DialogAction from '../../store/actions/fuse';

const headRows = [
    { id: 'doc_nm', numeric: false, disablePadding: true, label: 'Document Name' },
    { id: 'grp_nm', numeric: false, disablePadding: true, label: 'Group Name' },
];

function DocTableHead(props) {
    const classes = useStyles();
    const { order, onRequestSort } = props;
    const createSortHandler = property => event => {
        onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className={classes.tableRow}>
                {headRows.map(row => (
                    <TableCell
                        key={row.id}
                        align={row.numeric ? 'right' : 'left'}
                        sortDirection={order.columnId === row.id ? order.direction : false}
                        className={classes.cellHead}
                    >
                        <TableSortLabel
                            active={order.columnId === row.id}
                            direction={order.direction}
                            onClick={createSortHandler(row.id)}
                        >
                            {row.label}
                        </TableSortLabel>
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
}

function DocTable() {
    const [order, setOrder] = React.useState({
        direction: 'asc',
        columnId: null,
    });
    const [selected, setSelected] = React.useState([]);
    const [rowsPerPage, setRowsPerPage] = React.useState(25);
    const page = useSelector(({ document }) => document.docs.page);
    const docs = useSelector(({ document }) => document.docs.docList);
    const selectedDoc = useSelector(({ document }) => document.docs.selectedDoc);
    const searchForm = useSelector(({ document }) => document.docs.searchForm);
    const dispatch = useDispatch();
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    useEffect(() => {
        dispatch(Actions.getMatchingType());
    }, []);

    const rows = [];
    if (docs != null) {
        Object.keys(docs).forEach(function(key) {
            rows.push(docs[key]);
        });
    }

    function canBeDeleted() {
        return selectedDoc != null && !searchForm.deltFlg;
    }
    function canBeAdded() {
        return !searchForm.deltFlg;
    }
    function handleClick(event, row) {
        setSelected(row.doc_tp_id);
        dispatch(Actions.setSelectedDoc(row));
        dispatch(Actions.getDocFields(row.doc_tp_id));
        dispatch(Actions.closeFieldDetailSidebar());
        dispatch(Actions.editDocSidebar(row));
    }

    async function handleAdd(event) {
        dispatch(Actions.setSelectedDoc(null));
        dispatch(Actions.getDocFields(null));
        dispatch(Actions.closeFieldDetailSidebar());
        await dispatch(Actions.closeDocDetailSideBar());
        await dispatch(Actions.newDocSidebar());
    }

    const isSelected = id => selected.indexOf(id) !== -1;

    function handleRemoveDoc() {
        dispatch(Actions.checkDocRemove(selectedDoc, docs));
    }
    return (
        <FuseAnimate animation="transition.slideUpIn" delay={300}>
            <div className="w-1/2 flex flex-col border-1 p-1 mb-2 mt-2 mr-2">
                <div className="flex-grow overflow-x-auto">
                    <Table
                        stickyHeader
                        aria-label="sticky table"
                        className="w-full"
                        size="small"
                        aria-labelledby="tableTitle"
                    >
                        <DocTableHead
                            order={order}
                            onRequestSort={(event, property) =>
                                TableFnc.handleRequestSort(event, property, order, setOrder)
                            }
                        />
                        <TableBody>
                            {_.orderBy(rows, [order.columnId], [order.direction])
                                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                .map((row, index) => {
                                    const isItemSelected = isSelected(row.doc_tp_id);
                                    const labelId = `enhanced-table-checkbox-${index}`;

                                    return (
                                        <TableRow
                                            hover
                                            onClick={evt => handleClick(evt, row)}
                                            aria-checked={isItemSelected}
                                            tabIndex={-1}
                                            key={row.doc_tp_id}
                                            selected={isItemSelected}
                                        >
                                            <TableCell component="th" scope="row">
                                                {row.doc_nm}
                                            </TableCell>
                                            <TableCell component="th" scope="row">
                                                {row.doc_parent ? row.doc_parent.doc_nm : ''}
                                            </TableCell>
                                        </TableRow>
                                    );
                                })}
                        </TableBody>
                    </Table>
                </div>
                <div className="w-full flex flex-row items-center">
                    <div className="w-8/12 justify-start flex">
                        <TablePagination
                            rowsPerPageOptions={[10, 25, 50]}
                            component="div"
                            count={rows.length}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            backIconButtonProps={{
                                'aria-label': 'Previous Page',
                            }}
                            nextIconButtonProps={{
                                'aria-label': 'Next Page',
                            }}
                            labelRowsPerPage=""
                            onChangePage={(ev, page) => dispatch(Actions.setPage(page))}
                            onChangeRowsPerPage={ev => TableFnc.handleChangeRowsPerPage(ev, page, rows, (pageNumber) => dispatch(Actions.setPage(pageNumber)), setRowsPerPage)}
                        />
                    </div>
                    <div className="w-4/12 justify-end flex">
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_ADD) && (
                            <Button className="whitespace-no-wrap px-13" onClick={handleAdd}>
                                <span className="hidden sm:flex">New</span>
                            </Button>
                        )}
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_DELETE) && (
                            <Button
                                className="whitespace-no-wrap px-13"
                                onClick={ev =>
                                    dispatch(
                                        DialogAction.openDialog(
                                            `Are you sure to delete document ${
                                                selectedDoc ? selectedDoc.doc_nm : null
                                            }`,
                                            'Warning',
                                            'Confirm',
                                            handleRemoveDoc,
                                        ),
                                    )
                                }
                                disabled={!canBeDeleted()}
                            >
                                <span className="hidden sm:flex">Delete</span>
                            </Button>
                        )}
                    </div>
                </div>
            </div>
        </FuseAnimate>
    );
}
export default DocTable;

import HandleServerErrors from 'app/utils/handleServerErrors';
import { closeDocDetailSideBar } from './doc.action';
import { showMessage } from '../../../../store/actions/fuse';
import { API_EP } from '../../../../utils/commonAPI';

export const GET_DOC_FIELDS = 'GET_DOC_FIELDS';
export const EDIT_FIELD_TYPE = 'EDIT_FIELD_TYPE';
export const NEW_FIELD_TYPE = 'NEW_FIELD_TYPE';
export const CLOSE_FIELD_DETAIL = 'CLOSE_FIELD_DETAIL';
export const ADD_DOC_FIELD = 'ADD_DOC_FIELD';
export const UPDATE_DOC_FIELD = 'UPDATE_DOC_FIELD';
export const REMOVE_DOC_FIELD = 'REMOVE_DOC_FIELD';
export const SET_SELECTED_FIELD = 'SET_SELECTED_FIELD';
export const SEARCH_DOC_FIELD = 'SEARCH_DOC_FIELD';
export const GET_COMMON_DATA = 'GET_COMMON_DATA';
export const ADD_FIELD_DETAIL_ATTRS = 'ADD_FIELD_DETAIL_ATTRS';

export function getDocFields(docTpId) {
    const request = API_EP.get(`/doc-setting/${docTpId}/fields/`);
    return dispatch => {
        // dispatch(setSelectedDoc(docTpId));
        dispatch(setSelectedField(null));
        request
            .then(response =>
                dispatch({
                    type: GET_DOC_FIELDS,
                    payload: response.data.result,
                }),
            )
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
    };
}
export function editDocFieldSidebar(data) {
    if (data.attr_ctnt) {
        const attrCtnt = JSON.parse(data.attr_ctnt);
        if (!Array.isArray(attrCtnt) && attrCtnt) {
            const attrNew = [];
            for (const key in attrCtnt) {
                const item = {};
                item.attribute = key;
                item.value = attrCtnt[key];
                attrNew.push(item);
            }
            data.attr_ctnt = JSON.stringify(attrNew);
        }
    }
    return dispatch => {
        dispatch(setSelectedField(data.doc_fld_id));
        dispatch(closeDocDetailSideBar());
        dispatch({
            type: EDIT_FIELD_TYPE,
            data,
        });
    };
}
export function newDocFieldSidebar() {
    return dispatch => {
        dispatch({
            type: NEW_FIELD_TYPE,
        });
    };
}
export function closeFieldDetailSidebar() {
    return {
        type: CLOSE_FIELD_DETAIL,
    };
}

export function addDocField(field, attributes) {
    attributes[0].attribute = attributes[0].attribute.trim();
    attributes[0].value = attributes[0].value.trim();
    if (attributes[0].attribute) {
        attributes = JSON.stringify(attributes);
    } else attributes = null;
    return dispatch => {
        const request = API_EP.post(`/doc-setting/field/add`, {
            field,
            attributes,
        });
        return request
            .then(response => {
                dispatch(getDocFields(field.doc_tp_id));
                dispatch(newDocFieldSidebar());
                const option = {
                    message: response.data.message,
                    variant: 'success',
                };
                dispatch(showMessage(option));
            })
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
    };
}

export function updateDocField(field, attributes) {
    field.delt_flg = field.active_flg ? 'N' : 'Y';
    attributes[0].attribute = attributes[0].attribute.trim();
    attributes[0].value = attributes[0].value.trim();
    if (attributes[0].attribute) {
        attributes = JSON.stringify(attributes);
    } else attributes = null;
    return dispatch => {
        const request = API_EP.put(`/doc-setting/field/update`, {
            field,
            attributes,
        });
        return request.then(response =>
            Promise.all([
                dispatch({
                    type: UPDATE_DOC_FIELD,
                }),
            ])
                .then(() => {
                    dispatch(getDocFields(field.doc_tp_id));
                    const option = {
                        message: response.data.message,
                        variant: 'success',
                    };
                    dispatch(showMessage(option));
                })
                .catch(err => {
                    dispatch(
                        showMessage({
                            message: HandleServerErrors.getServerErrorMessage(err),
                            variant: 'error',
                        }),
                    );
                }),
        );
    };
}

export function removeField(docFldId, userId) {
    const request = API_EP.put(`/doc-setting/field/remove`, {
        docFldId,
        userId,
    });
    return dispatch =>
        request
            .then(response => {
                dispatch({
                    type: REMOVE_DOC_FIELD,
                    payload: response.data.result,
                });
            })
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function removeDocField(docFldId, docTpId) {
    const userId = JSON.parse(localStorage.getItem('userInfo')).usrId;
    return dispatch => {
        const request = API_EP.put(`/doc-setting/field/remove`, {
            docFldId,
            userId,
        });

        return request
            .then(response =>
                Promise.all([
                    dispatch({
                        type: REMOVE_DOC_FIELD,
                    }),
                ]).then(() => {
                    dispatch(getDocFields(docTpId));
                    dispatch(newDocFieldSidebar());
                    const option = {
                        message: response.data.message,
                        variant: 'success',
                    };
                    dispatch(showMessage(option));
                }),
            )
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
    };
}

export function setSelectedField(id) {
    return {
        type: SET_SELECTED_FIELD,
        payload: id,
    };
}

export function searchDocField(searchCond) {
    return {
        type: SEARCH_DOC_FIELD,
        searchField: searchCond.fieldName,
        fieldDeltFlg: searchCond.fieldDeltFlg,
    };
}

export function getCommonData() {
    const request = API_EP.get('/common-data/all-common-data');
    return dispatch =>
        request.then(response =>
            dispatch({
                type: GET_COMMON_DATA,
                commDatList: response.data.payload,
            }),
        );
}

export const addFieldDetailAttr = fieldDetailAttrs => dispatch =>
    dispatch({
        type: ADD_FIELD_DETAIL_ATTRS,
        fieldDetailAttrs,
    });

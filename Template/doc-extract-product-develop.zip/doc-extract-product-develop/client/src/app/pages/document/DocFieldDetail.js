import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
    Icon,
    OutlinedInput,
    Typography,
    List,
    ListItem,
    Collapse,
    Tooltip,
    IconButton,
    FormControlLabel,
    Checkbox,
    MenuItem,
    TextField,
} from '@material-ui/core';
import { ExpandLess, ExpandMore } from '@material-ui/icons';
import { FuseAnimate } from '@fuse';
import Button from 'app/components/Button';
import { useForm } from '@fuse/hooks';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import * as Actions from './store/actions';
import useStyles from './styles';
import buttons from '../../utils/constants/buttonConstants.json';
import DocFieldDetailAttr from './DocFieldDetailAttr';
import 'styles/scss/document-type.scss';
import _ from '@lodash';
import { openDialog } from '../../store/actions/fuse/dialog.actions';

const defaultFormState = {
    doc_fld_id: '',
    doc_tp_id: '',
    fld_nm: '',
    fld_cd: '',
    active_flg: false,
    fld_grp_id: '0',
    dflt_val: '',
    mdt_flg: false,
    tag_val: '',
    tmplt_flg: false,
    com_dat_id: '0',
    ord_no: '0',
    dp_tp_cd: 'R',
    doc_nm: '',
    extr_tp_cd: 'EMPTY',
    userId: JSON.parse(localStorage.getItem('userInfo')).usrId,
};

function DocFieldDetail(props) {
    const dispatch = useDispatch();

    const fieldList = useSelector(({ document }) => document.fields.fieldList);
    const fieldDetailSidebar = useSelector(({ document }) => document.fields.fieldSidebar);
    const selectedDoc = useSelector(({ document }) => document.docs.selectedDoc);
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const searchForm = useSelector(({ document }) => document.docs.searchForm);
    const commonData = useSelector(({ document }) => document.fields.commDatList);
    const docFieldDetailAttrs = useSelector(({ document }) => document.fields.fieldDetailAttrs);

    const { form, handleChange, setForm } = useForm(defaultFormState);

    const [isModify, setIsModify] = useState(false);
    const [commDatList, setCommDatList] = useState([]);
    const [docFieldAttrs, setDocFieldAttrs] = useState([]);
    const [indexDuplicateAttr, setIndexDuplicateAttr] = useState([]);
    const [fieldListData, setFieldListData] = useState([]);
    const [advanceExpand, setAdvanceExpand] = useState(false);

    useEffect(() => {
        setDocFieldAttrs(handleAlignArrayAttr(docFieldDetailAttrs));
    }, [docFieldDetailAttrs]);

    const handleAlignArrayAttr = array => {
        const returnAlignArray = array.map(item => ({ ...item }));
        for (let i = 0; i < array.length; i++) {
            returnAlignArray[i].index = i;
        }
        return returnAlignArray;
    };
    const initForm = useCallback(() => {
        /**
         * Dialog type: 'edit'
         */
        if (fieldDetailSidebar.type === 'edit' && fieldDetailSidebar.data) {
            const dataFieldDetail = fieldDetailSidebar.data;
            setForm({
                ...dataFieldDetail,
                active_flg: dataFieldDetail.delt_flg === 'N',
                mdt_flg: dataFieldDetail.mdt_flg === 'Y',
                tmplt_flg: dataFieldDetail.tmplt_flg === 'Y',
                fld_cd: dataFieldDetail.fld_cd ? dataFieldDetail.fld_cd : '',
                dp_tp_cd: dataFieldDetail.dp_tp_cd ? dataFieldDetail.dp_tp_cd : 'R',
                doc_nm: dataFieldDetail.doc ? dataFieldDetail.doc.doc_nm : '',
                userId: defaultFormState.userId ? defaultFormState.userId : '',
            });
        }

        /**
         * Dialog type: 'new'
         */
        if (fieldDetailSidebar.type === 'new') {
            setForm({
                ...defaultFormState,
                doc_tp_id: selectedDoc.doc_tp_id,
                fld_grp_flg: 'N',
                fld_grp_id: null,
            });
        }
    }, [fieldDetailSidebar.data, fieldDetailSidebar.type, setForm]);

    useEffect(() => {
        initForm();
        setIsModify(false);
    }, [fieldDetailSidebar.isActive, initForm]);
    // Get common data
    useEffect(() => {
        const comm = [];
        if (commonData != null) {
            Object.keys(commonData).forEach(function(key) {
                comm.push({
                    com_dat_id: commonData[key].com_dat_id,
                    com_dat_nm: commonData[key].com_dat_nm,
                });
            });
        }
        setCommDatList(comm);
    }, [commonData]);

    useEffect(() => {
        if (fieldList && !_.isEmpty(fieldList)) {
            const parentGroupField = Object.values(fieldList).filter(
                item => item.fld_grp_flg === 'Y' && item.delt_flg === 'N',
            );
            setFieldListData(parentGroupField);
        }
    }, [fieldList]);

    const classes = useStyles();

    const onGroupClick = event => {
        if (event.target.checked) {
            const updateForm = { ...form, fld_grp_flg: 'Y', fld_grp_id: null, dp_tp_cd: 'R' };
            setForm(updateForm);
        } else setForm(preState => ({ ...preState, fld_grp_flg: 'N' }));
    };

    const onGroupChange = event => {
        const updateForm =
            event.target.value === 'none'
                ? { ...form, fld_grp_id: null, dp_tp_cd: 'R' }
                : { ...form, fld_grp_id: event.target.value, dp_tp_cd: 'T' };
        setForm(updateForm);
    };

    function handleSubmit(event) {
        event.preventDefault();
        const isCheckdocFieldDetailAttrs = formatDocFieldDetail(docFieldDetailAttrs);
        setIsModify(true);
        if (!isCheckdocFieldDetailAttrs) {
            setIndexDuplicateAttr([]);
            dispatch(
                showMessage({
                    message: 'Attribute are not allowed empty',
                    variant: 'error',
                }),
            );
        } else {
            const isCheckDuplicateAttrs = checkDuplicateAttrs(docFieldDetailAttrs);
            if (isCheckDuplicateAttrs) {
                dispatch(
                    showMessage({
                        message: 'Attribute are not allowed duplicate',
                        variant: 'error',
                    }),
                );
            } else if (!validate(form)) {
                setIsModify(false);
                if (fieldDetailSidebar.type === 'edit') {
                    const wasGroup = fieldListData.find(item => item.doc_fld_id === form.doc_fld_id)?.fld_grp_flg;
                    if (form.fld_grp_flg === 'N' && wasGroup === 'Y') {
                        dispatch(
                            openDialog(
                                'Warning. You are breaking up group relations and it may affects extraction rule. Are you sure you want to proceed?',
                                'Update',
                                'Confirm',
                                () => {
                                    dispatch(Actions.updateDocField(form, docFieldDetailAttrs));
                                },
                            ),
                        );
                    } else dispatch(Actions.updateDocField(form, docFieldDetailAttrs));
                } else {
                    dispatch(Actions.addDocField(form, docFieldDetailAttrs));
                }
            }
        }
    }
    const formatDocFieldDetail = array => {
        let isCheckAttr = true;
        if (array.length !== 1) {
            array.map(item => {
                if (!item.attribute.trim() || !item.value.trim()) {
                    isCheckAttr = false;
                }
            });
        } else if (array.length === 1) {
            if (array[0].attribute.trim() || array[0].value.trim()) {
                if (!array[0].attribute.trim() || !array[0].value.trim()) {
                    isCheckAttr = false;
                }
            }
        }
        return isCheckAttr;
    };

    const checkDuplicateAttrs = array => {
        let isCheckAttr = false;
        const arrayAttr = [];
        const arrIndexAttrs = [];
        array.map((item, index) => {
            if (arrayAttr.includes(item.attribute.trim())) {
                isCheckAttr = true;
                arrIndexAttrs.push(index);
            } else {
                arrayAttr.push(item.attribute.trim());
            }
        });
        setIndexDuplicateAttr(arrIndexAttrs);
        return isCheckAttr;
    };

    function closeSideBar(event) {
        dispatch(Actions.closeFieldDetailSidebar());
    }

    function handleInputLength(e, maxLen) {
        e.target.value = Math.max(0, parseInt(e.target.value))
            .toString()
            .slice(0, maxLen);
    }
    function canBeSaved() {
        return !searchForm.deltFlg;
    }

    const validate = form => {
        if (form.fld_nm.length === 0 || form.fld_nm === '') {
            return true;
        }
        return false;
    };

    function handleChangeText(event) {
        handleChange(event);
        setIsModify(true);
    }

    function handleChangeName(event) {
        handleChange(event);
        setForm(form => ({
            ...form,
            fld_cd: form.fld_nm.toLowerCase().replace(/[^a-zA-Z0-9]+/g, '_'),
        }));
        setIsModify(true);
    }
    function handleChangeActFlg(event) {
        event.persist();
        setForm(form => ({
            ...form,
            active_flg: event.target.checked,
        }));
        setIsModify(true);
    }
    function handleChangeAttrs() {
        setIsModify(false);
    }
    function handleChangeValue(index) {
        const arrIndex = indexDuplicateAttr;
        if (indexDuplicateAttr.includes(index)) {
            arrIndex.splice(indexDuplicateAttr.indexOf(index), 1);
            setIndexDuplicateAttr(arrIndex);
        }
    }

    return (
        <FuseAnimate animation="transition.slideUpIn" delay={300}>
            <div className="p-8 sm:p-8 h-full">
                <IconButton className="float-right" onClick={closeSideBar}>
                    <Icon>close</Icon>
                </IconButton>
                <Typography variant="subtitle1" className="mb-10 mt-5">
                    Field Detail
                </Typography>
                <form noValidate onSubmit={handleSubmit}>
                    <TextField
                        fullWidth
                        className="mb-5"
                        id="fldNm"
                        name="fld_nm"
                        label="Field Name"
                        variant="outlined"
                        size="small"
                        value={form.fld_nm}
                        inputProps={{ maxLength: 50 }}
                        onChange={handleChangeName}
                        required={form.fld_nm === '' && isModify}
                        error={form.fld_nm === '' && isModify}
                        helperText={form.fld_nm === '' && isModify ? 'Field Name can not be empty!' : ''}
                    />

                    <TextField
                        fullWidth
                        id="ordNo"
                        name="ord_no"
                        label="Display Order"
                        variant="outlined"
                        type="number"
                        size="small"
                        value={form.ord_no}
                        onInput={e => handleInputLength(e, 3)}
                        onChange={handleChangeText}
                        hidden={fieldDetailSidebar.type === 'new'}
                    />

                    <FormControlLabel
                        className="mb-3"
                        label="Is group field"
                        control={<Checkbox color="secondary" checked={form.fld_grp_flg === 'Y'} />}
                        onChange={onGroupClick}
                    />

                    <TextField
                        select
                        fullWidth
                        className="mb-5"
                        id="fldTp"
                        name="dp_tp_cd"
                        variant="outlined"
                        size="small"
                        label="Display Type"
                        value={form.dp_tp_cd ? form.dp_tp_cd : 'T'}
                        onChange={handleChangeText}
                        disabled={form.fld_grp_flg === 'Y'}
                        hidden={form.fld_grp_flg !== 'N'}
                    >
                        <MenuItem value="R" key="R">
                            Text
                        </MenuItem>
                        <MenuItem value="T" key="T">
                            Table
                        </MenuItem>
                    </TextField>
                    <TextField
                        select
                        fullWidth
                        className="mb-5"
                        size="small"
                        autoComplete="off"
                        variant="outlined"
                        label="Belong to group"
                        value={!form.fld_grp_id ? 'none' : form.fld_grp_id}
                        onChange={onGroupChange}
                        hidden={form.fld_grp_flg !== 'N'}
                    >
                        <MenuItem key="none" value="none">
                            None
                        </MenuItem>
                        {fieldListData.map(item => (
                            <MenuItem key={item.doc_fld_id} value={item.doc_fld_id}>
                                {item.fld_nm}
                            </MenuItem>
                        ))}
                    </TextField>

                    <TextField
                        fullWidth
                        select
                        size="small"
                        label="Extract Type"
                        name="extr_tp_cd"
                        id="extrTpCd"
                        variant="outlined"
                        value={form.extr_tp_cd}
                        onChange={handleChangeText}
                        hidden={form.fld_grp_flg !== 'N'}
                    >
                        <MenuItem value="TICK" key="0">
                            TICK
                        </MenuItem>
                        <MenuItem value="FIX-HEIGHT" key="1">
                            FIX-HEIGHT
                        </MenuItem>
                        <MenuItem value="HEADER-FOOTER-REMOVAL" key="2">
                            HEADER-FOOTER-REMOVAL
                        </MenuItem>
                        <MenuItem value="EMPTY" key="3">
                            EMPTY
                        </MenuItem>
                    </TextField>

                    <FormControlLabel
                        hidden={form.fld_grp_flg !== 'N'}
                        control={
                            <Checkbox
                                onChange={handleChangeText}
                                name="tmplt_flg"
                                color="secondary"
                                checked={form.tmplt_flg}
                            />
                        }
                        label="Template Flag"
                    />

                    <FormControlLabel
                        control={
                            <Checkbox
                                onChange={handleChangeActFlg}
                                name="active_flg"
                                color="secondary"
                                checked={form.active_flg}
                            />
                        }
                        label="Active Flag"
                        hidden={!fieldDetailSidebar.type === 'new' || form.delt_flg === 'N'}
                    />

                    <div className="w-full flex items-end justify-end">
                        <Tooltip title="Advance option">
                            <IconButton onClick={() => setAdvanceExpand(!advanceExpand)}>
                                {advanceExpand ? <ExpandLess /> : <ExpandMore />}
                            </IconButton>
                        </Tooltip>
                    </div>

                    <Collapse in={advanceExpand} timeout="auto" unmountOnExit>
                        <Typography color="textSecondary" variant="caption">
                            Attributes
                        </Typography>
                        <div className="flex flex-col overflow-auto border-t border box-attr mt-1 pr-2">
                            <List component="nav" dense>
                                {docFieldAttrs.map(item => (
                                    <ListItem dense>
                                        <DocFieldDetailAttr
                                            index={item.index}
                                            attribute={item.attribute}
                                            isModify={isModify}
                                            indexDuplicateAttr={indexDuplicateAttr}
                                            onChangeAttrs={handleChangeAttrs}
                                            onChangeValue={handleChangeValue}
                                        />
                                    </ListItem>
                                ))}
                            </List>
                        </div>
                    </Collapse>

                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_SAVE) && (
                        <div className="w-full flex items-end justify-end fixed bottom-0 p-5">
                            <Button onClick={handleSubmit} disabled={!canBeSaved()}>
                                Save
                            </Button>
                        </div>
                    )}
                </form>
            </div>
        </FuseAnimate>
    );
}

export default DocFieldDetail;

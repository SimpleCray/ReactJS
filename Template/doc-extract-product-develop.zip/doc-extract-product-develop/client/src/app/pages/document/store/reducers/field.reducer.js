import * as Actions from '../actions';
import _ from '@lodash';

const initialState = {
    fieldList: [],
    fieldSidebar: {
        type: 'new',
        data: null,
        isActive: false,
    },
    selectedField: null,
    searchField: '',
    commDatList: [],
    fieldDetailAttrs: [{ attribute: '', value: '' }],
    fieldDeltFlg: 'N'
};
const fieldsReducer = function(state = initialState, action) {
    switch (action.type) {
        case Actions.GET_DOC_FIELDS:
            return {
                ...state,
                fieldList: _.keyBy(action.payload, 'doc_fld_id'),
            };
        case Actions.EDIT_FIELD_TYPE: {
            return {
                ...state,
                fieldSidebar: {
                    type: 'edit',
                    data: action.data,
                    isActive: true,
                },
                fieldDetailAttrs: action.data.attr_ctnt
                    ? JSON.parse(action.data.attr_ctnt)
                    : [{ attribute: '', value: '' }],
            };
        }
        case Actions.NEW_FIELD_TYPE: {
            return {
                ...state,
                fieldSidebar: {
                    type: 'new',
                    data: null,
                    isActive: true,
                },
                fieldDetailAttrs: [{ attribute: '', value: '' }],
            };
        }
        case Actions.CLOSE_FIELD_DETAIL: {
            return {
                ...state,
                fieldSidebar: {
                    type: 'new',
                    data: null,
                    isActive: false,
                },
            };
        }
        case Actions.SET_SELECTED_FIELD: {
            return {
                ...state,
                selectedField: action.payload,
            };
        }
        case Actions.SEARCH_DOC_FIELD: {
            return {
                ...state,
                searchField: action.searchField,
                fieldDeltFlg: action.fieldDeltFlg ? 'Y' : 'N',
            };
        }
        case Actions.GET_COMMON_DATA: {
            return {
                ...state,
                commDatList: action.commDatList,
            };
        }
        case Actions.ADD_FIELD_DETAIL_ATTRS:
            return {
                ...state,
                fieldDetailAttrs: action.fieldDetailAttrs,
            };
        default:
            return state;
    }
};

export default fieldsReducer;

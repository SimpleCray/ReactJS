import {combineReducers} from 'redux';
import docs from './doc.reducer';
import fields from "./field.reducer";

const reducer = combineReducers({
    docs,
    fields,
});

export default reducer;

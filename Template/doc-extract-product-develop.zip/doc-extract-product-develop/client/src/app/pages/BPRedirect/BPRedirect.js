import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import * as authActions from 'app/components/auth/store/actions';
import { logoutShine } from 'app/utils/utils';
import qs from 'qs';
import { Redirect } from 'react-router-dom';
import * as CommonActions from 'app/store/actions';
import AppConstants from 'app/utils/appConstants';

const BPRedirect = () => {
    const dispatch = useDispatch();
    const login = useSelector(({ auth }) => auth.login);
    const queryParams = qs.parse(window.location.href.split('?')[1], { ignoreQueryPrefix: true });

    useEffect(() => {
        // Validate query param if is the first authentication
        if (queryParams.hasOwnProperty(AppConstants.BP_TOKEN_PATTERN)) {
            dispatch(authActions.loginWithBP(queryParams.bptk, true));
        } else {
            const title = 'Login to SHINE failed!!!';
            CommonActions.showMessage({
                message: title,
                variant: 'error',
            });
            setTimeout(() => {
                logoutShine();
            }, 500);
        }
    }, []);

    const renderRedirect = () => {
        if (login.success === true) {
            return <Redirect to="/dashboard" />;
        }
        return null;
    };

    return (
        <>
            <div>{renderRedirect()}</div>
        </>
    );
};

export default BPRedirect;

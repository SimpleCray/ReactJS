import * as Actions from '../actions';

const initialState = {
    cmAllOptions: [],
    cmByIdData: {},
    createCommon: '',
    updateCommon: '',
    updateTable: '',
    page: 0,
    searchDeleted: 'No',
    searchText: '',
    companyList: [],
};

const commonReducers = (state = initialState, action) => {
    switch (action.type) {
        case Actions.ALL_COMMON_DATA:
            return {
                ...state,
                cmAllOptions: action.payload,
            };

        case Actions.CREATE_COMMON_DATA:
        case Actions.UPDATE_COMMON_DATA_VALUE:
        case Actions.COMMON_DATA_BY_ID:
            return {
                ...state,
                cmByIdData: {
                    ...action.payload,
                    com_dat_val: JSON.parse(action.payload.com_dat_val),
                },
            };

        case Actions.UPDATE_COMMON_DATA_VALUE:
            return {
                ...state,
                updateTable: action.payload,
            };

        case Actions.UPDATE_COMMON_DATA:
            return {
                ...state,
                updateCommon: action.payload,
            };

        case Actions.COMMON_DATA_COMPANY_NAME:
            return {
                ...state,
                companyList: action.payload.data.comList,
            };

        case Actions.SET_SEARCH_STATUS:
            return {
                ...state,
                searchDeleted: action.searchDeleted,
            };

        case Actions.SET_SEARCH_TEXT:
            return {
                ...state,
                searchText: action.searchText,
            };

        case Actions.SET_PAGE:
            return {
                ...state,
                page: action.page,
            };

        default:
            return state;
    }
};

export default commonReducers;

import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { FusePageCarded } from '@fuse';
import withReducer from 'app/store/withReducer';
import reducer from './store/reducers';
import _ from '@lodash';

import CommonHeader from './CommonDataHeader';
import CommonDataBody from './CommonDataBody';

import * as Actions from './store/actions';

const CommonDataPage = () => {
    const dispatch = useDispatch();
    const cmAllOptions = useSelector(({ CommonData }) => CommonData.common.cmAllOptions);
    const cmByIdData = useSelector(({ CommonData }) => CommonData.common.cmByIdData);

    useEffect(() => {
        dispatch(Actions.getCommonNameOptions());
        dispatch(Actions.getAllCompanyName());
    }, [dispatch]);

    useEffect(() => {
        if (cmAllOptions[0] && _.isEmpty(cmByIdData)) dispatch(Actions.getCommonDataById(cmAllOptions[0].com_dat_id));
    }, [cmAllOptions]);

    return (
        <FusePageCarded
            classes={{
                content: 'flex',
                header: 'min-h-60 h-60 py-2',
                topBg: 'min-h-60 h-60',
                contentWrapper: 'pr-0 pl-0',
            }}
            header={<CommonHeader />}
            content={<CommonDataBody />}
            innerScroll
        />
    );
};

export default withReducer('CommonData', reducer)(CommonDataPage);

import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    Input,
    IconButton,
    Dialog,
    DialogActions,
    DialogContent,
    InputAdornment,
    Toolbar,
    AppBar,
    TextField,
    Checkbox,
    Typography,
} from '@material-ui/core';
import {
    Close,
    AddBoxOutlined,
    EditOutlined,
    DeleteOutlined,
    CheckOutlined,
    ClearOutlined,
    DragIndicator,
    CheckBoxOutlineBlank,
    CheckBox,
} from '@material-ui/icons';
import { Autocomplete } from '@material-ui/lab';
import { sortableContainer, sortableElement, sortableHandle } from 'react-sortable-hoc';
import CustomButton from 'app/components/Button';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import arrayMove from 'array-move';

import * as Functions from '../commonDataFunction';
import * as Actions from '../store/actions';

const SortableContainer = sortableContainer(({ children }) => <ul className="p-0">{children}</ul>);

const CreateDialog = props => {
    const dispatch = useDispatch();
    const classes = Functions.useStyles();

    const companyList = useSelector(({ CommonData }) => CommonData.common.companyList);
    const cmAllOptions = useSelector(({ CommonData }) => CommonData.common.cmAllOptions);

    const [commonDataCode, setCommonDataCode] = useState('');
    const [commonDataName, setCommonDataName] = useState('');
    const [roleValue, setRoleValue] = useState([]);
    const [selectedItem, setSelectedItem] = useState(null);
    const [columnDefineList, setColumnDefineList] = useState([
        { type: 'key', label: 'code' },
        { type: 'value', label: 'value' },
    ]);
    const [columnDefineRegister, setColumnDefineRegister] = useState([]);

    const renderCompanyOptions = () => {
        const limitArrtibutes = companyList.map(item => ({ coCd: item.coCd, coNm: item.coNm })) || [];
        return [{ coCd: 'ALL', coNm: 'All' }, { coCd: 'ADMIN', coNm: 'Admin' }, ...limitArrtibutes];
    };

    const onCheckRoleChange = (event, option) => {
        if (event.target.checked) setRoleValue(option.coCd === 'ALL' ? [option] : [...roleValue, option]);
        else setRoleValue(roleValue.filter(item => item.coCd !== option.coCd));
    };

    const onAddClick = () => {
        setSelectedItem(columnDefineList.length);
        setColumnDefineRegister(columnDefineList);
        setColumnDefineList(prev => [
            ...prev,
            {
                type: 'none',
                label: '',
            },
        ]);
    };

    const onRemoveClick = index => {
        const updateLabelList = columnDefineList.filter((item, idx) => idx !== index);
        setColumnDefineList(updateLabelList);
    };

    const onCancelClick = () => {
        if (columnDefineRegister.length) setColumnDefineList(columnDefineRegister);
        setSelectedItem(null);
    };

    const onCheckClick = index => {
        const selectedData = {
            type: columnDefineList[index].type,
            label: document.getElementById(`cm-create-${index}`).value.trim(),
        };

        const isValidInput =
            selectedData.label.length &&
            !columnDefineList.some((item, id) => id !== index && item.label === selectedData.label);

        if (isValidInput) {
            const updateLabelList = [
                ...columnDefineList.slice(0, index),
                selectedData,
                ...columnDefineList.slice(index + 1),
            ];

            setColumnDefineList(updateLabelList);
            setSelectedItem(null);
        } else
            dispatch(
                showMessage({
                    message: !selectedData.label.length
                        ? 'Column name should not empty!'
                        : 'Column name had been exsited!',
                    variant: 'error',
                }),
            );
    };

    const onSaveClick = async () => {
        const validEmpty = commonDataCode.length && commonDataName.length && roleValue.length;
        const validDuplicate = !cmAllOptions.some(item => item.com_dat_cd === commonDataCode);
        if (validEmpty && validDuplicate) {
            await dispatch(
                Actions.createCommon({
                    com_dat_cd: commonDataCode,
                    com_dat_nm: commonDataName,
                    com_dat_val: JSON.stringify({
                        config: {
                            key: columnDefineList.find(item => item.type === 'key')?.label,
                            value: columnDefineList.find(item => item.type === 'value')?.label,
                        },
                        role: roleValue,
                        header: [...columnDefineList.map(item => item.label), 'deleted'],
                        data: [],
                    }),
                }),
            );

            await dispatch(Actions.getCommonNameOptions());

            props.onClose();
        } else
            dispatch(
                showMessage({
                    message: !validEmpty
                        ? 'Common data properties should not empty!'
                        : 'Common data code had been exsited!',
                    variant: 'warning',
                }),
            );
    };

    const onSortEnd = ({ oldIndex, newIndex }) => {
        if (newIndex > 1) setColumnDefineList(arrayMove(columnDefineList, oldIndex, newIndex));
        else
            dispatch(
                showMessage({
                    message: 'First and second columns are key and value. So always top!',
                    variant: 'warning',
                }),
            );
    };

    useEffect(() => {
        if (selectedItem === null) setColumnDefineRegister([]);
    }, [selectedItem]);

    useEffect(() => {
        setColumnDefineList([{ type: 'key', label: 'code' }, { type: 'value', label: 'value' }]);
        setColumnDefineRegister([]);
        setCommonDataCode('');
        setCommonDataName('');
        setRoleValue([]);
    }, [props.open]);

    const DragHandle = sortableHandle(({ value }) => (
        <IconButton className={classes.dragIconProps} disabled={value < 2}>
            <DragIndicator color="action" />
        </IconButton>
    ));

    const SortableItem = sortableElement(({ value }) => {
        const itemActive = value.index === selectedItem;

        return (
            <div className="w-full flex flex-row items-center">
                <DragHandle value={value.index} />
                <div className="flex flex-row mt-5 w-full ml-5 items-center">
                    <div className="w-2/12">
                        <Typography color="textSecondary">{value.type}</Typography>
                    </div>
                    <Input
                        fullWidth
                        id={`cm-create-${value.index}`}
                        autoComplete="off"
                        readOnly={!itemActive}
                        disableUnderline={!itemActive}
                        disabled={!itemActive}
                        autoFocus={itemActive}
                        defaultValue={value.label}
                        endAdornment={
                            <InputAdornment position="end">
                                {!itemActive && [
                                    <IconButton
                                        className={classes.iconProps}
                                        onClick={() => setSelectedItem(value.index)}
                                        disabled={selectedItem !== null && !itemActive}
                                    >
                                        <EditOutlined color="action" />
                                    </IconButton>,
                                    <IconButton
                                        className={classes.iconProps}
                                        disabled={value.index < 2}
                                        onClick={() => onRemoveClick(value.index)}
                                    >
                                        <DeleteOutlined color="action" />
                                    </IconButton>,
                                ]}

                                {itemActive && [
                                    <IconButton className={classes.iconProps}>
                                        <CheckOutlined color="action" onClick={() => onCheckClick(value.index)} />
                                    </IconButton>,
                                    <IconButton
                                        className={classes.iconProps}
                                        onClick={() => onCancelClick(value.index)}
                                    >
                                        <ClearOutlined color="action" />
                                    </IconButton>,
                                ]}
                            </InputAdornment>
                        }
                    />
                </div>
            </div>
        );
    });

    return (
        <Dialog maxWidth="xs" open={props.open} fullWidth>
            <AppBar position="static">
                <Toolbar className="flex flex-row w-full">
                    <div className="flex w-8/12 justify-start">New common data</div>
                    <div className="flex w-4/12 justify-end">
                        <IconButton onClick={props.onClose}>
                            <Close className={classes.whiteColor} />
                        </IconButton>
                    </div>
                </Toolbar>
            </AppBar>

            <DialogContent className="overflow-hidden">
                <TextField
                    {...Functions.textFieldProps}
                    className="mt-10"
                    label="Common data code"
                    value={commonDataCode}
                    onChange={e => setCommonDataCode(e.target.value)}
                />

                <TextField
                    {...Functions.textFieldProps}
                    className="mt-10"
                    label="Common data name"
                    value={commonDataName}
                    onChange={e => setCommonDataName(e.target.value)}
                />

                <Autocomplete
                    multiple
                    disableListWrap
                    limitTags={2}
                    className="my-10"
                    size="small"
                    options={renderCompanyOptions()}
                    disableCloseOnSelect
                    getOptionLabel={option => option.coNm}
                    getOptionDisabled={option => option.coCd !== roleValue[0]?.coCd && roleValue[0]?.coCd === 'ALL'}
                    renderOption={option => (
                        <React.Fragment>
                            <Checkbox
                                icon={<CheckBoxOutlineBlank fontSize="small" />}
                                checkedIcon={<CheckBox fontSize="small" />}
                                style={{ marginRight: 8 }}
                                checked={roleValue.some(item => item.coCd === option.coCd)}
                                onChange={e => onCheckRoleChange(e, option)}
                            />
                            {option.coNm}
                        </React.Fragment>
                    )}
                    renderInput={params => <TextField {...params} {...Functions.textFieldProps} label="Use role" />}
                    value={roleValue}
                    onChange={(event, value) => value.length < roleValue.length && setRoleValue(value)}
                />

                <IconButton disabled={selectedItem} onClick={onAddClick}>
                    <AddBoxOutlined color="action" />
                </IconButton>

                <SortableContainer useDragHandle onSortEnd={onSortEnd}>
                    {columnDefineList.map((value, idx) => (
                        <SortableItem
                            key={value.label}
                            index={idx}
                            value={{ label: value.label, index: idx, type: value.type }}
                        />
                    ))}
                </SortableContainer>
            </DialogContent>
            <DialogActions className="justify-end pl-8 sm:pl-16 mb-16 mr-8">
                <CustomButton disabled={selectedItem} onClick={onSaveClick}>
                    Save
                </CustomButton>
            </DialogActions>
        </Dialog>
    );
};

export default CreateDialog;

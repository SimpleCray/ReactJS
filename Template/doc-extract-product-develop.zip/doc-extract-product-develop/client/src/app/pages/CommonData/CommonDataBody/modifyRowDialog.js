import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    TextField,
    Dialog,
    DialogActions,
    DialogContent,
    Typography,
    Toolbar,
    AppBar,
    IconButton,
    Checkbox,
    FormControlLabel,
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import { ThemeProvider } from '@material-ui/styles';
import CustomButton from 'app/components/Button';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import _ from '@lodash';

import * as Actions from '../store/actions';
import * as Functions from '../commonDataFunction';

const ModifyDialog = props => {
    const dispatch = useDispatch();
    const classes = Functions.useStyles();

    const mainTheme = useSelector(({ fuse }) => fuse.settings.mainTheme);
    const cmByIdData = useSelector(({ CommonData }) => CommonData.common.cmByIdData);

    const [formData, setFormData] = useState({});

    const onSaveClick = async () => {
        const notEmptyCondition = Object.values(formData).filter(item => item.length).length > 1;

        const notDuplicate =
            Functions.isLikeRow(formData, props.dataModifyRow) ||
            !cmByIdData.com_dat_val?.data.some(item => Functions.isLikeRow(formData, item));

        if (notEmptyCondition && notDuplicate) {
            const updateTableData = !props.dataModifyRow
                ? [...cmByIdData.com_dat_val.data, formData]
                : cmByIdData.com_dat_val.data.map(item =>
                      Functions.isLikeRow(item, props.dataModifyRow) ? { ...formData } : item,
                  );
            const updateComDatVal = { ...cmByIdData.com_dat_val, data: updateTableData };
            await dispatch(
                Actions.updateCommonData({
                    com_dat_id: cmByIdData.com_dat_id,
                    com_dat_cd: cmByIdData.com_dat_cd,
                    com_dat_nm: cmByIdData.com_dat_nm,
                    com_dat_val: JSON.stringify(updateComDatVal),
                }),
            );
            props.onClose();
        } else {
            dispatch(
                showMessage({
                    message: !notEmptyCondition ? 'This row should be not plain!' : 'Row is duplicate!',
                    variant: 'error',
                }),
            );
        }
    };

    useEffect(() => {
        setFormData(props.dataModifyRow || { deleted: 'No' });
    }, [props.dataModifyRow, props.open]);

    return (
        <ThemeProvider theme={mainTheme}>
            <Dialog open={props?.open} maxWidth="xs" fullWidth>
                <AppBar position="static">
                    <Toolbar className="flex flex-row w-full">
                        <div className="flex w-8/12 justify-start">
                            <Typography variant="subtitle1" color="inherit">
                                {!props.dataModifyRow ? 'New row' : 'Update row'}
                            </Typography>
                        </div>
                        <div className="flex w-4/12 justify-end">
                            <IconButton onClick={props.onClose}>
                                <CloseIcon className={classes.whiteColor} />
                            </IconButton>
                        </div>
                    </Toolbar>
                </AppBar>
                <DialogContent className="flex flex-col">
                    {cmByIdData.com_dat_val?.header.slice(0, -1).map(item => {
                        return (
                            <TextField
                                className="mt-10"
                                fullWidth
                                variant="outlined"
                                size="small"
                                label={item}
                                value={formData[item]}
                                onChange={e => setFormData({ ...formData, [item]: e.target.value })}
                            />
                        );
                    })}
                    {props.dataModifyRow?.deleted === 'Yes' &&
                        [cmByIdData.com_dat_val?.header.slice(-1)[0]]?.map(item => (
                            <FormControlLabel
                                className="mt-5"
                                label="Deleted"
                                onChange={e => setFormData({ ...formData, [item]: e.target.checked ? 'Yes' : 'No' })}
                                control={<Checkbox color="secondary" checked={formData[item] === 'Yes'} />}
                            />
                        ))}
                </DialogContent>
                <DialogActions className="justify-end pl-8 sm:pl-16 mb-16 mr-8">
                    <CustomButton onClick={onSaveClick}>Save</CustomButton>
                </DialogActions>
            </Dialog>
        </ThemeProvider>
    );
};

export default ModifyDialog;

import { makeStyles } from '@material-ui/styles';
import { showMessage } from 'app/store/actions/fuse/message.actions';

export const useStyles = makeStyles({
    styleTextField: {
        marginRight: 20,
    },
    textFieldWidth: {
        minWidth: '200px',
    },
    whiteColor: {
        color: 'white',
    },
    editCmDataItem: {
        height: 35,
        width: 500,
        paddingLeft: 10,
    },
    editCmDataAddBox: {
        cursor: 'pointer',
        marginLeft: 10,
    },
    iconProps: {
        '&:hover': {
            backgroundColor: 'transparent',
        },
    },
    dragIconProps: {
        '&:hover': {
            backgroundColor: 'transparent',
        },
    },
    hindden: {
        display: 'none',
    },
});

export const textFieldProps = {
    fullWidth: true,
    variant: 'outlined',
    size: 'small',
};

export const createMessage = (dispatch, messParam, variantParam = 'warning') =>
    dispatch(
        showMessage({
            message: messParam,
            variant: variantParam,
        }),
    );

export const validateListItem = (listParam, labelNameParam, indexParam, dispatch) => {
    const isDuplicate = listParam.some((item, index) => index !== indexParam && item === labelNameParam);
    const isEmptyName = labelNameParam.trim().length === 0;

    let messageError = '';
    if (isDuplicate) messageError = 'Name had existed';
    if (isEmptyName) messageError = 'Name is not allowed empty';
    if (messageError.length !== 0) createMessage(dispatch, messageError);

    return !isEmptyName && !isDuplicate;
};

export const isArrayUnique = array => new Set(array).size === array.length;

export const isLikeRow = (primary, secondary) =>
    primary && secondary && Object.values(primary).join('-') === Object.values(secondary).join('-');

export const getCommonByRole = (commonData, userInfo) => {
    return commonData.flatMap(item => {
        const acceptByRole = item.com_dat_val?.role?.some(
            item =>
                item.coCd === 'ALL' ||
                item.coCd.toLowerCase() === userInfo.coCd.toLowerCase() ||
                item.coCd.toLowerCase() === userInfo.usrId.toLowerCase(),
        );
        return acceptByRole
            ? {
                  com_dat_id: item.com_dat_id,
                  com_dat_cd: item.com_dat_cd,
                  com_dat_nm: item.com_dat_nm,
              }
            : [];
    });
};

import { API_EP } from 'app/utils/commonAPI';
import EndPointAPI from 'app/utils/endPointAPI';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import { showError, checkResDataAPI } from 'app/utils/utils';

export const ALL_COMMON_DATA = 'ALL_COMMON_DATA';
export const COMMON_DATA_BY_ID = 'COMMON_DATA_BY_ID';
export const UPDATE_COMMON_DATA_VALUE = 'UPDATE_COMMON_DATA_VALUE';
export const CREATE_COMMON_DATA = 'CREATE_COMMON_DATA';
export const UPDATE_COMMON_DATA = 'UPDATE_COMMON_DATA';
export const SET_PAGE = 'SET_PAGE_COMMON_DATA';
export const SET_SEARCH_STATUS = 'SET_SEARCH_STATUS';
export const SET_SEARCH_TEXT = 'SET_SEARCH_TEXT';
export const COMMON_DATA_COMPANY_NAME = 'COMMON_DATA_COMPANY_NAME';

export const callBackFunction = (dispatch, typeParam, urlParam, messageParam) =>
    urlParam
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: typeParam,
                    payload: response.data,
                });
                if (messageParam)
                    dispatch(
                        showMessage({
                            message: messageParam,
                            variant: 'success',
                        }),
                    );
            }
        })
        .catch(error => dispatch(showError(error)));

export const getAllCompanyName = () => {
    const url = API_EP.get(EndPointAPI.ENDPOINT.BP.ALL_COM);
    return dispatch => callBackFunction(dispatch, COMMON_DATA_COMPANY_NAME, url);
};

export const getCommonNameOptions = () => {
    const url = API_EP.get('/common-data/all-common-data');
    return dispatch => callBackFunction(dispatch, ALL_COMMON_DATA, url);
};

export const getCommonDataById = idParam => {
    const url = API_EP.get('/common-data/common-data-by-id', { params: { id: idParam } });
    return dispatch => callBackFunction(dispatch, COMMON_DATA_BY_ID, url);
};

export const updateCommonData = param => {
    const url = API_EP.put('/common-data/update-common-data-value', {
        ...param,
        upd_usr_id: JSON.parse(localStorage.getItem('userInfo')).usrId,
    });
    return dispatch => callBackFunction(dispatch, UPDATE_COMMON_DATA_VALUE, url, 'Update successful');
};

export const createCommon = param => {
    const url = API_EP.post('/common-data/create-common-data', {
        ...param,
        userId: JSON.parse(localStorage.getItem('userInfo')).usrId,
    });
    return dispatch => callBackFunction(dispatch, CREATE_COMMON_DATA, url);
};

export const setSearchDeleted = searchDeleted => {
    return dispatch =>
        dispatch({
            type: SET_SEARCH_STATUS,
            searchDeleted,
        });
};

export const setSearchText = searchText => {
    return dispatch =>
        dispatch({
            type: SET_SEARCH_TEXT,
            searchText,
        });
};

export const setPage = value => {
    return dispatch =>
        dispatch({
            type: SET_PAGE,
            page: value,
        });
};

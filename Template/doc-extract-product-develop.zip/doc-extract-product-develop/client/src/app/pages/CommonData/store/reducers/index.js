import { combineReducers } from 'redux';
import common from './common.reducer';

const reducer = combineReducers({
    common,
});

export default reducer;

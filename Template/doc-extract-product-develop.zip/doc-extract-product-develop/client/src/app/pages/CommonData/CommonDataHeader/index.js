import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ThemeProvider } from '@material-ui/styles';
import { Paper, Input, FormControlLabel, Checkbox } from '@material-ui/core';
import { Search, Add } from '@material-ui/icons';
import Autocomplete from '@material-ui/lab/Autocomplete';
import buttons from 'app/utils/constants/buttonConstants.json';
import TextField from 'app/components/SearchTextField';

import CreateCommonDataDialog from './createCommonDataDialog';

import * as Functions from '../commonDataFunction';
import * as Actions from '../store/actions';

const CommonHeader = props => {
    const dispatch = useDispatch();
    const classes = Functions.useStyles();

    const mainTheme = useSelector(({ fuse }) => fuse.settings.mainTheme);
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const cmByIdData = useSelector(({ CommonData }) => CommonData.common.cmByIdData);
    const cmAllOptions = useSelector(({ CommonData }) => CommonData.common.cmAllOptions);
    const searchDeleted = useSelector(({ CommonData }) => CommonData.common.searchDeleted);
    const searchText = useSelector(({ CommonData }) => CommonData.common.searchText);

    const [openCreateDialog, setOpenCreateDialog] = useState(false);

    const onCreateClick = () => setOpenCreateDialog(true);

    const onInputChange = event => {
        dispatch(Actions.setSearchText(event.target.value));
        dispatch(Actions.setPage(0));
    };

    const onDeleteCheckboxChange = event => {
        dispatch(Actions.setSearchDeleted(event.target.checked ? 'Yes' : 'No'));
        dispatch(Actions.setPage(0));
    };

    const commonDataOptionChange = (e, value) => {
        dispatch(Actions.getCommonDataById(value.com_dat_id));
        dispatch(Actions.setPage(0));
    };

    return (
        <div className="flex w-full items-center">
            <Autocomplete
                openText="New common data"
                closeText="New common data"
                size="small"
                disableClearable
                className={`mx-3 ${classes.textFieldWidth}`}
                options={cmAllOptions || []}
                getOptionLabel={option => option.com_dat_nm || ''}
                popupIcon={btnList.some(btn => btn.BTN_NO === buttons.BTN_EDIT) && <Add onClick={onCreateClick} />}
                renderInput={params => <TextField {...params} label="Common data name" variant="outlined" />}
                onChange={commonDataOptionChange}
                value={cmAllOptions?.find(item => item.com_dat_id === cmByIdData.com_dat_id) || ''}
            />
            <ThemeProvider theme={mainTheme}>
                <CreateCommonDataDialog open={openCreateDialog} onClose={() => setOpenCreateDialog(false)} />
                <Paper className="flex items-center max-w-600 px-8 py-4 ml-2 rounded-8" elevation={1}>
                    <Search className="mr-8" color="action" />
                    <Input
                        fullWidth
                        disableUnderline
                        placeholder="Search row"
                        className="flex flex-1"
                        onChange={onInputChange}
                        value={searchText}
                    />
                </Paper>
            </ThemeProvider>
            <FormControlLabel
                className="ml-3"
                label="Deleted"
                onChange={onDeleteCheckboxChange}
                control={<Checkbox color="secondary" checked={searchDeleted === 'Yes'} />}
            />
        </div>
    );
};

export default CommonHeader;

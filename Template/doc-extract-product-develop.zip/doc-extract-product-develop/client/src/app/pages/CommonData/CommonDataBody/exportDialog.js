import React from 'react';
import { useSelector } from 'react-redux';
import { DialogTitle, DialogContent, DialogContentText, DialogActions, Dialog } from '@material-ui/core';

import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';

import CustomButton from 'app/components/Button';
import _ from '@lodash';

const ExportDialog = props => {
    const cmByIdData = useSelector(({ CommonData }) => CommonData.common.cmByIdData);

    const exportToSheet = exportDataParam => {
        const ws = XLSX.utils.json_to_sheet(exportDataParam);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Template');
        XLSX.writeFile(wb, `${cmByIdData.com_dat_nm}.xlsx`);
    };

    const exportToCsv = exportDataParam => {
        const csvExport = Papa.unparse(exportDataParam, { header: true });
        const s2ab = s => {
            const buf = new ArrayBuffer(s.length);
            const view = new Uint8Array(buf);
            for (let i = 0; i !== s.length; ++i) view[i] = s.charCodeAt(i) & 0xff;
            return buf;
        };
        FileSaver.saveAs(
            new Blob([s2ab(csvExport)], { type: 'application/octet-stream' }),
            `${cmByIdData.com_dat_nm}.csv`,
        );
    };

    const exportFile = async exportType => {
        const headerLabels = cmByIdData.com_dat_val?.header.slice(0, -1);
        const exportArrayEmpty = headerLabels.reduce((obj, key) => ({ ...obj, [key]: '' }), {});
        const exportArrayFull = cmByIdData.com_dat_val?.data.flatMap(item =>
            item.deleted === 'No' ? headerLabels.reduce((obj, key) => ({ ...obj, [key]: item[key] }), {}) : [],
        );
        const exportDataBundle = exportArrayFull || exportArrayEmpty;

        if (exportType === 'csv') await exportToCsv(exportDataBundle);
        else await exportToSheet(exportDataBundle);

        props.onClose();
    };

    return (
        <Dialog open={props.open}>
            <DialogTitle>Export file type</DialogTitle>
            <DialogContent>
                <DialogContentText>
                    Please choose export file type. Push CSV to export Comma-separated values (.csv) file and XLSX to
                    export Sheet (.xlsx) file.
                </DialogContentText>
            </DialogContent>
            <DialogActions>
                <CustomButton onClick={props.onClose}>Cancel</CustomButton>
                <CustomButton onClick={() => exportFile('csv')}>csv</CustomButton>
                <CustomButton onClick={() => exportFile('xlsx')}>xlsx</CustomButton>
            </DialogActions>
        </Dialog>
    );
};

export default ExportDialog;

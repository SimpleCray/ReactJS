import React from 'react';
import PanelGroup from 'react-panelgroup';

import CommonDataTable from './commonDataTable';
import CommonDataContent from './commonDataConent';

const CommonDataBody = () => {
    return (
        <PanelGroup
            panelWidths={[
                {
                    size: (document.documentElement.clientWidth - 73) / 4,
                    minSize: 100,
                    resize: 'dynamic',
                },
                {
                    size: ((document.documentElement.clientWidth - 73) * 3) / 4,
                    minSize: 100,
                    resize: 'dynamic',
                },
            ]}
        >
            <CommonDataContent />
            <CommonDataTable />
        </PanelGroup>
    );
};

export default CommonDataBody;

import React, { useEffect, useState, useRef } from 'react';
import { withStyles } from '@material-ui/core/styles';
import { useDispatch, useSelector } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { FuseScrollbars } from '@fuse';
import _ from '@lodash';
import { Table, TableBody, TableCell, TablePagination, TableRow, TableHead } from '@material-ui/core';

import * as XLSX from 'xlsx';
import Papa from 'papaparse';

import buttons from 'app/utils/constants/buttonConstants.json';
import CustomButton from 'app/components/Button';
import { openDialog } from 'app/store/actions/fuse/dialog.actions';
import * as TableFnc from 'app/utils/tableFunctions';

import EditComlumnDialog from './editColumnDialog';
import ModifyRowDialog from './modifyRowDialog';
import ExportDialog from './exportDialog';
import ImportDialog from './importDialog';

import * as Actions from '../store/actions';

const StyledTableCell = withStyles(theme => ({
    head: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
}))(TableCell);

const CommonTable = props => {
    const dispatch = useDispatch();

    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const page = useSelector(({ CommonData }) => CommonData.common.page);
    const cmByIdData = useSelector(({ CommonData }) => CommonData.common.cmByIdData);
    const searchDeleted = useSelector(({ CommonData }) => CommonData.common.searchDeleted);
    const searchText = useSelector(({ CommonData }) => CommonData.common.searchText);

    const [rowsPerPage, setRowsPerPage] = useState(25);

    const [openEditColumnDialog, setOpenEditColumnDialog] = useState(false);

    const [selectedRow, setSelectedRow] = useState(null);
    const [tableData, setTableData] = useState([]);
    const [tableHeader, setTableHeader] = useState([]);
    const [openModifyRow, setOpenModifyRow] = useState(false);
    const [dataModifyRow, setDataModifyRow] = useState(null);
    const [openExportDialog, setOpenExportDialog] = useState(false);
    const [openImportDialog, setOpenImportDialog] = useState(false);
    const [importWaitData, setImportWaitData] = useState([]);

    const inputFile = useRef(null);

    const onDeleteClick = () => {
        return dispatch(
            openDialog(
                'Do you want delete this row. This data will be tranfer to deleted tab!',
                'Delete row',
                'Confirm',
                async () => {
                    const updateRowData = tableData.map(item => {
                        const checkMatchRow = Object.values(item).join('-') === Object.values(selectedRow).join('-');
                        return checkMatchRow ? { ...item, deleted: 'Yes' } : { ...item };
                    });
                    await dispatch(
                        Actions.updateCommonData({
                            com_dat_id: cmByIdData.com_dat_id,
                            com_dat_cd: cmByIdData.com_dat_cd,
                            com_dat_nm: cmByIdData.com_dat_nm,
                            com_dat_val: JSON.stringify({
                                ...cmByIdData.com_dat_val,
                                data: updateRowData,
                            }),
                        }),
                    );
                },
            ),
        );
    };

    const onMofidyRowClick = pipData => {
        setDataModifyRow(pipData);
        setOpenModifyRow(true);
    };

    const sheetToJSON = file => {
        const promise = new Promise((resolve, reject) => {
            const fileReader = new FileReader();
            fileReader.readAsArrayBuffer(file);

            fileReader.onload = e => {
                const bufferArray = e.target.result;
                const wb = XLSX.read(bufferArray, { type: 'buffer' });
                const wsname = wb.SheetNames[0];
                const ws = wb.Sheets[wsname];
                const xlsxData = XLSX.utils.sheet_to_json(ws);
                resolve(xlsxData);
            };

            fileReader.onerror = err => reject(err);
        });
        promise.then(async result => setImportWaitData(result || []));
    };

    const csvToJSON = async file => {
        await Papa.parse(file, {
            header: true,
            complete: async csv => setImportWaitData(csv.data || []),
        });
    };

    const onChangeFile = file => {
        if (file) {
            const extensionName = file.name.split('.').pop();
            if (extensionName === 'csv') csvToJSON(file);
            if (extensionName === 'xlsx') sheetToJSON(file);
            if (['csv', 'xlsx'].includes(extensionName)) setOpenImportDialog(true);
        }
    };

    useEffect(() => {
        if (cmByIdData && cmByIdData.com_dat_val) {
            setTableHeader(cmByIdData.com_dat_val.header);
            setTableData(cmByIdData.com_dat_val.data);
        }
    }, [cmByIdData]);

    useEffect(() => setSelectedRow(null), [searchDeleted, cmByIdData]);

    return (
        <div className="w-full flex flex-col border-2 p-1 mb-2 mt-2 mr-1">
            <FuseScrollbars className="flex-grow overflow-x-auto">
                <Table stickyHeader className="w-full" aria-labelledby="tableTitle" size="small">
                    <TableHead>
                        <TableRow>
                            {tableHeader.slice(0, -1).map(item => (
                                <StyledTableCell key={item}>{item}</StyledTableCell>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {tableData
                            .filter(item => {
                                const matchSearch =
                                    !searchText.length ||
                                    Object.values(item).some(
                                        el =>
                                            typeof el === 'string' &&
                                            el?.toLowerCase()?.includes(searchText.toLowerCase()),
                                    );
                                const matchDeleted = item.deleted === searchDeleted;
                                return matchDeleted && matchSearch;
                            })
                            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            .map((row, index) => (
                                <TableRow
                                    key={index}
                                    hover
                                    className="cursor-pointer"
                                    selected={
                                        selectedRow &&
                                        Object.values(row).join('-') === Object.values(selectedRow).join('-')
                                    }
                                    onClick={() => setSelectedRow(row)}
                                >
                                    {tableHeader.slice(0, -1).map(item => (
                                        <TableCell key={item} className="w-3/12">
                                            <div className="w-full truncate px-3">{row[item]}</div>
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))}
                    </TableBody>
                </Table>
            </FuseScrollbars>

            <div className="flex flex-row w-full justify-between">
                <div className="flex justify-start">
                    <TablePagination
                        page={page}
                        labelRowsPerPage=""
                        component="div"
                        rowsPerPageOptions={[10, 25, 50]}
                        count={tableData.length}
                        rowsPerPage={rowsPerPage}
                        onChangePage={(ev, p) => dispatch(Actions.setPage(p))}
                        onChangeRowsPerPage={ev =>
                            TableFnc.handleChangeRowsPerPage(
                                ev,
                                page,
                                tableData,
                                pageNumber => dispatch(Actions.setPage(pageNumber)),
                                setRowsPerPage,
                            )
                        }
                    />
                </div>
                <div className="flex justify-end items-center">
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_EDIT) && (
                        <CustomButton disabled={searchDeleted === 'Yes'} onClick={() => setOpenEditColumnDialog(true)}>
                            Edit column
                        </CustomButton>
                    )}
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_IMPORT) && (
                        <CustomButton disabled={searchDeleted === 'Yes'} onClick={() => inputFile.current.click()}>
                            Import
                        </CustomButton>
                    )}
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_EXPORT) && (
                        <CustomButton disabled={searchDeleted === 'Yes'} onClick={() => setOpenExportDialog(true)}>
                            Export
                        </CustomButton>
                    )}
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_NEW) && (
                        <CustomButton disabled={searchDeleted === 'Yes'} onClick={() => onMofidyRowClick(null)}>
                            New
                        </CustomButton>
                    )}
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_UPDATE) && (
                        <CustomButton disabled={!selectedRow} onClick={() => onMofidyRowClick(selectedRow)}>
                            Update
                        </CustomButton>
                    )}
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_DELETE) && (
                        <CustomButton disabled={!selectedRow || searchDeleted === 'Yes'} onClick={onDeleteClick}>
                            Delete
                        </CustomButton>
                    )}
                    <EditComlumnDialog
                        comDatId={props?.comDatId}
                        comDataGlobal={props?.cmDataGlobal}
                        open={openEditColumnDialog}
                        onClose={() => setOpenEditColumnDialog(false)}
                    />
                    <ModifyRowDialog
                        dataModifyRow={dataModifyRow}
                        open={openModifyRow}
                        onClose={() => setOpenModifyRow(false)}
                    />
                    <input
                        type="file"
                        accept=".xlsx, .csv"
                        ref={inputFile}
                        className="hidden"
                        onChange={e => onChangeFile(e.target.files[0])}
                        onClick={e => {
                            e.target.value = '';
                        }}
                    />
                    <ExportDialog open={openExportDialog} onClose={() => setOpenExportDialog(false)} />
                    <ImportDialog
                        open={openImportDialog}
                        waitData={importWaitData}
                        onClose={() => setOpenImportDialog(false)}
                    />
                </div>
            </div>
        </div>
    );
};

export default withRouter(CommonTable);

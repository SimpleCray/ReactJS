import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    DialogTitle,
    DialogContent,
    DialogContentText,
    DialogActions,
    Dialog,
    TextField,
    MenuItem,
} from '@material-ui/core';

import CustomButton from 'app/components/Button';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import _ from '@lodash';

import * as Actions from '../store/actions';

const ImportDialog = props => {
    const dispatch = useDispatch();
    const cmByIdData = useSelector(({ CommonData }) => CommonData.common.cmByIdData);

    const [openChooseKeyValue, setOpenChooseKeyValue] = useState(false);

    const onOverWriteClick = () => {
        if (props?.waitData?.length && Object.keys(props.waitData[0]).length > 1) setOpenChooseKeyValue(true);
        else
            dispatch(
                showMessage({
                    message: 'Should have two columns at least!',
                    variant: 'error',
                }),
            );
    };

    const runImportClick = async type => {
        if (props.waitData) {
            const extractHeader =
                type === 'overwrite' ? [...Object.keys(props.waitData[0]), 'deleted'] : cmByIdData.com_dat_val.header;

            const extractData = props.waitData.flatMap(item => {
                const notPlainRow = Object.values(item).some(cell => cell.length);
                if (notPlainRow) {
                    const mapData = extractHeader.reduce((obj, key) => ({ ...obj, [key]: item[key] || '' }), {});
                    return Object.values(mapData).some(cell => cell.length) ? [{ ...mapData, deleted: 'No' }] : [];
                }
                return [];
            });

            await dispatch(
                Actions.updateCommonData({
                    com_dat_id: cmByIdData.com_dat_id,
                    com_dat_cd: cmByIdData.com_dat_cd,
                    com_dat_nm: cmByIdData.com_dat_nm,
                    com_dat_val: JSON.stringify({
                        ...cmByIdData.com_dat_val,
                        header: extractHeader,
                        data: extractData,
                        config:
                            type === 'overwrite'
                                ? {
                                      key: document.getElementById('import-key').innerText,
                                      value: document.getElementById('import-value').innerText,
                                  }
                                : cmByIdData.com_dat_val.config,
                    }),
                }),
            );
            setOpenChooseKeyValue(false);
            props.onClose();
        }
    };

    const ChooseKeyValueImportDialog = props => {
        const columnNameHeader = props?.waitData?.length ? Object.keys(props.waitData[0]) : [];

        const onContinueClick = () => {
            const keyChoose = document.getElementById('import-key').innerText.trim();
            const valueChoose = document.getElementById('import-value').innerText.trim();

            const isEmptyValid = keyChoose.length > 1 && valueChoose.length > 1;
            const isSameValid = keyChoose !== valueChoose;
            if (isEmptyValid && isSameValid) runImportClick('overwrite');
            else
                dispatch(
                    showMessage({
                        message: !isEmptyValid ? 'Key and value should not empty!' : 'Key and value should not same!!',
                        variant: 'error',
                    }),
                );
        };

        return (
            <Dialog open={props.open} maxWidth="xs" fullWidth>
                <DialogTitle>Please choose key and value</DialogTitle>
                <DialogContent>
                    <TextField id="import-key" select fullWidth variant="outlined" size="small" label="Key">
                        {columnNameHeader.map(item => (
                            <MenuItem key={item} value={item}>
                                {item}
                            </MenuItem>
                        ))}
                    </TextField>
                    <TextField
                        id="import-value"
                        className="mt-10"
                        select
                        fullWidth
                        variant="outlined"
                        size="small"
                        label="Value"
                    >
                        {columnNameHeader.map(item => (
                            <MenuItem key={item} value={item}>
                                {item}
                            </MenuItem>
                        ))}
                    </TextField>
                </DialogContent>
                <DialogActions>
                    <CustomButton onClick={props.onClose}>Cancel</CustomButton>
                    <CustomButton onClick={onContinueClick}>Continue</CustomButton>
                </DialogActions>
            </Dialog>
        );
    };

    return (
        <React.Fragment>
            <Dialog open={props.open}>
                <DialogTitle>Import option</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <strong>Mapping</strong>: Matching with exist column in current table.
                    </DialogContentText>
                    <DialogContentText>
                        <strong>Overwrite</strong>: Replace table by importing data and define properties.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <CustomButton onClick={props.onClose}>Cancel</CustomButton>
                    <CustomButton onClick={() => runImportClick('mapping')}>Mapping</CustomButton>
                    <CustomButton onClick={onOverWriteClick}>Overwrite</CustomButton>
                </DialogActions>
            </Dialog>
            <ChooseKeyValueImportDialog
                {...props}
                open={openChooseKeyValue}
                onClose={() => setOpenChooseKeyValue(false)}
            />
        </React.Fragment>
    );
};

export default ImportDialog;

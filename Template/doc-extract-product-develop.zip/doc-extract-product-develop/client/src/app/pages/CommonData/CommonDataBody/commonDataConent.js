import React, { useState, useEffect } from 'react';
import { withStyles } from '@material-ui/core/styles';
import { useDispatch, useSelector } from 'react-redux';
import {
    Table,
    TableBody,
    TableCell,
    TableRow,
    TableHead,
    TextField,
    Checkbox,
    FormControlLabel,
} from '@material-ui/core';
import { Autocomplete } from '@material-ui/lab';
import { CheckBoxOutlineBlank, CheckBox } from '@material-ui/icons';
import { FuseScrollbars } from '@fuse';

import CustomButton from 'app/components/Button';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import _ from 'lodash';

import * as Functions from '../commonDataFunction';
import * as Actions from '../store/actions';

const StyledTableCell = withStyles(theme => ({
    head: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
}))(TableCell);

const CommonDataContent = props => {
    const dispatch = useDispatch();

    const cmByIdData = useSelector(({ CommonData }) => CommonData.common.cmByIdData);
    const companyList = useSelector(({ CommonData }) => CommonData.common.companyList);

    const [roleValue, setRoleValue] = useState([]);
    const [cmNameValue, setCmNameValue] = useState('');
    const [cmActiveValue, setCmActiveValue] = useState('N');

    const renderCompanyOptions = () => {
        const limitArrtibutes = companyList.map(item => ({ coCd: item.coCd, coNm: item.coNm })) || [];
        return [{ coCd: 'ALL', coNm: 'All' }, { coCd: 'ADMIN', coNm: 'Admin' }, ...limitArrtibutes];
    };

    const onCheckRoleChange = (event, option) => {
        if (event.target.checked) setRoleValue(option.coCd === 'ALL' ? [option] : [...roleValue, option]);
        else setRoleValue(roleValue.filter(item => item.coCd !== option.coCd));
    };

    const onSaveClick = async () => {
        const isSaveValid = cmNameValue.length && roleValue.length;
        if (isSaveValid) {
            await dispatch(
                Actions.updateCommonData({
                    com_dat_id: cmByIdData.com_dat_id,
                    com_dat_cd: cmByIdData.com_dat_cd,
                    com_dat_nm: cmNameValue,
                    com_dat_val: JSON.stringify({
                        ...cmByIdData.com_dat_val,
                        role: roleValue,
                    }),
                    delt_flg: cmActiveValue,
                }),
            );
            await dispatch(Actions.getCommonNameOptions());
        } else {
            dispatch(
                showMessage({
                    message: !cmNameValue.length
                        ? 'Column name should not empty!'
                        : 'Please add role for new common data!',
                    variant: 'error',
                }),
            );
        }
    };

    useEffect(() => {
        if (cmByIdData?.com_dat_val) {
            setCmNameValue(cmByIdData.com_dat_nm);
            setRoleValue(cmByIdData.com_dat_val?.role || []);
            setCmActiveValue(cmByIdData.delt_flg);
        }
    }, [cmByIdData]);

    return (
        <div className="w-full flex flex-col border-2 p-1 mb-2 mt-2 mr-1">
            <FuseScrollbars className="flex-grow overflow-x-auto">
                <Table stickyHeader className="w-full" size="small">
                    <TableHead>
                        <TableRow>
                            <StyledTableCell>Common data attributes</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        <div className="px-5">
                            <TextField
                                {...Functions.textFieldProps}
                                disabled
                                className="mt-10"
                                label="Common data code"
                                value={cmByIdData?.com_dat_cd || ''}
                            />
                            <TextField
                                {...Functions.textFieldProps}
                                className="mt-10"
                                label="Common data name"
                                value={cmNameValue || ''}
                                onChange={e => setCmNameValue(e.target.value)}
                            />

                            <Autocomplete
                                multiple
                                disableListWrap
                                limitTags={2}
                                className="mt-10"
                                size="small"
                                options={renderCompanyOptions()}
                                disableCloseOnSelect
                                getOptionLabel={option => option.coNm}
                                getOptionDisabled={option =>
                                    option.coCd !== roleValue[0]?.coCd && roleValue[0]?.coCd === 'ALL'
                                }
                                renderOption={option => (
                                    <React.Fragment>
                                        <Checkbox
                                            icon={<CheckBoxOutlineBlank fontSize="small" />}
                                            checkedIcon={<CheckBox fontSize="small" />}
                                            style={{ marginRight: 8 }}
                                            checked={roleValue.some(item => item.coCd === option.coCd)}
                                            onChange={e => onCheckRoleChange(e, option)}
                                        />
                                        {option.coNm}
                                    </React.Fragment>
                                )}
                                renderInput={params => (
                                    <TextField {...params} {...Functions.textFieldProps} label="Use role" />
                                )}
                                value={roleValue}
                                onChange={(event, value) => value.length < roleValue.length && setRoleValue(value)}
                            />

                            <FormControlLabel
                                className="mt-5"
                                label="Active"
                                onChange={e => setCmActiveValue(e.target.checked ? 'N' : 'Y')}
                                control={<Checkbox color="secondary" checked={cmActiveValue === 'N'} />}
                            />
                        </div>
                    </TableBody>
                </Table>
            </FuseScrollbars>

            <div className="flex flex-row w-full p-3 justify-end">
                <CustomButton onClick={onSaveClick}>Save</CustomButton>
            </div>
        </div>
    );
};

export default CommonDataContent;

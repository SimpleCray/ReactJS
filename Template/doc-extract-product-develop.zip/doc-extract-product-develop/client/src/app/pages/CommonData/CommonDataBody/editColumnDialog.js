import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    Input,
    IconButton,
    Dialog,
    DialogActions,
    DialogContent,
    InputAdornment,
    Toolbar,
    AppBar,
    Typography,
} from '@material-ui/core';
import {
    Close,
    AddBoxOutlined,
    EditOutlined,
    DeleteOutlined,
    CheckOutlined,
    ClearOutlined,
    DragIndicator,
} from '@material-ui/icons';
import _ from '@lodash';
import { sortableContainer, sortableElement, sortableHandle } from 'react-sortable-hoc';
import CustomButton from 'app/components/Button';
import arrayMove from 'array-move';
import { showMessage } from 'app/store/actions/fuse/message.actions';

import * as Actions from '../store/actions';
import * as Functions from '../commonDataFunction';

const SortableContainer = sortableContainer(({ children }) => <ul className="p-0">{children}</ul>);

const EditComlumnDialog = props => {
    const dispatch = useDispatch();
    const classes = Functions.useStyles();

    const cmByIdData = useSelector(({ CommonData }) => CommonData.common.cmByIdData);

    const [columnList, setColumnList] = useState(['code']);
    const [dataList, setDataList] = useState([]);
    const [columnRegisterList, setColumnRegisterList] = useState([]);
    const [selectedItem, setSelectedItem] = useState(null);

    const onAddClick = () => {
        setSelectedItem(columnList.length - 1);
        setColumnRegisterList(columnList);
        setColumnList(prev => [...prev.slice(0, -1), '', ...prev.slice(columnList.length - 1)]);
    };

    const onRemoveClick = index => {
        const updateLabelList = columnList.filter((item, idx) => idx !== index);
        const updateColumnData = dataList.map(item =>
            updateLabelList.reduce((obj, key) => ({ ...obj, [key]: item[key] }), {}),
        );
        setDataList(updateColumnData);
        setColumnList(updateLabelList);
    };

    const onCancelClick = () => {
        if (columnRegisterList.length) setColumnList(columnRegisterList);
        setSelectedItem(null);
    };

    const onCheckClick = index => {
        const selectedData = document.getElementById(`cm-edit-column-${index}`).value.trim();

        const isValidInput =
            selectedData.length && !columnList.some((item, id) => id !== index && item === selectedData);

        if (isValidInput) {
            const updateLabelList = [...columnList.slice(0, index), selectedData, ...columnList.slice(index + 1)];

            const updateColumnData =
                columnRegisterList.length + 1 === updateLabelList.length
                    ? dataList.map(item =>
                          updateLabelList.reduce((obj, key) => ({ ...obj, [key]: item[key] || '' }), {}),
                      )
                    : dataList.map(item =>
                          _.mapKeys(item, (value, key) => (key === columnList[index] ? selectedData : key)),
                      );

            setColumnList(updateLabelList);
            setDataList(updateColumnData);
            setSelectedItem(null);
        } else
            dispatch(
                showMessage({
                    message: !selectedData.length ? 'Column name should not empty!' : 'Column name had been exsited!',
                    variant: 'error',
                }),
            );
    };

    const onSaveClick = async () => {
        await dispatch(
            Actions.updateCommonData({
                com_dat_id: cmByIdData.com_dat_id,
                com_dat_cd: cmByIdData.com_dat_cd,
                com_dat_nm: cmByIdData.com_dat_nm,
                com_dat_val: JSON.stringify({
                    ...cmByIdData.com_dat_val,
                    config: {
                        key: columnList[0],
                        value: columnList[1],
                    },
                    header: columnList,
                    data: dataList,
                }),
            }),
        );
        props.onClose();
    };

    useEffect(() => {
        if (cmByIdData?.com_dat_val) {
            setColumnList(cmByIdData.com_dat_val.header);
            setDataList(cmByIdData.com_dat_val.data);
        }
    }, [cmByIdData]);

    useEffect(() => {
        if (selectedItem === null) setColumnRegisterList([]);
    }, [selectedItem]);

    const onSortEnd = ({ oldIndex, newIndex }) => {
        if (newIndex > 1) setColumnList(arrayMove(columnList, oldIndex, newIndex));
        else
            dispatch(
                showMessage({
                    message: 'First and second columns are key and value. So always top!',
                    variant: 'warning',
                }),
            );
    };

    const DragHandle = sortableHandle(({ value }) => (
        <IconButton className={classes.dragIconProps} disabled={value < 2}>
            <DragIndicator color="action" />
        </IconButton>
    ));

    const SortableItem = sortableElement(({ value }) => {
        const itemActive = value.index === selectedItem;

        return (
            <div className="w-full flex flex-row items-center">
                <DragHandle value={value.index} />
                <div className="flex flex-row mt-5 w-full ml-5 items-center">
                    <div className="w-2/12">
                        <Typography color="textSecondary">
                            {cmByIdData?.com_dat_val?.config &&
                                (Object.keys(cmByIdData?.com_dat_val?.config)[value.index] || 'none')}
                        </Typography>
                    </div>
                    <Input
                        fullWidth
                        id={`cm-edit-column-${value.index}`}
                        autoComplete="off"
                        readOnly={!itemActive}
                        disableUnderline={!itemActive}
                        disabled={!itemActive}
                        autoFocus={itemActive}
                        defaultValue={value.label}
                        endAdornment={
                            <InputAdornment position="end">
                                {!itemActive && [
                                    <IconButton
                                        className={classes.iconProps}
                                        onClick={() => setSelectedItem(value.index)}
                                        disabled={selectedItem !== null && !itemActive}
                                    >
                                        <EditOutlined color="action" />
                                    </IconButton>,
                                    <IconButton
                                        className={classes.iconProps}
                                        disabled={value.index < 2}
                                        onClick={() => onRemoveClick(value.index)}
                                    >
                                        <DeleteOutlined color="action" />
                                    </IconButton>,
                                ]}

                                {itemActive && [
                                    <IconButton className={classes.iconProps}>
                                        <CheckOutlined color="action" onClick={() => onCheckClick(value.index)} />
                                    </IconButton>,
                                    <IconButton
                                        className={classes.iconProps}
                                        onClick={() => onCancelClick(value.index)}
                                    >
                                        <ClearOutlined color="action" />
                                    </IconButton>,
                                ]}
                            </InputAdornment>
                        }
                    />
                </div>
            </div>
        );
    });

    return (
        <React.Fragment>
            <Dialog maxWidth="xs" open={props.open} fullWidth>
                <AppBar position="static">
                    <Toolbar className="flex flex-row w-full">
                        <div className="flex w-8/12 justify-start">Edit column</div>
                        <div className="flex w-4/12 justify-end">
                            <IconButton onClick={props.onClose}>
                                <Close className={classes.whiteColor} />
                            </IconButton>
                        </div>
                    </Toolbar>
                </AppBar>

                <DialogContent className="overflow-hidden">
                    <IconButton disabled={selectedItem} onClick={onAddClick}>
                        <AddBoxOutlined color="action" />
                    </IconButton>

                    <SortableContainer useDragHandle onSortEnd={onSortEnd}>
                        {columnList
                            ?.slice(0, -1)
                            .map((value, idx) => (
                                <SortableItem key={value} index={idx} value={{ label: value, index: idx }} />
                            ))}
                    </SortableContainer>
                </DialogContent>

                <DialogActions className="justify-end pl-8 sm:pl-16 mb-16 mr-8">
                    <CustomButton disabled={selectedItem} onClick={onSaveClick}>
                        Save
                    </CustomButton>
                </DialogActions>
            </Dialog>
        </React.Fragment>
    );
};

export default EditComlumnDialog;

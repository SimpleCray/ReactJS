import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';
import {
    Paper,
    TableRow,
    TablePagination,
    TableHead,
    TableContainer,
    TableCell,
    Table,
    TableBody,
    Tooltip,
    TableSortLabel,
} from '@material-ui/core';
import { openDialog } from 'app/store/actions';
import * as BizRuleActions from 'app/pages/BizRule/store/actions/actions';
import _ from '@lodash';
import MsgNotifications from 'app/utils/msgNotifications';
import buttons from '../../../utils/constants/buttonConstants.json';
import CustomButton from '../../../components/Button';
import * as TableFnc from '../../../utils/tableFunctions';
import { FieldColumns, RuleColumns } from './BizViewConstants';

import * as Functions from './BizViewFunction';
import * as Actions from '../store/actions/actions';

const StyledTableCell = withStyles(theme => ({
    head: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
    body: {
        fontSize: 14,
    },
}))(TableCell);

export default function BizViewTable(props) {
    const dispatch = useDispatch();
    const classes = Functions.useStyles();
    const docId = window.location.href.split('/').pop();

    const docDataById = useSelector(({ extracted }) => extracted.docDataById);
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);

    const rowsPerPage = 10;
    const rows = props?.data || [];
    const columns = props?.type === 'field' ? FieldColumns : RuleColumns;

    const [page, setPage] = useState(0);
    const [rowSelected, setRowSelected] = useState(null);
    const [order, setOrder] = useState({
        direction: 'asc',
        columnId: null,
    });

    const onRowClick = row => {
        setRowSelected(row);
        if (props?.type === 'field') props.onClick(row);
    };

    const onAddClick = () => {
        window.open(`/biz-rule/new/${props?.currentField.adm_co_doc_fld_id}`);
    };

    const onEditClick = row => {
        if (props?.type === 'rule' && (row || rowSelected)) {
            window.open(`/biz-rule/edit/${rowSelected.biz_rule_id}/${props?.currentField.adm_co_doc_fld_id}`);
        }
    };

    const handleDeleteConfirm = () => {
        dispatch(
            openDialog(MsgNotifications.VIEW_RESULT.CONFIRM_DELETE_BIZ_RULE, '', 'Confirm', async () => {
                await dispatch(BizRuleActions.changeFlagBizRule(rowSelected.biz_rule_id, 'Y'));
                await dispatch(Actions.runBizRule(docId));
                return props?.unSelectRow;
            }),
        );
    };

    const createSortHandler = property => event => TableFnc.handleRequestSort(event, property, order, setOrder);

    const findColorStatus = row => {
        if (props?.type === 'rule') {
            const rowUpdDt = new Date(row.upd_dt).getTime();
            const rowCreDt = new Date(row.cre_dt).getTime();
            const docCreDt = new Date(docDataById.cre_dt).getTime();
            const hasError = row.error;
            if (hasError) return { class: classes.errorBackground, status: 'error' };
            if (rowCreDt > docCreDt) return { class: classes.createBackground, status: 'new' };
            if (rowUpdDt > docCreDt) return { class: classes.updateBackground, status: 'updated' };
        }
        return { class: classes.cursor, status: '' };
    };

    window.addEventListener(
        'message',
        e => {
            if (e.data === 'Reload data biz') {
                // Fixing bug use previous docId
                const currentDocId = window.location.href.split('/').pop();
                dispatch(Actions.runBizRule(currentDocId));
            }
            e.stopPropagation();
            e.stopImmediatePropagation();
        },
        false,
    );

    return (
        <Paper className="w-full shadow-none border-1 rounded-lg border-gray-300">
            <TableContainer className={classes.container}>
                <Table stickyHeader aria-label="sticky table" size="small">
                    <TableHead>
                        <TableRow className={classes.cursor}>
                            {columns.map(column => (
                                <StyledTableCell key={column.id} className="text-left hidden sm:table-cell ">
                                    <Tooltip title="" placement="bottom-end" enterDelay={300}>
                                        <TableSortLabel
                                            active={order.id === column.id}
                                            direction={order.direction}
                                            onClick={createSortHandler(column.id)}
                                        >
                                            {column.label}
                                        </TableSortLabel>
                                    </Tooltip>
                                </StyledTableCell>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {_.orderBy(rows, [order.columnId], [order.direction])
                            .filter(
                                item =>
                                    !props?.searchText ||
                                    item.fld_nm.toLowerCase().includes(props?.searchText.toLowerCase()),
                            )
                            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            .map(row => {
                                const rowClassname = findColorStatus(row);
                                const rowKey = props?.type === 'field' ? row.doc_fld_id : row.biz_rule_id;
                                return (
                                    <TableRow
                                        hover
                                        tabIndex={-1}
                                        key={rowKey}
                                        onClick={() => onRowClick(row)}
                                        selected={
                                            rowKey === rowSelected?.doc_fld_id || rowKey === rowSelected?.biz_rule_id
                                        }
                                        className={rowClassname.class}
                                    >
                                        {columns.map(column => {
                                            const columnKey = column.id;
                                            let value;
                                            if (columnKey === 'status') value = rowClassname.status;
                                            else if (columnKey === 'biz_rule') value = row[columnKey].length;
                                            else value = row[columnKey];
                                            const valueToSring = Array.isArray(value) ? value.join('\n') : value;
                                            return (
                                                <Tooltip
                                                    key={columnKey}
                                                    title={
                                                        valueToSring.length > 10 ? (
                                                            <span className={classes.preLine}>{valueToSring}</span>
                                                        ) : (
                                                            ''
                                                        )
                                                    }
                                                >
                                                    <TableCell align={column.align}>
                                                        {valueToSring.length > 10
                                                            ? `${valueToSring.slice(0, 10)}...`
                                                            : valueToSring}
                                                    </TableCell>
                                                </Tooltip>
                                            );
                                        })}
                                    </TableRow>
                                );
                            })}
                    </TableBody>
                </Table>
            </TableContainer>
            <div className="flex flex-row w-full">
                <div className="flex justify-start w-8/12">
                    <TablePagination
                        labelRowsPerPage={null}
                        rowsPerPageOptions={[]}
                        component="div"
                        count={rows.length}
                        rowsPerPage={rowsPerPage}
                        page={page}
                        onChangePage={(event, newPage) => setPage(newPage)}
                    />
                </div>
                {props?.type === 'rule' && (
                    <div className="flex justify-end w-5/12">
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_ADD) && (
                            <CustomButton
                                {...Functions.commonProps}
                                disabled={Object.keys(props?.currentField).length === 0}
                                // disabled={!props?.currentField}
                                onClick={onAddClick}
                            >
                                <span className="hidden sm:flex">Add</span>
                            </CustomButton>
                        )}
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_EDIT) && (
                            <CustomButton {...Functions.commonProps} disabled={!rowSelected} onClick={onEditClick}>
                                <span className="hidden sm:flex">Edit</span>
                            </CustomButton>
                        )}
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_DELETE) && (
                            <CustomButton
                                {...Functions.commonProps}
                                disabled={!rowSelected}
                                onClick={handleDeleteConfirm}
                            >
                                <span className="hidden sm:flex">Delete</span>
                            </CustomButton>
                        )}
                    </div>
                )}
            </div>
        </Paper>
    );
}

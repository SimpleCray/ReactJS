/* eslint-disable no-param-reassign */
import AppConstants from 'app/utils/appConstants';

/* eslint-disable no-cond-assign */
const getCoorList = contentOrigin => {
    const objFieldCoor = {};
    // Start to getting coor list
    const fieldListData = contentOrigin.field_list;
    if (fieldListData) {
        Object.keys(fieldListData).forEach(fieldName => {
            const fieldData = fieldListData[fieldName];
            const coorBox = fieldData.coor_box;
            const fieldCoors = [];
            coorBox.forEach(coor => {
                const obj = {};
                obj[`${fieldName}`] = coor;
                fieldCoors.push(obj);
            });
            objFieldCoor[`${fieldName}`] = fieldCoors;
        });
    }
    return objFieldCoor;
};

export const openAnnotationBox = (fieldId, contentOrigin) => {
    if (Object.keys(contentOrigin).length > 0) {
        const objFieldCoor = getCoorList(contentOrigin);
        const pdfFileInfo = {
            coors: objFieldCoor,
            size: contentOrigin.page_info,
        };
        const drawData = [];
        const pageNum = 0;
        if (fieldId in pdfFileInfo.coors) {
            createDrawDataBox(fieldId, pdfFileInfo, drawData, pageNum);
        } else return false;
        const boxAnnotationEle = document.getElementById('annotationBoxView');
        if (boxAnnotationEle) boxAnnotationEle.remove();
        const listOldAnnotationBox = document.getElementsByClassName('pdf_highlighted_box');
        while (listOldAnnotationBox[0]) {
            listOldAnnotationBox[0].remove();
        }
        if (drawData.length > 0) {
            drawData.forEach(sampleBox => {
                DrawBox(sampleBox);
            });
        }
        return true;
    }
};

export const createDrawDataBox = (fieldId, pdfFileInfo, drawData, pageNum) => {
    pdfFileInfo.coors[fieldId].forEach(coorBox => {
        const fieldCoorBox = coorBox[`${fieldId}`];
        const pageWidth = pdfFileInfo.size[`${pageNum}`].w;
        const pageHeight = pdfFileInfo.size[`${pageNum}`].h;
        if ('isAssociate' in fieldCoorBox.cfg && !fieldCoorBox.cfg.isAssociate) {
            drawData.push({
                page: fieldCoorBox.cfg.page + 1,
                x1: fieldCoorBox.x1 / pageWidth,
                y1: fieldCoorBox.y1 / pageHeight,
                x2: fieldCoorBox.x2 / pageWidth,
                y2: fieldCoorBox.y2 / pageHeight,
            });
        }
    });
};

const getFloatFromText = dataText => {
    return dataText ? parseFloat(dataText.replace(/[a-zA-Z(), ]/g, '')) : 0;
};

export const DrawBox = sampleBox => {
    const selectedPage = sampleBox.page - 1;
    const listPdfPage = document.getElementsByClassName('react-pdf__Page__canvas');
    const imagePage = document.getElementsByClassName('doc-file-image')[0];
    const listAnnotationBoxPage = document.getElementsByClassName('box-pdf-layer');
    const canvas = listPdfPage.length >= 1 && selectedPage >= 1 ? listPdfPage[selectedPage] : listPdfPage[0];
    const boxLayerEle =
        listPdfPage.length >= 1 && selectedPage >= 1 ? listAnnotationBoxPage[selectedPage] : listAnnotationBoxPage[0];
    if (canvas) {
        const pdfCanvasWidth = canvas ? getFloatFromText(canvas.style.width) : 0;
        const pdfCanvasHeight = canvas ? getFloatFromText(canvas.style.height) : 0;
        const box = {
            x1: sampleBox.x1 * pdfCanvasWidth,
            y1: sampleBox.y1 * pdfCanvasHeight,
            x2: sampleBox.x2 * pdfCanvasWidth,
            y2: sampleBox.y2 * pdfCanvasHeight,
        };
        boxLayerEle.appendChild(createDivAnnotationBox(box));
        // Focus to first annotation box
        document
            .getElementsByClassName('pdf_highlighted_box')[0]
            .scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    }
    if (imagePage) {
        // TODO: Handle size for image
        const pdfCanvasWidth = imagePage.getBoundingClientRect().width;
        const pdfCanvasHeight = imagePage.getBoundingClientRect().height;
        const box = {
            x1: sampleBox.x1 * pdfCanvasWidth,
            y1: sampleBox.y1 * pdfCanvasHeight,
            x2: sampleBox.x2 * pdfCanvasWidth,
            y2: sampleBox.y2 * pdfCanvasHeight,
        };
        boxLayerEle.appendChild(createDivAnnotationBox(box));
        // Focus to first annotation box
        document
            .getElementsByClassName('pdf_highlighted_box')[0]
            .scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    }
};

export const createDivAnnotationBox = (box, boxClass = 'pdf_highlighted_box') => {
    const left = box.x1 < box.x2 ? box.x1 : box.x2;
    const top = box.y1 < box.y2 ? box.y1 : box.y2;
    const width = Math.abs(box.x2 - box.x1);
    const height = Math.abs(box.y2 - box.y1);
    const insertDiv = document.createElement('div');
    insertDiv.setAttribute('style', `left: ${left}px; top: ${top}px; width: ${width}px; height: ${height}px;`);
    insertDiv.setAttribute('class', `${boxClass}`);
    return insertDiv;
};

export const handlePanelUpdate = numPages => {
    const viewPortPanelPDF = document.getElementsByClassName('panelWrapper')[0].clientWidth;

    for (let i = 0; i < numPages; i++) {
        if (document.getElementsByClassName('react-pdf__Page')[i]) {
            const pageEle = document.getElementsByClassName('react-pdf__Page')[i];
            const pageWidth = pageEle.width;
            const pageHeight = pageEle.height;
            const heightOfPagePdf = (pageHeight / pageWidth) * viewPortPanelPDF - pageHeight;
            document.getElementsByClassName('react-pdf__Page')[i].style.top = `${heightOfPagePdf * i}px`;
        }
    }

    for (let i = 0; i < document.querySelectorAll('textarea').length; i++) {
        document.querySelectorAll('textarea')[i].style.height = 'inherit';
        document.querySelectorAll('textarea')[i].style.height = `${
            document.querySelectorAll('textarea')[i].scrollHeight
        }px`;
    }

    if (document.getElementById('history-option')) {
        if (document.getElementsByClassName('header-right')[0].offsetHeight < 45) {
            document.getElementById('history-option').style.marginTop = 0;
        } else {
            document.getElementById('history-option').style.marginTop = `${5}px`;
        }
    }
};

export const newBox = (xTemp1, yTemp1, xTemp2, yTemp2) => ({
    x1: xTemp1 < xTemp2 ? xTemp1 : xTemp2,
    y1: yTemp1 < yTemp2 ? yTemp1 : yTemp2,
    x2: xTemp1 > xTemp2 ? xTemp1 : xTemp2,
    y2: yTemp1 > yTemp2 ? yTemp1 : yTemp2,
});

export const removeOldSelectedText = () => {
    const selectedOldText = document.getElementsByClassName('show-text-box');
    while (selectedOldText[0]) {
        selectedOldText[0].classList.remove('show-text-box');
    }
};

export const getTextInDrawnBox = (drawingBox, pageIndex) => {
    // Check the drawing box with multiple pages, pageIndex = 0 is the first page and so on
    Array.from(document.getElementsByClassName('react-pdf__Page__textContent')[pageIndex].children).forEach(span => {
        if (span.children.length > 0) {
            Array.from(span.children).forEach(subWord => {
                const corresPercent = calculateCorrespondingAreaRatio(subWord, drawingBox);
                if (corresPercent > 0.4) {
                    subWord.classList.add('show-text-box');
                }
            });
        }
    });
    let selectedText = '';
    const allSelectedTextBox = document.getElementsByClassName('show-text-box');
    const selectedRows = sortSpansIntoRows(Array.from(allSelectedTextBox).sort((a, b) => a.y1 - b.y1));

    for (let i = 0, row; (row = selectedRows[i]); i++) {
        if (row.length > 0) {
            if (i !== 0) {
                selectedText += '\n';
            }
            if (row) {
                const rowTextTrimed = row.reduce((texts, span) => `${texts + span.innerText} `, '').trim();
                selectedText += rowTextTrimed;
            }
        }
    }
    return selectedText;
};

const calculateCorrespondingAreaRatio = (staticBox, boundingBox) => {
    const iX1 = Math.max(staticBox.x1, boundingBox.x1);
    const iY1 = Math.max(staticBox.y1, boundingBox.y1);
    const iX2 = Math.min(staticBox.x2, boundingBox.x2);
    const iY2 = Math.min(staticBox.y2, boundingBox.y2);
    let result = 0;
    if (iX2 < iX1 && iY2 < iY1) {
        result = 0;
    } else {
        result = ((iX2 - iX1) * (iY2 - iY1)) / ((staticBox.x2 - staticBox.x1) * (staticBox.y2 - staticBox.y1));
    }
    return result;
};

const sortSpansIntoRows = spans => {
    const averageLineHeight = spans.reduce((sum, span) => sum + (span.y2 - span.y1), 0) / spans.length;

    const rows = [];
    let prevY1 = 0;
    spans.forEach((span, idx) => {
        const deltaY1 = Math.abs(span.y1 - prevY1);

        if (idx === 0) {
            rows.push([span]);
        } else if (deltaY1 < averageLineHeight * 0.4) {
            rows[rows.length - 1].push(span);
        } else if (deltaY1 > averageLineHeight * 2) {
            rows.push([]);
            rows.push([span]);
        } else {
            rows.push([span]);
        }
        prevY1 = span.y1;
    });

    rows.forEach(row => {
        row.sort((a, b) => a.x1 - b.x1);
    });
    return rows;
};

export const addLayerForEachWord = pageIndex => {
    // Complete add layer for multiple page, pageIndex = 0 is the first page and so on
    const sentenceSpanes = document.getElementsByClassName('react-pdf__Page__textContent')[pageIndex].children;

    Array.from(sentenceSpanes).forEach(sentenceSpan => {
        sentenceSpan.classList.add('sentence');
        const listComponent = createListWordSpan(sentenceSpan.textContent);
        sentenceSpan.innerHTML = ''; // Remove old sentence
        if (listComponent.length > 0) {
            listComponent.forEach(wordSpan => {
                sentenceSpan.appendChild(wordSpan);
            });
        }
        const wordSpanes = [...sentenceSpan.children];
        wordSpanes.forEach(wordSpan => {
            wordSpan.x1 = wordSpan.offsetLeft + sentenceSpan.offsetLeft;
            wordSpan.x2 = wordSpan.x1 + wordSpan.offsetWidth;
            // 0 is the offset of page, Page2 will be height of page 1
            wordSpan.y1 = wordSpan.offsetTop + sentenceSpan.offsetTop + 0;
            wordSpan.y2 = wordSpan.y1 + wordSpan.offsetHeight;
        });
    });
};

const createListWordSpan = str => {
    const regrexPattern = /\S+/g;
    let eachTextData;
    const listComponent = [];
    do {
        eachTextData = regrexPattern.exec(str);
        if (eachTextData) {
            const ele = document.createElement('span');
            ele.innerHTML = eachTextData;
            listComponent.push(ele);
        }
    } while (eachTextData);
    return listComponent;
};

export const a11yProps = index => ({
    id: `scrollable-auto-tab-${index}`,
    'aria-controls': `scrollable-auto-tabpanel-${index}`,
});

export const removeOldFocusTag = () => {
    const oldFocusField = document.getElementsByClassName('in-focus-for-copy')[0];
    if (oldFocusField) oldFocusField.classList.remove('in-focus-for-copy');
};

/**
 * Get image data of canvas pdfjs by index and coordinate
 * @param {*} indexCanvas
 * Other param is coordinate will capture
 */
function getPartImageDataInCanvas(indexCanvas, x1, y1 = null, x2, y2 = null, ratioZoomOfBrowser) {
    const canvasOrigin = document.getElementsByClassName('react-pdf__Page__canvas')[indexCanvas];
    const canvasContainer = document.getElementsByClassName('canvas-draw-box-area')[indexCanvas];
    if (!y1) y1 = 0;
    if (!y2) y2 = canvasOrigin.height;

    const context = canvasOrigin.getContext('2d');
    const currentZoom = Number((canvasOrigin.height / canvasContainer.height).toFixed(2));

    if (currentZoom !== ratioZoomOfBrowser) {
        // TODO: Recheck these canvas element, remove them after use. Next 10 lines create 3 canvas ele
        // Resize canvas from origin canvas
        const canvasResize = document.createElement('canvas');
        const ctxCanvasResize = canvasResize.getContext('2d');
        canvasResize.width = canvasOrigin.width;
        canvasResize.height = canvasOrigin.height;
        ctxCanvasResize.drawImage(canvasOrigin, 0, 0);
        // Resize to origin size
        resizeTo(canvasResize, Number((1 / currentZoom).toFixed(2)));
        // Resize to ratio zoom of browser
        resizeTo(canvasResize, ratioZoomOfBrowser);
        // get the resized imageData for the canvas
        const imageResizeData = ctxCanvasResize.getImageData(x1, y1, x2 - x1, y2 - y1);
        return imageResizeData;
    }

    // get the current ImageData for the canvas
    const imageData = context.getImageData(x1, y1, x2 - x1, y2 - y1);
    return imageData;
}

function getPartImageDataInImage(x1, y1, x2, y2, ratioZoomOfBrowser) {
    const imgEle = document.getElementsByClassName('doc-file-image')[0];
    const imgWidth = imgEle.getBoundingClientRect().width;
    const imgHeight = imgEle.getBoundingClientRect().height;
    imgEle.crossOrigin = 'Anonymos';
    const canvasImage = document.createElement('canvas');
    const context = canvasImage.getContext('2d');
    canvasImage.width = imgWidth;
    canvasImage.height = imgHeight;
    context.drawImage(imgEle, 0, 0);
    const imgData = context.getImageData(0, 0, imgWidth, imgHeight);
    // write the modified image data
    context.putImageData(imgData, 0, 0);
    // get the current ImageData for the canvas
    const drawImageData = context.getImageData(x1, y1, x2 - x1, y2 - y1);
    return drawImageData;
}

function resizeTo(canvas, percent) {
    const tempCanvas = document.createElement('canvas');
    const tempContext = tempCanvas.getContext('2d');
    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;
    tempCanvas.width = canvasWidth;
    tempCanvas.height = canvasHeight;
    tempContext.drawImage(canvas, 0, 0);
    canvas.width *= percent;
    canvas.height *= percent;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(tempCanvas, 0, 0, canvasWidth, canvasHeight, 0, 0, canvasWidth * percent, canvasHeight * percent);
}

/**
 * Find canvas by y coordinate
 * Func using recursive algorithm for find index canvas in list height
 * @param {*} arrayHeight
 * @param {*} value
 * @param {*} index
 * @returns canvasIndex and y coordinate will be start capture
 */
function findIndex(arrayHeight, value, index = 0) {
    if (index >= arrayHeight.length) return -1;
    let height = 0;
    for (let i = 0; i <= index; i++) {
        height += arrayHeight[i];
    }
    if (value <= height) return [index, value - (height - arrayHeight[index])];
    else return findIndex(arrayHeight, value, index + 1);
}

/**
 * Func using for get image data of canvas
 *
 * Input is coordinate of box draw
 * Output: list Image data
 */
const getCanvasImageData = (x1, y1, x2, y2, ratioZoomOfBrowser, docType) => {
    const arrayImageData = [];
    if (docType === 'pdf') {
        const canvasImage = document.getElementsByClassName('react-pdf__Page__canvas');
        if (canvasImage) {
            // These codes will find where the draw position was
            const list_height = [...canvasImage].map(item => item.clientHeight * ratioZoomOfBrowser);

            const [indexCanvasY1, y1C] = findIndex(list_height, y1);
            const [indexCanvasY2, y2C] = findIndex(list_height, y2);

            // TODO: Re-check these lines of code, getPartImageDataInCanvas create too much dummy canvas ele
            if (indexCanvasY1 === indexCanvasY2) {
                arrayImageData.push(getPartImageDataInCanvas(indexCanvasY1, x1, y1C, x2, y2C, ratioZoomOfBrowser));
            } else {
                arrayImageData.push(getPartImageDataInCanvas(indexCanvasY1, x1, y1C, x2, null, ratioZoomOfBrowser));
                for (let i = indexCanvasY1 + 1; i < indexCanvasY2; i++) {
                    arrayImageData.push(getPartImageDataInCanvas(i, x1, null, x2, null, ratioZoomOfBrowser));
                }
                arrayImageData.push(getPartImageDataInCanvas(indexCanvasY2, x1, null, x2, y2C, ratioZoomOfBrowser));
            }
        }
    } else {
        const docImg = document.getElementsByClassName('doc-file-image');
        if (docImg && docImg[0]) {
            arrayImageData.push(getPartImageDataInImage(x1, y1, x2, y2, ratioZoomOfBrowser));
        }
    }
    return arrayImageData;
};

/**
 * Func using get image data type base64 in box selected
 */
export const getBase64 = (drawnBox, ratioZoomOfBrowser, docType) => {
    // Assign temp value
    let x1Temp = drawnBox.x1;
    let x2Temp = drawnBox.x2;
    let y1Temp = drawnBox.y1;
    let y2Temp = drawnBox.y2;

    if (x1Temp > x2Temp) {
        const temp = x1Temp;
        x1Temp = x2Temp;
        x2Temp = temp;
    }
    if (y1Temp > y2Temp) {
        const temp = y1Temp;
        y1Temp = y2Temp;
        y2Temp = temp;
    }

    if (x2Temp - x1Temp === 0 || y2Temp - y1Temp === 0) return null;

    const tempCanvas = document.createElement('canvas');
    const contextTemp = tempCanvas.getContext('2d');

    tempCanvas.width = x2Temp - x1Temp;
    tempCanvas.height = y2Temp - y1Temp;

    // List Image data captured
    const listImageData = getCanvasImageData(x1Temp, y1Temp, x2Temp, y2Temp, ratioZoomOfBrowser, docType);

    let y = 0;
    // Put image to context temp
    for (const imageData of listImageData) {
        contextTemp.putImageData(imageData, 0, y);
        y += imageData.height;
    }
    return tempCanvas.toDataURL('image/png');
};

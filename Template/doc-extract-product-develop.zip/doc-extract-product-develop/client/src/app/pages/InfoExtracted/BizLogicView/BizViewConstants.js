export const FieldColumns = [
    { id: 'fld_nm', label: 'Field name', minWidth: 100 },
    { id: 'origin', label: 'Origin data', minWidth: 150 },
    { id: 'after_rule', label: 'After-biz data', minWidth: 150 },
    { id: 'biz_rule', label: 'Rules', minWidth: 30 },
];

export const RuleColumns = [
    { id: 'ord_no', label: 'Order no', width: 50 },
    { id: 'biz_rule_desc', label: 'Description', minWidth: 170 },
    { id: 'after_rule', label: 'After-biz data', minWidth: 170 },
    { id: 'status', label: 'Status', width: 50 },
];

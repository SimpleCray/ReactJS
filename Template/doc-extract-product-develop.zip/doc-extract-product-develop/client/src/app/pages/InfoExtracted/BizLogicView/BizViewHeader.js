import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { TextField } from '@material-ui/core';
import AppConstants from 'app/utils/appConstants';
import CustomButton from '../../../components/Button';

import * as Functions from './BizViewFunction';
import * as Actions from '../store/actions/actions';

export default function LocationsHeader(props) {
    const dispatch = useDispatch();
    const bizLogicRun = useSelector(({ extracted }) => extracted.bizLogicRun);
    const docInfo = useSelector(({ extracted }) => extracted.docInfo);
    const docId = window.location.href.split('/').pop();

    const onApplyClick = async () => {
        const userId = localStorage.getItem(AppConstants.BP_USER_ID);
        const typeName = AppConstants.TRANSACTION_STATUS.RE_APPLY_BIZ;
        const data = {
            transTypeId: docId,
            typeName,
            userId,
            transactionContent: {
                data: bizLogicRun.docData,
                timeSpend: 0,
            },
        };
        const reApplyBiz = {
            statusCode: docInfo.sts_cd,
            issueList: bizLogicRun.issueList,
        };
        await dispatch(Actions.saveTransaction(data, reApplyBiz));
    };

    return (
        <div className="flex flex-row w-full">
            <div className="w-6/12 flex justify-start px-15">
                <TextField
                    style={Functions.headerStyle}
                    size="small"
                    variant="outlined"
                    label="Search field"
                    onChange={e => props.onSearch(e.target.value)}
                />
            </div>
            <div className="w-6/12 flex justify-end px-15">
                <CustomButton size="medium" onClick={onApplyClick}>
                    RE-APPLY RULE
                </CustomButton>
            </div>
        </div>
    );
}

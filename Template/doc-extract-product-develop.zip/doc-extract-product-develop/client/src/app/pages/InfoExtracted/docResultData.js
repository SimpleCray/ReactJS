/* eslint-disable consistent-return */
/* eslint-disable no-unused-expressions */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-nested-ternary */
/* eslint-disable react/no-array-index-key */
/* eslint-disable no-param-reassign */
/* eslint-disable no-return-assign */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Tooltip, Popover, Typography, Card, CardContent, CardActions } from '@material-ui/core';
import { Translate } from '@material-ui/icons';
import 'styles/scss/sweet-alert.scss';
import { showMessage } from 'app/store/actions/fuse';
import AppConstants from 'app/utils/appConstants';
import MsgNotifications from 'app/utils/msgNotifications';
import TableRenderer from './tableRenderer';
import * as TableFunctions from './TableFunction';
import * as DocFunctions from './DocFunction';
import * as Actions from './store/actions/actions';

let currentPositionCursor = -1;
let countBreakLine = 0;
let copyTextInTableDoc = false;
let copyTextInTableRenderer = false;

export const DocResultData = ({ tabName, scale, classes, setCurrentFieldId }) => {
    const dispatch = useDispatch();
    const [listTableName, setListTableName] = useState([]);

    const editing = useSelector(({ extracted }) => extracted.editing);
    const tableDataList = useSelector(({ extracted }) => extracted.tableData);
    const normalTextData = useSelector(({ extracted }) => extracted.normalTextData);
    const inputNormalTextData = useSelector(({ extracted }) => extracted.inputNormalTextData);
    const dataOrigin = useSelector(({ extracted }) => extracted.dataOrigin);
    const pdfDrawedText = useSelector(({ extracted }) => extracted.pdfDrawedText);
    const resSaveTrans = useSelector(({ extracted }) => extracted.resSaveTrans);
    const docGroupInfo = useSelector(({ extracted }) => extracted.docGroupInfo);
    const translateToEnglish = useSelector(({ extracted }) => extracted.translateToEnglish);
    const bizLogicRun = useSelector(({ extracted }) => extracted.bizLogicRun);
    const fieldList = useSelector(({ extracted }) => extracted.fieldList);

    const [fieldInfo, setFieldInfo] = useState({
        fieldName: '',
        fieldData: '',
    });
    const [isSelectedField, setIsSelectedField] = useState(false);

    const [anchorEl, setAnchorEl] = useState(null);
    const [listChangedField, setListChangedField] = useState([]);

    useEffect(() => {
        if (translateToEnglish && translateToEnglish[0]) {
            const getTranslateText = translateToEnglish[0].reduce((obj, current) => obj + current[0] + ' ', '');
            setFieldInfo(preState => ({ ...preState, fieldData: getTranslateText }));
        }
    }, [translateToEnglish]);

    useEffect(() => {
        setListTableName([]);
    }, [tabName]);

    useEffect(() => {
        if (!editing) {
            dispatch(Actions.setInputNormalTextData([]));
            setListChangedField([]);
        }
    }, [editing]);

    useEffect(() => {
        if (Object.keys(tableDataList).length > 0) {
            const tmpListTableName = [];
            for (const [key, value] of Object.entries(tableDataList)) {
                const obj = {};
                obj.tableName = key;
                obj.ord_no = value[0].ord_no;
                tmpListTableName.push(obj);
            }
            tmpListTableName.sort(TableFunctions.comparePropsTable);
            setListTableName(tmpListTableName);
        } else {
            setListTableName([]);
        }

        // Set cursor position to the end of pdfDrawedText for both 2 table
        const oldFocusField = document.getElementsByClassName('in-focus-for-copy')[0];
        if (oldFocusField && copyTextInTableDoc) {
            setCursor(
                currentPositionCursor >= 0 ? currentPositionCursor : getCursorIndex(oldFocusField),
                oldFocusField,
            );
            countBreakLine = 0;
            currentPositionCursor = 0;
            copyTextInTableDoc = false;
        } else if (oldFocusField && copyTextInTableRenderer) {
            setCursor(
                currentPositionCursor >= 0 ? currentPositionCursor : getCursorIndex(oldFocusField),
                oldFocusField,
            );
            countBreakLine = 0;
            currentPositionCursor = 0;
            copyTextInTableRenderer = false;
        }
    }, [tableDataList, normalTextData]);

    useEffect(() => {
        if (resSaveTrans === false) {
            dispatch(showMessage({ message: MsgNotifications.VIEW_RESULT.SAVE_TRANSACTION_FAILED, variant: 'error' }));
        }
        if (resSaveTrans === true) {
            dispatch(
                showMessage({ message: MsgNotifications.VIEW_RESULT.SAVE_TRANSACTION_SUCCESSFUL, variant: 'success' }),
            );
        }
    }, [resSaveTrans]);

    // Used to update view result when drawing box to get data from pdf
    useEffect(() => {
        if (editing) {
            if (pdfDrawedText) {
                const oldFocusField = document.getElementsByClassName('in-focus-for-copy')[0];
                if (oldFocusField) {
                    // Paste text into the current clicked position of text field
                    const currentText = oldFocusField.innerText;
                    const endSelectPos = getCursorIndex(oldFocusField) + countBreakLine;
                    currentPositionCursor = endSelectPos + pdfDrawedText.length;
                    const dataOfDrawnText = currentText
                        ? currentText.slice(0, endSelectPos) +
                          pdfDrawedText +
                          currentText.slice(endSelectPos, currentText.length)
                        : pdfDrawedText;

                    oldFocusField.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
                    const focusResultType = oldFocusField.getAttribute(AppConstants.DOC_RESULT_ATT.DATATYPE);
                    const dataPos = parseInt(oldFocusField.getAttribute(AppConstants.DOC_RESULT_ATT.DATAPOS));
                    // Update data to table or normal type
                    if (focusResultType === AppConstants.DOC_RESULT_TYPE.NORMAL) {
                        const data = [...normalTextData];
                        const newFieldData = { ...data[dataPos] };
                        newFieldData.field_data = dataOfDrawnText;
                        data[dataPos] = newFieldData;
                        dispatch(Actions.setNormalTextData(data));
                        dispatch(Actions.setInputNormalTextData(data));
                        copyTextInTableDoc = true;
                    }
                    if (focusResultType === AppConstants.DOC_RESULT_TYPE.TABLE) {
                        const tableName = oldFocusField.getAttribute(AppConstants.DOC_RESULT_ATT.TABLE_NAME);
                        const fieldId = oldFocusField.getAttribute(AppConstants.DOC_RESULT_ATT.FIELD_ID);
                        const newTableData = { ...tableDataList };
                        const listDataTable = newTableData[`${tableName}`];
                        listDataTable.forEach(fieldData => {
                            if (fieldData.fld_id === fieldId) {
                                fieldData.col_data[`${dataPos}`] = dataOfDrawnText;
                            }
                        });
                        // oldFocusField.value = oldFocusField.innerHTML;
                        dispatch(Actions.setTableData(newTableData));
                        copyTextInTableRenderer = true;
                    }
                    dispatch(Actions.updateGettingDataPdf(''));
                } else
                    dispatch(
                        showMessage({
                            message: MsgNotifications.VIEW_RESULT.REMIND_CLICK_ON_FIELD,
                            variant: 'warning',
                        }),
                    );
            }
        }
    }, [pdfDrawedText, isSelectedField]);

    // press keyboard
    useEffect(() => {
        document.addEventListener('keydown', handleKeyDown);
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [handleKeyDown]);

    const handleKeyDown = event => {
        const keyCode = event.which;
        if (keyCode === 13) {
            // key Enter
            countBreakLine++;
        }
    };

    function setCursor(pos, element) {
        const tag = element;
        const setpos = document.createRange();
        const set = window.getSelection();
        if (tag.childNodes[0]) {
            // Set start position of range
            try {
                setpos.setStart(tag.childNodes[0], pos);
            } catch (err) {
                console.log(err);
                setpos.setStartAfter(tag.childNodes[0]);
            }
            // Collapse range within its boundary points
            setpos.collapse(true);
            set.removeAllRanges();
            set.addRange(setpos);
            // Set cursor on focus
            tag.focus();
        }
    }

    const getCursorIndex = element => {
        let position = 0;
        const isSupported = typeof window.getSelection !== 'undefined';
        if (isSupported) {
            const selection = window.getSelection();
            if (selection.rangeCount !== 0) {
                const range = window.getSelection().getRangeAt(0);
                const preCaretRange = range.cloneRange();
                preCaretRange.selectNodeContents(element);
                preCaretRange.setEnd(range.endContainer, range.endOffset);
                position = preCaretRange.toString().length;
            }
        }
        return position;
    };

    const getTableColHeader = tableName => {
        const headerName = [];
        if (tableDataList[tableName]) tableDataList[tableName].forEach(col => headerName.push(col.col_name));
        return headerName;
    };

    const tableRenderer = tableName => {
        if (tableName) {
            return (
                <TableRenderer
                    key={tableName}
                    editing={editing}
                    tableTitle={tableName}
                    tableColHeader={getTableColHeader(tableName)}
                    tableDataList={tableDataList}
                    pdfDrawedText={pdfDrawedText}
                    resSaveTrans={resSaveTrans}
                    dataOrigin={dataOrigin}
                    scale={scale}
                    dispatch={dispatch}
                    setCurrentFieldId={setCurrentFieldId}
                    bizLogicRun={bizLogicRun}
                    classes={classes}
                    fieldList={fieldList}
                />
            );
        }
        return null;
    };

    const handleInput = (e, index, itemFldId) => {
        const data = inputNormalTextData.length === 0 ? [...normalTextData] : [...inputNormalTextData];
        // Change field data
        const fieldData = { ...data[index] };
        fieldData.field_data = e.currentTarget.innerText;
        data[index] = fieldData;
        !listChangedField.includes(itemFldId) && setListChangedField([...listChangedField, itemFldId]);
        // Change field style
        e.target.style.height = 'auto';
        dispatch(Actions.setInputNormalTextData(data));
    };

    const onClickFieldList = (e, index, fieldId) => {
        if (editing) {
            DocFunctions.removeOldFocusTag();
            e.currentTarget.classList.add('in-focus-for-copy');
            setIsSelectedField(true);
        }
        DocFunctions.openAnnotationBox(fieldId, dataOrigin);
        setCurrentFieldId(fieldId);
    };

    const onTranslateClick = async (e, fieldNameParam, fieldDataParam) => {
        setAnchorEl(e.target);
        setFieldInfo({
            fieldName: fieldNameParam,
            fieldData: fieldInfo.fieldData.length !== fieldDataParam.length ? 'Translating...' : fieldDataParam,
        });
        await dispatch(Actions.translateToEnglish(JSON.stringify(fieldDataParam)));
    };

    const onTranslateClose = e => setAnchorEl(null);

    const characterAccuracy = itemParam => {
        if (!itemParam) return;
        // Handle change display type table -> text
        if (Array.isArray(itemParam.field_data)) {
            let transferFieldData = '';
            const transferAccuracy = [];
            itemParam.field_data.forEach((item, index) => {
                if (Array.isArray(itemParam.accuracy) && itemParam.field_data.length === itemParam.accuracy.length) {
                    itemParam.accuracy[index].map(acc => {
                        transferAccuracy.push(acc);
                    });
                }
                transferFieldData = `${transferFieldData} ${item}`;
            });
            transferFieldData.trimStart();
            itemParam.field_data = transferFieldData;
            itemParam.accuracy = transferAccuracy;
        }
        // Not found accuracy return origin
        if (
            !itemParam.accuracy ||
            (itemParam.accuracy.length > 0 && typeof itemParam.accuracy[0] !== 'object') ||
            itemParam.accuracy.length === 0
        ) {
            return itemParam.field_data;
        }
        // Check length field data and length accuracy
        if (itemParam.field_data.replace(/\s/g, '').length !== itemParam.accuracy.length) {
            return itemParam.field_data;
        }

        // Check biz logic applied
        if (bizLogicRun && bizLogicRun.docCompare) {
            const currentField = bizLogicRun.docCompare.find(item => item.doc_fld_id === itemParam.fld_id);
            if (currentField && currentField.biz_rule.length > 0 && currentField.after_rule !== itemParam.org_content) {
                return itemParam.field_data;
            }
        }
        // Add space to accuracy set
        let displayAccuracy = [...itemParam.accuracy];
        [...itemParam.field_data].forEach((item, characterIndex) => {
            if (item === ' ')
                displayAccuracy = [
                    ...displayAccuracy.slice(0, characterIndex),
                    { text: ' ', confdt: 100 },
                    ...displayAccuracy.slice(characterIndex),
                ];
            else if (item === '\n')
                displayAccuracy = [
                    ...displayAccuracy.slice(0, characterIndex),
                    { text: '\n', confdt: 100 },
                    ...displayAccuracy.slice(characterIndex),
                ];
        });

        return displayAccuracy.map(item => (
            <span
                className={
                    item.confdt > 90 || listChangedField.includes(itemParam.fld_id) ? '' : classes.warningCharacter
                }
            >
                {item.text}
            </span>
        ));
    };

    return (
        <div id="doc-result-data">
            {docGroupInfo && <h2 className="group-name">GROUP: {docGroupInfo.doc_nm}</h2>}
            {normalTextData && (
                <table id="table-doc">
                    <tbody>
                        {normalTextData.map((item, index) => (
                            <tr key={index}>
                                <td>
                                    <span>{TableFunctions.formatTextHeaderTable(item.field_name)}</span>
                                </td>
                                {/* Name of the column data */}
                                <td className={classes.rowContainer}>
                                    <div
                                        suppressContentEditableWarning
                                        contentEditable={editing ? 'true' : 'false'}
                                        className={classes.editArea}
                                        id={`${item.fld_id}-${index}`}
                                        onInput={e => handleInput(e, index, item.fld_id)}
                                        onClick={e => onClickFieldList(e, index, item.fld_id)}
                                        datatype={AppConstants.DOC_RESULT_TYPE.NORMAL}
                                        datapos={index}
                                    >
                                        {characterAccuracy(item)}
                                    </div>

                                    <div className={classes.buttonContainer}>
                                        <Tooltip title="Translate">
                                            <Translate
                                                fontSize="small"
                                                color="action"
                                                onClick={e => onTranslateClick(e, item.field_name, item.field_data)}
                                            />
                                        </Tooltip>
                                    </div>
                                    <Popover
                                        PaperProps={{ variant: 'outlined' }}
                                        open={Boolean(anchorEl)}
                                        anchorEl={anchorEl}
                                        onClose={onTranslateClose}
                                        anchorOrigin={{
                                            vertical: 'bottom',
                                            horizontal: 'right',
                                        }}
                                        transformOrigin={{
                                            vertical: 'top',
                                            horizontal: 'right',
                                        }}
                                    >
                                        <Card>
                                            <CardContent className="pb-0">
                                                <Typography variant="body2" color="textSecondary" component="p">
                                                    <span className={classes.preLine}>
                                                        {fieldInfo.fieldData.replace(/[\"\\n]/g, '')}
                                                    </span>
                                                </Typography>
                                            </CardContent>
                                            <CardActions>
                                                <Typography variant="caption" color="textSecondary" component="p">
                                                    Powered by GOOGLE
                                                </Typography>
                                            </CardActions>
                                        </Card>
                                    </Popover>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
            {listTableName.length > 0 && listTableName.map((table, _index) => tableRenderer(table.tableName))}
        </div>
    );
};

export default DocResultData;

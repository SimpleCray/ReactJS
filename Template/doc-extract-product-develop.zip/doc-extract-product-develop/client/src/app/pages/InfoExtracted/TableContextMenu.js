import React from 'react';
import { Menu, MenuItem } from '@material-ui/core';
import 'styles/scss/custom-table.scss';
import AppConstants from 'app/utils/appConstants';

const ContextMenu = ({ state, ...props }) => {
    const { showContextMenu, mouseY, mouseX, isCopied } = state;

    return (
        <Menu
            keepMounted
            className="react-contextmenu"
            open={showContextMenu === true}
            anchorReference="anchorPosition"
            onClose={props.handleCloseContextMenu}
            anchorPosition={showContextMenu ? { top: mouseY, left: mouseX } : undefined}
        >
            <MenuItem className="menu-item" onClick={() => props.insertRow(AppConstants.INSERT_TYPE.ABOVE)}>
                Insert row above
            </MenuItem>
            <MenuItem className="menu-item" onClick={() => props.insertRow(AppConstants.INSERT_TYPE.BELOW)}>
                Insert row below
            </MenuItem>
            <MenuItem className="menu-item" onClick={() => props.duplicateRow()}>
                Duplicate
            </MenuItem>
            <MenuItem className="menu-item" onClick={() => props.copyRow()}>
                Copy
            </MenuItem>
            <MenuItem
                className="menu-item"
                onClick={() => props.paste(AppConstants.INSERT_TYPE.ABOVE)}
                disabled={!isCopied}
            >
                Paste Above
            </MenuItem>
            <MenuItem
                className="menu-item"
                onClick={() => props.paste(AppConstants.INSERT_TYPE.BELOW)}
                disabled={!isCopied}
            >
                Paste Below
            </MenuItem>
            <MenuItem className="menu-item" onClick={() => props.handleDelete()}>
                Delete this row
            </MenuItem>
        </Menu>
    );
};

export default ContextMenu;

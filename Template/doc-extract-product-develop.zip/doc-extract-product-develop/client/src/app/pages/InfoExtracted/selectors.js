import { createSelector } from 'reselect';
import { initialState } from './store/reducers/reducer';

const selectInfoExtracted = state => state.extracted || initialState;

const makeTableData = () =>
    createSelector(
        selectInfoExtracted,
        selectInfoExtracted => selectInfoExtracted.tableData,
    );

const makeNormalTextData = () =>
    createSelector(
        selectInfoExtracted,
        selectInfoExtracted => selectInfoExtracted.normalTextData,
    );

export { makeTableData, makeNormalTextData };

/* eslint-disable react/button-has-type */
import React, { useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Document, Page, pdfjs } from 'react-pdf';
import FilterCenterFocusIcon from '@material-ui/icons/FilterCenterFocus';
import ZoomInIcon from '@material-ui/icons/ZoomIn';
import ZoomOutIcon from '@material-ui/icons/ZoomOut';
import AspectRatioIcon from '@material-ui/icons/AspectRatio';
import { showMessage } from 'app/store/actions/fuse';
import * as Actions from './store/actions/actions';
import * as DocFunctions from './DocFunction';
import {
    handlePanelUpdate,
    addLayerForEachWord,
    newBox,
    createDivAnnotationBox,
    removeOldSelectedText,
    getTextInDrawnBox,
} from './DocFunction';
import 'styles/scss/info-extracted.scss';
import 'styles/scss/commons.scss';
import * as CommonActions from 'app/store/actions';
import AppConstants from 'app/utils/appConstants';
import { getTypeDocFile } from 'app/utils/utils';
import MsgNotifications from 'app/utils/msgNotifications';

let isMouseDown = false;
let isMouseMove = false;

// These variables will hold the star and end mouse position
let startX = 0;
let startY = 0;
let endX = 0;
let endY = 0;

let currentPage = -1;
let beforeZoom = {};
let scrollTopValue = 0;
let rateAfterScale = 1;
let ratioZoomOfBrowser = Number(window.devicePixelRatio.toFixed(2));

export const DocFileRenderer = ({ docLink, currentFieldId, pdfNumPage }) => {
    const dispatch = useDispatch();
    const scaleValue = useSelector(({ extracted }) => extracted.scale);
    const dataOrigin = useSelector(({ extracted }) => extracted.dataOrigin);
    const editing = useSelector(({ extracted }) => extracted.editing);
    const drawStatus = useSelector(({ extracted }) => extracted.drawStatus);
    const fieldList = useSelector(({ extracted }) => extracted.fieldList);
    const docType = getTypeDocFile(docLink);

    const [hiddenResetZoom, setHiddenResetZoom] = useState(true);

    const ref = useRef(null);
    const [pageSizes, setPageSizes] = useState([]);

    const onDocumentLoadSuccess = pdfDocumentProxy => {
        dispatch(Actions.updatePdfDocNumPage(pdfDocumentProxy.numPages));
    };

    // Event to get ratio zoom value when user zooms in/out by browser
    window.addEventListener(
        'resize',
        () => {
            ratioZoomOfBrowser = Number(window.devicePixelRatio.toFixed(2));
        },
        true,
    );

    // Update cursor base on drawStatus
    useEffect(() => {
        if (ref && ref.current) ref.current.style.cursor = !drawStatus ? 'grab' : 'crosshair';
        if (!drawStatus) {
            const drawnBox = document.getElementsByClassName('drawing-box');
            if (drawnBox[0]) drawnBox[0].remove();
        }
    }, [drawStatus]);

    // When user change scale value, get field annotation box and update position
    const handlePageInfoAfterZoom = e => {
        const propositionWidth = pageSizes[currentPage] ? parseFloat(e.width / pageSizes[currentPage].vectorWidth) : 1;
        const propositionHeight = pageSizes[currentPage]
            ? parseFloat(e.height / pageSizes[currentPage].vectorHeight)
            : 1;
        rateAfterScale = propositionHeight !== 1 ? propositionHeight : rateAfterScale;
        if (Object.keys(beforeZoom).length > 0) {
            beforeZoom.x *= propositionWidth;
            beforeZoom.y *= propositionHeight;
            endX *= propositionWidth;
            endY *= propositionHeight;

            const drawnBox = document.getElementsByClassName('drawing-box');
            if (drawnBox[0]) {
                const sitePdf = document.getElementsByClassName('format-pdf')[currentPage + 1];
                const styleOfSitePdf = sitePdf.currentStyle || window.getComputedStyle(sitePdf);
                drawnBox[0].style.top = `${beforeZoom.y +
                    Math.floor(parseFloat(drawnBox[0].style.top) / pageSizes[currentPage].vectorHeight) *
                        (e.height + parseFloat(styleOfSitePdf.marginTop))}px`;
                drawnBox[0].style.left = `${beforeZoom.x}px`;
                drawnBox[0].style.width = `${endX - beforeZoom.x}px`;
                drawnBox[0].style.height = `${endY - beforeZoom.y}px`;
            }
        }

        const allPages = document.getElementsByClassName('canvas-draw-box-area');
        const updatePageSize = [];
        for (let i = 0; i < allPages.length; i++) {
            updatePageSize.push({
                vectorWidth: Math.floor(e.width),
                vectorHeight: Math.floor(e.height),
            });
        }

        setPageSizes(updatePageSize);

        if (currentFieldId) {
            const firstTimeDraw = DocFunctions.openAnnotationBox(currentFieldId, dataOrigin);
            if (!firstTimeDraw) {
                const fieldIdRenderBox = fieldList[currentFieldId]?.fld_grp_id || currentFieldId;
                DocFunctions.openAnnotationBox(fieldIdRenderBox, dataOrigin);
            }
        }
    };

    /** *********** HANDLING ZOOMING PDF PAGE ************ */
    const fixedOneDigit = param => Math.round(param * 10) / 10;

    const handleZoomIn = () => {
        if (scaleValue < AppConstants.SCALE_MAX) {
            const newScale = fixedOneDigit(scaleValue + AppConstants.SCALE_STEP);
            dispatch(Actions.onZoom(newScale));
        }
    };

    const handleZoomOut = () => {
        if (scaleValue > AppConstants.SCALE_MIN) {
            const newScale = fixedOneDigit(scaleValue - AppConstants.SCALE_STEP);
            dispatch(Actions.onZoom(newScale));
        }
    };

    const handleResetZoom = () => {
        dispatch(Actions.onZoom(AppConstants.SCALE_DEFAULT));
    };

    useEffect(() => {
        if (scaleValue !== AppConstants.SCALE_DEFAULT) {
            setHiddenResetZoom(false);
        } else {
            setHiddenResetZoom(true);
        }
    }, [scaleValue]);

    const onScrollDocument = e => {
        scrollTopValue = e.target.scrollTop > 0 ? e.target.scrollTop : scrollTopValue;
    };

    /** *********** HANDLING GET DATA TEXT FROM PDF ************ */
    const removeTextLayerOffset = pagePdfProxy => {
        document.querySelectorAll('.react-pdf__Page__textContent').forEach(layer => {
            const { style } = layer;
            style.top = '2px';
            style.left = '0px';
            style.transform = '';
            // style.display = 'none';
        });
        handlePanelUpdate(pdfNumPage);
    };

    // Keep current position of page after zoom
    useEffect(() => {
        if (ref.current && pageSizes.length > 0) {
            ref.current.scroll({
                top: scrollTopValue * rateAfterScale,
                behavior: 'smooth',
            });
        }
    }, [pageSizes]);

    /** *********** HANDLING CANVAS DRAW BOX ************ */

    const onMouseEnter = pageIndex => {
        currentPage = pageIndex;
    };

    const handleMouseDown = e => {
        e.preventDefault();
        e.stopPropagation();

        const allPages = document.getElementsByClassName('canvas-draw-box-area');
        for (let i = 0; i < allPages.length; i++) {
            if (i !== currentPage) {
                const ctxTemp = allPages[i]?.getContext('2d');
                ctxTemp.clearRect(0, 0, allPages[i].width, allPages[i].height);
            }
        }

        startX = e.clientX - allPages[currentPage].getBoundingClientRect()?.left;
        startY = e.clientY - allPages[currentPage].getBoundingClientRect()?.top;

        beforeZoom = { x: startX, y: startY };

        if (drawStatus) isMouseDown = true;
        isMouseMove = false;
    };

    const handleMouseUp = e => {
        e.preventDefault();
        e.stopPropagation();

        isMouseDown = false;
        if (drawStatus && isMouseMove) {
            const allPages = document.getElementsByClassName('canvas-draw-box-area');
            const boxDrawData = document.getElementById('draw-layer');
            const drawnBox = document.getElementsByClassName('drawing-box');
            if (drawnBox[0]) drawnBox[0].remove();
            // Set cooridinate to draw box
            let docArea = null;
            if (docType === 'pdf') {
                docArea = document.getElementsByClassName('format-pdf')[currentPage + 1];
            } else {
                docArea = document.getElementsByClassName('image-doc-area')[0];
            }
            if (!docArea) return null;
            const styleOfDocument = docArea.currentStyle || window.getComputedStyle(docArea);

            const drawingBox = newBox(
                startX,
                currentPage === 0
                    ? startY
                    : startY + (allPages[currentPage].height + parseFloat(styleOfDocument.marginTop)) * currentPage,
                endX,
                currentPage === 0
                    ? endY
                    : endY + (allPages[currentPage].height + parseFloat(styleOfDocument.marginTop)) * currentPage,
            );
            boxDrawData.append(createDivAnnotationBox(drawingBox, 'drawing-box'));
            removeOldSelectedText();
            const currentContext = allPages[currentPage]?.getContext('2d');
            currentContext.clearRect(0, 0, allPages[currentPage].width, allPages[currentPage].height);
            // Set cooridinate to get data
            const dataBox = newBox(startX, startY, endX, endY);
            let selectedText = '';
            if (docType === 'img') {
                selectedText = '';
            } else {
                selectedText = getTextInDrawnBox(dataBox, currentPage);
            }
            // Update textData, tableData
            if (selectedText) dispatch(Actions.updateGettingDataPdf(selectedText));
            else {
                // Use OCR API to get data of drawn box
                drawingBox.y1 =
                    currentPage === 0
                        ? drawingBox.y1 * ratioZoomOfBrowser
                        : (drawingBox.y1 - parseFloat(styleOfDocument.marginTop) * currentPage) * ratioZoomOfBrowser;
                drawingBox.y2 =
                    currentPage === 0
                        ? drawingBox.y2 * ratioZoomOfBrowser
                        : (drawingBox.y2 - parseFloat(styleOfDocument.marginTop) * currentPage) * ratioZoomOfBrowser;
                drawingBox.x1 *= ratioZoomOfBrowser;
                drawingBox.x2 *= ratioZoomOfBrowser;

                const imageData = DocFunctions.getBase64(drawingBox, ratioZoomOfBrowser, docType);
                if (imageData) dispatch(Actions.getTextOCR(imageData, docLink));
                else
                    dispatch(
                        showMessage({
                            message: MsgNotifications.VIEW_RESULT.GET_TEXT_FROM_DRAW_DOC_FAILED,
                            variant: 'warning',
                        }),
                    );
            }
        }
    };

    const handleMouseOut = e => {
        e.preventDefault();
        e.stopPropagation();

        isMouseDown = false;
    };

    const handleMouseMove = e => {
        e.preventDefault();
        e.stopPropagation();
        if (!isMouseDown) return;
        isMouseMove = true;

        const allPages = document.getElementsByClassName('canvas-draw-box-area');
        for (let i = 0; i < allPages.length; i++) {
            if (i !== currentPage) {
                const ctxTemp = allPages[i]?.getContext('2d');
                ctxTemp.clearRect(0, 0, allPages[i].width, allPages[i].height);
            }
        }
        // get the current mouse position
        endX = e.clientX - allPages[currentPage].getBoundingClientRect()?.left;
        endY = e.clientY - allPages[currentPage].getBoundingClientRect()?.top;
        const width = endX - startX;
        const height = endY - startY;

        const currentContext = allPages[currentPage]?.getContext('2d');

        if (currentContext) {
            currentContext.strokeStyle = 'blue';
            currentContext.lineWidth = '3';
            currentContext.clearRect(0, 0, allPages[currentPage].width, allPages[currentPage].height);
            currentContext.strokeRect(startX, startY, width, height);
        }
    };

    const handleDrawBox = () => {
        if (editing) {
            const documentElement = document.getElementsByClassName('react-pdf__Page__textContent');
            if (!drawStatus && documentElement) {
                const allPageSizes = [...documentElement].map(item => ({
                    vectorWidth: Math.floor(item.clientWidth),
                    vectorHeight: Math.floor(item.clientHeight),
                }));
                setPageSizes(allPageSizes);
            } else setPageSizes([]);

            dispatch(Actions.updateDrawStatus(!drawStatus));
            // Remove the old drawn box
            const drawnBox = document.getElementsByClassName('drawing-box');
            if (drawnBox[0]) drawnBox[0].remove();
        } else
            dispatch(
                showMessage({
                    message: MsgNotifications.VIEW_RESULT.REMIND_PRESS_EDIT_BUTTON,
                    variant: 'warning',
                }),
            );
    };

    const showWarningPDF = () => {
        dispatch(
            CommonActions.showMessage({
                message: MsgNotifications.VIEW_RESULT.LOAD_PDF_DOC_FAILED,
                autoHideDuration: 1000,
                variant: 'warning',
            }),
        );
    };

    const addCanvasToImageDoc = () => {
        const image = document.getElementsByClassName('doc-file-image')[0];
        if (image) {
            const imgWidth = image.getBoundingClientRect().width;
            const imgHeight = image.getBoundingClientRect().height;
            return (
                <canvas
                    className="canvas-draw-box-area"
                    width={imgWidth}
                    height={imgHeight}
                    onMouseEnter={() => onMouseEnter(0)}
                    onMouseOut={handleMouseOut}
                    onMouseUp={handleMouseUp}
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                />
            );
        }
        return null;
    };

    return (
        <div className="wrapper zoom-tool-view" ref={ref} onScroll={onScrollDocument}>
            <div className="pdf-view-extract-button">
                <button title="Draw Box" className="draw-box-class" onClick={() => handleDrawBox()}>
                    <FilterCenterFocusIcon className="iconDock" />
                </button>
                <div>
                    <button title="Zoom in hidden" onClick={handleZoomIn}>
                        <ZoomInIcon className="iconDock" />
                    </button>
                    <button title="Zoom out" className="zoom-out-icon" onClick={handleZoomOut}>
                        <ZoomOutIcon className="iconDock" />
                    </button>
                    <button
                        title="Reset size"
                        className="zoom-visible"
                        onClick={handleResetZoom}
                        hidden={hiddenResetZoom}
                    >
                        <AspectRatioIcon className="iconDock" />
                    </button>
                </div>
            </div>
            {docLink && (
                <div className="root-file-document">
                    {docType === 'img' ? (
                        <div style={{ position: 'relative' }} className="image-doc-area">
                            <img
                                src={docLink}
                                className="doc-file-image"
                                alt="Could not open document"
                                style={{ transform: `scale(${scaleValue - 0.2})`, transformOrigin: '0 0' }}
                            />
                            <div id="draw-layer" />
                            {addCanvasToImageDoc()}
                            <div className="box-pdf-layer" />
                        </div>
                    ) : (
                        <Document
                            file={docLink}
                            onLoadSuccess={onDocumentLoadSuccess}
                            onLoadError={showWarningPDF}
                            className="format-pdf"
                            loading="loadingPDF..."
                            noData="No PDF file specified."
                        >
                            {[...Array(pdfNumPage).keys()].map(pageIndex => [
                                <Page
                                    key={`page_${pageIndex + 1}`}
                                    pageNumber={pageIndex + 1}
                                    onLoadSuccess={removeTextLayerOffset}
                                    onGetTextSuccess={() => addLayerForEachWord(pageIndex)}
                                    onRenderSuccess={handlePageInfoAfterZoom}
                                    // renderTextLayer={false}
                                    scale={scaleValue}
                                    className="format-pdf"
                                    renderAnnotationLayer={false}
                                >
                                    <div id="draw-layer" />
                                    <div className="box-pdf-layer" />
                                    <canvas
                                        className="canvas-draw-box-area"
                                        id={`canvas${pageIndex}`}
                                        width={pageSizes[pageIndex] ? pageSizes[pageIndex].vectorWidth : 0}
                                        height={pageSizes[pageIndex] ? pageSizes[pageIndex].vectorHeight : 0}
                                        onMouseEnter={() => onMouseEnter(pageIndex)}
                                        onMouseOut={handleMouseOut}
                                        onMouseUp={handleMouseUp}
                                        onMouseDown={handleMouseDown}
                                        onMouseMove={handleMouseMove}
                                    />
                                </Page>,
                            ])}
                        </Document>
                    )}
                </div>
            )}
        </div>
    );
};

export default DocFileRenderer;

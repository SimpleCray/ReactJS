/* eslint-disable no-param-reassign */
/* eslint-disable no-nested-ternary */
/* eslint-disable no-case-declarations */
/* eslint-disable no-restricted-syntax */
/* eslint-disable default-case */
/* eslint-disable default-case actionTypes. */
import produce from 'immer';
import AppConstants from 'app/utils/appConstants';
import * as actionTypes from '../constants';
import { comparePropsTable } from '../../TableFunction';
import _ from '@lodash';

export const initialState = {
    loading: false,
    editing: false,
    docLink: '',
    fieldsHighlight: [],
    viewResultDone: false,
    companyCode: '',
    docCode: '',
    locationCode: '',
    templateType: '',
    templateId: '',
    scale: AppConstants.SCALE_DEFAULT,
    normalTextData: [],
    inputNormalTextData: [],
    tableData: {},
    docInfo: null,
    error: false,
    isDocGroup: false,
    resSaveTrans: null,
    transactionHistory: [],
    docGroupInfo: null,
    pdfDrawedText: '', // This is used to save current text which got from drawed box PDF
    dataOrigin: {}, // This is used to get extracted data raw -> show annotation box
    bizLogicRun: {}, // This is used to show biz rule result after new biz logic applied
    docDataById: {}, // Document in Dex_Doc by id
    translateToEnglish: {},
    allFieldRenderData: {},
    docOrgCtntUpdateDate: null,
    convertedOriginData: {},
    isTmptlUpdated: false,
    reExtractProc: { status: null, data: {} },
    drawStatus: false,
    fieldList: {},
    pdfDocNumPage: 0,
};

const createDataTableCol = (fieldData, fieldId) => {
    const dataTableCol = {};
    dataTableCol.col_name = fieldData.fld_nm;
    dataTableCol.col_data = fieldData.data;
    dataTableCol.ord_no = fieldData.ord_no;
    dataTableCol.fld_id = fieldId;
    dataTableCol.accuracy = fieldData.confdt;
    return dataTableCol;
};

const infoReducer = (state = initialState, action) =>
    produce(state, draft => {
        const buildDocDetailData = (data, orgData) => {
            const dataTable = {};
            const normalTextData = [];
            // Foreach all field to get group data table
            for (const [fieldId, fieldData] of Object.entries(data)) {
                if (fieldData && fieldData.dp_tp_cd === AppConstants.FIELD_TABLE_TYPE && fieldData.fld_grp_nm !== '') {
                    fieldData.fld_grp_nm = fieldData.fld_grp_nm || AppConstants.TABLE_WITH_NO_NAME;
                    if (fieldData.fld_grp_nm in dataTable) {
                        // Add data into group
                        const existColList = dataTable[fieldData.fld_grp_nm];
                        const dataTableCol = createDataTableCol(fieldData, fieldId);
                        existColList.push(dataTableCol);
                    } else {
                        // Add group name into table
                        const listOfTableCols = [];
                        const dataTableCol = createDataTableCol(fieldData, fieldId);
                        listOfTableCols.push(dataTableCol);
                        const fldGrpNm = fieldData.fld_grp_nm;
                        dataTable[fldGrpNm] = listOfTableCols;
                    }
                } else if (fieldData.fld_grp_flg === 'N') {
                    const textData = {};
                    textData.field_data = fieldData.data;
                    textData.ord_no = fieldData.ord_no;
                    textData.field_name = fieldData.fld_nm;
                    textData.fld_id = fieldId;
                    textData.org_content = orgData && orgData[fieldId] ? orgData[fieldId].data : null;
                    textData.accuracy = orgData && orgData[fieldId] ? orgData[fieldId].confdt : null;
                    normalTextData.push(textData);
                }
            }
            normalTextData.sort(comparePropsTable);
            Object.keys(dataTable).forEach(tableName => {
                dataTable[tableName].sort(comparePropsTable);
            });
            return [normalTextData, dataTable];
        };

        const getViewExtData = (objState, extractedTata) => {
            objState.allFieldRenderData = extractedTata.allFieldRenderData;
            const resData = extractedTata.extractedData;
            objState.docInfo = resData;
            // Use for sorting after re-annotate
            objState.docOrgCtntUpdateDate = JSON.parse(resData.org_ctnt).cre_dt;
            objState.companyCode = resData.co_cd;
            const docCode = resData.adm_doc_tp ? resData.adm_doc_tp.doc_cd : '';
            objState.docCode = docCode;
            objState.locationCode = resData.loc_cd;
            objState.dataOrigin = resData.org_ctnt ? JSON.parse(resData.org_ctnt) : [];
            if (!resData.isDocGroup) {
                objState.docLink = objState.isDocGroup
                    ? `${process.env.REACT_APP_DOC_LOC}/${objState.pdfLocation}/Output/${resData.doc_nm}`
                    : `${process.env.REACT_APP_DOC_LOC}/${resData.co_cd}/${resData.loc_cd}/${docCode}/Output/${
                            resData.doc_nm
                        }`;
                const tmplData = resData.dex_tmplt;
                if (tmplData) {
                    objState.templateType = tmplData.tp_val;
                    objState.templateId = tmplData.tmplt_id;
                }
                const docData = JSON.parse(resData.aft_biz_ctnt);
                const orgCtnt = JSON.parse(resData.extr_ctnt);
                /* pdf & feedback & fieldsHighlight */
                if (!docData) throw new Error("Don't have doc data");
                const [normalTextData, dataTable] = buildDocDetailData(docData, orgCtnt);
                objState.normalTextData = normalTextData;
                objState.tableData = dataTable;
                objState.convertedOriginData = JSON.stringify({
                    normalTextData,
                    tableData: dataTable,
                });
            }
            objState.loading = false;
            return objState;
        };

        switch (action.type) {
            case actionTypes.IS_EDITTING:
                draft.editing = action.status;
                break;

            case actionTypes.LOAD_DOC_DETAIL_SUCCESS:
                draft = getViewExtData(draft, action.data);
                break;

            case actionTypes.LOAD_DOC_DETAIL_ERROR:
                draft.loading = false;
                draft.error = true;
                break;

            case actionTypes.ON_OPEN_DOC_GROUP:
                draft.isDocGroup = true;
                const dataDispatch = action.data;
                draft.docGroupInfo = dataDispatch;
                const docCodeData = dataDispatch.adm_doc_tp ? dataDispatch.adm_doc_tp.doc_cd : '';
                draft.pdfLocation = `${dataDispatch.co_cd}/${dataDispatch.loc_cd}/${docCodeData}`;
                break;

            case actionTypes.LOAD_DOC_FIELD_INFO_SUCCESS:
                const keyByFieldList = _.keyBy(action.data, 'doc_fld_id');
                return { ...state, fieldList: keyByFieldList };

            case actionTypes.LOAD_DOC_FIELD_FAILED:
                draft.error = true;
                break;

            case actionTypes.VIEW_EXT_UPDATE_LOADING_STATUS:
                draft.loading = action.status;
                break;

            case actionTypes.UPDATE_SCALE:
                return { ...state, scale: action.scale };

            case actionTypes.LOAD_VIEW_RESULT_DONE:
                return { ...state, viewResultDone: true, loading: false };

            case actionTypes.LOAD_INIT_VIEW_EXTRACTION:
                return {
                    ...state,
                    scale: AppConstants.SCALE_DEFAULT,
                    normalTextData: [],
                    tableData: {},
                    error: false,
                    isDocGroup: false,
                    docInfo: null,
                    editing: false,
                    docGroupInfo: null,
                    loading: false,
                    reExtractProc: { status: null, data: {} },
                    isTmptlUpdated: false,
                    convertedOriginData: {},
                    dataOrigin: {},
                    allFieldRenderData: {},
                    bizLogicRun: {},
                    transactionHistory: [],
                    companyCode: '',
                    docCode: '',
                    locationCode: '',
                    templateType: '',
                    templateId: '',
                    docOrgCtntUpdateDate: '',
                    drawStatus: false,
                };

            case actionTypes.SAVE_TRANSACTION_SUCCESS:
                draft.loading = false;
                draft.resSaveTrans = true;
                draft.docInfo = { ...draft.docInfo, sts_cd: action.docStatus };
                break;

            case actionTypes.SAVE_TRANSACTION_ERROR:
                draft.loading = false;
                draft.resSaveTrans = false;
                break;

            case actionTypes.LOAD_HISTORY_TRANSACTION_SUCCESS:
                const resultData = action.response.data;
                const { allFieldRenderData } = state;
                const resultRefactor = [];
                // Assign missing property to transactions for render
                resultData.forEach(item => {
                    const transContent = JSON.parse(item.tj_ctnt);
                    Object.keys(transContent.data).forEach(transKey => {
                        // Loop through originData and set property to transaction with same field key
                        for (const fieldKey of Object.keys(allFieldRenderData)) {
                            if (transKey === fieldKey) {
                                transContent.data[transKey] = {
                                    ...allFieldRenderData[fieldKey],
                                    data: transContent.data[transKey].data,
                                };
                                break;
                            }
                        }
                    });
                    // Convert previous data into normalTextData and tableData for render
                    const [normalTextData, tableData] = buildDocDetailData(transContent.data);
                    transContent.data = { normalTextData, tableData };
                    resultRefactor.push({
                        ...item,
                        tj_ctnt: transContent,
                    });
                });
                // Origin Extracted
                resultRefactor.push({
                    cre_dt: state.docOrgCtntUpdateDate,
                    tj_ctnt: { data: JSON.parse(state.convertedOriginData) },
                    tp_nm: 'Original Extracted Data',
                });
                resultRefactor.sort((a, b) => new Date(b.cre_dt) - new Date(a.cre_dt));
                draft.transactionHistory = resultRefactor;
                draft.loading = false;
                break;

            case actionTypes.LOAD_HISTORY_TRANSACTION_ERROR:
                draft.transactionHistory = [];
                draft.loading = false;
                break;

            case actionTypes.SELECT_TRANSACTION:
                draft.resSaveTrans = null;
                draft.normalTextData = action.data.normalTextData;
                draft.tableData = action.data.tableData;
                break;

            case actionTypes.SET_NORMALTEXTDATA:
                draft.normalTextData = [...action.data];
                break;

            case actionTypes.SET_INPUT_NORMALTEXTDATA:
                draft.inputNormalTextData = [...action.data];
                break;

            case actionTypes.SET_TABLE_DATA:
                draft.tableData = { ...action.data };
                break;

            case actionTypes.GETTING_DATA_PDF:
                draft.pdfDrawedText = action.data;
                break;

            case actionTypes.RUN_BIZ_RULE_VIEW_BIZ:
                return { ...state, bizLogicRun: action.payload };

            case actionTypes.DOC_BY_ID_VIEW_BIZ:
                return { ...state, docDataById: action.payload };

            case actionTypes.GOOGLE_TRANSLATE:
                return { ...state, translateToEnglish: action.response.data };

            case actionTypes.RE_EXTRACT_SUCCESS:
                return { ...state, reExtractProc: { status: true, data: action.data } };

            case actionTypes.RE_EXTRACT_FAILED:
                return { ...state, reExtractProc: { status: false, data: {} } };

            case actionTypes.IS_TEMPLATE_VER_CHANGED:
                return { ...state, isTmptlUpdated: true };

            case actionTypes.CLEAR_TEMPLATE_VER_CHANGED:
                return { ...state, isTmptlUpdated: false };
            case actionTypes.UPDATE_DRAW_STATUS:
                return { ...state, drawStatus: action.drawStatus };
            case actionTypes.UPDATE_PDF_NUM_PAGE:
                return { ...state, pdfDocNumPage: action.pdfDocNumPage };
        }
    });

export default infoReducer;

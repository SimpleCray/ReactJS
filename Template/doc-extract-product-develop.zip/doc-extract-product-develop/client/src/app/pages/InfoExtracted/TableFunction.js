/* eslint-disable no-restricted-syntax */
/* eslint-disable no-plusplus */
/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable react/button-has-type */
/* eslint-disable react/react-in-jsx-scope */
import React from 'react';
import btnMoveUp from 'assets/images/arrow_up.png';
import btnMoveDown from 'assets/images/arrow_down.png';
import AppConstants from 'app/utils/appConstants';
const _ = require('lodash');

export const comparePropsTable = (a, b) => {
    const aOrder = parseInt(a.ord_no);
    const bOrder = parseInt(b.ord_no);
    if (aOrder && bOrder) {
        if (aOrder > bOrder) return 1;
        if (bOrder > aOrder) return -1;
        return 0;
    }
    if (aOrder) return 1;
    return 0;
};

const getFloatNumber = textVal => {
    const cleanedText = textVal.replace(',', '.');
    return isNaN(parseFloat(cleanedText)) ? 0.0 : parseFloat(cleanedText);
};

export const calTotalDataFooter = (arrayData, field) => {
    const listOfDataField = _.map(arrayData, d => getFloatNumber(d[field]));
    const totalVal = listOfDataField.reduce((total, val) => total + val, 0);
    const renderVal = isNaN(totalVal) ? '0.000' : totalVal.toFixed(3);
    return (
        <span className="custom-total-footer-table">
            <strong>{renderVal}</strong>
        </span>
    );
};

const isSelectedLastRow = (currentDataList, currentSelectedRow) => {
    const selectedLength = currentSelectedRow.length;
    const lastSelectedRow = currentSelectedRow[selectedLength - 1];
    if (lastSelectedRow && selectedLength === currentDataList.length) return true;
    return false;
};

const isSelectedFirstRow = currentSelectedRow => {
    if (currentSelectedRow[0]) return true;
    return false;
};

const isConsecutiveRows = currentSelectedRow => {
    if (getSelectedRows(currentSelectedRow)[0] <= 1) return true;
    let isConsecutiveRow = true;
    let selectRowCount = 0;
    for (let row = 0; row < currentSelectedRow.length; row++) {
        if (currentSelectedRow[row]) selectRowCount += 1;
        if (selectRowCount > 0 && !currentSelectedRow[row] && currentSelectedRow[row + 1]) {
            isConsecutiveRow = false;
            break;
        }
    }
    return isConsecutiveRow;
};

export const isArrayAllSelected = arrSelected => {
    for (let row = 0; row < arrSelected.length; row++) {
        if (!arrSelected[row]) return false;
    }
    return true;
};

export const checkMoveRowCondition = (currentDataList, currentSelectedRow, moveType, tableRowLength) => {
    let isRowMovable = true;
    // Check for consecutive row
    if (!isConsecutiveRows(currentSelectedRow)) {
        console.error('Is not Consecutive');
        return false;
    }
    // Check for all is selected, not allow for moving
    if (currentSelectedRow.length === tableRowLength && isArrayAllSelected(currentSelectedRow)) {
        console.error('On selected all rows');
        return false;
    }
    // Check for last row, first row condition
    if (moveType === AppConstants.MOVE_TYPE.DOWN) {
        isRowMovable = !isSelectedLastRow(currentDataList, currentSelectedRow);
    } else {
        isRowMovable = !isSelectedFirstRow(currentSelectedRow);
    }
    return isRowMovable;
};

const swapDataEle = (arr, currentSelectedPos, moveType) => {
    const newComparedPos = getNewComparedPos(currentSelectedPos, moveType);
    const temp = arr[newComparedPos];
    arr[newComparedPos] = arr[currentSelectedPos];
    arr[currentSelectedPos] = temp;
};

export const getSelectedRows = currentSelectedRow => {
    let selectedRowCount = 0;
    const selectedIndexList = [];
    for (let row = 0; row < currentSelectedRow.length; row++) {
        if (currentSelectedRow[row]) {
            selectedIndexList.push(row);
            selectedRowCount += 1;
        }
    }
    return [selectedRowCount, selectedIndexList];
};

const getNewComparedPos = (currentSelectedPos, moveType) =>
    moveType === AppConstants.MOVE_TYPE.UP ? currentSelectedPos - 1 : currentSelectedPos + 1;

const updateNewCheckList = (currentSelectedIndexList, currentSelectedRow, moveType) => {
    const newSelectedIndexList = currentSelectedIndexList.map(x => getNewComparedPos(x, moveType));
    const newChecked = currentSelectedRow.fill(false);
    newSelectedIndexList.forEach(index => {
        newChecked[index] = true;
    });
    return newChecked;
};

const getNewColorPosArr = (currentDataList, selectedIndexList, selectedRow, colorPosArr, moveType) => {
    const currentSelectedPos = selectedIndexList[selectedRow];
    swapDataEle(currentDataList, currentSelectedPos, moveType);
    const newComparedPos = getNewComparedPos(currentSelectedPos, moveType);
    if (colorPosArr.includes(currentSelectedPos) && colorPosArr.includes(newComparedPos)) {
        // Swap if both current and new pos is in colorPosArr
        swapDataEle(colorPosArr, currentSelectedPos, moveType);
    } else {
        // Assign new pos at specified index
        const i = colorPosArr.includes(currentSelectedPos)
            ? colorPosArr.indexOf(currentSelectedPos)
            : colorPosArr.indexOf(newComparedPos);
        const newColorPositionArr = getNewComparedPos(colorPosArr[i], moveType);
        colorPosArr[i] = newColorPositionArr;
    }
    return colorPosArr;
};

export const getDataListAfterMove = (currentDataList, currentSelectedRow, moveType, currentColorPosArr) => {
    // set new current Data List pos
    const [selectedRowCount, selectedIndexList] = getSelectedRows(currentSelectedRow);
    let newColorPosArr = null;
    if (moveType === AppConstants.MOVE_TYPE.DOWN) {
        for (let selectedRow = selectedRowCount - 1; selectedRow >= 0; selectedRow--) {
            newColorPosArr = getNewColorPosArr(
                currentDataList,
                selectedIndexList,
                selectedRow,
                currentColorPosArr,
                moveType,
            );
        }
    } else {
        for (let selectedRow = 0; selectedRow < selectedRowCount; selectedRow++) {
            newColorPosArr = getNewColorPosArr(
                currentDataList,
                selectedIndexList,
                selectedRow,
                currentColorPosArr,
                moveType,
            );
        }
    }
    const newChecked = updateNewCheckList(selectedIndexList, currentSelectedRow, moveType);
    return [currentDataList, newChecked, newColorPosArr];
};

export const headerWithButton = (headerName, colPos, handleMoveContRow) => (
    <div>
        <span>
            <b>{headerName}</b>
        </span>
        {colPos === 0 ? (
            <div>
                <button
                    className="icon-move-up-down move-up"
                    title="Move Container Up"
                    onClick={e => handleMoveContRow(e)}
                >
                    <img src={btnMoveUp} />
                </button>
                <button
                    className="icon-move-up-down move-down"
                    title="Move Container Down"
                    onClick={e => handleMoveContRow(e)}
                >
                    <img src={btnMoveDown} />
                </button>
            </div>
        ) : null}
    </div>
);

export const colStyle = {
    fontSize: '13px',
    minHeight: '18px',
};

export const getTableData = (tableData, tableColHeader) => {
    const dataList = [];
    const accuracyList = [];
    if (!tableData) return dataList;
    let tableRow = 0;
    tableData.forEach(col => {
        if (typeof col.col_data === 'string') return true;
        if (col.col_data.length > tableRow) tableRow = col.col_data.length;
    });
    for (let row = 0; row < tableRow; row++) {
        const rowData = {};
        const rowAccuracy = {};
        for (let col = 0; col < tableColHeader.length; col++) {
            if (typeof tableData[col].col_data === 'string') {
                rowData[tableColHeader[col]] = row === 0 ? tableData[col].col_data : '';
                rowAccuracy[tableColHeader[col]] = row === 0 ? tableData[col].accuracy : '';
                continue;
            }
            const colData = tableData[col].col_data[row] ? tableData[col].col_data[row] : '';
            let colAccuracy = '';
            if (tableData[col].accuracy) {
                colAccuracy = tableData[col].accuracy[row] ? tableData[col].accuracy[row] : '';
            }
            rowData[tableColHeader[col]] = colData;
            rowAccuracy[tableColHeader[col]] = colAccuracy;
        }
        dataList.push(rowData);
        accuracyList.push(rowAccuracy);
    }
    return { dataList, accuracyList };
};

export const formatTextHeaderTable = textData => {
    if (textData) {
        const splitedText = textData.split('_');
        for (let i = 0; i < splitedText.length; i++) {
            splitedText[i] = splitedText[i].charAt(0).toUpperCase() + splitedText[i].substring(1);
        }
        return splitedText.join(' ');
    }
    return '';
};

export const updateDataAfterCopy = (state, pasteType, colorPosArr) => {
    const { dataRowInfo, dataCopy, tableDataState } = state;
    const { index } = dataRowInfo;
    const pasteIndex = pasteType === AppConstants.INSERT_TYPE.ABOVE ? index : index + 1;
    let newColorPosArr = [];
    if (dataCopy) {
        tableDataState.splice(pasteIndex, 0, dataCopy);
        newColorPosArr = updateColorPosition(pasteIndex, colorPosArr, AppConstants.MOVE_TYPE.DOWN);
        newColorPosArr.push(pasteIndex);
    }
    return [tableDataState, newColorPosArr];
};

export const createEmptyRow = (tableTitle, tableColHeader) => {
    const emptyRow = tableColHeader.reduce((obj, current) => ({ ...obj, [current]: '' }), {});
    return emptyRow;
};

export const createCopyRow = (tableTitle, tableColHeader, rowDataCopy) => {
    const copyRow = tableColHeader.reduce((obj, colHeader) => ({ ...obj, [colHeader]: rowDataCopy[colHeader] }), {});
    return copyRow;
};

export const updateColorPosition = (newInsertPos, currentColorPosArr, moveType) => {
    const newColorPosArr = currentColorPosArr
        ? currentColorPosArr.map(indexValue =>
            indexValue >= newInsertPos ? getNewComparedPos(indexValue, moveType) : indexValue,
        )
        : [];
    return newColorPosArr;
};

export const onInsert = (data, state, newRow, insertType, colorPosArr) => {
    const { index } = state.dataRowInfo;
    const newInsertPos = insertType === AppConstants.INSERT_TYPE.BELOW ? index + 1 : index;
    let newColorPosArr = colorPosArr;
    if (data.length > 0) {
        data.splice(newInsertPos, 0, newRow);
        // update color pos for new row
        newColorPosArr = updateColorPosition(newInsertPos, colorPosArr, AppConstants.MOVE_TYPE.DOWN);
        newColorPosArr.push(newInsertPos);
    }
    return [data, newColorPosArr];
};

const updateColorArrAfterDelete = (currentSelectedPos, currentColorPosArr) => {
    currentColorPosArr.includes(currentSelectedPos) &&
        currentColorPosArr.splice(currentColorPosArr.indexOf(currentSelectedPos), 1);
    const newColorPosArr = updateColorPosition(currentSelectedPos, currentColorPosArr, AppConstants.MOVE_TYPE.UP);
    return newColorPosArr;
};

export const onDeleteRow = (data, state) => {
    let { checked, colorPosArr } = state;
    const { index } = state.dataRowInfo;
    let newColorPosArr = colorPosArr;
    if (checked.length > 0) {
        for (let index = checked.length; index >= 0; index--) {
            if (checked[index]) {
                data.splice(index, 1);
                newColorPosArr = updateColorArrAfterDelete(index, newColorPosArr);
            }
        }
        checked = [];
    } else {
        // single
        data.splice(index, 1);
        newColorPosArr = updateColorArrAfterDelete(index, colorPosArr);
    }
    return [data, checked, newColorPosArr];
};

export const formatIdHeaderTable = textData => `table-${textData.toLowerCase().replace(' ', '-')}`;

export const getNewTableData = (newData, allTableData, tableTitle) => {
    const newDataCombine = newData.reduce((obj, crr) => {
        Object.keys(crr).forEach(key => {
            if (!obj[key]) obj[key] = [];
            obj[key].push(crr[key]);
        });
        return obj;
    }, {});
    const currentTableData = allTableData[tableTitle];
    for (const row of currentTableData) {
        for (const key of Object.keys(newDataCombine)) {
            if (row.col_name === key) {
                row.col_data = newDataCombine[key];
                break;
            }
        }
    }
    return allTableData;
};

import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Dialog, DialogContent, IconButton, Typography, Toolbar, AppBar } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import _ from '@lodash';

import BizViewHeader from './BizViewHeader';
import BizViewTable from './BizViewTable';
import * as Functions from './BizViewFunction';

const BizLogicView = props => {
    const classes = Functions.useStyles();

    const bizLogicRun = useSelector(({ extracted }) => extracted.bizLogicRun);

    const [searchText, setSearchText] = useState('');
    const [fieldData, setFieldData] = useState({});
    const [tableData, setTableData] = useState([]);

    const onSelectRow = field => {
        if (field.doc_fld_id !== fieldData.doc_fld_id) {
            setFieldData(field);
        }
    };

    useEffect(() => {
        if (bizLogicRun) {
            setTableData(bizLogicRun.docCompare);
            if (!_.isEmpty(fieldData)) {
                const updateCurrentField = bizLogicRun.docCompare.find(
                    item => item.adm_co_doc_fld_id === fieldData.adm_co_doc_fld_id,
                );
                setFieldData(updateCurrentField);
            }
        }
    }, [bizLogicRun]);

    const unSelectRow = () => setFieldData(null);

    return (
        <Dialog
            classes={{
                paper: 'm-24',
            }}
            fullWidth
            maxWidth="lg"
            open={props?.open}
        >
            <AppBar position="static" elevation={1}>
                <Toolbar className="flex flex-row w-full">
                    <div className="flex w-8/12 justify-start">
                        <Typography variant="subtitle1" color="inherit">
                            View biz logic rules
                        </Typography>
                    </div>
                    <div className="flex w-4/12 justify-end">
                        <IconButton
                            onClick={() => {
                                setFieldData({});
                                return props?.onClose();
                            }}
                        >
                            <CloseIcon className={classes.colorWhite} />
                        </IconButton>
                    </div>
                </Toolbar>
            </AppBar>
            <form className="flex flex-col overflow-hidden">
                <DialogContent classes={{ root: 'p-24' }}>
                    <BizViewHeader onSearch={text => setSearchText(text)} />
                    <div className="flex flex-row mt-5">
                        <div className="w-full mr-5 	">
                            <BizViewTable
                                type="field"
                                history={props?.history}
                                searchText={searchText}
                                data={tableData}
                                onClick={onSelectRow}
                                open={props?.open}
                                unSelectRow={unSelectRow}
                            />
                        </div>
                        <BizViewTable
                            type="rule"
                            history={props?.history}
                            data={fieldData.biz_rule}
                            currentField={fieldData}
                        />
                    </div>
                </DialogContent>
            </form>
        </Dialog>
    );
};

export default BizLogicView;

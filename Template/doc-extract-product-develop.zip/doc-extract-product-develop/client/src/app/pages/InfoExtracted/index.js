/* eslint-disable no-plusplus */
/* eslint-disable no-cond-assign */
/* eslint-disable no-undef */
/* eslint-disable react/button-has-type */
import React, { useEffect, useState, useRef } from 'react';
import { useForm } from '@fuse/hooks';
import { useDispatch, useSelector } from 'react-redux';
import { pdfjs } from 'react-pdf';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import OpenInNewIcon from '@material-ui/icons/OpenInNew';
import PanelGroup from 'react-panelgroup';
import { openDialog } from 'app/store/actions/fuse';
import { CircularProgress } from '@material-ui/core';
import * as Actions from './store/actions/actions';
import { a11yProps, handlePanelUpdate } from './DocFunction';
import history from '@history';
import DocResultData from './docResultData';
import 'styles/scss/info-extracted.scss';
import 'styles/scss/commons.scss';
import reducer from './store/reducers/reducer';
import * as CommonActions from 'app/store/actions';
import withReducer from 'app/store/withReducer';
import DocFileRenderer from './docFileRenderer';
import { initUploadProc } from '../viewDoc/store/actions/actions';
import AppConstants from 'app/utils/appConstants';
import MsgNotifications from 'app/utils/msgNotifications';
import { TabPanelDocGroup } from './tabPanelDocGroup';
import { HeaderDoc } from './HeaderDoc';
import * as Styles from './styles';
import { getUserId } from 'app/utils/utils';

// Added to load PDF file
pdfjs.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
// Default tab if docType is Group
const defaultFormState = {
    docId: null,
    fixHeight: '',
    listSubDoc: [],
};

export const InfoExtracted = props => {
    const classes = Styles.useStyles();
    const matchingData = useRef({}); // Use to store information help to matching at template submit step
    const docId = window.location.href.split('/').pop();
    const { form, setForm } = useForm(defaultFormState);
    const templateType = useSelector(({ extracted }) => extracted.templateType);
    const templateId = useSelector(({ extracted }) => extracted.templateId);
    const docLink = useSelector(({ extracted }) => extracted.docLink);
    const scaleValue = useSelector(({ extracted }) => extracted.scale);
    const viewResultDone = useSelector(({ extracted }) => extracted.viewResultDone);
    const viewResultError = useSelector(({ extracted }) => extracted.error);
    const isDocGroup = useSelector(({ extracted }) => extracted.isDocGroup);
    const docInfo = useSelector(({ extracted }) => extracted.docInfo);
    const dataOrigin = useSelector(({ extracted }) => extracted.dataOrigin);
    const loading = useSelector(({ extracted }) => extracted.loading);
    const isTmptlUpdated = useSelector(({ extracted }) => extracted.isTmptlUpdated);
    const reExtractProc = useSelector(({ extracted }) => extracted.reExtractProc);
    const pdfNumPage = useSelector(({ extracted }) => extracted.pdfDocNumPage);

    const [currentDoc, setCurrentDoc] = useState(null);
    const [tabValue, setTabValue] = React.useState(0);

    const dispatch = useDispatch();
    const [selectedTabName, setSelectedTabName] = useState(null);
    const [annotationPreviewStatus, setAnnotationPreviewStatus] = useState(false);
    const [currentFieldId, setCurrentFieldId] = useState(null);
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));

    const showNotiViewResult = (notiType, msg) => {
        const errorMsg = notiType === 'error' ? MsgNotifications.VIEW_RESULT.COULD_NOT_OPEN_DOC_DATA : '';
        return CommonActions.showMessage({
            message: errorMsg || msg || MsgNotifications.VIEW_RESULT.TEMPLATE_FOR_DOC_CHANGED,
            variant: notiType || 'warning',
        });
    };

    useEffect(() => {
        if (!docId) {
            dispatch(showNotiViewResult('error'));
            history.push('/not-found');
        } else {
            dispatch(Actions.runBizRule(docId));
            dispatch(Actions.loadDocDetail(docId, matchingData, true));
        }
        return () => {
            dispatch(Actions.onLoadInitViewExtraction());
            dispatch(initUploadProc());
        };
    }, []);

    useEffect(() => {
        if (viewResultError) {
            dispatch(showNotiViewResult('error'));
            dispatch(Actions.onLoadInitViewExtraction());
            const url = '/extract/view-doc';
            history.push(url);
        }
    }, [viewResultError]);

    // Process data if doc is group
    useEffect(() => {
        if (docInfo) {
            if (userInfo.usrId !== 'admin') {
                if (docInfo.co_cd !== userInfo.coCd) {
                    dispatch(openDialog(MsgNotifications.VIEW_RESULT.NOT_ALLOW_OPEN_DOC_DATA, 'WARNING', 'Alert'));
                    history.push('/extract/view-doc');
                }
            }
            dispatch(Actions.checkTemplateVersionChange(templateId, docInfo));
            dispatch(Actions.loadDocField(docInfo.doc_tp_id));
        }
        if (docInfo && isDocGroup && docInfo.allDocData) {
            const newFormData = {
                ...form,
                docId: docInfo.doc_id,
            };
            setForm({
                ...newFormData,
                fixHeight: 'flex-y',
                docGroup: docInfo.doc_tp_id,
            });
            const { allDocData } = docInfo;
            const tabList = [];
            for (let i = 0; i < allDocData.length; i++) {
                const tabInfo = {
                    doc_nm: allDocData[i].adm_doc_tp.doc_nm,
                    doc_tp_id: allDocData[i].adm_doc_tp.doc_tp_id,
                    doc_id: allDocData[i].doc_id,
                    aft_biz_ctnt: allDocData[i].aft_biz_ctnt,
                };
                if (tabInfo.aft_biz_ctnt) {
                    let checkFlag = false;
                    for (let j = 0; j < tabList.length; j++) {
                        if (tabList[j].doc_tp_id === tabInfo.doc_tp_id) {
                            if (tabList[j].doc_id < tabInfo.doc_id) {
                                tabList[j] = tabInfo;
                            }
                            checkFlag = true;
                            break;
                        }
                    }
                    if (!checkFlag) {
                        tabList.push(tabInfo);
                    }
                }
            }
            for (let i = 0; i < tabList.length; i++) {
                tabList[i].number = i;
            }
            setCurrentDoc(tabList[0]); // First Doc which have data
            setForm({
                ...form,
                listSubDoc: tabList,
            });
        }
    }, [docInfo]);

    // Load doc field for group
    useEffect(() => {
        if (currentDoc) {
            dispatch(Actions.loadDocDetail(currentDoc.doc_id, matchingData));
            setTabValue(currentDoc.number);
        }
    }, [currentDoc]);

    useEffect(() => {
        if (isTmptlUpdated) {
            dispatch(showNotiViewResult('warning'));
        }
    }, [isTmptlUpdated]);

    useEffect(() => {
        const reExtractResData = reExtractProc.data;
        if (reExtractProc.status && reExtractResData && Object.keys(reExtractResData).length > 0) {
            if (reExtractResData.tmpltId && reExtractResData.status === AppConstants.DOC_STATUS_CODE.E) {
                dispatch(showNotiViewResult('success', MsgNotifications.VIEW_RESULT.RE_EXTRACT_SUCCESS));
                dispatch(Actions.clearTemplateVersionChangeFlag());
                dispatch(Actions.loadDocDetail(docId, matchingData, true));
            } else if (reExtractResData.status === AppConstants.DOC_STATUS_CODE.N) {
                dispatch(showNotiViewResult('warning', MsgNotifications.VIEW_RESULT.RE_EXTRACT_REQUIRE_ANNOTATE));
                const url = `/extract/annotation/${reExtractResData.tmpltType}/${reExtractResData.tmpltId}`;
                setTimeout(() => {
                    history.push({
                        pathname: url,
                        state: {
                            newFormat: false,
                            docId,
                            matchingData: matchingData.current,
                            coordinate_flexible: {}, // Re-annotate, pass empty to not match with gen new format
                        },
                    });
                }, 300);
            }
        } else if (reExtractProc.status === false) {
            dispatch(showNotiViewResult('error', MsgNotifications.VIEW_RESULT.RE_EXTRACT_FAILED));
        }
    }, [reExtractProc]);

    /** *********** HANDLING BUTTON ON ANNOTATION VIEW ************ */
    const handleAnnotate = () => {
        if (templateType && templateId && docLink) {
            // Routing to annotation
            const url = `/extract/annotation/${templateType}/${templateId}`;
            setTimeout(() => {
                history.push({
                    pathname: url,
                    state: {
                        newFormat: false,
                        docId,
                        matchingData: matchingData.current,
                        coordinate_flexible: {}, // Re-annotate, pass empty to not match with gen new format
                    },
                });
            }, 300);
        } else {
            dispatch(
                CommonActions.showMessage({
                    message: MsgNotifications.VIEW_RESULT.OPEN_ANNOTATION_ERROR,
                    variant: 'warning',
                }),
            );
        }
    };

    const handleOpenInNewTab = isOpenPdf => {
        if (!isOpenPdf) window.open(`/extract/annotation/${templateType}/${templateId}?readonly`);
        else window.open(`${docLink}`, `height=${window.screen.height}, width=${window.screen.width}`).moveTo(0, 0);
    };

    const onReExtractDocument = () => {
        dispatch(
            openDialog(MsgNotifications.VIEW_RESULT.RE_EXTRACT_MSG, 'NOTICE', 'Confirm', () => {
                const extractData = {
                    docId,
                    coCd: docInfo.co_cd,
                    locCd: docInfo.loc_cd,
                    docTpId: docInfo.doc_tp_id,
                    fileUrl: docLink,
                    usrId: getUserId(),
                };
                dispatch(Actions.reExtractDocument(extractData));
            }),
        );
    };

    const handleGenNewFormatButton = () => {
        if (templateType && templateId && docLink) {
            if (isTmptlUpdated) {
                const msg = MsgNotifications.VIEW_RESULT.MSG_CHECK_BEFORE_GEN_NEW_FORMAT;
                dispatch(showNotiViewResult('warning', msg));
            } else {
                dispatch(
                    openDialog(MsgNotifications.VIEW_RESULT.GENERATE_NEW_FORMAT, 'NOTICE', 'Confirm', () => {
                        const data = {
                            oldTmplId: templateId,
                            userId: JSON.parse(localStorage.getItem('userInfo')).usrId,
                            docId,
                            fileUrl: docLink,
                            docTpId: docInfo.doc_tp_id,
                            usrId: getUserId(),
                        };
                        dispatch(Actions.generateNewFormat(data, dataOrigin, matchingData));
                    }),
                );
            }
        } else {
            dispatch(
                CommonActions.showMessage({
                    message: MsgNotifications.VIEW_RESULT.GENERATE_NEW_FORMAT_FAILED,
                    variant: 'warning',
                }),
            );
        }
    };

    const handleAnnotationPreviewButton = () => {
        setAnnotationPreviewStatus(!annotationPreviewStatus);
    };

    const handleTabSelection = (event, newValue) => {
        setTabValue(newValue);
        form.listSubDoc.forEach(subDoc => {
            if (subDoc.doc_nm === event.target.innerHTML) {
                dispatch(Actions.loadDocDetail(subDoc.doc_id, matchingData));
                setSelectedTabName(subDoc.doc_id);
            }
        });
    };

    /** *********** VALIDATE FOR ANNOTATION PREVIEW ERROR ************ */

    const AnnotationPreviewHeader = () => (
        <div className="header-right">
            <button title="Open In New Tab" onClick={() => handleOpenInNewTab(false)}>
                <OpenInNewIcon className="iconDock" />
            </button>
        </div>
    );

    return (
        <div className="view-extract-screen">
            {viewResultDone && !loading ? (
                <PanelGroup
                    onUpdate={() => handlePanelUpdate(pdfNumPage)}
                    panelWidths={[
                        { size: (document.documentElement.clientWidth - 73) / 2, minSize: 350, resize: 'dynamic' },
                        { minSize: 200, resize: 'dynamic' },
                    ]}
                >
                    <div className="column">
                        {isDocGroup ? (
                            <AppBar position="static" color="default">
                                <Tabs
                                    value={tabValue}
                                    onChange={handleTabSelection}
                                    indicatorColor="primary"
                                    textColor="inherit"
                                    variant="scrollable"
                                    scrollButtons="auto"
                                    // aria-label="scrollable auto tabs example"
                                >
                                    {form.listSubDoc.map(item => (
                                        <Tab
                                            label={item.doc_nm}
                                            className="button-in-view-ext nav-tab"
                                            {...a11yProps(item.number)}
                                            disabled={!item.doc_id}
                                        />
                                    ))}
                                </Tabs>
                            </AppBar>
                        ) : (
                            <></>
                        )}
                        <div className={`header-left ${form.fixHeight}`}>
                            <button title="Open In New Tab" onClick={() => handleOpenInNewTab(true)}>
                                <OpenInNewIcon className="iconDock" />
                            </button>
                            <p>
                                <label className="doc-type-info">{`Doc Type: ${docInfo &&
                                    docInfo.root_nm
                                        .split('.')
                                        .pop()
                                        .toUpperCase()}`}</label>
                            </p>
                            <div className="div-button-in-view-ext">
                                <button
                                    className="button-in-view-ext"
                                    title="RE-EXTRACT"
                                    onClick={() => onReExtractDocument()}
                                >
                                    RE-EXTRACT
                                </button>
                                <button
                                    className="button-in-view-ext"
                                    title="Generate new format"
                                    onClick={() => handleGenNewFormatButton()}
                                >
                                    GENERATE NEW FORMAT
                                </button>
                                <button
                                    className="button-in-view-ext"
                                    title="Annotation preview"
                                    onClick={() => handleAnnotationPreviewButton()}
                                >
                                    {annotationPreviewStatus ? 'VIEW DATA' : 'ANNOTATION PREVIEW'}
                                </button>
                                <button
                                    className="button-in-view-ext"
                                    title="Annotate"
                                    onClick={() => handleAnnotate()}
                                >
                                    ANNOTATE
                                </button>
                            </div>
                        </div>
                        {isDocGroup &&
                            form.listSubDoc.map(e => (
                                <TabPanelDocGroup value={tabValue} index={e.number}>
                                    <DocFileRenderer
                                        docLink={docLink}
                                        currentFieldId={currentFieldId}
                                        pdfNumPage={pdfNumPage}
                                    />
                                </TabPanelDocGroup>
                            ))}
                        {!isDocGroup && (
                            <DocFileRenderer
                                docLink={docLink}
                                currentFieldId={currentFieldId}
                                pdfNumPage={pdfNumPage}
                            />
                        )}
                    </div>
                    <div className="column">
                        {!annotationPreviewStatus && [
                            <HeaderDoc docInfo={docInfo} history={props?.history} />,
                            <div className="wrapper">
                                <DocResultData
                                    tabName={selectedTabName}
                                    scale={scaleValue}
                                    classes={classes}
                                    setCurrentFieldId={id => setCurrentFieldId(id)}
                                />
                            </div>,
                        ]}
                        {annotationPreviewStatus && [
                            <AnnotationPreviewHeader />,
                            <iFrame
                                className="annotation-preview-iframe"
                                src={`/extract/annotation/${templateType}/${templateId}?readonly=iframe`}
                            />,
                        ]}
                    </div>
                </PanelGroup>
            ) : (
                <div className="circleloading">
                    <CircularProgress size={200} />
                </div>
            )}
        </div>
    );
};

export default withReducer('extracted', reducer)(InfoExtracted);

import { API_EP, API_TRANSLATE } from 'app/utils/commonAPI';
import EndPointAPI from 'app/utils/endPointAPI';
import { showError, checkResDataAPI } from 'app/utils/utils';
import AppConstants from 'app/utils/appConstants';
import history from '@history';
import { showMessage } from 'app/store/actions';
import MsgNotifications from 'app/utils/msgNotifications';
import * as ViewDocFunctions from 'app/pages/viewDoc/viewDocFuctions';
import * as actionTypes from '../constants';

// Load DB in Saas
export const loadDocField = docTypeId => dispatch => {
    const url = `doc-field/${docTypeId}`;

    API_EP.get(url)
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: actionTypes.LOAD_DOC_FIELD_INFO_SUCCESS,
                    data: response.data,
                });
            }
        })
        .catch(error => {
            dispatch({
                type: actionTypes.LOAD_DOC_FIELD_FAILED,
                error,
            });
            dispatch(showError(error));
        });
};

// Load DB in Saas
export const loadDocDetail = (docId, matchingData, loadTransHistory = false) => (dispatch, getState) => {
    const url = `doc-data/get-renderable-data/${docId}`;
    API_EP.get(url)
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: actionTypes.LOAD_VIEW_RESULT_DONE,
                });
                const resData = response.data;
                if (resData.isDocGroup && !getState().extracted.isDocGroup) {
                    dispatch({
                        type: actionTypes.ON_OPEN_DOC_GROUP,
                        data: resData,
                    });
                }
                const { extractedData } = resData;
                if (extractedData) {
                    matchingData.current = {
                        co_cd: extractedData.co_cd,
                        lo_cd: extractedData.loc_cd,
                        doc_tp_id: extractedData.doc_tp_id,
                    };
                }
                if (loadTransHistory) dispatch(loadTransactionHistory(docId));
                return dispatch({
                    type: actionTypes.LOAD_DOC_DETAIL_SUCCESS,
                    data: resData,
                });
            }
        })
        .catch(error => {
            dispatch({
                type: actionTypes.LOAD_DOC_DETAIL_ERROR,
                error,
            });
            dispatch(showError(error));
        });
};

export function resizeUpdateState() {
    return {
        type: actionTypes.RESIZE_UPDATE_STATE,
    };
}

export function updateLoadingStatus(status) {
    return {
        type: actionTypes.VIEW_EXT_UPDATE_LOADING_STATUS,
        status,
    };
}

export function onZoom(scale) {
    return dispatch =>
        dispatch({
            type: actionTypes.UPDATE_SCALE,
            scale,
        });
}

export function onLoadInitViewExtraction() {
    return {
        type: actionTypes.LOAD_INIT_VIEW_EXTRACTION,
    };
}

export const isEditing = status => dispatch => {
    dispatch({
        type: actionTypes.IS_EDITTING,
        status,
    });
};

export function updateDoc(data) {
    return {
        type: actionTypes.UPDATE_DOC,
        data,
    };
}

export const loadTransactionHistory = docId => dispatch => {
    API_EP.get(`${EndPointAPI.ENDPOINT.TRANSACTION.GET_TRANSACTION_HISTORY}/${docId}`)
        .then(response =>
            dispatch({
                type: actionTypes.LOAD_HISTORY_TRANSACTION_SUCCESS,
                response,
            }),
        )
        .catch(error =>
            dispatch({
                type: actionTypes.LOAD_HISTORY_TRANSACTION_ERROR,
                error,
            }),
        );
};

export const saveTransaction = (data, reApplyBiz = null) => dispatch => {
    const docId = data.transTypeId;
    const transactionInfo = ViewDocFunctions.convertTransactionInfo(data);
    API_EP.post(EndPointAPI.ENDPOINT.TRANSACTION.SAVE_TRANSACTION, JSON.stringify(transactionInfo), {
        params: { transType: AppConstants.TRANSACTION_TYPE.DOC },
    })
        .then(response => {
            dispatch({
                type: actionTypes.SAVE_TRANSACTION_SUCCESS,
                docStatus: reApplyBiz?.statusCode || 'V',
            });
            if (reApplyBiz) {
                const { statusCode, issueList } = reApplyBiz;
                ViewDocFunctions.updateIssueStatusDoc(docId, statusCode, issueList, true);
            }
            dispatch(loadTransactionHistory(docId));
        })
        .catch(error => {
            dispatch({
                type: actionTypes.SAVE_TRANSACTION_ERROR,
                error,
            });
        });
};

export const runBizRule = docIdParam => dispatch => {
    API_EP.get(EndPointAPI.ENDPOINT.BIZ.GET_BIZ_DATA, { params: { docId: docIdParam } })
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: actionTypes.RUN_BIZ_RULE_VIEW_BIZ,
                    payload: response.data,
                });
            }
        })
        .catch(error => dispatch(showError(error)));
};

export const getDocById = docId => dispatch => {
    API_EP.get(`/doc-data/${docId}`)
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: actionTypes.DOC_BY_ID_VIEW_BIZ,
                    payload: response.data,
                });
            }
        })
        .catch(error => dispatch(showError(error)));
};

export const selectTransaction = data => dispatch => {
    dispatch({
        type: actionTypes.SELECT_TRANSACTION,
        data,
    });
};

export const setNormalTextData = data => dispatch => {
    dispatch({
        type: actionTypes.SET_NORMALTEXTDATA,
        data,
    });
};

export const setInputNormalTextData = data => dispatch => {
    dispatch({
        type: actionTypes.SET_INPUT_NORMALTEXTDATA,
        data,
    });
};

export const updateGettingDataPdf = data => dispatch => {
    dispatch({
        type: actionTypes.GETTING_DATA_PDF,
        data,
    });
};

export const setTableData = data => dispatch => {
    dispatch({
        type: actionTypes.SET_TABLE_DATA,
        data,
    });
};

export const generateNewFormat = (params, dataOrigin, matchingData) => dispatch => {
    dispatch(updateLoadingStatus(true));
    API_EP.post(EndPointAPI.ENDPOINT.TEMPLATE.GENERATE_NEW_FORMAT, params)
        .then(response => {
            dispatch(updateLoadingStatus(false));
            const { data } = response;
            if (!data.tmpltType || !data.tmpltId) throw new Error('Generate new template failed!');
            const url = `/extract/annotation/${data.tmpltType}/${data.tmpltId}`;
            history.push({
                pathname: url,
                state: {
                    newFormat: true,
                    docId: params.docId,
                    matchingData: matchingData.current,
                    coordinate_flexible: dataOrigin.coordinate_flexible || {},
                },
            });
        })
        .catch(error => {
            dispatch(updateLoadingStatus(false));
            dispatch(
                showMessage({ message: MsgNotifications.VIEW_RESULT.GENERATE_NEW_FORMAT_FAILED, variant: 'error' }),
            );
        });
};

export const translateToEnglish = textParams => dispatch => {
    const paramsDetail = { client: 'gtx', sl: 'auto', tl: 'en', dt: 't', q: textParams };

    API_TRANSLATE.get('/single', { params: paramsDetail })
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: actionTypes.GOOGLE_TRANSLATE,
                    response,
                });
            }
        })
        .catch(err => {
            dispatch({
                type: actionTypes.GOOGLE_TRANSLATE,
                response: { data: [[[textParams]]] },
            });
        });
};

export const reExtractDocument = extractData => dispatch => {
    dispatch(updateLoadingStatus(true));
    API_EP.post(EndPointAPI.ENDPOINT.EXTRACTION.EXTRACT_DOC, { extractData, reExtract: true, updateTmplt: true })
        .then(response => {
            dispatch(updateLoadingStatus(false));
            if (checkResDataAPI(response)) {
                if (!response.data.tmpltId) throw new Error('Re-extract document failed!');
                dispatch({
                    type: actionTypes.RE_EXTRACT_SUCCESS,
                    data: response.data,
                });
            }
        })
        .catch(error => {
            console.log(error);
            dispatch(updateLoadingStatus(false));
            dispatch({
                type: actionTypes.RE_EXTRACT_FAILED,
            });
        });
};

export const checkTemplateVersionChange = (templateId, docInfo) => dispatch => {
    API_EP.get(EndPointAPI.ENDPOINT.TEMPLATE.GET_TMP_VERSION, { params: { tmpltId: templateId } })
        .then(response => {
            dispatch(updateLoadingStatus(false));
            if (checkResDataAPI(response)) {
                const docVersion = docInfo.org_ctnt ? JSON.parse(docInfo.org_ctnt).tmplt_ver_val : '';
                if (docVersion !== response.data) {
                    dispatch({
                        type: actionTypes.IS_TEMPLATE_VER_CHANGED,
                        data: response.data,
                    });
                }
            }
        })
        .catch(error => {
            console.log(error);
        });
};

export const clearTemplateVersionChangeFlag = () => dispatch =>
    dispatch({
        type: actionTypes.CLEAR_TEMPLATE_VER_CHANGED,
    });

export const getTextOCR = (data, file_url) => {
    const payload = {
        image: data.replace('data:image/png;base64,', ''),
        file_url,
    };
    const apiCalling = API_EP.post(EndPointAPI.CORE.OCR_TEXT.SUBMIT, payload);
    return dispatch =>
        apiCalling
            .then(response => {
                if (checkResDataAPI(response)) {
                    const textData = response.data.data;
                    if (textData.length > 0) dispatch(updateGettingDataPdf(textData));
                    else
                        dispatch(
                            showMessage({
                                message: MsgNotifications.VIEW_RESULT.GET_TEXT_FROM_DRAW_DOC_FAILED,
                                variant: 'warning',
                            }),
                        );
                }
            })
            .catch(error => {
                dispatch(
                    showMessage({
                        message: MsgNotifications.VIEW_RESULT.GET_TEXT_FROM_DRAW_DOC_FAILED,
                        variant: 'warning',
                    }),
                );
            });
};

export function updateDrawStatus(drawStatus) {
    return {
        type: actionTypes.UPDATE_DRAW_STATUS,
        drawStatus,
    };
}

export function updatePdfDocNumPage(pdfDocNumPage) {
    return {
        type: actionTypes.UPDATE_PDF_NUM_PAGE,
        pdfDocNumPage,
    };
}

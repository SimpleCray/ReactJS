import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles({
    belowSeventy: {
        backgroundColor: '#ff6701',
        pointerEvents: 'none',
    },
    seventyToEighty: {
        backgroundColor: '#fea82f',
    },
    eightyToNinety: {
        backgroundColor: '#ffc288',
    },
    ninetyToOneHundred: {
        backgroundColor: '#fcecdd',
    },
    rowContainer: {
        display: 'flex',
        flexDirection: 'row',
        padding: 5,
    },
    buttonContainer: {
        marginTop: 5,
        paddingRight: 15,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-start',
        cursor: 'pointer',
    },
    preLine: {
        whiteSpace: 'pre-line',
    },
    editArea: {
        width: '100%',
        minHeight: '25px',
        color: 'black',
        caretColor: 'black',
        overflowWrap: 'break-word',
        wordWrap: 'break-word',
        wordBreak: 'break-all',
        whiteSpace: 'pre-wrap',
    },
    warningCharacter: {
        color: 'red',
    },
});

export const accuracyColorDefine = {
    belowSeventy: '#ff6701',
    seventyToEighty: '#fea82f',
    eightyToNinety: '#ffc288',
    ninetyToOneHundred: '#fcecdd',
};

/* eslint-disable react/no-access-state-in-setstate */
/* eslint-disable react/no-did-update-set-state */
/* eslint-disable react/prop-types */
import React from 'react';
import ReactTable from 'react-table';
import Button from '@material-ui/core/Button';
import 'react-table/react-table.css';
import 'styles/scss/custom-table.scss';
import AppConstants from 'app/utils/appConstants';
import { connect } from 'react-redux';
import ContextMenu from './TableContextMenu';
import * as TableFunctions from './TableFunction';
import * as DocFunctions from './DocFunction';
import { accuracyColorDefine } from './styles';
import { setTableData } from './store/actions/actions';
const _ = require('lodash');

export class TableRenderer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tableDataState: [],
            editableCol: true,
            selectAll: false,
            checked: [],
            dataRowInfo: {},
            mouseX: null,
            mouseY: null,
            showContextMenu: false,
            isCopied: false,
            dataCopy: {},
            colorPosArr: [],
            changedField: [],
        };
        this.renderEditable = this.renderEditable.bind(this);
        this.handleAllCheckboxChange = this.handleAllCheckboxChange.bind(this);
        this.handleSingleCheckboxChange = this.handleSingleCheckboxChange.bind(this);
    }

    componentDidMount() {
        const tableData = this.props.tableDataList[this.props.tableTitle];
        const { dataList, accuracyList } = TableFunctions.getTableData(tableData, this.props.tableColHeader);
        this.setState({
            tableDataState: dataList,
            tableAccuracy: accuracyList,
        });
    }

    // TODO: This will make many renders => Will be replaced => Change libs
    componentWillReceiveProps(newProps) {
        const tableData = newProps.tableDataList[newProps.tableTitle];
        const { dataList, accuracyList } = TableFunctions.getTableData(tableData, newProps.tableColHeader);
        this.setState({
            tableDataState: dataList,
            tableAccuracy: accuracyList,
        });
        // Remove all selected checkbox after click save
        if (this.props.resSaveTrans) {
            const checkedCopy = [];
            this.state.tableDataState.forEach(() => {
                checkedCopy.push(false);
            });
            this.setState({ selectAll: false });
            this.setState({ checked: checkedCopy });
        }
    }

    componentDidUpdate(prevProps, _prevState) {
        if (!_.isEqual(prevProps.tableDataList, this.props.tableDataList)) {
            const tableData = this.props.tableDataList[this.props.tableTitle];
            const { dataList, accuracyList } = TableFunctions.getTableData(tableData, this.props.tableColHeader);
            this.setState({
                tableDataState: dataList,
                tableAccuracy: accuracyList,
                changedField: [],
            });
        }
    }

    handleInputChange = (cellInfo, event) => {
        const data = [...this.state.tableDataState];
        data[cellInfo.index][cellInfo.column.id] = event.currentTarget.innerText;
        this.setState({ tableDataState: data });
        // Also change value of tableList in store
        const modifiedTableData = TableFunctions.getNewTableData(data, this.props.tableDataList, this.props.tableTitle);
        this.props.setTableData(modifiedTableData);
    };

    handleChangeField = (cellInfo, event) => {
        this.setState({ changedField: [...this.state.changedField, cellInfo.column.id] });
    };

    handleClickFieldTable = (cellInfo, event) => {
        DocFunctions.removeOldFocusTag();
        event.currentTarget.classList.add('in-focus-for-copy');
        const currentFocusField = document.getElementsByClassName('in-focus-for-copy')[0];
        let fieldId = null;
        // Will showing annotation boxes here
        if (currentFocusField && currentFocusField.getAttribute(AppConstants.DOC_RESULT_ATT.FIELD_ID)) {
            fieldId = cellInfo.column.className.split(' ').pop();
            const firstTimeDraw = DocFunctions.openAnnotationBox(fieldId, this.props.dataOrigin);
            if (!firstTimeDraw) {
                const fieldIdRenderBox = this.props.fieldList[fieldId]?.fld_grp_id || fieldId;
                DocFunctions.openAnnotationBox(fieldIdRenderBox, this.props.dataOrigin);
            }
        }
        this.props.setCurrentFieldId(fieldId);
    };

    characterAccuracy = (cellValue, cellAccuracy, fldNm, index) => {
        if (!cellValue || typeof cellValue === 'object') return;
        // // Not found accuracy return origin
        if (
            !Array.isArray(cellAccuracy) ||
            (cellAccuracy.length > 0 && typeof cellAccuracy[0] !== 'object') ||
            cellAccuracy.length === 0
        )
            return cellValue;
        // Check biz logic applied
        if (this.props.bizLogicRun && this.props.bizLogicRun.docCompare) {
            const currentField = this.props.bizLogicRun.docCompare.find(item => item.fld_nm === fldNm);
            if (currentField && currentField.biz_rule.length > 0 && currentField.after_rule[index] !== cellValue) {
                return cellValue;
            }
        }
        //Check length Cell value and length Cell accuracy
        if (cellValue.replace(/\s/g, '').length !== cellAccuracy.length) {
            return cellValue;
        }
        // Add space to accuracy set
        let displayAccuracy = [...cellAccuracy];
        [...cellValue].forEach((item, index) => {
            if (item === ' ')
            displayAccuracy = [...displayAccuracy.slice(0, index), { text: ' ', confdt: 100 }, ...displayAccuracy.slice(index)];
        });
        return (
            <div contentEditable={this.props.editing}>
                {displayAccuracy.map(item => (
                    <span
                        contentEditable={this.props.editing}
                        className={
                            item.confdt > 90 || this.state.changedField.includes(fldNm)
                                ? ''
                                : this.props.classes.warningCharacter
                        }
                    >
                        {item.text}
                    </span>
                ))}
            </div>
        );
    };

    renderEditable = cellInfo => {
        const cellValue = this.state.tableDataState[cellInfo.index]
            ? this.state.tableDataState[cellInfo.index][cellInfo.column.id]
            : '';
        const cellAccuracy = this.state.tableAccuracy[cellInfo.index]
            ? this.state.tableAccuracy[cellInfo.index][cellInfo.column.id]
            : [];
        const fieldId = cellInfo.column.className.split(' ').pop();
        const cellId = `${fieldId}-${cellInfo.index}`;
        return (
            <div
                contentEditable={this.props.editing}
                suppressContentEditableWarning
                className="table-div-editable"
                datatype={AppConstants.DOC_RESULT_TYPE.TABLE}
                tablename={this.props.tableTitle}
                fieldid={fieldId}
                datapos={cellInfo.index}
                onBlur={e => this.handleInputChange(cellInfo, e)}
                onInput={e => this.handleChangeField(cellInfo, e)}
                onClick={this.handleClickFieldTable.bind(null, cellInfo)}
                id={cellId}
                defaultChecked={false}
                style={{
                    background:
                        this.state.colorPosArr?.includes(cellInfo.index) && AppConstants.VIEW_EXTR_COLOR.LIGHT_YELLOW,
                }}
            >
                {this.characterAccuracy(cellValue, cellAccuracy, cellInfo.column.id, cellInfo.index)}
            </div>
        );
    };

    handleAllCheckboxChange = () => {
        const selectAll = !this.state.selectAll;
        this.setState({ selectAll });
        const checkedCopy = [];
        this.state.tableDataState.forEach(() => {
            checkedCopy.push(selectAll);
        });
        this.setState({
            checked: checkedCopy,
        });
    };

    handleSingleCheckboxChange = index => {
        const checkedCopy = this.state.checked;
        checkedCopy[index] = !this.state.checked[index];
        if (checkedCopy[index] === false) {
            this.setState({ selectAll: false });
        }
        this.setState({ checked: checkedCopy });
        const tableRow = this.state.tableDataState.length;
        if (
            checkedCopy[index] &&
            this.state.checked.length === tableRow &&
            TableFunctions.isArrayAllSelected(this.state.checked)
        ) {
            this.setState({ selectAll: true });
        }
    };

    handleDelete = () => {
        const data = this.state.tableDataState;
        const [newData, checkedCopy, newColorPosArr] = TableFunctions.onDeleteRow(data, this.state);
        this.setState({ checked: checkedCopy, tableDataState: newData, colorPosArr: newColorPosArr });
        this.handleCloseContextMenu();
        // Also change value of tableList in store
        const modifiedTableData = TableFunctions.getNewTableData(
            newData,
            this.props.tableDataList,
            this.props.tableTitle,
        );
        this.props.setTableData(modifiedTableData);
    };

    handleContextMenu = event => {
        event.preventDefault();
        this.setState({ mouseX: event.clientX, mouseY: event.clientY });
        this.setState({ showContextMenu: true });
    };

    handleCloseContextMenu = () => {
        this.setState({ showContextMenu: false });
        this.setState({ mouseX: null, mouseY: null });
    };

    addNewTableRow = () => {
        const tableData = this.state.tableDataState;
        const newRow = TableFunctions.createEmptyRow(this.props.tableTitle, this.props.tableColHeader);
        tableData.push(newRow);

        const newColorPosArr = [...this.state.colorPosArr, tableData.length - 1];
        this.setState({ colorPosArr: newColorPosArr });
        this.setState({ tableDataState: tableData });
        // Also change value of tableList in store
        const modifiedTableData = TableFunctions.getNewTableData(
            tableData,
            this.props.tableDataList,
            this.props.tableTitle,
        );
        this.props.setTableData(modifiedTableData);
    };

    insertRow = insertType => {
        const newRow = TableFunctions.createEmptyRow(this.props.tableTitle, this.props.tableColHeader);
        const [newTableData, newColorPosArr] = TableFunctions.onInsert(
            this.state.tableDataState,
            this.state,
            newRow,
            insertType,
            this.state.colorPosArr,
        );
        this.setState({ tableDataState: newTableData, colorPosArr: newColorPosArr });
        // Also change value of tableList in store
        const modifiedTableData = TableFunctions.getNewTableData(
            newTableData,
            this.props.tableDataList,
            this.props.tableTitle,
        );
        this.props.setTableData(modifiedTableData);
        this.handleCloseContextMenu();
    };

    duplicateRow = () => {
        const { original, index } = this.state.dataRowInfo;
        const data = this.state.tableDataState;
        data.splice(index, 0, TableFunctions.createCopyRow(this.props.tableTitle, this.props.tableColHeader, original));
        const newColorPosArr = TableFunctions.updateColorPosition(index + 1, this.state.colorPosArr);
        this.setState({ tableDataState: data, colorPosArr: newColorPosArr });
        // Also change value of tableList in store
        const modifiedTableData = TableFunctions.getNewTableData(data, this.props.tableDataList, this.props.tableTitle);
        this.props.setTableData(modifiedTableData);
        this.handleCloseContextMenu();
    };

    copyRow = () => {
        const { original } = this.state.dataRowInfo;
        const newRowCopy = TableFunctions.createCopyRow(this.props.tableTitle, this.props.tableColHeader, original);
        this.setState({ isCopied: true, dataCopy: newRowCopy });
        this.handleCloseContextMenu();
    };

    paste = pasteType => {
        const [data, newColorPosArr] = TableFunctions.updateDataAfterCopy(
            this.state,
            pasteType,
            this.state.colorPosArr,
        );
        this.setState({ tableDataState: data, colorPosArr: newColorPosArr });
        // Also change value of tableList in store
        const modifiedTableData = TableFunctions.getNewTableData(data, this.props.tableDataList, this.props.tableTitle);
        this.props.setTableData(modifiedTableData);
        this.setState({ dataCopy: {} });
        this.setState({ isCopied: false });
        this.handleCloseContextMenu();
    };

    render() {
        const moveRowUI = (currentDataList, currentSelectedRow, moveType) => {
            const [newDataList, newCheckedList, newColorPosArr] = TableFunctions.getDataListAfterMove(
                currentDataList,
                currentSelectedRow,
                moveType,
                this.state.colorPosArr,
            );
            this.setState({ tableDataState: newDataList });
            // Also change value of tableList in store
            const modifiedTableData = TableFunctions.getNewTableData(
                newDataList,
                this.props.tableDataList,
                this.props.tableTitle,
            );
            this.props.setTableData(modifiedTableData);
            this.setState({ checked: newCheckedList });
            this.setState({ colorPosArr: newColorPosArr });
        };

        const handleMoveContRow = event => {
            const currentDataList = this.state.tableDataState;
            const currentSelectedRow = this.state.checked;
            const moveType = event.currentTarget.classList.contains(AppConstants.MOVE_TYPE.DOWN)
                ? AppConstants.MOVE_TYPE.DOWN
                : AppConstants.MOVE_TYPE.UP;
            const tableRowLength = currentDataList.length;
            const isMovable = TableFunctions.checkMoveRowCondition(
                currentDataList,
                currentSelectedRow,
                moveType,
                tableRowLength,
            );
            if (isMovable) moveRowUI(currentDataList, currentSelectedRow, moveType);
        };

        const createHeader = (headerName, colPos) =>
            TableFunctions.headerWithButton(headerName, colPos, handleMoveContRow);

        const headerType = {
            Header: '',
            accessor: '',
            className: 'wordwrap without-padding',
            contentEditable: true,
            resizable: false,
            width: 140,
            style: TableFunctions.colStyle,
            Cell: this.renderEditable,
        };

        const getHeaderCol = () => {
            const { tableAccuracy } = this.state;
            const headerName = this.props.tableColHeader;
            const tableData = this.props.tableDataList[`${this.props.tableTitle}`];
            const headers = [];
            const checkableRowHeader = {
                Header: state => (
                    <input
                        type="checkbox"
                        disabled={!this.props.editing}
                        onChange={() => this.handleAllCheckboxChange(state.sortedData)}
                        checked={this.state.selectAll}
                    />
                ),
                Cell: row => (
                    <div>
                        <input
                            type="checkbox"
                            disabled={!this.props.editing}
                            defaultChecked={this.state.checked[row.index]}
                            checked={this.state.checked[row.index]}
                            onChange={() => this.handleSingleCheckboxChange(row.index)}
                            className="custom-checkbox-table"
                        />
                        <span className="custom-checkbox-table"> {row.index + 1}</span>
                    </div>
                ),
                width: 45,
                sortable: false,
                filterable: false,
                resizable: false,
            };
            headers.push(checkableRowHeader);
            for (let colPos = 0; colPos < headerName.length; colPos++) {
                const formatedTextHeader = TableFunctions.formatTextHeaderTable(headerName[colPos]);
                const newHeader = {
                    ...headerType,
                    Header: createHeader(formatedTextHeader, colPos),
                    accessor: headerName[colPos],
                    className: `${headerType.className} ${tableData[colPos].fld_id}`,
                };
                headers.push(newHeader);
            }
            return headers;
        };

        return (
            <div id={TableFunctions.formatIdHeaderTable(this.props.tableTitle)}>
                <h2 className="header-table">{TableFunctions.formatTextHeaderTable(this.props.tableTitle)}</h2>
                <ReactTable
                    className="-striped -highlight cont-detail"
                    showPagination={false}
                    data={this.state.tableDataState}
                    pageSize={this.state.tableDataState ? this.state.tableDataState.length : 0}
                    columns={getHeaderCol()}
                    sortable={false}
                    getTdProps={(_state, _rowInfo, _column) => ({
                        onContextMenu: this.props.editing ? e => {
                            _rowInfo && this.setState({ dataRowInfo: _rowInfo });
                            this.handleContextMenu(e);
                        } : () => {},
                    })}
                    minRows={1}
                />
                <ContextMenu
                    state={this.state}
                    handleCloseContextMenu={this.handleCloseContextMenu}
                    insertRow={this.insertRow}
                    duplicateRow={this.duplicateRow}
                    copyRow={this.copyRow}
                    paste={this.paste}
                    handleDelete={this.handleDelete}
                />

                <div className="con-detail-button-wrapper">
                    <Button
                        variant="contained"
                        disabled={!this.props.editing}
                        className="delete-button"
                        onClick={() => this.handleDelete()}
                    >
                        Delete selected rows
                    </Button>
                    <Button
                        variant="contained"
                        disabled={!this.props.editing}
                        className="add-button"
                        onClick={() => this.addNewTableRow()}
                    >
                        Add Row
                    </Button>
                </div>
            </div>
        );
    }
}

export default connect(
    null,
    { setTableData },
)(TableRenderer);

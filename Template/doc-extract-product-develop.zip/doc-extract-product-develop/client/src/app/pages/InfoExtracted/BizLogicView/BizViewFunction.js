import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles({
    root: {
        width: '100%',
        boxShadow: 'none',
    },
    container: {
        height: '400px',
    },
    cursor: {
        cursor: 'pointer',
    },
    preLine: {
        whiteSpace: 'pre-line',
    },
    colorWhite: {
        color: 'white',
    },
    updateBackground: {
        backgroundColor: '#fadfbb',
        cursor: 'pointer',
    },
    errorBackground: {
        backgroundColor: '#FFA7A7',
        cursor: 'pointer',
    },
    createBackground: {
        backgroundColor: '#d8f3dc',
        cursor: 'pointer',
    },
});

export const commonProps = {
    className: 'whitespace-no-wrap h-32 mx-2',
    variant: 'contained',
    color: 'primary',
};

export const headerStyle = {
    margin: 3,
    '& MuiOutlinedInput': {
        borderColor: 'white',
        border: '1px',
    },
    '& label': {
        color: 'white',
    },
    '& label.MuiFocused': {
        color: 'white',
    },
    '& .MuiInputUnderline:after': {
        borderBottomColor: 'white',
    },

    minWidth: '20ch',
};

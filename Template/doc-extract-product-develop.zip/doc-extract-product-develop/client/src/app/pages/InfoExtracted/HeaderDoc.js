/* eslint-disable react/button-has-type */
/* eslint-disable no-nested-ternary */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import FullscreenIcon from '@material-ui/icons/Fullscreen';
import FullscreenExitIcon from '@material-ui/icons/FullscreenExit';
import moment from 'moment';
import 'styles/scss/info-extracted.scss';
import 'styles/scss/view-doc.scss';
import withReducer from 'app/store/withReducer';
import AppConstants from 'app/utils/appConstants';
import { showMessage } from 'app/store/actions/fuse';
import { API_EP } from 'app/utils/commonAPI';
import EndPointAPI from 'app/utils/endPointAPI';
import * as FuseActions from 'app/store/actions';
import reducer from './store/reducers/reducer';
import * as Actions from './store/actions/actions';

import BizView from './BizLogicView/BizView';

export const HeaderDoc = props => {
    const dispatch = useDispatch();

    const [fullscreen, setFullscreen] = useState(false);
    const [seconds, setSeconds] = useState(0);
    const [pausing, setPausing] = useState(true);
    const [bizViewOpen, setBizViewOpen] = useState(false);

    const editing = useSelector(({ extracted }) => extracted.editing);
    const transactionHistory = useSelector(({ extracted }) => extracted.transactionHistory);
    const docId = window.location.href.split('/').pop();
    const normalTextData = useSelector(({ extracted }) => extracted.normalTextData);
    const inputNormalTextData = useSelector(({ extracted }) => extracted.inputNormalTextData);
    const tableData = useSelector(({ extracted }) => extracted.tableData);
    // Init time counter
    useEffect(() => {
        const interval = setInterval(() => {
            if (editing) {
                setSeconds(sec => ++sec);
            } else {
                clearInterval(interval);
            }
        }, 1000);
        return () => clearInterval(interval);
    }, [editing]);

    // Load transaction history, if available, select the lastest data
    useEffect(() => {
        // select Lastest Transaction
        if (transactionHistory.length > 0) {
            const lastestData = transactionHistory[0].tj_ctnt.data;
            dispatch(Actions.selectTransaction(lastestData));
        }
    }, [transactionHistory]);

    const onFocus = () => {
        dispatch(Actions.isEditing(true));
    };

    // User has switched or clicked away from the tab
    const onBlur = () => {
        dispatch(Actions.isEditing(false));
    };

    useEffect(() => {
        if (!pausing) {
            window.addEventListener('focus', onFocus);
            window.addEventListener('blur', onBlur);
            return () => {
                window.removeEventListener('focus', onFocus);
                window.removeEventListener('blur', onBlur);
            };
        }
    });

    const handleFullScreen = () => {
        document.getElementsByClassName('panelWrapper')[0].classList.add('fullScreen');
        document.getElementsByClassName('panelWrapper')[0].classList.remove('notFullScreen');
        setFullscreen(true);
    };

    const handleCloseFullScreen = () => {
        document.getElementsByClassName('panelWrapper')[0].classList.add('notFullScreen');
        document.getElementsByClassName('panelWrapper')[0].classList.remove('fullScreen');
        setFullscreen(false);
    };

    const handlePause = () => {
        dispatch(Actions.isEditing(false));
        dispatch(Actions.updateDrawStatus(false));
        setPausing(true);
    };

    const handleEdit = () => {
        dispatch(showMessage({ message: 'Begin Edit !', variant: 'success' }));
        dispatch(Actions.isEditing(true));
        setPausing(false);
    };

    const handleSave = async () => {
        const userId = localStorage.getItem(AppConstants.BP_USER_ID);
        const typeName = AppConstants.TRANSACTION_STATUS.VERIFY;
        const data = {
            transTypeId: docId,
            typeName,
            userId,
            transactionContent: {
                data: {
                    normalTextData: inputNormalTextData.length === 0 ? normalTextData : inputNormalTextData,
                    tableData,
                },
                timeSpend: seconds,
            },
        };
        dispatch(Actions.isEditing(false));
        dispatch(Actions.updateDrawStatus(false));
        await dispatch(Actions.saveTransaction(data));
        // TODO: Check the logic with line 41 - 47 to re-handle this
        // Prevent undefined when first transaction is saved (document has no transaction before)
        if (document.getElementById('history-option')) {
            document.getElementById('history-option').selectedIndex = 0;
        }
        setSeconds(0);
        setPausing(true);
    };

    const onChangeHistory = e => {
        const { data } = transactionHistory[e.target.value].tj_ctnt;
        dispatch(Actions.selectTransaction(data));
        setSeconds(0);
        dispatch(Actions.isEditing(false));
    };

    const onViewBizLogicClick = () => {
        dispatch(Actions.runBizRule(docId));
        dispatch(Actions.getDocById(docId));
        API_EP.post(EndPointAPI.ENDPOINT.BP.GET_BTN, { mnuPgmId: AppConstants.MENU_BP.VIEW_BIZ }).then(res => {
            dispatch(FuseActions.getButtonAuth(res.data.data));
        });
        setBizViewOpen(true);
    };

    const onCloseViewBizLogic = () => {
        API_EP.post(EndPointAPI.ENDPOINT.BP.GET_BTN, { mnuPgmId: AppConstants.MENU_BP.VIEW_DOC }).then(res => {
            dispatch(FuseActions.getButtonAuth(res.data.data));
        });
        setBizViewOpen(false);
    };

    return (
        <>
            <div className="header-right">
                <div>
                    {fullscreen ? (
                        <button className="btn-fullscreen" title="Close">
                            <FullscreenExitIcon className="iconFullscreen" onClick={() => handleCloseFullScreen()} />
                        </button>
                    ) : (
                        <button className="btn-fullscreen" title="Fullscreen">
                            <FullscreenIcon className="iconFullscreen" onClick={() => handleFullScreen()} />
                        </button>
                    )}
                </div>
                <div>
                    <p className="wrapper-status">
                        <label className="doc-status">Doc Status: </label>
                        <span className={`custom-status status-${props.docInfo && props.docInfo.sts_cd}`}>
                            {props.docInfo && AppConstants.DOC_STATUS[props.docInfo.sts_cd]}
                        </span>
                    </p>
                    <p className="wrapper-label-highlight">
                        <label>Current edited time: </label>
                        <span>{seconds}</span>
                    </p>
                    <div className="group-btn">
                        <button className="group-btn-edit-save" disabled={editing} onClick={() => handleEdit()}>
                            EDIT
                        </button>
                        <button
                            id="btnPause"
                            disabled={!editing}
                            className="group-btn-edit-save"
                            onClick={() => handlePause()}
                        >
                            PAUSE
                        </button>
                        <button className="group-btn-edit-save" disabled={!editing} onClick={() => handleSave()}>
                            SAVE
                        </button>
                        <button className="group-btn-edit-save" onClick={onViewBizLogicClick}>
                            VIEW BIZ LOGIC
                        </button>
                    </div>

                    {transactionHistory.length > 1 && (
                        <div className="float-right">
                            <span className="font-bold">Transaction History:</span>
                            <select className="border" id="history-option" onChange={onChangeHistory}>
                                {transactionHistory.map((el, index) =>
                                    el.tp_nm === 'Original Extracted Data' ? (
                                        <option key={index} value={index}>
                                            {`${moment(moment.utc(el.cre_dt).toDate()).format('YYYY/MM/DD HH:mm:ss')} `}
                                            {`GMT${moment
                                                .utc(el.cre_dt)
                                                .local()
                                                .format('Z')} ~ `}
                                            {el.tp_nm}
                                        </option>
                                    ) : (
                                        <option key={index} value={index}>
                                            {`${moment(moment.utc(el.cre_dt).toDate()).format('YYYY/MM/DD HH:mm:ss')} `}
                                            {`GMT${moment
                                                .utc(el.cre_dt)
                                                .local()
                                                .format('Z')} ~ `}
                                            {`${el.cre_usr_id.toString().toUpperCase()} ~ `}
                                            Edited time: {el.tj_ctnt.timeSpend} ~ Type: {el.tp_nm}
                                        </option>
                                    ),
                                )}
                            </select>
                        </div>
                    )}
                </div>
            </div>
            <BizView history={props?.history} open={bizViewOpen} onClose={onCloseViewBizLogic} />
        </>
    );
};

export default withReducer('extracted', reducer)(HeaderDoc);

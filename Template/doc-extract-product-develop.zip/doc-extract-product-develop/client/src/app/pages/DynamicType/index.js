import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Typography } from '@material-ui/core';
import { NotInterestedOutlined } from '@material-ui/icons';
import { FusePageCarded } from '@fuse';
import PanelGroup from 'react-panelgroup';
import _ from '@lodash';

import withReducer from '../../store/withReducer';
import reducer from './store/reducers';

import DynamicTable from './DynamicTable';
import DynamicHeader from './DynamicHeader';

import * as Actions from './store/actions';

let hotReload = true;
const DynamicNotFound = () => {
    return (
        <div className="w-full h-full flex flex-col border-2 items-center justify-center">
            <NotInterestedOutlined color="action" />
            <Typography color="textSecondary" variant="subtitle1">
                Not found any dynamic type. Please create new item.
            </Typography>
        </div>
    );
};

const DynamicType = () => {
    const dispatch = useDispatch();

    const dynamicTypes = useSelector(({ dynamicType }) => dynamicType.dynamicType.dynamicTypes);
    const saveDynamicCallback = useSelector(({ dynamicType }) => dynamicType.dynamicType.saveDynamicCallback);
    const currentDynamicType = useSelector(({ dynamicType }) => dynamicType.dynamicType.currentDynamicType);

    const [searchText, setSearchText] = useState('');
    const [showDeleted, setShowDeleted] = useState('N');
    const [showNotFound, setShowNotFound] = useState(false);

    const onAddDynamicTypeClick = () => {
        const originDynamicType = {
            dyn_nm: '--/--',
            reg_expr_val: '',
            src_val: [],
        };
        dispatch(Actions.setCurrentDynamicType(originDynamicType));
    };

    const onSearchChange = text => setSearchText(text);

    const onDeletedChange = async flag => {
        const getFirstRow = dynamicTypes.find(item => item.delt_flg === flag);
        const validateFirstRow = getFirstRow || {};
        await dispatch(Actions.setCurrentDynamicType(validateFirstRow));
        setShowNotFound(!getFirstRow);
        setShowDeleted(flag);
    };

    // TODO: get data from server database
    useEffect(() => {
        dispatch(Actions.getDynamicType());
        dispatch(Actions.getCommonData());
        dispatch(Actions.getDocDefine());
    }, [dispatch]);

    // TODO: load first dynamic type in list
    useEffect(() => {
        if (dynamicTypes && dynamicTypes.length && hotReload) {
            hotReload = false;
            const getFirstRow = dynamicTypes.find(item => item.delt_flg === showDeleted);
            const validateFirstRow = getFirstRow || {};
            setShowNotFound(!getFirstRow);
            dispatch(Actions.setCurrentDynamicType(validateFirstRow));
        }
    }, [dynamicTypes]);

    // TODO: add save result to current dynamic type
    useEffect(async () => {
        if (saveDynamicCallback && saveDynamicCallback.dyn_id) {
            if (saveDynamicCallback.dyn_id && saveDynamicCallback.delt_flg !== showDeleted) hotReload = true;
            await dispatch(Actions.setCurrentDynamicType(saveDynamicCallback));
            await dispatch(Actions.getDynamicType());
        }
    }, [saveDynamicCallback]);

    return (
        <FusePageCarded
            classes={{
                content: 'flex',
                header: 'min-h-60 h-60 sm:h-60 sm:min-h-60',
                topBg: 'min-h-60 h-60 sm:h-60 sm:min-h-60',
                contentWrapper: 'pr-0 pl-0',
            }}
            header={<DynamicHeader onSearchChange={onSearchChange} onDeletedChange={onDeletedChange} />}
            content={
                <PanelGroup
                    panelWidths={[
                        {
                            size: (document.documentElement.clientWidth - 73) / 3,
                            minSize: 100,
                            resize: 'dynamic',
                        },
                        {
                            size: ((document.documentElement.clientWidth - 73) * 2) / 3,
                            minSize: 100,
                            resize: 'dynamic',
                        },
                    ]}
                >
                    <DynamicTable
                        tableName="dynamic-table"
                        search={searchText}
                        deleted={showDeleted}
                        onAddClick={onAddDynamicTypeClick}
                    />
                    {!showNotFound || (!currentDynamicType.dyn_id && !_.isEmpty(currentDynamicType)) ? (
                        <DynamicTable tableName="source-table" />
                    ) : (
                        <DynamicNotFound />
                    )}
                </PanelGroup>
            }
            innerScroll
        />
    );
};

export default withReducer('dynamicType', reducer)(DynamicType);

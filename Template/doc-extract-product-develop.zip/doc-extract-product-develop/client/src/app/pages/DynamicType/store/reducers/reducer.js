import * as Actions from '../actions';

const initialState = {
    dynamicTypes: [],
    commonData: [],
    documentDefine: [],
    currentDynamicType: {},
    saveDynamicCallback: {},
};

const dynamicReducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.DYNAMIC_TYPES:
            const parseDynamic =
                action.payload &&
                action.payload.map(item => ({
                    ...item,
                    src_val: JSON.parse(item.src_val),
                }));

            return {
                ...state,
                dynamicTypes: parseDynamic,
            };

        case Actions.COMMON_DATA:
            return {
                ...state,
                commonData: action.payload,
            };

        case Actions.DOCUMENT_DEFINE:
            const parseDocumentDefine =
                action.payload && action.payload.result.map(item => JSON.parse(item.dyn_tp_val));
            return {
                ...state,
                documentDefine: parseDocumentDefine,
            };

        case Actions.CRR_DYNAMIC_TYPE:
            return {
                ...state,
                currentDynamicType: action.dynamicType,
            };

        case Actions.ADD_DYNAMIC_TYPE:
        case Actions.UPDATE_DYNAMIC_TYPE:
            const callBackParse = action.payload && {
                ...action.payload,
                src_val: JSON.parse(action.payload.src_val),
            };
            return {
                ...state,
                saveDynamicCallback: callBackParse,
            };

        default:
            return state;
    }
};
export default dynamicReducer;

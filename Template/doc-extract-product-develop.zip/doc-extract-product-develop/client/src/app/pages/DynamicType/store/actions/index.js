import { API_EP } from '../../../../utils/commonAPI';
import { showMessage } from '../../../../store/actions/fuse/message.actions';
import { showError, checkResDataAPI } from '../../../../utils/utils';

export const DYNAMIC_TYPES = 'DYNAMIC_TYPES';
export const CRR_DYNAMIC_TYPE = 'CRR_DYNAMIC_TYPE';
export const COMMON_DATA = 'COMMON_DATA';
export const ADD_DYNAMIC_TYPE = 'ADD_DYNAMIC_TYPE';
export const UPDATE_DYNAMIC_TYPE = 'UPDATE_DYNAMIC_TYPE';
export const DOCUMENT_DEFINE = 'DOCUMENT_DEFINE';

export const callBackFunction = (dispatch, typeParam, urlParam, messageParam) =>
    urlParam
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: typeParam,
                    payload: response.data,
                });
                if (messageParam)
                    dispatch(
                        showMessage({
                            message: messageParam,
                            variant: 'success',
                        }),
                    );
            }
        })
        .catch(error => dispatch(showError(error)));

export const getCommonData = () => {
    const url = API_EP.post('/common-data/common-data-by-code');
    return dispatch => callBackFunction(dispatch, COMMON_DATA, url);
};

export const getDocDefine = () => {
    const url = API_EP.get('/doc-setting');
    return dispatch => callBackFunction(dispatch, DOCUMENT_DEFINE, url);
};

export const getDynamicType = () => {
    const url = API_EP.get('/dynamic-type/get-dynamic-type');
    return dispatch => callBackFunction(dispatch, DYNAMIC_TYPES, url);
};

export const addDynamicType = body => {
    const url = API_EP.post('/dynamic-type/add-dynamic-type', body);
    return dispatch => callBackFunction(dispatch, ADD_DYNAMIC_TYPE, url, 'Save successful!');
};

export const updateDynamicType = body => {
    const url = API_EP.put('/dynamic-type/update-dynamic-type', body);
    return dispatch => callBackFunction(dispatch, UPDATE_DYNAMIC_TYPE, url, 'Save successful!');
};

export const setCurrentDynamicType = dynamicType => dispatch =>
    dispatch({
        type: CRR_DYNAMIC_TYPE,
        dynamicType,
    });

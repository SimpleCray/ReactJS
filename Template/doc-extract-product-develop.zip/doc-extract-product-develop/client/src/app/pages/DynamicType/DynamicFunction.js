import { makeStyles } from '@material-ui/styles';
import { showMessage } from '../../store/actions/fuse/message.actions';

export const buttonCommonProps = {
    className: 'whitespace-no-wrap h-32',
    variant: 'contained',
    color: 'primary',
};

export const sourceHeader = [
    {
        id: 'regExp',
        align: 'left',
        disablePadding: false,
        label: 'Params',
        sort: true,
    },
    {
        id: 'source',
        align: 'left',
        disablePadding: false,
        label: 'Common data reference',
        sort: true,
    },
    {
        id: 'colNm',
        align: 'left',
        disablePadding: false,
        label: 'Column name',
        sort: true,
    },
];

export const docHeader = [
    {
        id: 'doc_nm',
        align: 'left',
        disablePadding: false,
        label: 'Document name',
        sort: true,
    },
];

export const dynamicHeader = [
    {
        id: 'dyn_nm',
        align: 'left',
        disablePadding: false,
        label: 'Dynamic type name',
        sort: true,
    },
];

export const getHeaderConstraint = label => {
    if (label === 'dynamic-table') return dynamicHeader;
    if (label === 'source-table') return sourceHeader;
    return docHeader;
};

export const useStyles = makeStyles({
    textFieldWidth: {
        width: '200px',
    },
    panelContainer: {
        width: '100%',
        height: '100%',
        paddingBottom: 50,
    },
    listContainer: {
        marginTop: 10,
        maxHeight: 1000,
        overflow: 'auto',
    },
    saveContainer: {
        width: '100%',
        height: 50,
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
        position: 'relative',
        bottom: 0,
        right: 0,
    },
});

export const textFieldCommonProps = {
    fullWidth: true,
    size: 'small',
    autoComplete: 'off',
    variant: 'outlined',
};

export const autoCompleteProps = {
    fullWidth: true,
    className: 'flex flex-1',
    size: 'small',
};

export const addMessage = (dispatch, text, type) => {
    return dispatch(
        showMessage({
            message: text,
            variant: type || 'warning',
        }),
    );
};

export const isSameArray = (a, b) => {
    const AeuqalB = a.length === b.length;
    const AinB = !a.some(item => !b.includes(item));
    const BinA = !b.some(item => !a.includes(item));
    return AeuqalB && AinB && BinA;
};

export const isContainArray = (parent, child) => {
    const parentLargerChild = parent.length >= child.length;
    const parentContainChild = !child.some(item => !parent.includes(item));
    return parentLargerChild && parentContainChild;
};

export const containDocument = (parent, child) => {
    const getDocumentId = parent.map(item => item.doc_tp_id);
    return getDocumentId.includes(child.doc_tp_id);
};

import React from 'react';
import { useSelector } from 'react-redux';
import { ThemeProvider } from '@material-ui/styles';
import { Paper, Input, FormControlLabel, Checkbox } from '@material-ui/core';
import { Search } from '@material-ui/icons';

const DynamicHeader = props => {
    const mainTheme = useSelector(({ fuse }) => fuse.settings.mainTheme);

    return (
        <div className="flex w-full items-center">
            <div className="flex-none px-15 mx-3">
                <ThemeProvider theme={mainTheme}>
                    <Paper className="flex items-center max-w-600 px-8 py-4 ml-2 rounded-8" elevation={1}>
                        <Search className="mr-8" color="action" />
                        <Input
                            placeholder="Search dynamic type"
                            className="flex flex-1"
                            disableUnderline
                            fullWidth
                            onChange={e => props.onSearchChange(e.target.value)}
                        />
                    </Paper>
                </ThemeProvider>
            </div>
            <FormControlLabel
                label="Deleted"
                control={<Checkbox color="secondary" />}
                onChange={e => props.onDeletedChange(e.target.checked ? 'Y' : 'N')}
            />
        </div>
    );
};

export default DynamicHeader;

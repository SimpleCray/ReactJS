import { combineReducers } from 'redux';
import dynamicType from './reducer';

const reducer = combineReducers({
    dynamicType,
});

export default reducer;

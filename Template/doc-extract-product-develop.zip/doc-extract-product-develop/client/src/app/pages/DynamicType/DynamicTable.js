import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Table, TableBody, TableCell, TableRow, TableHead, TextField, Paper, MenuItem } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { FuseScrollbars } from '@fuse';
import { openDialog } from '../../store/actions/fuse/dialog.actions';
import buttons from '../../utils/constants/buttonConstants.json';
import AppConstants from 'app/utils/appConstants';
import _ from '@lodash';

import CustomButton from '../../components/Button';

import DynamicContent from './DynamicContent';

import * as Actions from './store/actions';
import * as Functions from './DynamicFunction';
import * as CommonDataFunctions from 'app/pages/CommonData/commonDataFunction';

const StyledTableCell = withStyles(theme => ({
    head: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
    body: {
        fontSize: 14,
    },
}))(TableCell);

const DynamicTable = props => {
    const classes = Functions.useStyles();
    const dispatch = useDispatch();

    const headerConstraint = Functions.getHeaderConstraint(props?.tableName);
    const isDynamicTable = props?.tableName === 'dynamic-table';

    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const dynamicTypes = useSelector(({ dynamicType }) => dynamicType.dynamicType.dynamicTypes);
    const commonData = useSelector(({ dynamicType }) => dynamicType.dynamicType.commonData);
    const documentDefine = useSelector(({ dynamicType }) => dynamicType.dynamicType.documentDefine);
    const currentDynamicType = useSelector(({ dynamicType }) => dynamicType.dynamicType.currentDynamicType);
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));

    const [tableData, setTableData] = useState([]);

    const onRowClick = rowItemParam => {
        if (isDynamicTable && rowItemParam.dyn_id && rowItemParam.dyn_id !== currentDynamicType.dyn_id) {
            if (!currentDynamicType.dyn_id)
                dispatch(
                    openDialog('Do you want cancel without saving?', '', 'Confirm', () => {
                        dispatch(Actions.setCurrentDynamicType(rowItemParam));
                    }),
                );
            else dispatch(Actions.setCurrentDynamicType(rowItemParam));
        }
    };

    const onRowChange = (value, rowIndexParam, key) => {
        const changedRow = {
            ...tableData[rowIndexParam],
            [key]: value,
        };
        const updateTableData = tableData.map((item, index) =>
            index === rowIndexParam ? { ...changedRow } : { ...item },
        );
        const updateCurrentDynamicType = { ...currentDynamicType, src_val: updateTableData };
        dispatch(Actions.setCurrentDynamicType(updateCurrentDynamicType));
    };

    const saveValidation = () => {
        // TODO: validate empty field
        const isNameEmpty = currentDynamicType.dyn_nm.length === 0;
        const isRegexEmpty = currentDynamicType.reg_expr_val.length === 0;
        const isSourceEmpty = currentDynamicType.src_val.some(
            item => _.isEmpty(item.source) || !item.colNm.length || !item.regExp.length,
        );

        // TODO: validate duplicate dynamic name
        const isDuplicateName = dynamicTypes.some(
            item =>
                currentDynamicType &&
                currentDynamicType.dyn_id !== item.dyn_id &&
                currentDynamicType.dyn_nm === item.dyn_nm,
        );
        const isValid = !isNameEmpty && !isRegexEmpty && !isSourceEmpty && !isDuplicateName;
        if (!isValid)
            Functions.addMessage(dispatch, isDuplicateName ? 'Duplicate name error' : 'Empty component error', 'error');
        return isValid;
    };

    const onSaveClick = () => {
        if (currentDynamicType.delt_flg === 'Y') {
            const dynamicTypeUsed = documentDefine.some(
                item => item && Object.values(item).some(el => el.dyn_id === currentDynamicType.dyn_id),
            );
            if (dynamicTypeUsed) return Functions.addMessage(dispatch, 'Dynamic type is used', 'warning');
        }
        if (saveValidation()) {
            const addUserInfoData = {
                ...currentDynamicType,
                src_val: JSON.stringify(currentDynamicType.src_val),
            };
            if (!currentDynamicType.dyn_id)
                dispatch(
                    Actions.addDynamicType({
                        ...addUserInfoData,
                        cre_usr_id: JSON.parse(localStorage.getItem('userInfo')).usrId,
                        upd_usr_id: JSON.parse(localStorage.getItem('userInfo')).usrId,
                    }),
                );
            else
                dispatch(
                    Actions.updateDynamicType({
                        ...addUserInfoData,
                        upd_usr_id: JSON.parse(localStorage.getItem('userInfo')).usrId,
                    }),
                );
        }
    };

    const onCancelClick = () => {
        if (currentDynamicType.dyn_id) {
            const restoreDynamicType = dynamicTypes.find(item => item.dy_id === dynamicTypes.dyn_id);
            dispatch(Actions.setCurrentDynamicType(restoreDynamicType));
        } else dispatch(Actions.setCurrentDynamicType(dynamicTypes[0]));
    };

    // TODO: load current dynamic type data to table body
    useEffect(() => {
        if (!_.isEmpty(currentDynamicType)) {
            if (isDynamicTable && dynamicTypes) setTableData(dynamicTypes);
            if (!isDynamicTable && currentDynamicType.src_val) setTableData(currentDynamicType.src_val);
        }
    }, [currentDynamicType, dynamicTypes]);

    return (
        <div className="w-full flex flex-col border-2 p-1 mb-2 mt-2 mr-1 ml-1 column">
            <FuseScrollbars className="flex-grow">
                {props?.tableName === 'source-table' && <DynamicContent />}
                <Table stickyHeader className="w-full cursor-pointer" size="small">
                    <TableHead>
                        <TableRow>
                            {headerConstraint.map(headerItem => (
                                <StyledTableCell key={headerItem.id} className="text-left hidden sm:table-cell ">
                                    {headerItem.label}
                                </StyledTableCell>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {(isDynamicTable && !currentDynamicType.dyn_id ? [currentDynamicType, ...tableData] : tableData)
                            .filter(rowItem => {
                                const matchDeletedFlag = rowItem.delt_flg === props?.deleted;
                                const matchSearch =
                                    !props?.search ||
                                    rowItem.dyn_nm.toLowerCase().includes(props?.search.toLowerCase());
                                return !rowItem.dyn_id || (matchDeletedFlag && matchSearch);
                            })
                            .map((rowItem, rowIndex) => {
                                const isSelected = !rowItem.dyn_id || rowItem.dyn_id === currentDynamicType.dyn_id;
                                return (
                                    <TableRow
                                        key={rowItem.dyn_id}
                                        hover={isDynamicTable}
                                        selected={isDynamicTable && isSelected}
                                        onClick={() => onRowClick(rowItem)}
                                    >
                                        {headerConstraint.map(headerItem => {
                                            const key = `${rowItem.dyn_id}${headerItem.id}`;

                                            if (headerItem.id === 'source') {
                                                const filterCommonByRole = CommonDataFunctions.getCommonByRole(
                                                    commonData,
                                                    userInfo,
                                                );

                                                const getValue = filterCommonByRole.find(
                                                    item => item.com_dat_id === rowItem.source.com_dat_id,
                                                );

                                                return (
                                                    <TableCell
                                                        key={key}
                                                        className="text-left hidden sm:table-cell w-5/12"
                                                    >
                                                        <Autocomplete
                                                            {...Functions.autoCompleteProps}
                                                            disableClearable
                                                            options={filterCommonByRole || []}
                                                            getOptionLabel={option => option.com_dat_nm || ''}
                                                            renderInput={params => (
                                                                <TextField {...params} variant="outlined" />
                                                            )}
                                                            onChange={(e, value) =>
                                                                onRowChange(value, rowIndex, 'source')
                                                            }
                                                            value={getValue || ''}
                                                        />
                                                    </TableCell>
                                                );
                                            }

                                            if (headerItem.id === 'colNm') {
                                                const findCommonValue = commonData.find(
                                                    item =>
                                                        !_.isEmpty(rowItem.source) &&
                                                        item.com_dat_id === rowItem.source.com_dat_id,
                                                );
                                                const columnNames = findCommonValue
                                                    ? findCommonValue.com_dat_val.header
                                                    : [];

                                                return (
                                                    <TableCell
                                                        key={key}
                                                        className="text-left hidden sm:table-cell w-4/12"
                                                    >
                                                        <TextField
                                                            {...Functions.textFieldCommonProps}
                                                            select
                                                            value={rowItem.colNm}
                                                            onChange={e =>
                                                                onRowChange(e.target.value, rowIndex, 'colNm')
                                                            }
                                                        >
                                                            {columnNames.slice(0, -1).map(subItem => (
                                                                <MenuItem key={subItem} value={subItem}>
                                                                    {subItem}
                                                                </MenuItem>
                                                            ))}
                                                        </TextField>
                                                    </TableCell>
                                                );
                                            }

                                            return (
                                                <TableCell key={key} className="text-left hidden sm:table-cell w-3/12">
                                                    {rowItem[headerItem.id]}
                                                </TableCell>
                                            );
                                        })}
                                    </TableRow>
                                );
                            })}
                    </TableBody>
                </Table>
            </FuseScrollbars>

            <div className="flex justify-end item-center w-full">
                {props?.tableName === 'dynamic-table' && btnList.some(btn => btn.BTN_NO === buttons.BTN_ADD) && (
                    <CustomButton
                        {...Functions.buttonCommonProps}
                        onClick={props?.onAddClick}
                        disabled={props?.deleted === 'Y'}
                    >
                        ADD
                    </CustomButton>
                )}
            </div>

            {props?.tableName === 'source-table' && (
                <Paper elevation={0} className={classes.saveContainer}>
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_CANCEL) && (
                        <CustomButton {...Functions.buttonCommonProps} onClick={onCancelClick}>
                            CANCEL
                        </CustomButton>
                    )}
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_SAVE) && (
                        <CustomButton {...Functions.buttonCommonProps} onClick={onSaveClick}>
                            SAVE
                        </CustomButton>
                    )}
                </Paper>
            )}
        </div>
    );
};

export default DynamicTable;

import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { TextField, Checkbox, FormControlLabel } from '@material-ui/core';

import * as Functions from './DynamicFunction';
import * as Actions from './store/actions';

const DynamicContent = props => {
    const dispatch = useDispatch();

    const currentDynamicType = useSelector(({ dynamicType }) => dynamicType.dynamicType.currentDynamicType);

    const onNameChange = e => {
        const updateCurrentDynamicType = { ...currentDynamicType, dyn_nm: e.target.value };
        dispatch(Actions.setCurrentDynamicType(updateCurrentDynamicType));
    };

    const onRegexChange = value => {
        // TODO: find regex pattern
        const regex = new RegExp('\\{{[\\w!@#$%^&*!-=+,.//]*\\}}', 'g');
        const matchValue = value.match(regex);
        const replaceValue = matchValue ? matchValue.map(item => item.replace(/[\{\}]/g, '')) : [];
        const uniqueValue = [...new Set(replaceValue)];
        const mapToSource = uniqueValue.map(item => {
            const findOldCommon = currentDynamicType.src_val.find(common => common.regExp === item);
            return {
                regExp: item,
                source: findOldCommon ? findOldCommon.source : {},
                colNm: findOldCommon ? findOldCommon.colNm : '',
            };
        });

        // TODO: update current dynamic name data
        const updateCurrentDynamicType = { ...currentDynamicType, reg_expr_val: value, src_val: mapToSource };
        dispatch(Actions.setCurrentDynamicType(updateCurrentDynamicType));
    };

    const onActiveChange = e => {
        const parseFlag = e.target.checked ? 'N' : 'Y';
        dispatch(Actions.setCurrentDynamicType({ ...currentDynamicType, delt_flg: parseFlag }));
    };

    return (
        <div className="w-full flex flex-col p-1 mb-2 mt-2 mr-1 ml-1 column">
            <div className="flex flex-row my-5">
                <TextField
                    {...Functions.textFieldCommonProps}
                    className="w-6/12 mr-5"
                    label="Name"
                    value={currentDynamicType.dyn_nm || ''}
                    onChange={onNameChange}
                />
                <FormControlLabel
                    label="Active"
                    control={
                        <Checkbox
                            checked={!currentDynamicType.dyn_id || currentDynamicType.delt_flg === 'N'}
                            color="secondary"
                        />
                    }
                    disabled={!currentDynamicType.dyn_id}
                    onChange={onActiveChange}
                />
            </div>

            <TextField
                label="Regular expression"
                {...Functions.textFieldCommonProps}
                value={currentDynamicType.reg_expr_val || ''}
                onChange={e => onRegexChange(e.target.value)}
            />
        </div>
    );
};

export default DynamicContent;

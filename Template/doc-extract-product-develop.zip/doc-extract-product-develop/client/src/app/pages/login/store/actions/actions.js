import { API_EP } from 'app/utils/commonAPI';
import { checkResDataAPI } from 'app/utils/utils';
import EndPointAPI from 'app/utils/endPointAPI';
import { showMessage } from 'app/store/actions';
import { loginWithBP } from 'app/components/auth/store/actions';
import * as actionTypes from '../constants';

export const loginBluePrint = data => dispatch => {
    API_EP.post(EndPointAPI.ENDPOINT.BP.BP_LOGIN, data)
        .then(async response => {
            if (checkResDataAPI(response)) {
                const { userInfo, token } = response.data;
                if (userInfo) {
                    await dispatch(loginWithBP(token, false));
                    dispatch({
                        type: actionTypes.BP_LOGIN_SUCCESS,
                    });
                } else {
                    dispatch({
                        type: actionTypes.BP_LOGIN_FAILED,
                        payload: { message: 'Wrong credentials!' },
                    });
                }
            }
        })
        .catch(err => {
            dispatch(showMessage({ message: `Login Failed! Error: ${err.message}`, variant: 'error' }));
        });
};

export const clearStore = () => dispatch => {
    dispatch({
        type: actionTypes.CLEAR_STORE,
    });
};

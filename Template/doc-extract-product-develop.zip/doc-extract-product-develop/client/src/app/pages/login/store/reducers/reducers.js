import * as Actions from '../constants';

const initialState = {
    loginState: false,
    loginMessage: null,
};

const loginReducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.BP_LOGIN_SUCCESS:
            return {
                ...state,
                loginState: true,
            };
        case Actions.BP_LOGIN_FAILED:
            return {
                ...state,
                loginState: false,
                loginMessage: action.payload.message,
            };
        case Actions.CLEAR_STORE:
            return {
                initialState,
            };
        default:
            return {
                ...state,
            };
    }
};

export default loginReducer;

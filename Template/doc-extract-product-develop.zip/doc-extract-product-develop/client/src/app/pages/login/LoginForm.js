/* eslint-disable prettier/prettier */
import React, { useEffect, useRef, useState } from 'react';
import { Button, InputAdornment, Tooltip, Typography, TextField } from '@material-ui/core';
import { AccountCircleOutlined, VisibilityOutlined, VisibilityOffOutlined } from '@material-ui/icons';
import { FuseAnimate, TextFieldFormsy } from '@fuse';
import Formsy from 'formsy-react';
import { useDispatch, useSelector } from 'react-redux';
import history from '@history';
import { Alert } from '@material-ui/lab';
import AppConstants from 'app/utils/appConstants';
import * as Actions from './store/actions/actions';

const textFieldProps = {
    className: 'mb-16 mr-0 pl-o',
    variant: 'outlined',
    required: true,
};

const LoginForm = () => {
    const dispatch = useDispatch();
    const formRef = useRef(null);

    const loginState = useSelector(({ loginReducer }) => loginReducer.loginState);
    const loginMessage = useSelector(({ loginReducer }) => loginReducer.loginMessage);

    const [isFormValid, setIsFormValid] = useState(false);
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        if (localStorage.getItem(AppConstants.BP_USER_INFO) || loginState) {
            history.push(AppConstants.VIEW_DOC_URL);
            return dispatch(Actions.clearStore());
        }
    }, [loginState]);

    const handleSubmit = data => dispatch(Actions.loginBluePrint(data));

    return (
        <div className="w-full">
            {loginMessage && (
                <FuseAnimate animation="transition.slideUpIn" delay={50}>
                    <Alert className="mb-32 -mt-5" severity="error">
                        {loginMessage}
                    </Alert>
                </FuseAnimate>
            )}
            <Formsy
                onValidSubmit={handleSubmit}
                onValid={() => setIsFormValid(true)}
                onInvalid={() => setIsFormValid(false)}
                ref={formRef}
                className="flex flex-col justify-center w-full"
            >
                <TextFieldFormsy
                    {...textFieldProps}
                    type="text"
                    name="usrId"
                    placeholder="Username"
                    InputProps={{
                        startAdornment: (
                            <InputAdornment className="mr-5" position="end">
                                <AccountCircleOutlined fontSize="small" color="action" />
                            </InputAdornment>
                        ),
                    }}
                />

                <TextFieldFormsy
                    {...textFieldProps}
                    type={visible ? 'text' : 'password'}
                    name="usrPwd"
                    placeholder="Password"
                    error="true"
                    InputProps={{
                        startAdornment: (
                            <InputAdornment className="mr-5" position="end">
                                <Tooltip
                                    className="cursor-pointer"
                                    title={`Click to ${visible ? 'hide' : 'show'} password`}
                                    onClick={() => setVisible(!visible)}
                                >
                                    {visible ? (
                                        <VisibilityOutlined fontSize="small" color="action" />
                                    ) : (
                                        <VisibilityOffOutlined fontSize="small" color="action" />
                                    )}
                                </Tooltip>
                            </InputAdornment>
                        ),
                    }}
                />

                <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    className="w-full mx-auto mt-16 normal-case"
                    disabled={!isFormValid}
                    value="legacy"
                >
                    Login
                </Button>
            </Formsy>
        </div>
    );
};

export default LoginForm;

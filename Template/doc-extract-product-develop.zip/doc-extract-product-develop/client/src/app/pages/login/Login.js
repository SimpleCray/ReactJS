/* eslint-disable prefer-template */
import React from 'react';
import { Card, CardContent, Typography } from '@material-ui/core';
import { darken } from '@material-ui/core/styles/colorManipulator';
import { FuseAnimate } from '@fuse';
import clsx from 'clsx';
import { makeStyles } from '@material-ui/styles';
import withReducer from 'app/store/withReducer';
import loginReducer from './store/reducers/reducers';
import LoginForm from './LoginForm';

const useStyles = makeStyles(theme => ({
    root: {
        background:
            'linear-gradient(to right, ' +
            theme.palette.primary.dark +
            ' 0%, ' +
            darken(theme.palette.primary.dark, 0.5) +
            ' 100%)',
        color: theme.palette.primary.contrastText,
        backgroundImage: `url('assets/images/backgrounds/Login-BG2.jpg')`,
        backgroundRepeat: true,
    },
    cardContainer: {
        backgroundColor: theme.palette.primary,
    },
}));

const Login = () => {
    const classes = useStyles();

    return (
        <div className={clsx(classes.root, 'bg-cover flex flex-col justify-center flex-1 p-24 md:flex-row md:p-0')}>
            <div className="flex flex-col flex-grow-0 items-center text-white p-16 text-center md:p-128  md:flex-1">
                <Typography variant="h4" className="font-extrabold">
                    <div style={{ textShadow: '1px 3px 5px black' }}>Welcome to SHINE!</div>
                </Typography>
                <Typography variant="subtitle1" color="action" className="max-w-512 mb-20 mt-5 font-bold float-right">
                    <div style={{ textShadow: '1px 2px 3px black' }}>Change The Way We Do Business</div>
                </Typography>
                <br />
                <FuseAnimate animation="transition.slideUpIn" delay={0}>
                    <React.Fragment>
                        <Card className="w-full max-w-400">
                            <div style={{ backgroundColor: '#3c4252' }} className="w-full max-w-400 pt-3 pb-5">
                                <img
                                    className="logo-icon w-60 mt-5 rounded-lg mb-3"
                                    src="assets/images/logos/shine_logo.png"
                                    alt="logo"
                                />
                            </div>
                            <CardContent className="flex flex-col items-center justify-center rounded-lg p-48 pt-28">
                                <Typography
                                    style={{ color: '#3c4252' }}
                                    variant="subtitle1"
                                    className="mb-24 font-bold"
                                >
                                    LOGIN TO YOUR ACCOUNT
                                </Typography>
                                <LoginForm />

                                <a
                                    href="https://www.cyberlogitec.com"
                                    className="flex flex-col items-center justify-center pt-24 cursor-pointer"
                                    target="blank"
                                >
                                    <Typography variant="body1" className="text-gray font-medium mt-24 pb-12">
                                        Powered by CyberLogitec
                                    </Typography>
                                </a>
                            </CardContent>
                        </Card>
                    </React.Fragment>
                </FuseAnimate>
            </div>
        </div>
    );
};

export default withReducer('loginReducer', loginReducer)(Login);

/* eslint-disable no-shadow */
/* eslint-disable no-plusplus */
/* eslint-disable no-param-reassign */
/* eslint-disable camelcase */
/* eslint-disable prettier/prettier */
/* eslint-disable react/prop-types */
/* eslint-disable no-unused-expressions */
/* eslint-disable import/no-unresolved */
import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TablePagination, TableRow, Checkbox } from '@material-ui/core';
import { FuseScrollbars } from '@fuse';
import _ from '@lodash';
import { makeStyles } from '@material-ui/core/styles';
import { useDispatch, useSelector } from 'react-redux';
import * as TableFnc from 'app/utils/tableFunctions';
import buttons from 'app/utils/constants/buttonConstants.json';
import Button from 'app/components/Button';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import FieldTableHead from './FieldTableHead';
import * as Actions from './store/actions';

const useStyles = makeStyles({
    tableRow: {
        '&$hover:hover': {
            backgroundColor: '#f5f5f5',
        },
        '&$selected, &$selected:hover': {
            backgroundColor: '#ebf7fd',
        },
    },
    hover: {},
    selected: {},
});

function CompanyFieldTable() {
    const classes = useStyles();
    const dispatch = useDispatch();
    const comDocSetupData = useSelector(({ comDocSetup }) => comDocSetup.getResults);
    const selectedItem = useSelector(({ comDocSetup }) => comDocSetup.getResults);

    const [filterDocumentFields, setFilterDocumentFields] = useState([]);
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);

    const [orderDocField, setOrderDocField] = useState({
        direction: 'asc',
        columnId: null,
    });

    const [rowChange, setRowChange] = useState([]);
    // store data of selected company document
    useEffect(() => {
        setRowChange([]);
    }, [selectedItem.selectedDocument]);
    // change display when input search bar of company field table
    useEffect(() => {
        if (comDocSetupData.allDocumentFields) {
            const filterField = _.filter(
                comDocSetupData.allDocumentFields,
                item =>
                    item.fld_nm.toLowerCase().includes(comDocSetupData.searchText.toLowerCase()) &&
                    item.deleteFlag === comDocSetupData.fieldDeltFlg,
            );
            filterField.map(item => {
                item.ord_no = item.orderNumber;
            })
            setFilterDocumentFields(filterField);
        }
        dispatch(Actions.setPageField(0));
    }, [comDocSetupData.allDocumentFields, comDocSetupData.searchText, comDocSetupData.fieldDeltFlg]);

    function handleChange(row, value, isUsed){
        const cloneRow = {...row};
        const cloneRowChange = [...rowChange];
        isUsed ? value ? cloneRow.deleteFlag = "N" : cloneRow.deleteFlag = "Y"  
            :cloneRow.ord_no = value;
        if(cloneRowChange.length > 0){
            const indexField = cloneRowChange.findIndex(function(item, i){
                return item.doc_fld_id === cloneRow.doc_fld_id
            });
            indexField !== -1 ? cloneRowChange[indexField] = cloneRow : cloneRowChange.push(cloneRow);
        }else{
            cloneRowChange.push(cloneRow);
        }
        setRowChange(cloneRowChange);
    }

    function canBeSave() {
        return rowChange.length > 0;
    }

    function handleSave() {
        let validateOrderNo = true;
        rowChange.map(item => {
            if(!(/^\d+$/.test(item.ord_no))){
                validateOrderNo = false;
            }
        })
        if(validateOrderNo){
            dispatch(Actions.saveFieldInfo(rowChange, selectedItem.selectedDocument, JSON.parse(localStorage.getItem('userInfo')).usrId));
            setRowChange([]);
        }else{
            dispatch(
                showMessage({
                    message: 'DisplayOrder only accept numbers',
                    variant: 'error',
                }),
            );
        }
    }

    return (
        <div className="w-6/12 flex flex-col border-2 p-1 mb-2 mt-2 mr-1">
            <FuseScrollbars className="flex-grow overflow-x-auto">
                <Table stickyHeader aria-label="sticky table" className="w-full" size="small">
                    <FieldTableHead
                        order={orderDocField}
                        onRequestSort={(event, property) =>
                            TableFnc.handleRequestSort(event, property, orderDocField, setOrderDocField)
                        }
                    />

                    <TableBody>
                        {_.orderBy(
                            _.orderBy(
                                filterDocumentFields,
                                [item => TableFnc.handleOrderType(item, 'orderNumber')],
                                ['asc'],
                            ),
                            [item => TableFnc.handleOrderType(item, orderDocField.columnId)],
                            [orderDocField.direction],                           
                        )
                            .slice(
                                comDocSetupData.pageField * comDocSetupData.rowsPerPageField,
                                comDocSetupData.pageField * comDocSetupData.rowsPerPageField +
                                    comDocSetupData.rowsPerPageField,
                            )
                            .map(n => {
                                const isSelected = n.deleteFlag === 'N';
                                return (
                                    <TableRow
                                        classes={{ hover: classes.hover, selected: classes.selected }}
                                        className={`${classes.tableRow} h-54 `}
                                        // hover
                                        role="checkbox"
                                        aria-checked={isSelected}
                                        tabIndex={-1}
                                        key={n.doc_fld_id}
                                    >
                                        <TableCell component="th" scope="row">
                                            {n.fld_nm}
                                        </TableCell>

                                        <TableCell className="w-48 px-4 sm:px-12" padding="checkbox">
                                            <Checkbox defaultChecked={isSelected} onChange={e => handleChange(n, e.target.checked, true)}/>
                                        </TableCell>

                                        <TableCell component="th" scope="row">
                                            <input defaultValue={n.orderNumber} onChange={e => handleChange(n, e.target.value, false)}></input>
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                    </TableBody>
                </Table>
            </FuseScrollbars>

            <div className="w-full flex flex-row">
                <div className="w-8/12 justify-start flex">
                    <TablePagination
                        component="div"
                        labelRowsPerPage=""
                        count={filterDocumentFields.length}
                        rowsPerPageOptions={[10, 20, 50]}
                        rowsPerPage={comDocSetupData.rowsPerPageField}
                        page={comDocSetupData.pageField}
                        backIconButtonProps={{
                            'aria-label': 'Previous Page',
                        }}
                        nextIconButtonProps={{
                            'aria-label': 'Next Page',
                        }}
                        onChangePage={(event, page) => dispatch(Actions.setPageField(page))}
                        onChangeRowsPerPage={event => {
                            TableFnc.handleChangeRowsPerPage(
                                event,
                                comDocSetupData.pageField,
                                filterDocumentFields,
                                pageNumber => dispatch(Actions.setPageField(pageNumber)),
                                rowsPerPageNumber => dispatch(Actions.setRowsPerPageField(rowsPerPageNumber)),
                            );
                        }}
                    />
                </div>
                <div className="w-4/12 justify-end flex">
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_SAVE) && (
                        <Button onClick={handleSave} disabled={!canBeSave()}>
                            <span className="hidden sm:flex">Save</span>
                        </Button>
                    )}
                </div>
            </div>
        </div>
    );
}

export default CompanyFieldTable;

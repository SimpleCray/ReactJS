/* eslint-disable indent */
/* eslint-disable array-callback-return */
/* eslint-disable arrow-body-style */
/* eslint-disable func-names */
/* eslint-disable no-unused-expressions */
/* eslint-disable react/prop-types */
/* eslint-disable import/no-unresolved */
import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TablePagination, TableRow } from '@material-ui/core';
import { FuseScrollbars } from '@fuse';
import _ from '@lodash';
import { useDispatch, useSelector } from 'react-redux';
import { makeStyles } from '@material-ui/core/styles';

import * as TableFnc from 'app/utils/tableFunctions';

import AppConstants from 'app/utils/appConstants';
import DocTableHead from './DocTableHead';
import * as Actions from './store/actions';

const useStyles = makeStyles({
    tableRow: {
        '&$hover:hover': {
            backgroundColor: '#f5f5f5',
        },
        '&$selected, &$selected:hover': {
            backgroundColor: '#ebf7fd',
        },
    },
    hover: {},
    selected: {},
});

function CompanyDocTable(props) {
    const classes = useStyles();
    const dispatch = useDispatch();
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));
    const comDocSetupData = useSelector(({ comDocSetup }) => comDocSetup.getResults);

    const [dataCompanyDocuments, setDataCompanyDocuments] = useState(comDocSetupData.companyDocuments);
    const [selectedRow, setSelectedRow] = useState('');

    const [orderComDoc, setOrderComDoc] = useState({
        direction: 'asc',
        columnId: null,
    });

    useEffect(() => {
        dispatch(Actions.resetDocumentFields());
    }, []);

    // set sorted data for company document table
    useEffect(() => {
        const listSortedData = comDocSetupData.companyDocuments.sort(function(a, b) {
            if (a.co_cd > b.co_cd) return 1;
            if (b.co_cd > a.co_cd) return -1;
            return 0;
        });
        const listDataForCompany =
            userInfo.usrId === 'admin'
                ? listSortedData
                : listSortedData.filter(item => JSON.parse(localStorage.getItem('userInfo')).coCd === item.co_cd);

        setDataCompanyDocuments(listDataForCompany);
        setSelectedRow('');
    }, [comDocSetupData.companyDocuments]);

    function handleClick(item) {
        dispatch(Actions.setSelectedDocument(item));
        setSelectedRow(`${item.co_cd}-${item.loc_cd}-${item.documents.doc_tp_id}`);
        dispatch(Actions.getAllDocumentFields(item.loc_id, item.doc_tp_id));
        selectedRow !== `${item.co_cd}-${item.loc_cd}-${item.documents.doc_tp_id}`;
        props.setIsChanged(false);
    }

    return (
        <div className="w-6/12 flex flex-col border-2 p-1 mb-2 mt-2 mr-1">
            <FuseScrollbars className="flex-grow overflow-x-auto">
                <Table stickyHeader aria-label="sticky table" className="w-full" size="small">
                    <DocTableHead
                        order={orderComDoc}
                        onRequestSort={(event, property) =>
                            TableFnc.handleRequestSort(event, property, orderComDoc, setOrderComDoc)
                        }
                        userInfo={userInfo}
                    />

                    <TableBody>
                        {_.orderBy(dataCompanyDocuments, [orderComDoc.columnId], [orderComDoc.direction])
                            .slice(
                                comDocSetupData.pageDocument * comDocSetupData.rowsPerPageDocument,
                                comDocSetupData.pageDocument * comDocSetupData.rowsPerPageDocument +
                                    comDocSetupData.rowsPerPageDocument,
                            )
                            .map(n => {
                                return (
                                    <TableRow
                                        classes={{ hover: classes.hover, selected: classes.selected }}
                                        className={`${classes.tableRow} h-54 cursor-pointer`}
                                        hover
                                        role="checkbox"
                                        tabIndex={-1}
                                        key={`${n.co_cd}-${n.loc_cd}-${n.documents.doc_tp_id}`}
                                        selected={selectedRow === `${n.co_cd}-${n.loc_cd}-${n.documents.doc_tp_id}`}
                                        onClick={() => {
                                            handleClick(n);
                                        }}
                                    >
                                        {userInfo.usrId === 'admin' ? (
                                            <TableCell component="th" scope="row">
                                                {comDocSetupData.companies.map(company =>
                                                    company.co_cd === n.co_cd ? company.coNm : '',
                                                )}
                                            </TableCell>
                                        ) : (
                                            <></>
                                        )}

                                        <TableCell className="truncate" component="th" scope="row">
                                            {n.loc_nm}
                                        </TableCell>

                                        <TableCell className="truncate" component="th" scope="row">
                                            {n.documents.doc_nm}
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                    </TableBody>
                </Table>
            </FuseScrollbars>

            <div className="w-full flex flex-row">
                <div className="w-6/12 justify-start flex">
                    <TablePagination
                        component="div"
                        labelRowsPerPage=""
                        count={dataCompanyDocuments.length}
                        rowsPerPageOptions={[10, 20, 50]}
                        rowsPerPage={comDocSetupData.rowsPerPageDocument}
                        page={comDocSetupData.pageDocument}
                        backIconButtonProps={{
                            'aria-label': 'Previous Page',
                        }}
                        nextIconButtonProps={{
                            'aria-label': 'Next Page',
                        }}
                        onChangePage={(event, page) => {
                            dispatch(Actions.setPageDocument(page));
                        }}
                        onChangeRowsPerPage={event => {
                            TableFnc.handleChangeRowsPerPage(
                                event,
                                comDocSetupData.pageDocument,
                                dataCompanyDocuments,
                                pageNumber => dispatch(Actions.setPageDocument(pageNumber)),
                                rowsPerPageNumber => dispatch(Actions.setRowsPerPageDocument(rowsPerPageNumber)),
                            );
                        }}
                    />
                </div>
            </div>
        </div>
    );
}

export default CompanyDocTable;

/* eslint-disable react/prop-types */
import React from 'react';
import { TableHead, TableSortLabel, TableCell, TableRow, Tooltip } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(theme => ({
    tableHead: {
        backgroundColor: theme.palette.primary.main,
        borderWidth: 1,
    },
    tableRow: {
        height: 43,
    },
    cellHead: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
    cellHeadCheckbox: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
}));

const rows = [
    {
        id: 'fld_nm',
        align: 'left',
        disablePadding: false,
        label: 'Field Name',
        sort: true,
    },
    {
        id: 'deleteFlag',
        align: 'left',
        disablePadding: false,
        label: 'Used',
        sort: true,
    },
    {
        id: 'orderNumber',
        align: 'left',
        disablePadding: false,
        label: 'Display Order',
        sort: true,
    },
];

function FieldTableHead(props) {
    const classes = useStyles();

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead className={classes.tableHead}>
            <TableRow className="h-54">
                {rows.map(row => (
                    <TableCell
                        key={row.id}
                        align={row.align}
                        padding={row.disablePadding ? 'none' : 'default'}
                        className={classes.cellHead}
                        sortDirection={props.order.columnId === row.id ? props.order.direction : false}
                    >
                        {row.sort && (
                            <Tooltip
                                title="Sort"
                                placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                enterDelay={300}
                            >
                                <TableSortLabel
                                    active={props.order.columnId === row.id}
                                    direction={props.order.direction}
                                    onClick={createSortHandler(row.id)}
                                    style={{ fontSize: 16, fontWeight: 'bold', color: 'white' }}
                                >
                                    {row.label}
                                </TableSortLabel>
                            </Tooltip>
                        )}
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
}

export default FieldTableHead;

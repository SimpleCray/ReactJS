/* eslint-disable func-names */
/* eslint-disable no-continue */
/* eslint-disable import/no-unresolved */
/* eslint-disable no-plusplus */
/* eslint-disable one-var */
/* eslint-disable prefer-const */
/* eslint-disable no-unused-expressions */
/* eslint-disable prefer-template */
/* eslint-disable no-sequences */
/* eslint-disable spaced-comment */
/* eslint-disable prettier/prettier */
import React, { useState } from 'react';
import { withRouter } from 'react-router-dom';
import CompanyFieldTable from './CompanyFieldTable';
import CompanyDocTable from './CompanyDocTable';

function DocAndFieldTable() {
    const [isChanged, setIsChanged] = useState(false);

    function handleIsChanged(change) {
        setIsChanged(change);
    }

    return (
        <div className="w-full flex flex-row">
            <CompanyDocTable setIsChanged={change => handleIsChanged(change)} />
            <CompanyFieldTable isChanged={isChanged} setIsChanged={change => handleIsChanged(change)} />
        </div>
    );
}

export default withRouter(DocAndFieldTable);

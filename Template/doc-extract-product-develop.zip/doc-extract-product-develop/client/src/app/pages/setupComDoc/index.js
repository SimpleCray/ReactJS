/* eslint-disable prettier/prettier */
/* eslint-disable import/no-unresolved */
import React from 'react';
import { useSelector } from 'react-redux';
import { FusePageCarded } from '@fuse';
import withReducer from 'app/store/withReducer';
import SetupComDocContent from './SetupComDocContent';
import SetupComDocHeader from './SetupComDocHeader';
import reducer from './store/reducers';

function ComDocSetup() {
    return (
        <FusePageCarded
            classes={{
                content: 'flex',
                header: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
                topBg: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
                contentWrapper: 'pr-3 pl-3',
                sidebarWrapper: 'w-2/12',
                rightSidebar: 'w-full',
                sidebarHeader: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
            }}
            header={<SetupComDocHeader />}
            content={<SetupComDocContent />}
            // eslint-disable-next-line react/jsx-boolean-value
            innerScroll
        />
    );
}

export default withReducer('comDocSetup', reducer)(ComDocSetup);

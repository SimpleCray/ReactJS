/* eslint-disable import/no-unresolved */
/* eslint-disable prefer-const */
/* eslint-disable prettier/prettier */
/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import { Paper, Input, Icon, MenuItem, FormControlLabel, Checkbox } from '@material-ui/core';
import { ThemeProvider } from '@material-ui/styles';
import { FuseAnimate } from '@fuse';
import buttons from 'app/utils/constants/buttonConstants.json';
import { useDispatch, useSelector } from 'react-redux';
import SearchTextField from 'app/components/SearchTextField';
import Button from 'app/components/Button';
import * as Actions from './store/actions';

function DocAndFieldHeader(props) {
    const dispatch = useDispatch();
    const comDocSetupData = useSelector(({ comDocSetup }) => comDocSetup.getResults);
    const mainTheme = useSelector(({ fuse }) => fuse.settings.mainTheme);
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const [searchFieldCond, setSearchFieldCond] = useState({
        fieldName: '',
        fieldDeltFlg: false,
    });
    const [searchDocCondition, setSearchDocCondition] = useState({
        companyCode: '',
        documentName: '',
        deleteFlag: false,
    });
    // Get data for header
    useEffect(() => {
        dispatch(Actions.getCompanies());
        dispatch(Actions.getDocuments());
        dispatch(Actions.getInitCompanyDocuments());
        dispatch(Actions.getCompanyDocuments(searchDocCondition, ''));
    }, [dispatch]);

    function handleSearchCompanyDocument() {
        let documentIDs = [];
        if (searchDocCondition.documentName !== '') {
            comDocSetupData.documents.forEach(document => {
                if (document.doc_nm.toLowerCase().includes(searchDocCondition.documentName.toLowerCase())) {
                    documentIDs.push(document.doc_tp_id);
                }
            });
        }

        dispatch(Actions.getCompanyDocuments(searchDocCondition, documentIDs.length === 0 ? '' : documentIDs));
        dispatch(Actions.resetDocumentFields());
        dispatch(Actions.setSelectedDocument(''));
        dispatch(Actions.setPageDocument(0));
    }

    const handleSearchDocumentChange = event => {
        event.persist();
        setSearchDocCondition({
            ...searchDocCondition,
            [event.target.name]:
                event.target.type === 'checkbox' ? event.target.checked.toString() : event.target.value,
        });
    };

    const handleSearchFieldChange = event => {
        event.persist();
        setSearchFieldCond({
            ...searchFieldCond,
            [event.target.name]: event.target.type === 'checkbox' ? event.target.checked : event.target.value,
        });
    };

    useEffect(() => {
        dispatch(Actions.setFieldsSearchText(searchFieldCond));
    }, [searchFieldCond]);

    return (
        <div className="w-full flex flex-row items-center justify-between">
            <div className="w-1/2 flex items-center px-1">
                <div className="flex-none">
                    {JSON.parse(localStorage.getItem('userInfo')).usrId === 'admin' && (
                        <SearchTextField
                            className="flex flex-1"
                            value={searchDocCondition.companyCode}
                            onChange={handleSearchDocumentChange}
                            label="Company Name"
                            name="companyCode"
                            select
                        >
                            <MenuItem value="All">All</MenuItem>

                            {comDocSetupData.initCompanyDocuments &&
                                comDocSetupData.companies
                                    .filter(item =>
                                        comDocSetupData.initCompanyDocuments
                                            .map(comDoc => comDoc.co_cd)
                                            .includes(item.co_cd),
                                    )
                                    .map(company => (
                                        <MenuItem value={company.co_cd} key={company.co_cd}>
                                            {company.coNm}
                                        </MenuItem>
                                    ))}
                        </SearchTextField>
                    )}
                </div>

                <div className="flex-none">
                    <SearchTextField
                        className="flex flex-1"
                        value={searchDocCondition.documentName}
                        onChange={handleSearchDocumentChange}
                        label="Document name"
                        name="documentName"
                    />
                </div>

                <div className="flex-none pl-4">
                    <FormControlLabel
                        control={<Checkbox onChange={handleSearchDocumentChange} name="deleteFlag" color="secondary" />}
                        label="Deleted"
                    />
                </div>

                {btnList.some(btn => btn.BTN_NO === buttons.BTN_SEARCH) && (
                    <Button color="default" onClick={handleSearchCompanyDocument}>
                        Search
                    </Button>
                )}
            </div>

            <div className="w-1/2 flex px-1">
                <ThemeProvider theme={mainTheme}>
                    <FuseAnimate animation="transition.slideDownIn" delay={300}>
                        <Paper className="flex items-center w-1/2 max-w-600 px-8 py-4 rounded-8" elevation={1}>
                            <Icon className="mr-8" color="action">
                                search
                            </Icon>

                            <Input
                                placeholder="Search field name"
                                className="flex flex-1"
                                disableUnderline
                                name="fieldName"
                                fullWidth
                                value={searchFieldCond.fieldName}
                                inputProps={{
                                    'aria-label': 'Search',
                                }}
                                onChange={handleSearchFieldChange}
                            />
                        </Paper>
                    </FuseAnimate>
                </ThemeProvider>
                <FormControlLabel
                    control={<Checkbox onChange={handleSearchFieldChange} name="fieldDeltFlg" color="secondary" />}
                    label="Not used"
                    className="pl-8"
                />
            </div>
        </div>
    );
}

export default DocAndFieldHeader;

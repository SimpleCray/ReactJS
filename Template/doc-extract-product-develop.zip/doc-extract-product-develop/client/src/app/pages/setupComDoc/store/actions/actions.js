/* eslint-disable prefer-const */
/* eslint-disable import/no-unresolved */
/* eslint-disable prettier/prettier */
/* eslint-disable no-unused-vars */
import { API_EP } from 'app/utils/commonAPI';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import HandleServerErrors from 'app/utils/handleServerErrors';
import { checkResDataAPI } from 'app/utils/utils';
import EndPointAPI from 'app/utils/endPointAPI';
export const SET_FIELDS_SEARCH_TEXT = 'SET_FIELDS_SEARCH_TEXT';
export const GET_COMPANIES = 'GET COMPANIES';
export const GET_COMPANY_DOCUMENTS = 'GET COMPANY DOCUMENTS';
export const GET_COMPANY_DOCUMENT_FIELDS = 'GET_COMPANY_DOCUMENT_FIELDS';
export const ADD_COMPANY_DOCUMENTS = 'ADD_COMPANY_DOCUMENTS';
export const DELETE_COMPANY_DOCUMENTS = 'DELETE_COMPANY_DOCUMENTS';
export const GET_ALL_DOCUMENT_FIELDS = 'GET_ALL_DOCUMENT_FIELDS';
export const GET_DOCUMENTS = 'GET DOCUMENTS';
export const GET_INIT_COMPANY_DOCUMENTS = 'GET_INIT_COMPANY_DOCUMENTS';

export const SET_ROWS_PER_PAGE_DOCUMENT = 'SET_ROWS_PER_PAGE_DOCUMENT';
export const SET_PAGE_DOCUMENT = 'SET_PAGE_DOCUMENT';
export const SET_ROWS_PER_PAGE_FIELD = 'SET_ROWS_PER_PAGE_FIELD';
export const SET_PAGE_FIELD = 'SET_PAGE_FIELD';
export const RESET_DOCUMENT_FIELDS = 'RESET_DOCUMENT_FIELDS';
export const SET_SELECTED_DOCUMENT = 'SET_SELECTED_DOCUMENT';

export function setFieldsSearchText(searchCond) {
    return dispatch =>
        dispatch({
            type: SET_FIELDS_SEARCH_TEXT,
            searchText: searchCond.fieldName,
            fieldDeltFlg: searchCond.fieldDeltFlg ? 'Y' : 'N',
        });
}

export function getDocuments() {
    const request = API_EP.get('/setup-com-doc/document');

    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_DOCUMENTS,
                        payload: response.data,
                    });
                }
            })
            .catch(error => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(error),
                        variant: 'error',
                    }),
                );
            });
}

export function getCompanies() {
    const request = API_EP.get(EndPointAPI.ENDPOINT.BP.ALL_COM);

    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    const listDataCompany = response.data.data.comList;
                    let listCompanyCode = [];
                    listDataCompany.forEach(item => {
                        listCompanyCode.push({ co_cd: item.coCd, coNm: item.coNm });
                    });
                    dispatch({
                        type: GET_COMPANIES,
                        payload: listCompanyCode,
                    });
                }
            })
            .catch(error => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(error),
                        variant: 'error',
                    }),
                );
            });
}

export function getAllDocumentFields(locId, docTpId) {
    const request = API_EP.get('/setup-com-doc/company-documents/all-document-fields', {
        params: {
            locId,
            docTpId,
        },
    });

    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_ALL_DOCUMENT_FIELDS,
                        payload: response.data,
                    });
                }
            })
            .catch(error => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(error),
                        variant: 'error',
                    }),
                );
            });
}

export function getCompanyDocuments(searchDocCondition, documentIDs) {
    const request = API_EP.get('/setup-com-doc/company-document/get-data-com-doc', {
        params: {
            ...searchDocCondition,
            documentIDs,
        },
    });

    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_COMPANY_DOCUMENTS,
                        payload: response.data,
                    });
                }
            })
            .catch(error => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(error),
                        variant: 'error',
                    }),
                );
            });
}

export function getInitCompanyDocuments() {
    const request = API_EP.get('/setup-com-doc/company-document/init-company-document');

    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_INIT_COMPANY_DOCUMENTS,
                        payload: response.data,
                    });
                }
            })
            .catch(error => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(error),
                        variant: 'error',
                    }),
                );
            });
}

export function setPageDocument(value) {
    return dispatch =>
        dispatch({
            type: SET_PAGE_DOCUMENT,
            page: value,
        });
}

export function setRowsPerPageDocument(value) {
    return dispatch =>
        dispatch({
            type: SET_ROWS_PER_PAGE_DOCUMENT,
            rowsPerPage: value,
        });
}

export function setPageField(value) {
    return dispatch =>
        dispatch({
            type: SET_PAGE_FIELD,
            page: value,
        });
}

export function setRowsPerPageField(value) {
    return dispatch =>
        dispatch({
            type: SET_ROWS_PER_PAGE_FIELD,
            rowsPerPage: value,
        });
}

export function resetDocumentFields() {
    return dispatch =>
        dispatch({
            type: RESET_DOCUMENT_FIELDS,
        });
}

export function setSelectedDocument(item) {
    return {
        type: SET_SELECTED_DOCUMENT,
        payload: item,
    };
}

export function saveFieldInfo(data, selectedItem, userId) {
    const request = API_EP.put('/setup-com-doc/save-field-detail', {
        fieldList: data,
        locId: selectedItem.loc_id,
        documentId: selectedItem.doc_tp_id,
        userId,
    });

    return dispatch => {
        request
            .then(response => {
                dispatch(showMessage({ message: response.data.message, variant: 'success' }));
                dispatch(getAllDocumentFields(selectedItem.loc_id, selectedItem.doc_tp_id));
            })
            .catch(error => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(error),
                        variant: 'error',
                    }),
                );
            });
    };
}

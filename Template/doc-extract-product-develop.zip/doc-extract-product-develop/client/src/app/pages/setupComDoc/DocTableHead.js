/* eslint-disable react/prop-types */
import React from 'react';
import { TableHead, TableSortLabel, TableCell, TableRow, Tooltip } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import * as TableFnc from 'app/utils/tableFunctions';

const useStyles = makeStyles(theme => ({
    tableHead: {
        backgroundColor: theme.palette.primary.main,
        borderWidth: 1,
        // padding: '0.25rem',
    },
    cellHead: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
    cellHeadCheckbox: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
}));

function DocTableHead(props) {
    const classes = useStyles();

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    const rows = [
        {
            id: 'co_nm',
            align: 'left',
            disablePadding: false,
            label: 'Company Name',
            sort: true,
        },
        {
            id: 'loc_nm',
            align: 'left',
            disablePadding: false,
            label: 'Location Name',
            sort: true,
        },
        {
            id: 'documents.doc_nm',
            align: 'left',
            disablePadding: false,
            label: 'Document Name',
            sort: true,
        },
    ];

    const { userInfo } = props;

    // Hide column Company Name when login user
    if (userInfo.usrId !== 'admin') {
        TableFnc.hideColComName(rows);
    }

    return (
        <TableHead className={classes.tableHead}>
            <TableRow className="h-54">
                {rows.map(row => (
                    <TableCell
                        key={row.id}
                        align={row.align}
                        padding={row.disablePadding ? 'none' : 'default'}
                        className={classes.cellHead}
                        sortDirection={props.order.columnId === row.id ? props.order.direction : false}
                    >
                        {row.sort && (
                            <Tooltip
                                title="Sort"
                                placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                enterDelay={300}
                            >
                                <TableSortLabel
                                    active={props.order.columnId === row.id}
                                    direction={props.order.direction}
                                    onClick={createSortHandler(row.id)}
                                    style={{ fontSize: 16, fontWeight: 'bold', color: 'white' }}
                                >
                                    {row.label}
                                </TableSortLabel>
                            </Tooltip>
                        )}
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
}

export default DocTableHead;

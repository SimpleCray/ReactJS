/* eslint-disable func-names */
import * as Actions from '../actions';
const initialState = {
    searchText: '',
    companies: [],
    documents: [],
    selectedDocument: '',
    companyDocuments: [],
    initCompanyDocuments: [],
    allDocumentFields: [],
    pageDocument: 0,
    rowsPerPageDocument: 20,
    pageField: 0,
    rowsPerPageField: 20,
    fieldDeltFlg: 'N',
};

const comDocSetupReducer = function(state = initialState, action) {
    switch (action.type) {
        case Actions.GET_COMPANIES: {
            return {
                ...state,
                companies: action.payload,
            };
        }

        case Actions.GET_COMPANY_DOCUMENTS: {
            return {
                ...state,
                companyDocuments: action.payload,
                pageDocument: 0,
            };
        }

        case Actions.GET_INIT_COMPANY_DOCUMENTS: {
            return {
                ...state,
                initCompanyDocuments: action.payload,
            };
        }

        case Actions.GET_DOCUMENTS: {
            return {
                ...state,
                documents: action.payload,
            };
        }

        case Actions.GET_ALL_DOCUMENT_FIELDS: {
            return {
                ...state,
                allDocumentFields: action.payload,
            };
        }

        case Actions.RESET_DOCUMENT_FIELDS: {
            return {
                ...state,
                allDocumentFields: [],
            };
        }

        case Actions.SET_FIELDS_SEARCH_TEXT: {
            return {
                ...state,
                searchText: action.searchText,
                fieldDeltFlg: action.fieldDeltFlg,
            };
        }

        case Actions.SET_PAGE_DOCUMENT: {
            return {
                ...state,
                pageDocument: action.page,
            };
        }

        case Actions.SET_ROWS_PER_PAGE_DOCUMENT: {
            return {
                ...state,
                rowsPerPageDocument: action.rowsPerPage,
            };
        }

        case Actions.SET_PAGE_FIELD: {
            return {
                ...state,
                pageField: action.page,
            };
        }

        case Actions.SET_ROWS_PER_PAGE_FIELD: {
            return {
                ...state,
                rowsPerPageField: action.rowsPerPage,
            };
        }

        case Actions.SET_SELECTED_DOCUMENT: {
            return {
                ...state,
                selectedDocument: action.payload,
            };
        }

        default: {
            return state;
        }
    }
};

export default comDocSetupReducer;

import { combineReducers } from 'redux';
import getResults from './reducer';

const reducer = combineReducers({
    getResults,
});

export default reducer;

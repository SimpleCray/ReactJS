/* eslint-disable no-unused-expressions */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable no-nested-ternary */
import React, { useState, Fragment, useEffect, useCallback, useMemo, useRef } from 'react';
import { ShapeEditor, ImageLayer, DrawLayer } from 'react-shape-editor';
import { useDispatch, useSelector } from 'react-redux';
import { Drawer, CircularProgress, Button } from '@material-ui/core';
import { withRouter } from 'react-router-dom';
import withReducer from 'app/store/withReducer';
import history from '@history';
import * as FuseAction from 'app/store/actions/fuse';
import AppConstants from 'app/utils/appConstants';
import MsgNotifications from 'app/utils/msgNotifications';
import reducer from './store/reducers/reducer';
import {
    handleMousemove,
    arrayReplace,
    getAllDataBoxItems,
    getOldDataTemplate,
    deleteItemValueById,
    isOverlapse,
    formatSpecialRuleData,
    updateIdBoxNameItemList,
    getListValueDefined,
    handleAlignOrderId,
    createFormatedDataTemplate,
    setValueDefined,
    checkSearchFldStatus,
    modifyFieldListWithExtrType,
} from './annotateFunction';
import { useStyles } from './styles';
import * as AnnotateActions from './store/actions/actions';
import FieldListTable from './fieldListTable';
import AnnotateToolbar from './annotateToolbar';
import ValueAndKeyList from './valueAndKeyList';
import RectShape from './RectShape';
import KeyTypeDrawer from './keyType';
import ExtractionFieldType from './extractionFieldType';

let firstLoad = true;
let realChanged = false;
let isClickOnBox = false; // use to check whether user click on Box
const stackUndo = [];
const stackRedo = [];
const { BOX_VIEW, MOVE_FOCUS_BOX_TYPE } = AppConstants;

const Annotate = props => {
    const { template, countdown, annotateImage, handleSubmitTemplate, location } = props;

    const classes = useStyles();
    const dispatch = useDispatch();

    // just show file and box in file without any tool, use for annotation preview
    const readOnly = location.search.includes('readonly');
    // use to scale for read only fit with iframe of annotation preview in result page
    const IFRAME_FACTOR = location.search.includes('iframe') ? 0.45 : 1;

    const ref = useRef(null);
    const isSelectOneBox = useRef(false);
    const ordinateXCursor = useRef(null);
    const ordinateYCursor = useRef(null);
    const loading = useSelector(({ annotate }) => annotate.loading);
    const allSpecialRules = useSelector(({ annotate }) => annotate.specialRule);
    const [selectedSRules, setSelectedSRules] = useState([]);
    const docFieldList = useSelector(({ annotate }) => annotate.docFieldList);
    const [scroll, setScroll] = useState({ isScrolling: false, clientX: 0, scrollX: 0, scrollY: 0, clientY: 0 });
    const [{ vectorHeight, vectorWidth }, setVectorDimensions] = useState({ vectorHeight: 0, vectorWidth: 0 });
    const scaleZoom = useSelector(({ annotate }) => annotate.scaleZoom);
    const [draw, setDraw] = useState(false);
    const [disableSubmitButton, setDisableSubmitButton] = useState(true);
    /** ** Load old annotated data */
    const getKeyValueData = useMemo(() => getOldDataTemplate(template, docFieldList), [template, docFieldList]);
    const [keyDefined, valueDefined] = getKeyValueData;
    const [items, setItems] = useState(getAllDataBoxItems(keyDefined, valueDefined));
    const [listValueDefined, setListValueDefined] = useState(valueDefined);
    const [boxView, setBoxView] = useState(BOX_VIEW.VALUE);
    /** ** Used for annotation Field List */
    const [isSearchOn, setIsSearchOn] = useState(false);
    const [isSearchFocus, setIsSearchFocus] = useState(false);
    const [sortedFieldList, setSortedFieldList] = useState();
    const [idIterator, setIdIterator] = useState(items.length);
    const [idBoxKey, setIdBoxKey] = useState(keyDefined.length);
    const [idBoxValue, setIdBoxValue] = useState(valueDefined.length);
    const [isSortedFields, setIsSortedFields] = useState(false);
    const [searchText, setSearchText] = useState(''); // Keep current search text in field list
    /** ** Used for undo-redo */
    const [undoValid, setUndoValid] = useState(false);
    const [redoValid, setRedoValid] = useState(false);
    const [toggle, setToggle] = useState(false);

    /** ** Get the first id value */
    const valueIDDefault = items.sort((a, b) => a.id - b.id).find((valueIDDefault) => {
        return valueIDDefault.types[0] === 'value';
    });
    /** ** Check valueIDDefault null */
    const checkValueIDDefault = valueIDDefault ? valueIDDefault.id : null
    /** ** Used for shape editting */
    const [editID, setEditID] = useState(checkValueIDDefault); // Focused box

    const [editIdArray, setEditIdArray] = useState([]); // Focused boxes (click on list fields)
    const [replaceBox, setReplacebox] = useState([]);
    const [isReplaceBox, setIsReplaceBox] = useState(false);
    const [isNewBox, setIsNewBox] = useState(false);
    const [currentBox, setCurrentBox] = useState();
    const [isAnnotateMode, setIsAnnotateMode] = useState(false);
    const [lastKey, setlastKey] = useState();
    const [boxExtractionType, setBoxExtractionType] = useState(AppConstants.EXTRACTION_TYPE.EMPTY);
    //* * Used for disable resize shape when drawing */
    const isDrawing = useSelector(({ annotate }) => annotate.isDrawing);
    //* * Used for display sniper cursor when resizing*/
    const [resize, setResize] = useState({ isResizing: false, isChangingX: false, isChangingY: false });

    const [keyType, setKeyType] = useState('STATIC');
    const canMoveFocusBox = moveType => {
        if (moveType === MOVE_FOCUS_BOX_TYPE.PREV) {
            if (editID <= 1) return false;
            if (boxView === BOX_VIEW.VALUE) {
                const checkPos = editID - idBoxKey;
                if (checkPos === 1) return false;
            }
        } else {
            if (editID === idIterator) return false;
            if (boxView === BOX_VIEW.KEY) {
                if (editID === idBoxKey) return false;
            }
        }
        return true;
    };

    const handleKeyDown = event => {
        if (lastKey === event.which) return;
        const keyCode = event.which;
        if (keyCode && checkSearchFldStatus(isSearchOn, isSearchFocus)) {
            event.preventDefault();
            if (keyCode === 68 || keyCode === 46) {
                // key D and Delete
                handleDelete();
            } else if (keyCode === 69) {
                // key E
                changeBoxView();
                setIsSearchOn(false);
            } else if (keyCode === 81 && !isReplaceBox) {
                // key Q
                handleDrawBox('new');
            } else if ((keyCode === 70 && event.ctrlKey) || keyCode === 70) {
                // key F or Ctrl+F
                if (boxView === BOX_VIEW.VALUE) {
                    setIsSearchOn(true);
                    setIsSearchFocus(true);
                }
            } else if (keyCode === 13) {
                // key Enter
                handleSubmitTemplate(items, selectedSRules);
            } else if (keyCode === 90 && event.ctrlKey && event.shiftKey) {
                // key Ctrl+Shift+Z
                stackRedo.length > 1 && handleRedoItems();
            } else if (keyCode === 90 && event.ctrlKey) {
                // key Ctrl+Z
                stackUndo.length > 0 && handleUndoItems();
            } else if (keyCode === 89 && event.ctrlKey) {
                // key Ctrl+Y
                stackRedo.length > 1 && handleRedoItems();
            } else if (keyCode === 65 && !isNewBox && editID) {
                // key A
                handleDrawBox('replace');
            } else if (keyCode === 16) {
                // key shift + left mouse click
                setlastKey(keyCode);
                if (!isAnnotateMode) {
                    setDraw(true);
                    ref.current.style.cursor = 'crosshair';
                    setIsAnnotateMode(true);
                    event.preventDefault();
                    event.stopPropagation();
                }
            } else if (keyCode === 87 && canMoveFocusBox(MOVE_FOCUS_BOX_TYPE.PREV)) {
                // Case W to go to previous box
                handleChangeFocus(editID - 1);
            } else if (keyCode === 83 && canMoveFocusBox(MOVE_FOCUS_BOX_TYPE.NEXT)) {
                // Case S to go to nex box
                handleChangeFocus(editID + 1);
            }
        } else if (keyCode === 27) {
            // key Esc
            setlastKey(keyCode);
            setIsSearchOn(false);
            setIsSearchFocus(false);
        }
    };

    useEffect(() => {
        setItems(getAllDataBoxItems(keyDefined, valueDefined));
        setValueDefined(valueDefined, docFieldList, keyDefined.length || 0);
    }, [docFieldList]);

    useEffect(() => {
        if (template) {
            const [tempValue, tempKey] = createFormatedDataTemplate(template);
            // Repush into template
            template.cordi_val_ctnt = tempValue;
            template.cordi_key_ctnt = tempKey;
            setSelectedSRules(template.rule_id_val ? template.rule_id_val.replace(/\s/g, '').split(',') : []);
        }
    }, [template]);

    // press keyboard
    useEffect(() => {
        document.addEventListener('keydown', handleKeyDown);
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [handleKeyDown]);

    useEffect(() => {
        document.onkeyup = function(e) {
            if (e.button !== 0 && !e.shiftKey && isAnnotateMode) {
                setlastKey('');
                setDraw(false);
                ref.current.style.cursor = 'grab';
                setIsAnnotateMode(false);
            }
        };
    }, [isAnnotateMode]);

    //  auto focus
    useEffect(() => {
        if (editID && !isClickOnBox) {
            setIsSearchFocus(false);
            setSearchText('');
            const classSet = document.querySelectorAll('.rse-shape-wrapper');
            if (classSet && classSet[editID - 1]) {
                const positionOfBox = {
                    x: classSet[editID - 1].transform.baseVal.consolidate().matrix.e * 0.5,
                    y: classSet[editID - 1].transform.baseVal.consolidate().matrix.f * 0.8,
                };
                scroll.scrollX = !firstLoad ? positionOfBox.x : scroll.scrollX;
                scroll.scrollY = !firstLoad ? positionOfBox.y : scroll.scrollY;
                ref.current.scrollTo({
                    top: positionOfBox.y,
                    left: positionOfBox.x,
                    behavior: 'smooth',
                });
            }
        }
    }, [editID]);

    // Check to make sure items had values, then load only one time to stackRedo
    useEffect(() => {
        if (firstLoad) {
            // Check item had value for first load document from device
            if (items.length === 0) {
                stackRedo.push([]);
                firstLoad = false;
                return;
            }
            // Document had existed in system
            if (items.some(item => item.names.length !== 0)) {
                stackRedo.push(items.map(item => ({ ...item })));
                firstLoad = false;
            }
        }
    }, [items]);

    // Change stack on items real change by action of user
    useEffect(() => {
        handleRefreshOrderId(items);
        if (realChanged) {
            const itemsTemp = items.map(item => ({ ...item }));
            insertStack(itemsTemp);
            realChanged = false;
        }
    }, [items]);

    useEffect(() => {
        setKeyType(
            editID !== null && items.filter(item => item.id === editID)[0]
                ? items.filter(item => item.id === editID)[0].types[1]
                : 'disabled',
        );
    }, [items, editID]);

    useEffect(() => {
        setUndoValid(stackUndo.length > 0);
        setRedoValid(stackRedo.length > 1);
    }, [toggle]);

    useEffect(() => {
        let newReplaceBoxes = [];
        if (isReplaceBox && !isNewBox && editID) {
            const replacedItem = items.filter(item => item.id === editID)[0];
            newReplaceBoxes = [editID, replacedItem.boxName, editID - 1, replacedItem.fields, replacedItem.names, replacedItem.extr_type];
        }
        setReplacebox(newReplaceBoxes);
    }, [isReplaceBox, editID]);

    // This function return data after select field in field list area
    const getData = (allRowsSelected, id, allFieldData) => {
        if (id) {
            const newListValue = getListValueDefined(items, listValueDefined, allRowsSelected, allFieldData, id);
            realChanged = true;
            setListValueDefined([...newListValue]);
            setItems([...items]);
            setIsSortedFields(true);
            setCurrentBox(id);
            setSortedFieldList(allFieldData);
            setIsSearchFocus(false);
        }
    };

    /** *********** HANDLING DRAWING AND ACTION ON ANNOTATION BOXES ************ */
    const onMouseDown = e => {
        if (!draw) {
            ref.current.style.cursor = 'grabbing';
            setScroll({
                ...scroll,
                isScrolling: true,
                clientX: e.clientX,
                clientY: e.clientY,
            });
        }
    };

    const onMouseUp = () => {
        if (!draw) {
            ref.current.style.cursor = 'grab';
            setScroll({ ...scroll, isScrolling: false });
        }
    };

    const onMouseMove = e => {
        if (!draw) {
            const { clientX, scrollX, clientY, scrollY } = scroll;
            if (scroll.isScrolling) {
                ref.current.scrollLeft = scrollX - e.clientX + clientX;
                scroll.scrollX = scrollX - e.clientX + clientX;
                scroll.clientX = e.clientX;
                ref.current.scrollTop = scrollY - e.clientY + clientY;
                scroll.scrollY = scrollY - e.clientY + clientY;
                scroll.clientY = e.clientY;
            }
        } else {
            ordinateXCursor.current.style.display = 'inline-block';
            ordinateYCursor.current.style.display = 'inline-block';
        }

        ordinateXCursor.current.style.left = '0px';
        ordinateXCursor.current.style.top = e.clientY - ordinateXCursor.current.offsetHeight / 2 + 'px'; 
        ordinateYCursor.current.style.left = e.clientX - ordinateYCursor.current.offsetWidth / 2 + 'px';
        ordinateYCursor.current.style.top = '0px';

        if (resize.isResizing) {
            ordinateYCursor.current.style.display = resize.isChangingX ? 'inline-block' : 'none';
            ordinateXCursor.current.style.display = resize.isChangingY ? 'inline-block' : 'none';
            // ** Set correct positions for comparison lines*/
            const classSet = document.querySelectorAll('.rse-shape-wrapper');
            if (classSet && classSet[editID - 1]) {
                const boundingRect = classSet[editID - 1].getBoundingClientRect();
                const ordinateX_Top = parseFloat(ordinateXCursor.current.style.top);
                const ordinateY_Left = parseFloat(ordinateYCursor.current.style.left);

                if (boundingRect.top - 10 <= ordinateX_Top &&
                    ordinateX_Top <= boundingRect.top + 10) ordinateXCursor.current.style.top = boundingRect.top + 2.5 + 'px';
                else if (boundingRect.bottom - 10 <= ordinateX_Top &&
                    ordinateX_Top <= boundingRect.bottom + 10) ordinateXCursor.current.style.top = boundingRect.bottom - 6.5 + 'px';
                        
                if (boundingRect.left - 10 <= ordinateY_Left &&
                    ordinateY_Left <= boundingRect.left + 10) ordinateYCursor.current.style.left = boundingRect.left + 3 + 'px';
                else if (boundingRect.right - 10 <= ordinateY_Left &&
                    ordinateY_Left <= boundingRect.right + 10) ordinateYCursor.current.style.left = boundingRect.right - 6 + 'px';   
            }
        }
    };

    const handleScrollPage = e => {
        scroll.scrollX = e.target.scrollLeft;
        scroll.scrollY = e.target.scrollTop;
    };

    const showWarningAnnotationAction = msg => {
        dispatch(
            FuseAction.showMessage({
                message: msg || MsgNotifications.ANNOTATE.NOT_ALLOW_OVERLAP,
                autoHideDuration: 3000,
                anchorOrigin: {
                    vertical: 'top',
                    horizontal: 'center',
                },
                variant: 'error',
            }),
        );
    };

    const handleChangeFocus = id => {
        setEditID(id);
        isClickOnBox = false;
        isSelectOneBox.current = false;
    };

    const handleDrawBox = type => {
        if (draw) {
            ordinateXCursor.current.style.display = 'none';
            ordinateYCursor.current.style.display = 'none';
        }
        setDraw(!draw);
        dispatch(AnnotateActions.disableComponenstWhenDrawing(!isDrawing));
        ref.current.style.cursor = draw ? 'grab' : 'crosshair';
        switch (type) {
            case 'new':
                draw ? setIsNewBox(false) : setIsNewBox(true);
                break;
            case 'replace':
                isReplaceBox ? setIsReplaceBox(false) : setIsReplaceBox(true);
                break;
            default:
                break;
        }
    };

    const constrainMove = ({ x, y, width, height }) => ({
        x: Math.min(vectorWidth - width, Math.max(0, x)),
        y: Math.min(vectorHeight - height, Math.max(0, y)),
    });

    const constrainResize = ({ movingCorner: { x: movingX, y: movingY }, lockedDimension: lockedAxis }) => {
        setResize({
            ...resize,
            isResizing: true,
            isChangingX: lockedAxis === 'y' || !lockedAxis,
            isChangingY: lockedAxis === 'x' || !lockedAxis,
        });

        return {
            x: Math.min(vectorWidth, Math.max(0, movingX)),
            y: Math.min(vectorHeight, Math.max(0, movingY)),
        };
    };

    const onChangeRectShape = (newRect, id, item, index) => {
        setResize({
            ...resize,
            isResizing: false,
            isChangingX: false,
            isChangingY: false,
        });
        ordinateXCursor.current.style.display = 'none';
        ordinateYCursor.current.style.display = 'none';

        if (!isOverlapse(newRect, items, id)) {
            handleItems(index, {
                ...item,
                x: newRect.x / scaleZoom,
                y: newRect.y / scaleZoom,
                w: newRect.width / scaleZoom,
                h: newRect.height / scaleZoom,
            });
        } else showWarningAnnotationAction();
    };

    const onFocusRectShape = (id, index) => {
        isSelectOneBox.current = false;
        setEditID(id);
        isClickOnBox = true;
        if (id !== currentBox) {
            setIsSortedFields(false);
        }
        // Enable save button when focus to any box
        setDisableSubmitButton(false);
    };

    const getNewItemList = (x, y, width, height) => {
        let itemList = [];
        const createdBox = {
            id: idIterator + 1,
            x,
            y,
            w: width,
            h: height,
            fields: [],
            names: [],
            types: [boxView, 'STATIC'],
            typeIndex: [],
            boxName: boxView === BOX_VIEW.KEY ? idBoxKey + 1 : idBoxValue + 1,
        };
        if (replaceBox.length > 4) {
            createdBox.id = replaceBox[0];
            createdBox.boxName = replaceBox[1];
            createdBox.fields = replaceBox[3];
            createdBox.names = replaceBox[4];
            createdBox.extr_type = replaceBox[5]
            const itemData = items;
            for (let i = 0; i < items.length; i++) {
                if (i === replaceBox[2]) {
                    itemData[i] = createdBox;
                }
            }
            itemList = [...itemData];
        } else {
            itemList = [...items, createdBox];
        }
        return itemList;
    };

    const onAddShapeCallBack = ({ x, y, width, height }) => {
        dispatch(AnnotateActions.disableComponenstWhenDrawing(false));
        ordinateXCursor.current.style.display = 'none';
        ordinateYCursor.current.style.display = 'none';

        if (!isOverlapse({ x, y, width, height }, items, -1)) {
            realChanged = true;
            const newItemList = getNewItemList(
                x / scaleZoom,
                y / scaleZoom,
                width / scaleZoom,
                height / scaleZoom,
            );
            setItems(newItemList);
            if (isNewBox && boxView === BOX_VIEW.VALUE) {
                setListValueDefined(newItemList);
            }
            if (draw) {
                setDraw(!draw);
                ref.current.style.cursor = 'grab';
                if (isNewBox) {
                    setIsNewBox(false);
                } else if (isReplaceBox) {
                    setIsReplaceBox(false);
                }
            }
            setDisableSubmitButton(false);
        } else showWarningAnnotationAction();
    };

    /** *********** HANDLING TABLE FIELDS, BOXES LIST ************ */
    const changeBoxView = () => {
        boxView === BOX_VIEW.KEY ? setBoxView(BOX_VIEW.VALUE) : setBoxView(BOX_VIEW.KEY);
        if (boxView === BOX_VIEW.KEY) {
            setEditID(idBoxKey + 1);
        } else {
            setEditID(1);
        }
        isClickOnBox = false;
        isSelectOneBox.current = false;
    };

    const handleItems = (index, dict) => {
        realChanged = true;
        setItems(arrayReplace(items, index, dict));
    };

    const showSearchField = isEnabled => {
        setIsSearchOn(isEnabled);
        setIsSearchFocus(isEnabled);
    };

    const selectFieldForBox = name => {
        const allItemHasName = items.filter(item => item.names.includes(name[0]));
        const allItemHasNameId = allItemHasName.map(item => item.id);
        setEditID(null);
        setEditIdArray(allItemHasNameId);
        setIsSearchFocus(false);
        isSelectOneBox.current = true;
        // Focus to first box
        const classSet = document.querySelectorAll('.rse-shape-wrapper');
        allItemHasNameId.length > 0 &&
            classSet &&
            classSet[allItemHasNameId[0] - 1] &&
            classSet[allItemHasNameId[0] - 1].scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    };

    const handleDelete = () => {
        if (editID) {
            realChanged = true;
            isSelectOneBox.current = false;
            const newItems = arrayReplace(items, editID - 1, []);
            const [modifiedNewItemList, typeBox] = updateIdBoxNameItemList(newItems, boxView, idBoxKey, idBoxValue);
            setItems([...modifiedNewItemList]);

            if (typeBox === BOX_VIEW.VALUE) {
                const newListValueDefined = deleteItemValueById(listValueDefined, editID);
                setListValueDefined([...newListValueDefined]);
            }
            setEditID(null);
        }
    };

    const handleRefreshOrderId = items => {
        const keyBoxArray = items.filter(item => item.types[0] === BOX_VIEW.KEY);
        const valueBoxArray = items.filter(item => item.types[0] === BOX_VIEW.VALUE);
        setIdIterator(items.length);
        setIdBoxKey(keyBoxArray.length);
        setIdBoxValue(valueBoxArray.length);
    };

    /** *********** HANDLING UNDO - REDO ************ */
    const handleUndoItems = () => {
        const undoItem = getPrevState();
        setItems(undoItem);
    };

    const handleRedoItems = () => {
        const redoItem = getNextState();
        setItems(redoItem);
    };

    const insertStack = newState => {
        const oldState = handleAlignOrderId(stackRedo.pop());
        stackUndo.push(oldState.map(item => ({ ...item })));
        stackRedo.length = 0;
        stackRedo.push(newState.map(item => ({ ...item })));
        setToggle(!toggle);
    };

    const getPrevState = () => {
        setToggle(!toggle);
        if (stackUndo.length > 0) {
            const state = handleAlignOrderId(stackUndo.pop());
            const newListValueDefined = state.filter(item => item.types[0] === BOX_VIEW.VALUE);
            stackRedo.push(state.map(item => ({ ...item })));
            setListValueDefined(newListValueDefined);
            return state;
        }
    };

    const getNextState = () => {
        setToggle(!toggle);
        if (stackRedo.length > 1) {
            const state = handleAlignOrderId(stackRedo.pop());
            stackUndo.push(state.map(item => ({ ...item })));
            const returnState = stackRedo[stackRedo.length - 1];
            const newListValueDefined = returnState.filter(item => item.types[0] === BOX_VIEW.VALUE);
            setListValueDefined(newListValueDefined);
            return returnState;
        }
    };

    const onChangeKeyType = e => {
        if (editID) {
            handleItems(editID - 1, {
                ...items.filter(item => item.id === editID)[0],
                types: [BOX_VIEW.KEY, e.target.value],
            });
        }
    };

    const onChangeExtractionType = event => {
        const boxIndex = editID - 1;
        if (items[boxIndex]) {
            const cloneItems = [...items];
            const currentItem = cloneItems[boxIndex];
            if (
                event.target.value === AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL &&
                currentItem.fields.length > 0 &&
                currentItem.fields[0] !== AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL
            ) {
                showWarningAnnotationAction(MsgNotifications.ANNOTATE.NOT_ALLOW_FIELD_IN_HEADER_REMOVAL_EXTR_TYPE);
                return;
            }
            const extrType = event.target.value;
            currentItem.fields = modifyFieldListWithExtrType(extrType, currentItem.fields);
            currentItem.extr_type = event.target.value;
            setItems(cloneItems);
            setBoxExtractionType(AppConstants.EXTRACTION_TYPE.EMPTY);
        }
    };

    const renderBoxExtractionType = useCallback(() => {
        if (boxView === BOX_VIEW.VALUE) {
            const boxIndex = editID - 1;
            return (
                <ExtractionFieldType
                    onChangeExtractionType={onChangeExtractionType}
                    boxExtractionType={items[boxIndex] ? items[boxIndex].extr_type : boxExtractionType}
                />
            );
        }
        return null;
    }, [items, editID, boxExtractionType]);

    // Show the box list of all the annotation key, value boxes
    const renderBoxList = useCallback(
        () => (
            <ValueAndKeyList
                items={items}
                editIdArray={editIdArray}
                editID={editID}
                handleChangeFocus={handleChangeFocus}
                boxView={boxView}
                handleChangeBoxView={changeBoxView}
                isSelectOneBox={isSelectOneBox}
            />
        ),
        [items, boxView, editID, editIdArray],
    );

    // The area for rendering key type and field annotation list
    const renderFieldKeyData = useCallback(() => {
        if (boxView === BOX_VIEW.KEY) {
            return <KeyTypeDrawer keyType={keyType} onChangeKeyType={onChangeKeyType} />;
        }
        return (
            <FieldListTable
                className={classes.customHeight}
                onRowSelectionChange={getData}
                data={isSortedFields ? sortedFieldList : docFieldList}
                isSortedFields={isSortedFields}
                isSearchFocus={isSearchFocus}
                isSearchOn={isSearchOn}
                showSearchField={showSearchField}
                onRowClick={selectFieldForBox}
                listValueData={listValueDefined}
                editID={editID}
                items={items}
                searchText={searchText}
                setSearchText={setSearchText}
                setIsSearchOn={setIsSearchOn}
                setIsSearchFocus={setIsSearchFocus}
            />
        );
    }, [keyType, boxView, editID, isSearchOn, isSearchFocus, searchText, listValueDefined, items, boxExtractionType]);

    return (
        <>
            {loading ? (
                <div className={classes.circleloading}>
                    <CircularProgress size={200} />
                </div>
            ) : (
                <div
                    ref={ref}
                    className={classes.root}
                    onMouseDown={onMouseDown}
                    onMouseMove={onMouseMove}
                    onMouseUp={onMouseUp}
                    onScroll={handleScrollPage}
                >
                    {!readOnly && (
                        <AnnotateToolbar
                            undoItems={handleUndoItems}
                            canUndo={undoValid}
                            redoItems={handleRedoItems}
                            canRedo={redoValid}
                            countdown={countdown}
                            selectedSRules={selectedSRules}
                            setSelectedSRules={setSelectedSRules}
                            allSpecialRules={allSpecialRules}
                        />
                    )}
                    {/** Sniper cursor */}
                    <div ref={ordinateXCursor} className={classes.horizontalLine} />
                    <div ref={ordinateYCursor} className={classes.verticalLine} />
                    {/** --------------------------------------------------------------- */}
                    {/*  Draw shape  */}
                    <div className={readOnly ? classes.wrapReadonly : classes.wrap}>
                        <main className={readOnly ? 'overflow-auto' : classes.content}>
                            <ShapeEditor
                                vectorWidth={vectorWidth * IFRAME_FACTOR * scaleZoom}
                                vectorHeight={vectorHeight * IFRAME_FACTOR * scaleZoom}
                                focusOnAdd
                                focusOnDelete={false}
                            >
                                <ImageLayer
                                    width={vectorWidth * IFRAME_FACTOR * scaleZoom}
                                    height={vectorHeight * IFRAME_FACTOR * scaleZoom}
                                    src={annotateImage}
                                    onLoad={({ naturalWidth, naturalHeight }) => {
                                        setVectorDimensions({
                                            vectorWidth: naturalWidth,
                                            vectorHeight: naturalHeight,
                                        });
                                    }}
                                />
                                {draw && (
                                    <DrawLayer
                                        onAddShape={({ x, y, width, height }) =>
                                            onAddShapeCallBack({ x, y, width, height })
                                        }
                                        onDrawStart={() => {
                                            document.addEventListener('mousemove', handleMousemove, false);
                                        }}
                                        onDrawEnd={() => {
                                            document.removeEventListener('mousemove', handleMousemove);
                                        }}
                                    />
                                )}
                                {items.map((item, index) => {
                                    const { id, h, w, x, y, fields, names, typeIndex, types, boxName } = item;
                                    if (readOnly)
                                        return (
                                            <Fragment>
                                                <RectShape
                                                    shapeId={String(boxName)}
                                                    height={h * IFRAME_FACTOR}
                                                    width={w * IFRAME_FACTOR}
                                                    x={x * IFRAME_FACTOR}
                                                    y={y * IFRAME_FACTOR}
                                                    disabled
                                                    names={names}
                                                    types={types}
                                                    boxView={boxView}
                                                    readOnly
                                                    fontScale={IFRAME_FACTOR}
                                                />
                                            </Fragment>
                                        );
                                    return (
                                        <Fragment key={id}>
                                            <RectShape
                                                shapeId={String(boxName)}
                                                height={h * scaleZoom}
                                                width={w * scaleZoom}
                                                constrainMove={constrainMove}
                                                constrainResize={constrainResize}
                                                x={x * scaleZoom}
                                                y={y * scaleZoom}
                                                active={
                                                    isSelectOneBox.current ? editIdArray.includes(id) : id === editID
                                                }
                                                disabled={boxView !== types[0] || isDrawing}
                                                // fields={fields}
                                                names={names}
                                                types={types}
                                                boxView={boxView}
                                                onChange={newRect => onChangeRectShape(newRect, id, item, index)}
                                                onFocus={() => onFocusRectShape(id, index)}
                                                isInSelectionGroup={
                                                    isSelectOneBox.current
                                                        ? !editIdArray.includes(id)
                                                        : !(id === editID)
                                                }
                                            />
                                        </Fragment>
                                    );
                                })}
                            </ShapeEditor>
                        </main>
                    </div>
                    {/** ******************* Value and key drawer list  ************************** */}
                    {!readOnly && !isDrawing && renderBoxList()}
                    {!readOnly && !isDrawing && (
                        <Drawer
                            variant="permanent"
                            className={classes.drawer}
                            classes={{
                                paper: classes.drawerPaper,
                                paperAnchorDockedRight: classes.paperAnchorDockedRight,
                            }}
                            anchor="right"
                        >
                            <div className={classes.drawerHeader} />
                            {renderBoxExtractionType()}
                            {renderFieldKeyData()}
                            <div className="div-submit-annotate">
                                <Button
                                    disabled={disableSubmitButton}
                                    className="submit-annotate"
                                    onClick={() => handleSubmitTemplate(items, selectedSRules)}
                                >
                                    SUBMIT
                                </Button>
                            </div>
                        </Drawer>
                    )}
                </div>
            )}
        </>
    );
};

export default withRouter(withReducer('annotate', reducer)(Annotate));

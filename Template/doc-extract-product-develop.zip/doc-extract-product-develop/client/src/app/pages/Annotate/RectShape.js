/* eslint-disable react/no-array-index-key */
/* eslint-disable import/no-unresolved */
/* eslint-disable no-unused-expressions */
/* eslint-disable no-unused-vars */
/* eslint-disable no-nested-ternary */
import React, { useCallback } from 'react';
import { wrapShape } from 'react-shape-editor';
import AppConstants from 'app/utils/appConstants';

const RectShape = wrapShape(
    ({ width, height, fields, names, types, shapeId, boxView, active, readOnly, fontScale = 1 }) => {
        const getTextWidth = (text, font) => {
            const canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement('canvas'));
            const context = canvas.getContext('2d');
            context.font = font;
            const metrics = context.measureText(text);
            return metrics.width;
        };

        const renderContentBox = useCallback(() => {
            const listContent = [];
            const listField = [...names];
            const widthContent = getTextWidth(listField.join(', '), `${15 * fontScale}px verdana`);

            if (widthContent + 10 > width) {
                let accumulationWidth = 0;
                let accumulationField = [];

                listField.forEach((field, index) => {
                    accumulationWidth += getTextWidth(`${field}, `, `${15 * fontScale}px verdana`);
                    accumulationField.push(field);
                    if (accumulationWidth + 10 > width) {
                        accumulationField.splice(accumulationField.length - 1, 1);
                        accumulationField.join(', ').length !== 0 &&
                            listContent.push(`${accumulationField.join(', ')},`);
                        accumulationField = [];
                        accumulationField.push(field);
                        accumulationWidth = getTextWidth(`${field}, `, `${15 * fontScale}px verdana`);
                    }
                    index === listField.length - 1 &&
                        !listContent.join(', ').includes(accumulationField.join(', ')) &&
                        listContent.push(accumulationField.join(', '));
                });
            } else listContent.push(listField.join(', '));

            return listContent.map((content, index) => (
                <tspan
                    key={index}
                    x={width - getTextWidth(content, `${15 * fontScale}px verdana`) - 10 * fontScale}
                    y={16 * fontScale * (index + 1)}
                >
                    {content}
                </tspan>
            ));
        }, [width, height, names]);

        return (
            <>
                {types[0] === boxView || readOnly ? (
                    active ? (
                        <rect
                            width={width}
                            height={height}
                            strokeWidth={3}
                            stroke={AppConstants.ANNOTATION_COLOR.BOX_ACTIVE_BORDER}
                            fill={AppConstants.ANNOTATION_COLOR.BOX_ACTIVE_BACKGROUND}
                        />
                    ) : (
                        <rect
                            width={width}
                            height={height}
                            strokeWidth={2}
                            stroke={AppConstants.ANNOTATION_COLOR.BOX_DISACTIVE_BORDER}
                            fill={AppConstants.ANNOTATION_COLOR.BOX_DISACTIVE_BACKGROUND}
                        />
                    )
                ) : (
                    <rect
                        width={width}
                        height={height}
                        strokeWidth={2}
                        stroke={AppConstants.ANNOTATION_COLOR.NORMAL_BORDER_SHAPE}
                        fill={AppConstants.ANNOTATION_COLOR.NORMAL_BACKGROUND_SHAPE}
                    />
                )}
                {(boxView === AppConstants.BOX_VIEW.VALUE || readOnly) && (
                    <text fontSize={15 * fontScale} fontFamily="Verdana" fill="red">
                        {renderContentBox()}
                    </text>
                )}
                {(types[0] === boxView || readOnly) && (
                    <text
                        x={width - shapeId.length * 8 * fontScale - 10}
                        y={height - 5}
                        fontFamily="Verdana"
                        fontSize={15 * fontScale}
                        fill="red"
                    >
                        {shapeId}
                    </text>
                )}
            </>
        );
    },
);

export default RectShape;

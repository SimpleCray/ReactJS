import { API_EP } from 'app/utils/commonAPI';
import { showError, checkResDataAPI, getUserId } from 'app/utils/utils';
import MsgNotifications from 'app/utils/msgNotifications';
import EndPointAPI from 'app/utils/endPointAPI';
import { showMessage } from 'app/store/actions/fuse';
import HandleServerErrors from 'app/utils/handleServerErrors';
import * as actionTypes from '../constants';
import { getKeySeqsMatching, makeTemplateData, checkTmpltChangeVer, saveTemplateInfo } from '../../annotateFunction';

export function updateLoadingStatus(status) {
    return {
        type: actionTypes.UPDATE_LOADING_STATUS,
        status,
    };
}

export const initStateAnnotation = () => dispatch =>
    dispatch({
        type: actionTypes.RELOAD_INIT_STATE_ANNOTATE,
    });

export const onErrorSubmitAnnotate = error => dispatch => {
    dispatch(showError(error));
    dispatch(updateLoadingStatus(false));
    dispatch(initStateAnnotation());
};

export const showMsgCoreAPI = message => dispatch => {
    dispatch(
        showMessage({
            message,
            variant: 'error',
        }),
    );
    dispatch(onErrorSubmitAnnotate(message));
};

export const showAnnotateNotification = message => dispatch => {
    dispatch({
        type: actionTypes.SHOW_NOTI_ANNOTATION_CHECK,
        message,
    });
};

export const onTimeout = () => dispatch =>
    dispatch({
        type: actionTypes.ON_ANNOTATING_TIMEOUT,
    });

// Getting all SpecialRule was defined in template data
export const getSPRule = template => dispatch => {
    // Getting all SpecialRule from DBget-all-rules
    API_EP.get(EndPointAPI.ENDPOINT.TEMPLATE.GET_RULE_BY_TMPL, {
        params: { templateId: template.id, docTypeId: template.docTypeId },
    })
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: actionTypes.GET_SPRULE_SUCCESSFUL,
                    data: response.data,
                });
            }
        })
        .catch(error => {
            dispatch({
                type: actionTypes.GET_SPRULE_FAILED,
                error,
            });
            dispatch(showError(error));
        });
};

export const getTemplateData = (templateType, templateId) => dispatch => {
    API_EP.get(EndPointAPI.ENDPOINT.TEMPLATE.GET_TMP_DATA, { params: { tmpltId: templateId } })
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: actionTypes.GET_TEMPLATE_SUCCESSFUL,
                    data: response.data,
                });
            }
        })
        .catch(error => {
            dispatch({
                type: actionTypes.GET_TEMPLATE_FAILED,
                error,
            });
            dispatch(showError(error));
        });
};

export const getLatestDataByTmplId = (templateId, matchingParamObj) => dispatch => {
    API_EP.get(EndPointAPI.ENDPOINT.DOC_DATA.LATEST_DOC_BY_TMPL, { params: { tmpltId: templateId } })
        .then(response => {
            if (checkResDataAPI(response)) {
                const resData = response.data;
                dispatch(loadDocField(resData.doc_id, resData.doc_tp_id));
                matchingParamObj.current = {
                    co_cd: resData.co_cd,
                    lo_cd: resData.loc_cd,
                    doc_tp_id: resData.doc_tp_id,
                };
                dispatch({
                    type: actionTypes.SET_CURRENT_DOC_ID,
                    data: resData,
                });
            }
        })
        .catch(error =>
            dispatch({
                type: actionTypes.LOAD_DOC_FIELD_FAILED,
                error,
            }),
        );
};

// This func is use to update templateId to doc
const updateTemplateIdToDoc = (templateId, docId) => dispatch => {
    const usrId = getUserId();
    API_EP.post(EndPointAPI.ENDPOINT.DOC_DATA.UPDATE_TEMPLATE_ID_DOC, { templateId, docId, usrId })
        .then(response => {
            dispatch(
                showMessage({
                    message: MsgNotifications.ANNOTATE.GENERATE_NEW_FORMAT_SUCCESSFUL,
                    variant: 'success',
                }),
            );
        })
        .catch(error => {
            throw error;
        });
};

/**
 * This func is used to submit template after annotation, called to Core
 */
export const submitTemplate = (template, docId, newAnnotateTmpltKeySeq, templateVersion, editOnly) => dispatch => {
    dispatch(showAnnotateNotification('')); // If old msg is exist
    API_EP.post(EndPointAPI.CORE.TEMPLATE.SUBMIT, template)
        .then(response => {
            if (checkResDataAPI(response)) {
                const resData = response.data;
                if (resData.status_code === 200 && resData) {
                    const keySeqAnnotation = getKeySeqsMatching(resData);
                    saveTemplateInfo(template, resData, keySeqAnnotation, templateVersion);
                    newAnnotateTmpltKeySeq.current = keySeqAnnotation;
                    if (editOnly) {
                        dispatch(
                            showMessage({
                                message: MsgNotifications.ANNOTATE.UPDATE_TEMPLATE_SUCCESSFUL,
                                variant: 'success',
                            }),
                        );
                    } else {
                        dispatch(updateTemplateIdToDoc(template.tmp_id, docId));
                    }
                    dispatch({
                        type: actionTypes.SUBMIT_TEMPLATE_SUCCESSFUL,
                        data: resData,
                    });
                } else if (resData.status_code === 400 && resData) {
                    // For case User Annotate Behavior is wrong, status API is 200, but status in data is 400
                    const msgDisplay = resData.message || MsgNotifications.ANNOTATE.TEMPLATE_SAVE_FAILED;
                    dispatch(showAnnotateNotification(msgDisplay));
                    dispatch(updateLoadingStatus(false));
                }
            }
        })
        .catch(error => {
            console.error('Error when submit template: ', error);
            dispatch({
                type: actionTypes.SUBMIT_TEMPLATE_FAILED,
                error,
            });
            dispatch(onErrorSubmitAnnotate(error));
        });
};

export const loadDocField = (docId, docTypeId) => dispatch => {
    const url = EndPointAPI.ENDPOINT.TEMPLATE.GET_FIELD_BY_COM_DOC;
    API_EP.get(url, { params: { docId, docTypeId } })
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: actionTypes.LOAD_DOC_FIELD_SUCCESS,
                    data: response.data,
                });
            }
        })
        .catch(error =>
            dispatch({
                type: actionTypes.LOAD_DOC_FIELD_FAILED,
                error,
            }),
        );
};

export function submitExtract(data) {
    const apiCalling = API_EP.post(EndPointAPI.CORE.EXTRACTION.SUBMIT, data);

    return dispatch =>
        apiCalling
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: actionTypes.SAVE_TMPL_EXTRACTION_SUCCESS,
                        data: response.data,
                    });
                }
            })
            .catch(error => {
                dispatch({
                    type: actionTypes.SAVE_TMPL_EXTRACTION_FAILED,
                });
                dispatch(onErrorSubmitAnnotate(error));
            });
}

export function onLoadInitData() {
    return {
        type: actionTypes.SAVE_TMPL_RELOAD_REDUCER,
    };
}

export function submitMatching(data) {
    const apiCalling = API_EP.post(EndPointAPI.CORE.MATCHING.SUBMIT, data);

    return dispatch =>
        apiCalling
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: actionTypes.SUBMIT_TMP_MATCHING_SUCCESS,
                        data: response.data,
                    });
                }
            })
            .catch(error => {
                dispatch({
                    type: actionTypes.SUBMIT_TMP_MATCHING_FAILED,
                });
                dispatch(onErrorSubmitAnnotate(error));
            });
}
export const setZoomScale = value => dispatch =>
    dispatch({
        scaleZoom: value,
        type: actionTypes.SET_SCALE_IMAGE,
    });

export const updateStatusForTemplate = (templateId, status) => dispatch => {
    const usrId = getUserId();
    API_EP.put(EndPointAPI.ENDPOINT.TEMPLATE.UPDATE_STATUS, { tmpltId: templateId, status, usrId }).catch(error => {
        dispatch({
            type: actionTypes.CATCH_UPDATE_TEMPLATE_STATUS_ERROR,
            payload: HandleServerErrors.getServerErrorMessage(error),
        });
    });
};

export const disableComponenstWhenDrawing = value => dispatch =>
    dispatch({
        isDrawing: value,
        type: actionTypes.DISABLE_COMPONENTS_WHEN_DRAWING,
    });

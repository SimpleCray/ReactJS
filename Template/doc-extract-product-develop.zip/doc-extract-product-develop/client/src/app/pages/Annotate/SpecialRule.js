import React, { useEffect, useState } from 'react';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import { Checkbox, Table, TableBody, TableCell, TableHead, TableRow } from '@material-ui/core';
import Modal from '@material-ui/core/Modal';
const useStyles = makeStyles(theme => ({
    root: {
        margin: theme.spacing(2),
        textAlign: 'center',
    },
    table: {
        minWidth: 700,
    },
    paper: {
        position: 'absolute',
        backgroundColor: theme.palette.background.paper,
        border: '2px solid #000',
        boxShadow: theme.shadows[5],
        padding: theme.spacing(2),
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        objectFit: 'contain',
        alignSelf: 'center',
    },
    styleBoxImg: {
        width: '90%',
        height: '255px',
        border: '1px solid #22292f',
        objectFit: 'contain',
        alignSelf: 'center',
    },
    imageContainer: {
        marginBottom: '10px',
        maxHeight: '80vh',
        overflow: 'scroll',
    },
    imageClass: {
        transformOrigin: '0 0',
        minWidth: '80vh',
    },
    buttonClass: {
        padding: '0px 15px 0px 15px',
        margin: '0px 8px 0px 8px',
        fontWeight: 'bold',
        fontSize: '25px',
        background: 'darkgray',
    },
}));
const TableRowStyles = withStyles({
    root: {
        border: '1px solid black',
    },
})(TableRow);
const TableCellStyles = withStyles({
    root: {
        border: '1px solid black',
    },
})(TableCell);

export const SPRuleTable = ({ setSelectedSRules, selectedSRules, allSpecialRules }) => {
    const classes = useStyles();
    function getModalStyle() {
        const top = 50;
        const left = 50;
        return {
            top: `${top}%`,
            left: `${left}%`,
            transform: `translate(-${top}%, -${left}%)`,
            textAlign: 'center',
        };
    }
    const [modalStyle] = React.useState(getModalStyle);
    const [open, setOpen] = React.useState(false);
    const [showImgUrl, setImgUrl] = React.useState(null);
    const [stateScale, setStateScale] = React.useState(1);
    const handleOpen = e => {
        setImgUrl(e.target.currentSrc);
        setOpen(true);
    };
    const handleClose = () => {
        setStateScale(1);
        setOpen(false);
    };
    const handleChange = (event, code) => {
        const list = selectedSRules;

        if (event.target.checked) {
            list.push(code);
        } else {
            const index = list.indexOf(code);
            if (index > -1) {
                list.splice(index, 1);
            }
        }
        setSelectedSRules(list);
    };

    const zoomIn = () => {
        setStateScale(stateScale + 0.1);
    };

    const zoomOut = () => {
        setStateScale(stateScale - 0.1);
    };

    return (
        <Table className={classes.table}>
            <TableHead>
                <TableRowStyles>
                    <TableCellStyles>Image</TableCellStyles>
                    <TableCellStyles align="center">Description</TableCellStyles>
                    <TableCellStyles align="right">Action</TableCellStyles>
                </TableRowStyles>
            </TableHead>
            <TableBody>
                {allSpecialRules.map(row => (
                    <TableRowStyles key={row.rule_id}>
                        <TableCellStyles className="w-2/6">
                            <img src={row.img_url} className={classes.styleBoxImg} onClick={handleOpen} />
                        </TableCellStyles>
                        <TableCellStyles align="left">{row.rule_desc}</TableCellStyles>
                        <TableCellStyles align="center">
                            <Checkbox
                                checked={!!selectedSRules.includes(row.rule_id)}
                                onChange={e => {
                                    handleChange(e, row.rule_id);
                                }}
                            />
                        </TableCellStyles>
                    </TableRowStyles>
                ))}
                <div className={classes.root}>
                    <Modal open={open} onClose={handleClose}>
                        <div style={modalStyle} className={classes.paper}>
                            <div className="container">
                                <div className={classes.imageContainer}>
                                    <img
                                        src={showImgUrl}
                                        style={{ transform: `scale(${stateScale})` }}
                                        className={classes.imageClass}
                                    />
                                </div>
                                <button className={classes.buttonClass} onClick={zoomIn}>
                                    +
                                </button>
                                <button className={classes.buttonClass} onClick={zoomOut}>
                                    -
                                </button>
                            </div>
                        </div>
                    </Modal>
                </div>
            </TableBody>
        </Table>
    );
};

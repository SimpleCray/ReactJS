import React, { useState, useMemo } from 'react';
import { Radio, RadioGroup, Paper } from '@material-ui/core';
import AppConstants from 'app/utils/appConstants';
import { useStyles, CustomFormControl } from './styles';

const KeyTypeDrawer = React.memo(({ keyType, onChangeKeyType }) => {
    const classes = useStyles();
    return (
        <Paper className={classes.paper}>
            <div className={classes.jss110}>KEYS TYPE</div>
            <RadioGroup
                aria-label="position"
                name="position"
                value={keyType}
                onChange={e => onChangeKeyType(e)}
                row
            >
                {AppConstants.KEYS_TYPE.map(item => (
                    <CustomFormControl
                        value={item[0]}
                        control={<Radio size="small" color="primary" />}
                        label={item[1]}
                        labelPlacement="end"
                        key={item[0]}
                    />
                ))}
            </RadioGroup>
        </Paper>
    );
});

export default KeyTypeDrawer;

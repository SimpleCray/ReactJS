/* eslint-disable no-nested-ternary */
import React, { useEffect, useState, useRef } from 'react';
import history from '@history';
import { useDispatch, useSelector } from 'react-redux';
import {
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
    Button,
    DialogContent,
    DialogContentText,
    withStyles,
} from '@material-ui/core';
import HighlightOffIcon from '@material-ui/icons/HighlightOff';
import withReducer from 'app/store/withReducer';
import 'styles/scss/sweet-alert.scss';
import AppConstants from 'app/utils/appConstants';
import MsgNotifications from 'app/utils/msgNotifications';
import * as FuseAction from 'app/store/actions/fuse';
import * as CommonActions from 'app/store/actions';
import { formatDateTimeString, getTimingRangeMSec, sumOfArray } from 'app/utils/utils';
import {
    checkPermissionAnnotation,
    updateDirectTemplateStatus,
    getIntKeyAndValueList,
    getMsgCheckValueData,
    getKeySeqsTemplate,
    checkGetCurrentRootPdf,
    getComLocDocMatching,
} from './annotateFunction';
import Annotate from './Annotate';
import * as AnnotateActions from './store/actions/actions';
import { useStyles } from './styles';
import reducer from './store/reducers/reducer';
import 'styles/scss/commons.scss';
import * as ViewDocFuncs from '../viewDoc/viewDocFuctions';

let isAnnotatingByOther = false;
let loadingTimeOut = null;

const DialogStyled = withStyles({
    root: {
        margin: 'auto',
        fontSize: '30px',
        fontWeight: 'bold',
    },
})(DialogTitle);

const objMatchingParams = {
    co_cd: '',
    lo_cd: '',
    doc_tp_id: '',
};

const Template = props => {
    const classes = useStyles();
    const dispatch = useDispatch();
    const currentTmpltKeySeq = useRef('');
    const newAnnotateTmpltKeySeq = useRef('');
    const templateVersion = useRef('');
    const matchingParamObj = useRef(objMatchingParams);
    const template = useSelector(({ annotate }) => annotate.template);
    const docFieldList = useSelector(({ annotate }) => annotate.docFieldList);
    const templateDone = useSelector(({ annotate }) => annotate.templateDone);
    const error = useSelector(({ annotate }) => annotate.error);
    const msgSubmitAnnotate = useSelector(({ annotate }) => annotate.msgSubmitAnnotate);
    const templateError = useSelector(({ annotate }) => annotate.error);
    const templateSavingStatus = useSelector(({ annotate }) => annotate.saveTemplate);
    const extractionStatus = useSelector(({ annotate }) => annotate.extractionStatus);
    const matchingStatus = useSelector(({ annotate }) => annotate.matchingStatus);
    // Check for the routing from extracted to annotation, to keep the newest pdf file when submit template and extract
    const propsPrevious = props.location.state ? props.location.state : null;
    const annotatePdf = template && template.root_url ? `${process.env.REACT_APP_DOC_LOC}/${template.root_url}` : '';
    const currentPdfFile = useSelector(state => checkGetCurrentRootPdf(state, propsPrevious, template));
    // Used when open URL annotate, get latest docID by template -> use to extract doc
    const currentDocId = useSelector(({ annotate }) => annotate.currentDocId);
    const prntCurrentDocId = useSelector(({ annotate }) => annotate.prntCurrentDocId);
    // Used to show message when user open the same template
    const tmpltStatusMsg = useSelector(({ annotate }) => annotate.tmpltStatusMsg);
    // Used from flow upload view-doc -> annotate
    const uploadedData = useSelector(state => {
        let uploadedData = {};
        if (state.viewDoc) {
            uploadedData = state.viewDoc.uploadedData;
            matchingParamObj.current = {
                co_cd: uploadedData.comCd,
                lo_cd: uploadedData.locCd,
                doc_tp_id: uploadedData.docTypeId,
            };
        }
        return uploadedData;
    });
    const [countdown, setCountdown] = useState(AppConstants.ALLOWED_ANNOTATION_TIME);
    const locationPathNamePart = window.location.pathname.split('/');
    let templateType = locationPathNamePart[locationPathNamePart.length - 2];
    const templateId = locationPathNamePart.pop();
    const startSubmitTemplate = useRef(new Date().getTime());
    // props.location.state?.docId: docId received when click generateNewFormat
    const docId = uploadedData.docId || currentDocId || propsPrevious?.docId || '';
    const loading = useSelector(({ annotate }) => annotate.loading);

    // just show file and box in file without any tool, use for annotation preview
    const readOnly = props?.location.search.includes('readonly');
    const isNewFormat = propsPrevious ? propsPrevious.newFormat : false;

    const showMessErrorAnnotate = message =>
        CommonActions.showMessage({
            message: message || MsgNotifications.GENERAL,
            variant: 'error',
        });

    const routingToViewDoc = () => {
        setTimeout(() => {
            history.push(AppConstants.VIEW_DOC_URL);
        }, 1000);
    };

    const showWarningOpenOtherTmpl = message =>
        CommonActions.showMessage({
            message: message || MsgNotifications.ANNOTATE.MATCHING_MATCHED_WITH_OTHER_TMPLT,
            variant: 'warning',
        });

    const onProcExtraction = reqExtractData => {
        setTimeout(() => {
            dispatch(
                FuseAction.showMessage({
                    message: MsgNotifications.ANNOTATE.DOCUMENT_IS_BEING_EXTRACTED,
                    variant: 'info',
                }),
            );
        }, 1500);
        dispatch(AnnotateActions.submitExtract(reqExtractData));
    };

    useEffect(() => {
        const timer = setInterval(() => {
            setCountdown(countdown => countdown - 1);
        }, 1000);
        window.addEventListener('beforeunload', e => {
            e.preventDefault();
            updateDirectTemplateStatus(templateId, AppConstants.TEMPLATE.STATUS.ANNOTATED, isAnnotatingByOther);
        });
        return () => {
            updateDirectTemplateStatus(templateId, AppConstants.TEMPLATE.STATUS.ANNOTATED, isAnnotatingByOther);
            dispatch(AnnotateActions.initStateAnnotation());
            clearInterval(timer);
        };
    }, []);

    useEffect(() => {
        dispatch(AnnotateActions.getTemplateData(templateType, templateId));
    }, [templateId]);

    useEffect(() => {
        if (template && template.doc_tp_id) {
            templateVersion.current = template.tmplt_ver_val;
            templateType = template.tp_val;
            if (docId) {
                const docTypeId = uploadedData.docTypeId ? uploadedData.docTypeId : template.doc_tp_id;
                dispatch(AnnotateActions.loadDocField(docId, docTypeId));
            } else {
                // In case open an annotation URL directly
                dispatch(AnnotateActions.getLatestDataByTmplId(templateId, matchingParamObj));
            }
            dispatch(
                AnnotateActions.getSPRule({
                    id: templateId,
                    type: templateType,
                    docTypeId: uploadedData.docTypeId ? uploadedData.docTypeId : template.doc_tp_id,
                }),
            );
        }
    }, [template]);

    useEffect(() => {
        if (!readOnly && docFieldList.length > 0 && template && template.sts_flg) {
            // Check annotating here by template data
            if (template.sts_flg === AppConstants.TEMPLATE.STATUS.ANNOTATING) {
                const usrId = localStorage.getItem(AppConstants.BP_USER_INFO)
                    ? JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO)).usrId
                    : '';
                if (template.proc_usr_id === usrId) {
                    dispatch(showMessErrorAnnotate(MsgNotifications.ANNOTATE.TEMPLATE_IS_OPENED_IN_OTHER_TAB));
                } else {
                    dispatch(showMessErrorAnnotate(MsgNotifications.ANNOTATE.TEMPLATE_ARE_BEING_USED));
                }
                routingToViewDoc();
                isAnnotatingByOther = false;
            } else {
                isAnnotatingByOther = true;
                dispatch(AnnotateActions.updateStatusForTemplate(templateId, AppConstants.TEMPLATE.STATUS.ANNOTATING));
                currentTmpltKeySeq.current = getKeySeqsTemplate(template);
            }
        }
    }, [template, docFieldList]);

    useEffect(() => {
        if (tmpltStatusMsg.length > 0) {
            dispatch(showMessErrorAnnotate(tmpltStatusMsg));
            routingToViewDoc();
            isAnnotatingByOther = false;
        }
    }, [tmpltStatusMsg]);

    useEffect(() => {
        if (msgSubmitAnnotate) {
            dispatch(showMessErrorAnnotate(msgSubmitAnnotate));
        }
    }, [msgSubmitAnnotate]);

    useEffect(() => {
        if (templateError) {
            // when view was loaded in iframe, when template error post message to view result to excute validate action
            if (readOnly) window.parent.postMessage('iframe error', '*');
            dispatch(showMessErrorAnnotate());
            routingToViewDoc();
        }
    }, [templateError]);

    /* ==================== BEGIN SAVING AND EXTRACTION PROCESS ==================== */
    // notify when save successful or failed
    useEffect(() => {
        if (templateSavingStatus) {
            dispatch(
                FuseAction.showMessage({
                    message: MsgNotifications.ANNOTATE.TEMPLATE_SAVE_SUCCESSFUL,
                    variant: 'success',
                }),
            );
            // Calling extraction, if generate new format, call extract without matching or check key seq
            if (propsPrevious && propsPrevious.editOnly) {
                history.push('/extract/template-management');
            } else {
                if (isNewFormat || newAnnotateTmpltKeySeq.current === currentTmpltKeySeq.current) {
                    const reqExtractData = {
                        file_url: currentPdfFile || annotatePdf,
                        doc_id: docId,
                        tmp_type: templateType,
                        tmp_id: templateId,
                        doc_tp_id: uploadedData.docTypeId || template.doc_tp_id,
                    };
                    console.log('---- ON EXTRACTING ----');
                    onProcExtraction(reqExtractData);
                } else {
                    const comLocDocInfo = getComLocDocMatching(matchingParamObj.current, propsPrevious, objMatchingParams);
                    const reqMatchingData = {
                        ...comLocDocInfo,
                        doc_id: docId,
                        file_url: currentPdfFile,
                        grp_val: '',
                    };
                    console.log('---- ON MATCHING ----');
                    setTimeout(() => {
                        dispatch(
                            FuseAction.showMessage({
                                message: MsgNotifications.ANNOTATE.MATCHING_MSG,
                                variant: 'info',
                            }),
                        );
                    }, 500);
                    dispatch(AnnotateActions.submitMatching(reqMatchingData));
                }
            }
        }
        if (templateSavingStatus === false) {
            dispatch(AnnotateActions.initStateAnnotation());
            dispatch(
                FuseAction.showMessage({ message: MsgNotifications.ANNOTATE.TEMPLATE_SAVE_FAILED, variant: 'error' }),
            );
        }
    }, [templateSavingStatus]);

    const routeToOtherPageTmpl = (tmpltType, tmpltId) => {
        // ViewDocFuncs.updateTemplateForDoc(docId, tmpltId);
        dispatch(AnnotateActions.updateStatusForTemplate(templateId, AppConstants.TEMPLATE.STATUS.ANNOTATED)); // Remove annotating on old tmplt
        dispatch(showWarningOpenOtherTmpl());
        dispatch(AnnotateActions.initStateAnnotation());
        setTimeout(() => {
            history.push({
                pathname: `/extract/annotation/${tmpltType}/${tmpltId}`,
                state: propsPrevious,
            });
        }, 300);
    };

    useEffect(() => {
        const matchingData = matchingStatus.data;
        if (matchingStatus.status && Object.keys(matchingData).length > 0) {
            const matchingTmpId = matchingData.tmp_id;
            const matchingTmpType = matchingData.tmp_type;
            if (matchingData.is_annotated) {
                const reqExtractData = {
                    file_url: currentPdfFile || annotatePdf,
                    doc_id: docId,
                    tmp_type: matchingTmpType,
                    tmp_id: matchingTmpId,
                    doc_tp_id: uploadedData.docTypeId || template.doc_tp_id,
                };
                console.log('---- ON EXTRACTING ----');
                if (templateId !== matchingTmpId) {
                    ViewDocFuncs.updateTemplateForDoc(docId, matchingData.tmp_id);
                }
                onProcExtraction(reqExtractData);
            } else if (matchingTmpId && matchingTmpType) {
                ViewDocFuncs.updateTemplateAfterMatching(matchingTmpId, matchingData);
                routeToOtherPageTmpl(matchingTmpType, matchingTmpId);
            } else {
                // Query to get template id
                const docTypeId = uploadedData.docTypeId || template.doc_tp_id;
                ViewDocFuncs.findOrCreateTemplateMatching(matchingData, docTypeId).then(res => {
                    const [mappedTmpType, mappedTmpId] = res;
                    if (mappedTmpId) {
                        routeToOtherPageTmpl(mappedTmpType, mappedTmpId);
                    } else {
                        dispatch(CommonActions.openDialog(MsgNotifications.GENERAL, 'Error', 'Alert'));
                    }
                });
            }
        }
        if (matchingStatus.status === false) {
            dispatch(AnnotateActions.initStateAnnotation());
            dispatch(CommonActions.openDialog(MsgNotifications.GENERAL, 'Error', 'Alert'));
            routingToViewDoc();
        }
    }, [matchingStatus]);

    useEffect(async () => {
        const extractedData = extractionStatus.data;
        if (extractionStatus.status && Object.keys(extractedData).length > 0) {
            dispatch(AnnotateActions.initStateAnnotation());
            try {
                const parentDocId = uploadedData.parentDocId ? uploadedData.parentDocId : prntCurrentDocId;
                const docTypeId = uploadedData.docTypeId || template.doc_tp_id || '';
                extractedData.data.tmplt_ver_val = templateVersion.current;
                await ViewDocFuncs.saveExtractAndRunBiz(docId, extractedData, docTypeId);
                const currentDate = new Date();
                const endTime = currentDate.getTime();
                const totalTimeToExt = getTimingRangeMSec(endTime, startSubmitTemplate.current);
                console.log(`Extracted - Extracted in: ${totalTimeToExt.minute} mins ${totalTimeToExt.sec} secs`);
                console.log(`OCR TIME Extraction: ${sumOfArray(extractedData.ocr_time)}`);
                dispatch(AnnotateActions.updateLoadingStatus(false));
                // Calling view Result
                if (parentDocId) {
                    history.push(`/info-extracted/${parentDocId}`);
                } else {
                    history.push(`/info-extracted/${docId}`);
                }
            } catch (err) {
                ViewDocFuncs.updateStatusDoc(docId, AppConstants.DOC_STATUS_CODE.F);
                dispatch(AnnotateActions.updateLoadingStatus(false));
                dispatch(AnnotateActions.initStateAnnotation());
                dispatch(CommonActions.openDialog(err.message, 'Error', 'Alert'));
                routingToViewDoc();
            }
        }
        if (extractionStatus.status === false) {
            dispatch(AnnotateActions.initStateAnnotation());
            dispatch(CommonActions.openDialog(MsgNotifications.ANNOTATE.EXTRACTION_FAILED, 'Error', 'Alert'));
            routingToViewDoc();
        }
    }, [extractionStatus]);
    /* ==================== END SAVE AND EXTRACT PROCESS ==================== */

    // If loading is over 2 mins 30 secs, close loading, show error -> routing
    useEffect(() => {
        if (loading) {
            // count time
            loadingTimeOut = setTimeout(() => {
                clearTimeout(loadingTimeOut);
                dispatch(AnnotateActions.initStateAnnotation());
                dispatch(
                    CommonActions.showMessage({
                        message: MsgNotifications.GENERAL,
                        variant: 'error',
                    }),
                );
                routingToViewDoc();
            }, AppConstants.TIMEOUT_LOADING);
        } else {
            clearTimeout(loadingTimeOut);
        }
    }, [loading]);

    const handleSubmitTemplate = (items, specialRuleList) => {
        const [key, value] = getIntKeyAndValueList(items);
        const flexibleCoordExtracted = propsPrevious ? propsPrevious.coordinate_flexible : {};
        const annotateData = {
            tmp_type: templateType,
            tmp_id: templateId,
            keys: key,
            values: value,
            rules: specialRuleList,
            root_url: annotatePdf,
            coordinate_flexible: flexibleCoordExtracted || {},
            doc_tp_id: uploadedData.docTypeId || template.doc_tp_id || '',
            annotateTime: AppConstants.ALLOWED_ANNOTATION_TIME - countdown,
            co_cd: getComLocDocMatching(matchingParamObj.current, propsPrevious, objMatchingParams).co_cd || '',
        };
        const msgCheck = getMsgCheckValueData(value);
        if (!msgCheck) {
            newAnnotateTmpltKeySeq.current = '';
            dispatch(AnnotateActions.updateLoadingStatus(true));
            // Save start annotate time to context
            const currentTime = new Date();
            startSubmitTemplate.current = currentTime.getTime();
            console.log(`Start submit template at: ${formatDateTimeString(currentTime)}`);
            console.log(`Root file template: ${annotatePdf}`);
            dispatch(
                AnnotateActions.submitTemplate(
                    annotateData,
                    docId,
                    newAnnotateTmpltKeySeq,
                    templateVersion,
                    propsPrevious ? propsPrevious.editOnly : false,
                ),
            );
        } else {
            dispatch(showMessErrorAnnotate(msgCheck));
        }
    };

    const checkingLoadingCondition = () => {
        if (
            templateDone &&
            !error &&
            checkPermissionAnnotation(
                template,
                templateType,
                templateId,
                countdown,
                `${process.env.REACT_APP_DOC_LOC}/${template.img_url}`,
            )
        )
            return true;
        return false;
    };

    return (
        <>
            {checkingLoadingCondition() ? (
                !error ? (
                    // Check if current user is same with processingBy User or not
                    template.img_url && (
                        <Annotate
                            {...props}
                            template={template}
                            countdown={countdown}
                            annotateImage={`${process.env.REACT_APP_DOC_LOC}/${template.img_url}`}
                            handleSubmitTemplate={handleSubmitTemplate}
                        />
                    )
                ) : (
                    <Dialog classes={{ paper: classes.paper1 }} open>
                        <div className={classes.highlight}>
                            <HighlightOffIcon style={{ fontSize: 150, margin: 'auto' }} color="error" />
                        </div>
                        <DialogStyled disableTypography>ERROR</DialogStyled>
                        <DialogContent>
                            <DialogContentText classes={{ root: classes.contentext }}>
                                {error ? `${error}` : MsgNotifications.ANNOTATE.COULD_NOT_OPEN_TEMPLATE}
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button onClick={routingToViewDoc} color="primary">
                                Ok
                            </Button>
                        </DialogActions>
                    </Dialog>
                )
            ) : (
                <div className={classes.circleloading}>
                    <CircularProgress size={200} />
                </div>
            )}
        </>
    );
};

export default withReducer('annotate', reducer)(Template);

import React from 'react';
import AppConstants from 'app/utils/appConstants';
import SearchTextField from 'app/components/SearchTextField';
import { MenuItem } from '@material-ui/core';

const ExtractionFieldType = ({ boxExtractionType, onChangeExtractionType }) => (
    <SearchTextField
        className="flex flex-1 menu-extraction-type"
        value={boxExtractionType || AppConstants.EXTRACTION_TYPE.EMPTY}
        onChange={onChangeExtractionType}
        label="Extraction Type"
        select
    >
        <MenuItem value={AppConstants.EXTRACTION_TYPE.EMPTY}>{AppConstants.EXTRACTION_TYPE.EMPTY}</MenuItem>
        <MenuItem value={AppConstants.EXTRACTION_TYPE.TICK}>{AppConstants.EXTRACTION_TYPE.TICK}</MenuItem>
        <MenuItem value={AppConstants.EXTRACTION_TYPE.FIX_HEIGHT}>{AppConstants.EXTRACTION_TYPE.FIX_HEIGHT}</MenuItem>
        <MenuItem value={AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL}>
            {AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL}
        </MenuItem>
        <MenuItem value={AppConstants.EXTRACTION_TYPE.KEEP_IN_HEADER}>
            {AppConstants.EXTRACTION_TYPE.KEEP_IN_HEADER}
        </MenuItem>
    </SearchTextField>
);

export default ExtractionFieldType;

import React, { useEffect, useState } from 'react';
import {
    Typography,
    IconButton,
    DialogTitle,
    Dialog,
    DialogActions,
    Button,
    DialogContent,
    Tooltip,
    Avatar,
} from '@material-ui/core';
import { Help, Undo, Redo } from '@material-ui/icons';
import textFormatWhite from 'assets/images/text_format_white.png';
import { useDispatch, useSelector } from 'react-redux';
import * as FuseAction from 'app/store/actions/fuse';
import MsgNotifications from 'app/utils/msgNotifications';
import ZoomOutIcon from '@material-ui/icons/ZoomOut';
import ZoomInIcon from '@material-ui/icons/ZoomIn';
import { useStyles } from './styles';
import { SPRuleTable } from './SpecialRule';
import { formatTime } from './annotateFunction';
import * as AnnotateActions from './store/actions/actions';
import { actions } from 'react-table';
import _ from '@lodash';

export const AnnotateToolbar = ({
    undoItems,
    canUndo,
    redoItems,
    canRedo,
    countdown,
    selectedSRules,
    setSelectedSRules,
    allSpecialRules,
}) => {
    const dispatch = useDispatch();
    const [openHelp, setOpenHelp] = useState(false);
    const [openSPRule, setOpenSPRule] = useState(false);
    const classes = useStyles();
    const scaleZoom = useSelector(({ annotate }) => annotate.scaleZoom);
    const isDrawing = useSelector(({ annotate }) => annotate.isDrawing);
    const handleHelpOpen = () => {
        setOpenHelp(true);
    };

    const handleHelpClose = () => {
        setOpenHelp(false);
    };
    const handleModalOpen = () => {
        setOpenSPRule(true);
    };

    const handleModalClose = () => {
        setOpenSPRule(false);
    };

    const zoomIn = () => {
        const zoomInValue = scaleZoom + 0.1;
        dispatch(AnnotateActions.setZoomScale(_.round(zoomInValue, 1)));
    };

    const zoomOut = () => {
        const zoomOutValue = scaleZoom > 0.1 ? scaleZoom - 0.1 : scaleZoom;
        dispatch(AnnotateActions.setZoomScale(_.round(zoomOutValue, 1)));
    };

    useEffect(() => {
        if (countdown) {
            if (countdown <= 1) {
                dispatch(
                    FuseAction.showMessage({
                        message: MsgNotifications.ANNOTATE.TIMEOUT,
                        variant: 'error',
                    }),
                );
                dispatch(AnnotateActions.onTimeout());
            }
        }
    }, [countdown]);

    return (
        <div id="icon_template" className={classes.sticky}>
            <Tooltip title="Special Rules">
                <IconButton disabled={isDrawing} onClick={handleModalOpen}>
                    <Avatar className={classes.avatar} src={textFormatWhite} />
                </IconButton>
            </Tooltip>
            <Tooltip title="Help">
                <IconButton disabled={isDrawing} onClick={handleHelpOpen}>
                    <Help color="primary" style={{ fontSize: 37 }} />
                </IconButton>
            </Tooltip>
            <IconButton onClick={undoItems} disabled={!canUndo || isDrawing}>
                <Undo style={{ fontSize: 37 }} />
            </IconButton>
            <IconButton onClick={redoItems} disabled={!canRedo || isDrawing}>
                <Redo style={{ fontSize: 37 }} />
            </IconButton>
            <Dialog open={openSPRule} onClose={handleModalClose} maxWidth="md">
                <DialogTitle disableTypography classes={{ root: classes.title1 }}>
                    <b>Special Rules</b>
                </DialogTitle>
                <DialogContent dividers>
                    <SPRuleTable
                        setSelectedSRules={setSelectedSRules}
                        selectedSRules={selectedSRules}
                        allSpecialRules={allSpecialRules}
                    />
                </DialogContent>
                <DialogActions>
                    {/* <Button color="primary">Save changes</Button> */}
                    <Button onClick={handleModalClose}>Close</Button>
                </DialogActions>
            </Dialog>
            {/** ********************* Help Dialog  *************************** */}
            <Dialog open={openHelp} onClose={handleHelpClose} maxWidth="md">
                <DialogTitle disableTypography classes={{ root: classes.title1 }}>
                    <b>README</b>
                </DialogTitle>
                <DialogContent>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        Press <b>"Q"</b> button to Add new Box
                    </Typography>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        Press <b>"A"</b> button to Start annotate selected Box
                    </Typography>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        Keep key <b>"Shift"</b> and Left-Click to Start annotate new Box
                    </Typography>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        Press <b>"D"</b> or <b>"Delete"</b> button to Delete selected Box
                    </Typography>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        Press <b>"W"</b> button to Select upward Box
                    </Typography>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        Press <b>"S"</b> button to Select downward Box
                    </Typography>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        Press <b>"Ctrl + F"</b> or <b>"F"</b> button to Focus search box
                    </Typography>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        Press <b>"Ctrl + Z"</b> to Undo active
                    </Typography>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        Press <b>"Ctrl + Shift + Z"</b> or <b>"Ctrl + Y"</b> to Redo active
                    </Typography>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        Press <b>"Enter"</b> button to Submit
                    </Typography>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        Press <b>"E"</b> button to switch between "KEYS" and "VALUES" annotation
                    </Typography>
                    <Typography gutterBottom classes={{ body1: classes.body1 }}>
                        In Key Template mode, "VALUE BOXES" will have gray color background and click-able to switch to
                        "KEYS" mode
                    </Typography>
                    {/* <Typography gutterBottom variant="h4">
                        Key Template mode only process with number of keys greater than 4 "Key", otherwise it will
                        process in Line Template mode.
                    </Typography> */}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleHelpClose}>OK</Button>
                </DialogActions>
            </Dialog>
            <IconButton title="Zoom out" onClick={zoomOut} disabled={isDrawing}>
                <ZoomOutIcon className={classes.iconDock} />
            </IconButton>
            <IconButton title="Zoom in hidden" onClick={zoomIn} disabled={isDrawing}>
                <ZoomInIcon className={classes.iconDock} />
            </IconButton>
            {/** ******************* Timer  ************************** */}
            <span className={classes.selection}>{formatTime(countdown)}</span>
        </div>
    );
};

export default AnnotateToolbar;

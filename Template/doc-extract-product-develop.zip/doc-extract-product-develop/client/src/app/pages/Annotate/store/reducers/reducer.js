import * as actionTypes from '../constants';

export const initialState = {
    loading: false,
    error: '',
    template: { data: { value_defined: [], key_defined: [] } },
    status: { data: {} },
    specialRule: [],
    templateDone: false,
    saveTemplate: null,
    docFieldList: [],
    currentDocId: '',
    prntCurrentDocId: '',
    extractionStatus: {
        status: null,
        data: {},
    },
    matchingStatus: {
        status: null,
        data: {},
    },
    msgSubmitAnnotate: null,
    appliedTemplateId: null,
    scaleZoom: 1,
    tmpltStatusMsg: '',
    isDrawing: false,
};

export default function AnnotateReducer(state = initialState, action) {
    switch (action.type) {
        case '@@router/LOCATION_CHANGE':
            return initialState;

        case actionTypes.ON_ANNOTATING_TIMEOUT:
            return { ...state, error: true };

        case actionTypes.GET_SPRULE_SUCCESSFUL:
            console.log('----GETTING SPECIAL RULE SUCCESSFUL----');
            return { ...state, specialRule: action.data };

        case actionTypes.GET_SPRULE_FAILED:
            return { ...state, error: true };

        case actionTypes.SUBMIT_TEMPLATE_SUCCESSFUL:
            console.log('----SAVE TEMPLATE SUCCESSFUL----');
            return { ...state, saveTemplate: true, loading: true, templateDone: true };

        case actionTypes.SUBMIT_TEMPLATE_FAILED:
            return { ...state, error: action.error, saveTemplate: false, loading: false, templateDone: true };

        case actionTypes.GET_TEMPLATE_FAILED:
            console.log('----GET TEMPLATE FAILED----');
            return { ...state, error: action.error, templateDone: true, loading: false };

        case actionTypes.GET_TEMPLATE_SUCCESSFUL:
            console.log('----GET TEMPLATE SUCCESSFUL----');
            return { ...state, template: action.data, loading: false };

        case actionTypes.LOAD_DOC_FIELD_SUCCESS:
            return { ...state, docFieldList: action.data, templateDone: true, loading: false };

        case actionTypes.LOAD_DOC_FIELD_FAILED:
            return { ...state, error: true, loading: false };

        case actionTypes.SAVE_TMPL_EXTRACTION_SUCCESS:
            console.log('---- EXTRACTION SUCCESS ----');
            return {
                ...state,
                extractionStatus: {
                    status: true,
                    data: action.data,
                },
                loading: true,
            };

        case actionTypes.SAVE_TMPL_EXTRACTION_FAILED:
            console.log('---- EXTRACTION ERROR ----');
            return {
                ...state,
                extractionStatus: {
                    status: false,
                    data: {},
                },
                loading: false,
            };

        case actionTypes.RELOAD_INIT_STATE_ANNOTATE:
            return {
                ...initialState,
                templateDone: false,
            };

        case actionTypes.UPDATE_LOADING_STATUS:
            return {
                ...state,
                loading: action.status,
            };

        case actionTypes.SAVE_TMPL_RELOAD_REDUCER:
            return {
                ...state,
                loading: false,
                extractionStatus: {
                    status: null,
                    data: {},
                },
                matchingStatus: {
                    status: null,
                    data: {},
                },
                prntCurrentDocId: '',
                currentDocId: '',
            };
        case actionTypes.SET_CURRENT_DOC_ID:
            return {
                ...state,
                prntCurrentDocId: action.data.prnt_doc_id,
                currentDocId: action.data.doc_id,
            };

        case actionTypes.SHOW_NOTI_ANNOTATION_CHECK:
            return {
                ...state,
                msgSubmitAnnotate: action.message,
            };
        case actionTypes.SUBMIT_TMP_MATCHING_SUCCESS:
            return {
                ...state,
                matchingStatus: {
                    status: true,
                    data: action.data,
                },
                loading: true,
            };
        case actionTypes.SUBMIT_TMP_MATCHING_FAILED:
            return {
                ...state,
                matchingStatus: {
                    status: false,
                    data: {},
                },
                loading: false,
            };
        case actionTypes.SET_SCALE_IMAGE:
            return {
                ...state,
                scaleZoom: action.scaleZoom,
            };
        case actionTypes.CATCH_UPDATE_TEMPLATE_STATUS_ERROR:
            return {
                ...state,
                tmpltStatusMsg: action.payload,
            };
        case actionTypes.DISABLE_COMPONENTS_WHEN_DRAWING:
            return {
                ...state,
                isDrawing: action.isDrawing,
            };
        default:
            return state;
    }
}

/* eslint-disable radix */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-plusplus */
/* eslint-disable operator-assignment */
/* eslint-disable no-param-reassign */
import AppConstants from 'app/utils/appConstants';
import EndPointAPI from 'app/utils/endPointAPI';
import { API_EP } from 'app/utils/commonAPI';
import { getUserId, getCurrentTimeString } from 'app/utils/utils';

let timer = null;
const edgeSize = 5;
const APPROXIMATE = 8;
export function arrayReplace(arr, index, item) {
    return [...arr.slice(0, index), ...(Array.isArray(item) ? item : [item]), ...arr.slice(index + 1)];
}

export function getAllDataBoxItems(keyDefined, valueDefined) {
    return keyDefined.concat(valueDefined);
}

export function getOldDataTemplate(template, docFieldList) {
    const oldKeyData = template.cordi_key_ctnt ? JSON.parse(template.cordi_key_ctnt) : [];
    const oldValueData = template.cordi_val_ctnt ? JSON.parse(template.cordi_val_ctnt) : [];
    const keyDefined = setKeydefined(oldKeyData);
    const currentId = oldKeyData.length || 0;
    const valueDefined = setValueDefined(oldValueData, docFieldList, currentId);
    return [keyDefined, valueDefined];
}

export function setKeydefined(keyDefined) {
    if (keyDefined) {
        for (let i = 0; i < keyDefined.length; i++) {
            keyDefined[i].x = keyDefined[i].x1;
            keyDefined[i].w = keyDefined[i].x2;
            keyDefined[i].y = keyDefined[i].y1;
            keyDefined[i].h = keyDefined[i].y2;
            keyDefined[i].w = keyDefined[i].w - keyDefined[i].x;
            keyDefined[i].h = keyDefined[i].h - keyDefined[i].y;
            keyDefined[i].id = i + 1;
            keyDefined[i].types.unshift('key');
            keyDefined[i].fields = [];
            keyDefined[i].names = [];
            keyDefined[i].typeIndex = [];
            keyDefined[i].boxName = i + 1;
        }
    }
    return keyDefined;
}

export function setValueDefined(valueDefined, annotationField, idx) {
    if (valueDefined) {
        for (let k = 0; k < valueDefined.length; k++) {
            valueDefined[k].x = valueDefined[k].x1;
            valueDefined[k].w = valueDefined[k].x2;
            valueDefined[k].y = valueDefined[k].y1;
            valueDefined[k].h = valueDefined[k].y2;
            valueDefined[k].w = valueDefined[k].w - valueDefined[k].x;
            valueDefined[k].h = valueDefined[k].h - valueDefined[k].y;
            valueDefined[k].id = idx + 1;
            valueDefined[k].types = ['value', 'static'];
            valueDefined[k].typeIndex = [];
            valueDefined[k].names = [];
            valueDefined[k].boxName = k + 1;
            const valueFieldDefines = valueDefined[k].fields;
            if (annotationField && valueFieldDefines && annotationField.length > 0) {
                for (let j = 0; j < valueFieldDefines.length; j++) {
                    annotationField.forEach(element => {
                        if (element.doc_fld_id === valueFieldDefines[j]) {
                            const index = annotationField.indexOf(element);
                            valueDefined[k].typeIndex.push(index);
                            valueDefined[k].names.push(element.fld_nm);
                            valueDefined[k].extr_type = valueDefined[k].extr_type
                                ? valueDefined[k].extr_type
                                : element.extr_tp_cd || AppConstants.EXTRACTION_TYPE.EMPTY;
                        }
                    });
                }
            }
            idx += 1;
        }
    }
    return valueDefined;
}

export function formatTime(time) {
    let seconds = time % 60;
    let minutes = Math.floor(time / 60);
    minutes = minutes.toString().length === 1 ? `0${minutes}` : minutes;
    seconds = seconds.toString().length === 1 ? `0${seconds}` : seconds;
    return `${minutes}:${seconds}`;
}

export function handleMousemove(event) {
    // Get the viewport-relative coordinates of the mousemove event.
    const viewportX = event.clientX;
    const viewportY = event.clientY;

    // Get the viewport dimensions.
    const viewportWidth = document.documentElement.clientWidth;
    const viewportHeight = document.documentElement.clientHeight;

    // Next, we need to determine if the mouse is within the "edge" of the
    // viewport, which may require scrolling the window. To do this, we need to
    // calculate the boundaries of the edge in the viewport (these coordinates
    // are relative to the viewport grid system).
    const edgeTop = edgeSize;
    const edgeLeft = edgeSize;
    const edgeBottom = viewportHeight - edgeSize;
    const edgeRight = viewportWidth - edgeSize;

    const isInLeftEdge = viewportX < edgeLeft;
    const isInRightEdge = viewportX > edgeRight;
    const isInTopEdge = viewportY < edgeTop;
    const isInBottomEdge = viewportY > edgeBottom;

    // If the mouse is not in the viewport edge, there's no need to calculate
    // anything else.
    if (!(isInLeftEdge || isInRightEdge || isInTopEdge || isInBottomEdge)) {
        clearTimeout(timer);
        return;
    }

    // If we made it this far, the user's mouse is located within the edge of the
    // viewport. As such, we need to check to see if scrolling needs to be done.
    const main = document.querySelector('#app > div > main');
    if (!main) return;
    // Get the document dimensions.
    const documentWidth = Math.max(
        main.scrollWidth,
        document.body.scrollWidth,
        document.body.offsetWidth,
        document.body.clientWidth,
        document.documentElement.scrollWidth,
        document.documentElement.offsetWidth,
        document.documentElement.clientWidth,
    );
    const documentHeight = Math.max(
        main.scrollHeight,
        document.body.scrollHeight,
        document.body.offsetHeight,
        document.body.clientHeight,
        document.documentElement.scrollHeight,
        document.documentElement.offsetHeight,
        document.documentElement.clientHeight,
    );

    // Calculate the maximum scroll offset in each direction. Since you can only
    // scroll the overflow portion of the document, the maximum represents the
    // length of the document that is NOT in the viewport.
    const maxScrollX = documentWidth - viewportWidth;
    const maxScrollY = documentHeight - viewportHeight;

    // As we examine the mousemove event, we want to adjust the window scroll in
    // immediate response to the event; but, we also want to continue adjusting
    // the window scroll if the user rests their mouse in the edge boundary. To
    // do this, we'll invoke the adjustment logic immediately. Then, we'll setup
    // a timer that continues to invoke the adjustment logic while the window can
    // still be scrolled in a particular direction.

    (function checkForWindowScroll() {
        clearTimeout(timer);

        if (adjustWindowScroll()) {
            timer = setTimeout(checkForWindowScroll, 30);
        }
    })();

    // Adjust the window scroll based on the user's mouse position. Returns True
    // or False depending on whether or not the window scroll was changed.
    function adjustWindowScroll() {
        // Get the current scroll position of the document.
        const currentScrollX = window.pageXOffset;
        const currentScrollY = window.pageYOffset;

        // Determine if the window can be scrolled in any particular direction.
        const canScrollUp = currentScrollY > 0;
        const canScrollDown = currentScrollY < maxScrollY;
        const canScrollLeft = currentScrollX > 0;
        const canScrollRight = currentScrollX < maxScrollX;

        // Since we can potentially scroll in two directions at the same time,
        // let's keep track of the next scroll, starting with the current scroll.
        // Each of these values can then be adjusted independently in the logic
        // below.
        let nextScrollX = currentScrollX;
        let nextScrollY = currentScrollY;
        // 10 is scroll speed

        // Should we scroll left?
        if (isInLeftEdge && canScrollLeft) {
            nextScrollX -= 10;

            // Should we scroll right?
        } else if (isInRightEdge && canScrollRight) {
            nextScrollX += 10;
        }

        // Should we scroll up?
        if (isInTopEdge && canScrollUp) {
            nextScrollY -= 10;

            // Should we scroll down?
        } else if (isInBottomEdge && canScrollDown) {
            nextScrollY += 10;
        }

        // Sanitize invalid maximums. An invalid scroll offset won't break the
        // subsequent .scrollTo() call; however, it will make it harder to
        // determine if the .scrollTo() method should have been called in the
        // first place.
        nextScrollX = Math.max(0, Math.min(maxScrollX, nextScrollX));
        nextScrollY = Math.max(0, Math.min(maxScrollY, nextScrollY));

        if (nextScrollX !== currentScrollX || nextScrollY !== currentScrollY) {
            window.scrollTo(nextScrollX, nextScrollY);
            return true;
        }

        return false;
    }
}

export function deleteItemValueById(listItem, itemId) {
    let indexOfItem = 0;
    for (let index = 0; index < listItem.length; index++) {
        if (listItem[index].id === itemId) {
            indexOfItem = index;
            break;
        }
    }
    return [...listItem.slice(0, indexOfItem), ...listItem.slice(indexOfItem + 1)];
}
export const getExistKeyValueField = data => {
    const keys = [];
    const { calculatedCoordinate } = data;
    if (data && data.keysCoors && data.keysCoors.length > 0) {
        data.keysCoors.forEach((item, idx) => {
            const k = {
                x1: parseInt(item.x1),
                y1: parseInt(item.y1),
                x2: parseInt(item.x2),
                y2: parseInt(item.y2),
                boxName: idx,
            };
            if (item.types) k.types = item.types;
            if (!calculatedCoordinate) k.recommend = true;
            keys.push(k);
        });
    }

    const fields = [];
    if (data && data.valuesCoors && data.valuesCoors.length > 0) {
        data.valuesCoors.forEach(item => {
            const value = {
                x1: parseInt(item.x1),
                y1: parseInt(item.y1),
                x2: parseInt(item.x2),
                y2: parseInt(item.y2),
                fields: item.fields,
                extr_type: item.extr_type || AppConstants.EXTRACTION_TYPE.EMPTY,
            };
            if (!calculatedCoordinate) value.recommend = true;
            fields.push(value);
        });
    }
    return [fields, keys];
};

/**
 * Used when turning on sub-format
 * Notice for user for old annotated boxes
 * @param {*} dataTemplate
 */
export const checkRecommendFieldKey = dataTemplate => {
    if (dataTemplate) {
        if (dataTemplate.key_defined) {
            const keys = JSON.parse(dataTemplate.key_defined);
            for (const key of keys) {
                if (key.recommend) return true;
            }
        }
        if (dataTemplate.value_defined) {
            const values = JSON.parse(dataTemplate.value_defined);
            for (const value of values) {
                if (value.recommend) return true;
            }
        }
    }
    return false;
};

/**
 * Check mimimum key and value box, current, SI have 5
 * TODO: Dynamic this, make var for 5
 * @param {*} key
 * @param {*} value
 */
export const checkMininumFieldTemplate = (key, value) => {
    if (
        (key && key.length < AppConstants.MINIMUM_KEY_VALUES_ANNOTATION) ||
        (value && value.length < AppConstants.MINIMUM_KEY_VALUES_ANNOTATION)
    )
        return false;
    return true;
};

/**
 * Check for the value box without any field
 * @param {*} key list
 * @param {*} value list
 */
export const checkValueFieldBox = values => {
    for (const value of values) {
        if (value.fields && value.fields.length === 0) return false;
    }
    return true;
};

/**
 * Check for the same Header and Footer in one box
 * @param {*} key list
 * @param {*} value list
 */
export const checkBoxHeaderFooter = values => {
    for (const value of values) {
        if (value.fields && value.fields.includes('header') && value.fields.includes('footer')) return false;
    }
    return true;
};

// Check with RnD about the req data
export const getIntKeyAndValueList = items => {
    const key = [];
    const value = [];
    let i = 0;
    if (items) {
        for (i; i < items.length; i++) {
            if (items[i].types && items[i].types[0] === AppConstants.BOX_VIEW.KEY) {
                key.push({
                    types: [items[i].types[1]],
                    x1: parseInt(items[i].x),
                    y1: parseInt(items[i].y),
                    x2: parseInt(items[i].w + items[i].x),
                    y2: parseInt(items[i].h + items[i].y),
                });
            } else {
                let fieldValueData = items[i].fields;
                if (items[i].extr_type === AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL) {
                    fieldValueData = [AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL];
                }
                const valueObj = {
                    fields: fieldValueData,
                    x1: parseInt(items[i].x),
                    y1: parseInt(items[i].y),
                    x2: parseInt(items[i].w + items[i].x),
                    y2: parseInt(items[i].h + items[i].y),
                    extr_type: items[i].extr_type || AppConstants.EXTRACTION_TYPE.EMPTY,
                };
                value.push(valueObj);
            }
        }
    }
    return [key, value];
};

export const getKeyAndValueList = items => {
    const key = [];
    const value = [];
    let i = 0;
    if (items) {
        for (i; i < items.length; i++) {
            if (items[i].types && items[i].types[0] === AppConstants.BOX_VIEW.KEY) {
                key.push({
                    types: [items[i].types[1]],
                    x1: items[i].x,
                    y1: items[i].y,
                    x2: items[i].w + items[i].x,
                    y2: items[i].h + items[i].y,
                });
            } else {
                value.push({
                    fields: items[i].fields,
                    x1: items[i].x,
                    y1: items[i].y,
                    x2: items[i].w + items[i].x,
                    y2: items[i].h + items[i].y,
                });
            }
        }
    }
    return [key, value];
};

/**
 * Check for value is not higher than top key
 * @param {*} keys
 * @param {*} values
 */
export const checkValueIsAboveKey = (keys, values) => {
    let yCenterKey = 0;
    let flagKey = true;

    // Find y center of top box key
    keys.forEach(boxKey => {
        if (boxKey.x1 === Number) return;
        const center = (boxKey.y2 + boxKey.y1) / 2;
        if (flagKey) {
            yCenterKey = center;
            flagKey = false;
        } else if (center < yCenterKey) yCenterKey = center;
    });

    let yBottomValue = 0;
    let flagValue = true;

    // Find y_bottom(y2) of top box value
    values.forEach(boxValue => {
        if (boxValue.x1 === Number) return;

        if (
            boxValue.fields &&
            ((boxValue.fields.header && boxValue.fields.header === true) ||
                (boxValue.fields.footer && boxValue.fields.footer === true))
        ) {
            return;
        }
        if (flagValue) {
            yBottomValue = boxValue.y2;
            flagValue = false;
        } else if (boxValue.y2 < yBottomValue) yBottomValue = boxValue.y2;
    });

    if (yBottomValue <= yCenterKey) return false;
    return true;
};

export const checkAnnotation = (preProcessedData, key, value) => {
    let message = '';
    let status = true;
    if (!preProcessedData) {
        // Need to get the pre_processed_data before save template
        status = false;
        message = 'Template can not save now. Please try again later!';
    } else if (!checkMininumFieldTemplate(key, value)) {
        status = false;
        message = 'Need to define minimum 5 boxes on each Key and Value Box!';
    } else if (!checkValueFieldBox(value)) {
        status = false;
        message = 'Value Box have to had at least one Field data!';
    } else if (!checkBoxHeaderFooter(value)) {
        status = false;
        message = 'Value Box should not have both Header and Footer. Please choose only one: Header or Footer!';
    } else if (!checkValueIsAboveKey(key, value)) {
        status = false;
        message = 'Value Box can not locate at higher position than Key Top Box!';
    }
    return [status, message];
};

export const checkIsAnnotated = dataTemplate => {
    let isAnnotated = false;
    if (dataTemplate) {
        if (dataTemplate.key_defined && JSON.parse(dataTemplate.key_defined).length > 0) {
            isAnnotated = true;
        }
        if (dataTemplate.value_defined && JSON.parse(dataTemplate.value_defined).length > 0) {
            isAnnotated = true;
        }
    }
    return isAnnotated;
};

export const isOverlapseItem = (fBox, sBox) => {
    const isTopLeftOverlapse =
        Math.abs(fBox.topLeftCoord.x - sBox.topLeftCoord.x) < APPROXIMATE &&
        Math.abs(fBox.topLeftCoord.y - sBox.topLeftCoord.y) < APPROXIMATE;
    const isBottomRightOverlapse =
        Math.abs(fBox.bottomRightCoord.x - sBox.bottomRightCoord.x) < APPROXIMATE &&
        Math.abs(fBox.bottomRightCoord.y - sBox.bottomRightCoord.y) < APPROXIMATE;
    return isTopLeftOverlapse && isBottomRightOverlapse;
};

export const isOverlapse = (compareBox, compareSet, id) => {
    const compareSetAfterFilter = id !== -1 ? compareSet.filter(item => item.id !== id) : compareSet;
    return compareSetAfterFilter.some(item => {
        const fBox = {
            topLeftCoord: { x: compareBox.x, y: compareBox.y },
            bottomRightCoord: { x: compareBox.x + compareBox.width, y: compareBox.y + compareBox.height },
        };
        const sBox = {
            topLeftCoord: { x: item.x, y: item.y },
            bottomRightCoord: { x: item.x + item.w, y: item.y + item.h },
        };
        return isOverlapseItem(fBox, sBox);
    });
};

export const formatSpecialRuleData = specialRules => {
    const list = [];
    if (specialRules && specialRules.length > 0) {
        for (let i = 0; i < specialRules.length; i++) {
            if (specialRules[i].isChecked) {
                list.push(specialRules[i].rule_id);
            }
        }
    }
    return list;
};

export const updateIdBoxNameItemList = (newItems, boxView, idBoxKey, idBoxValue) => {
    let i = 1;
    const typeBoxArr = boxView === AppConstants.BOX_VIEW.KEY ? idBoxKey : idBoxValue;
    const typeBox = boxView === AppConstants.BOX_VIEW.KEY ? AppConstants.BOX_VIEW.KEY : AppConstants.BOX_VIEW.VALUE;
    /** Update id and boxName after deleting item */
    for (let j = 0; j < newItems.length; j++) {
        if (newItems[j].id > i) {
            newItems[j].id = i;
        }
        i += 1;
    }
    let k = 1;
    newItems.forEach(element => {
        if (element.types[0] === typeBox) {
            if (element.boxName > k && k <= typeBoxArr) {
                element.boxName = k;
            }
            k += 1;
        }
    });
    return [newItems, typeBox];
};

export const getListValueDefined = (items, listValueDefined, allRowsSelected, allFieldData, id) => {
    const clone = items;
    const listField = [];
    const listName = [];
    const listIndex = [];
    for (let i = 0; i < allRowsSelected.length; i++) {
        listField.push(allFieldData[allRowsSelected[i].dataIndex].doc_fld_id);
        listName.push(allFieldData[allRowsSelected[i].dataIndex].fld_nm);
        listIndex.push(allRowsSelected[i].dataIndex);
    }
    const itemData = clone.filter(item => item.id === id)[0];
    if (itemData) {
        itemData.fields = listField;
        itemData.names = listName;
        itemData.typeIndex = listIndex;
    }
    const valueData = listValueDefined.filter(item => item.id === id)[0];
    if (valueData) {
        valueData.fields = listField;
        valueData.names = listName;
        valueData.typeIndex = listIndex;
    }
    return listValueDefined;
};

export const handleAlignOrderId = items => {
    let keyId = 1;
    let valueId = 1;
    if (!items || items.length <= 0) return [];
    const itemsTemp = items.map(item => ({ ...item }));
    items.forEach((item, index) => {
        itemsTemp[index].id = index + 1;
        if (item.types[0] === AppConstants.BOX_VIEW.KEY) {
            itemsTemp[index].boxName = keyId;
            keyId += 1;
        } else {
            itemsTemp[index].boxName = valueId;
            valueId += 1;
        }
    });
    return itemsTemp;
};

export const getFormatedReqBiz = (extractionData, fileName, matchingStatus) => {
    const reqData = {
        content_origin: {
            fields_data: extractionData.fields_data,
            fields_coordinate: extractionData.fields_coordinate,
            fields_sentences: extractionData.fields_sentences,
            fields_map: extractionData.fields_map,
            uncertain_highlight: extractionData.uncertain_highlight,
            size: extractionData.size,
        },
        file_name: fileName,
        template_type: matchingStatus.data.template_type,
        template_id: matchingStatus.data.template_id,
    };
    return reqData;
};

export const checkPermissionAnnotation = (template, templateType, templateId, countdown, fileUrl) => {
    if (!fileUrl) return false;
    return true;
};

export const createFormatedDataTemplate = template => {
    if (template) {
        const formatedTemplateData = {
            valuesCoors: JSON.parse(template.cordi_val_ctnt),
            keysCoors: JSON.parse(template.cordi_key_ctnt),
            calculatedCoordinate: template.cordi_calc_ctnt ? JSON.parse(template.cordi_calc_ctnt) : null,
        };
        const [tempValue, tempKey] = getExistKeyValueField(formatedTemplateData);
        return [JSON.stringify(tempValue), JSON.stringify(tempKey)];
    }
};

export const updateDirectTemplateStatus = (templateId, status, isAnnotatingByOther) => {
    if (isAnnotatingByOther) {
        fetch(`${process.env.REACT_APP_END_POINT}${EndPointAPI.ENDPOINT.TEMPLATE.UPDATE_STATUS}`, {
            method: 'PUT',
            body: JSON.stringify({
                tmpltId: templateId,
                status,
                usrId: getUserId(),
            }),
            keepalive: true,
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
        });
    }
};

// Used in FieldListTable
export const countSelectedField = arr => {
    const a = [];
    const b = [];
    let prev;

    arr.sort();
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] !== prev) {
            a.push(arr[i]);
            b.push(1);
        } else {
            b[b.length - 1]++;
        }
        prev = arr[i];
    }

    const listCountField = [];
    for (let i = 0; i < a.length; i++) {
        listCountField.push({ fieldCode: a[i], count: b[i] });
    }

    return listCountField;
};

// Used in FieldListTable
export const makeFieldList = list => {
    const listFieldCode = [];
    list.forEach(element => {
        element.fields.forEach(item => {
            listFieldCode.push(item);
        });
    });
    return listFieldCode;
};

export const checkSearchFldStatus = (isSearchOn, isSearchFocus) => {
    if (!isSearchOn) return true;
    if (!isSearchFocus) return true;
    return false;
};

export const getMsgCheckValueData = valueList => {
    if (valueList.length < 1) return 'Need to annotate for value boxes.';
    const haveEmptyVal = valueList.some(valueData => valueData.fields.length < 1);
    if (haveEmptyVal) return 'Some value boxes does not contain field data.';
    return '';
};

export const checkTmpltChangeVer = (template, keySeqAnnotation) => {
    let isNewTemplateVersion = false;
    const keySeqCurrent = getKeySeqsTemplate(template);
    if (keySeqAnnotation !== keySeqCurrent) isNewTemplateVersion = true;
    return isNewTemplateVersion;
};

export const getKeySeqsTemplate = template => {
    let keySeqs = '';
    if (template) {
        const corCalVal = template.cordi_calc_ctnt ? JSON.parse(template.cordi_calc_ctnt) : {};
        if (corCalVal && corCalVal.key_sequence) {
            keySeqs = corCalVal.key_sequence;
        }
    }
    return keySeqs;
};

export const getKeySeqsMatching = matchingResData => {
    return matchingResData.coord_cal && matchingResData.coord_cal.key_sequence
        ? matchingResData.coord_cal.key_sequence
        : '';
};

export const checkGetCurrentRootPdf = (state, propsPrevious, template) => {
    if (propsPrevious && state.extracted && state.extracted.docLink) return state.extracted.docLink;
    if (state.viewDoc && state.viewDoc.uploadedData && state.viewDoc.uploadedData.fileName)
        return `${process.env.REACT_APP_DOC_LOC}/${template.root_url}`;
    if (state.extracted && state.extracted.docLink) return state.extracted.docLink;
    return `${process.env.REACT_APP_DOC_LOC}/${template.root_url}` || '';
};

/**
 * This func is used to get the com, loc, doctype to pass in matching req
 * These params can be pass through the prevProps (From View Result routing)
 * Or can be get from latest docId was mapped with template
 */
export const getComLocDocMatching = (matchingObjParam, prevProps, initMatchingParams) => {
    let comLocDoc = initMatchingParams;
    if (matchingObjParam.co_cd) {
        comLocDoc = matchingObjParam;
    } else if (prevProps) {
        comLocDoc = prevProps.matchingData;
    }
    return comLocDoc;
};

export const modifyFieldListWithExtrType = (extrType, fieldList) => {
    if (
        extrType === AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL &&
        fieldList[0] !== AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL
    ) {
        // Add default fieldID to box, requested from CORE
        fieldList.push(AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL);
    } else if (
        extrType !== AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL &&
        fieldList[0] === AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL
    ) {
        fieldList.shift();
    }
    return fieldList;
};

export const updateTransaction = async templateData => {
    const transData = makeTemplateTransactionData(templateData);
    await API_EP.post(EndPointAPI.ENDPOINT.TRANSACTION.SAVE_TRANSACTION, JSON.stringify(transData)).catch(error => {
        throw error;
    });
    return true;
};

export const makeTemplateData = (data, oldTmplData) => {
    const templateData = {
        tmplt_id: oldTmplData.tmp_id,
        tp_val: oldTmplData.tmp_type,
        cordi_calc_ctnt: data.coord_cal,
        cordi_val_ctnt: oldTmplData.values,
        cordi_key_ctnt: oldTmplData.keys,
        rule_id_val: oldTmplData.rules.join(','),
        annotateTime: oldTmplData.annotateTime,
        co_cd: oldTmplData.co_cd,
    };
    return templateData;
};

/**
 * This func is use to save template to DB
 * @param {*}
 * @returns
 */
export const saveTemplateData = async (data, isNewVer, templateVersion) => {
    if (isNewVer) {
        const currentTimeString = getCurrentTimeString();
        data.tmplt_ver_val = currentTimeString;
        templateVersion.current = currentTimeString;
    }
    data.usrId = getUserId();
    await API_EP.post(EndPointAPI.ENDPOINT.TEMPLATE.SAVE, data, { params: { tmpltId: data.tmplt_id } }).catch(error => {
        throw error;
    });
    return true;
};

const makeTemplateTransactionData = templateData => {
    const tmpltTransData = {
        transTypeId: `${templateData.tp_val}-${templateData.tmplt_id}`,
        typeName: AppConstants.TRANSACTION_STATUS.ANNOTATE,
        userId: getUserId(),
    };
    tmpltTransData.transactionContent = {
        timeSpend: templateData.annotateTime,
        data: JSON.stringify(templateData),
    };
    return tmpltTransData;
};

/**
 * This func is use to save template to DB
 * @param {*}
 * @returns
 */
export const saveTemplateInfo = async (oldTemplateData, newTemplateData, keySeqAnnotation, templateVersion) => {
    const isNewVer = checkTmpltChangeVer(oldTemplateData, keySeqAnnotation);
    const templateData = makeTemplateData(newTemplateData, oldTemplateData);
    await saveTemplateData(templateData, isNewVer, templateVersion);
    await updateTransaction(templateData);
    return true;
};

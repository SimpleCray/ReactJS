import { makeStyles } from '@material-ui/styles';
import { withStyles, FormControlLabel } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
    root: {
        display: 'flex',
        overflow: 'auto',
        backgroundColor: 'white',
    },
    highlight: {
        padding: '20px',
        textAlign: 'center',
    },
    contentext: {
        fontSize: '20px',
        textAlign: 'center',
    },
    paper1: {
        minWidth: '450px',
    },
    circleloading: {
        display: 'flex',
        justifyContent: 'center',
        marginTop: 200,
    },
    wrap: {
        padding: theme.spacing(7),
        // backgroundColor: '#fafafa',
    },
    wrapReadonly: {
        paddingTop: 10
    },
    content: {
        border: '1mm solid rgba(131,132,135,0.6)',
        overflow: 'auto',
    },
    drawer: {
        width: '240px',
        maxHeight: '100%',
        flexShrink: 0,
    },
    drawerPaper: {
        width: '240px',
        maxHeight: '100%',
        marginTop: '0px',
    },
    drawerRight: {
        width: '380px',
        maxHeight: '100%',
        flexShrink: 0,
        paddingRight: '240px',
    },
    drawerPaperRight: {
        width: '380px',
        maxHeight: '100%',
        marginTop: '0px',
        paddingRight: '240px',
    },
    sticky: {
        position: 'fixed',
        left: '80px',
    },
    selection: {
        left: '290px',
        userSelect: 'none',
        color: 'red',
        fontSize: '25px',
    },
    timer: {
        position: 'fixed',
        top: 0,
        right: 0,
        zIndex: 999999,
    },
    textDrawer: {
        padding: '15px',
    },
    formControl: {
        margin: theme.spacing(1),
        maxWidth: 120,
    },
    select: {
        width: 100,
    },
    paperAnchorDockedRight: {
        backgroundColor: '#f5f5f5',
    },
    drawerHeader: {
        display: 'flex',
        alignItems: 'center',
        padding: theme.spacing(0, 1),
        // necessary for content to be below app bar
        ...theme.mixins.toolbar,
        justifyContent: 'flex-start',
    },
    avatar: {
        backgroundColor: '#3f51b5',
        width: theme.spacing(4),
        height: theme.spacing(4),
    },
    paper: {
        margin: '5px',
        maxHeight: 'calc(100%-50px)',
        boxShadow: 'none',
    },
    paperHeader: {
        margin: '0px 5px 5px 5px',
        maxHeight: 'calc(100%-50px)',
        boxShadow: 'none',
        position:'fixed', 
        zIndex: 1, 
        width: '14ch'
    },
    paperBody: {
        marginTop: '6rem',
        margin: '5px',
        maxHeight: 'calc(100%-50px)',
        boxShadow: 'none',
    },
    headerValueKey: {
        position: 'relative', 
        paddingTop: '40%'
    },
    jss109: {
        flexGrow: '1',
        paddingLeft: '8px',
        fontSize: '16px',
        fontWeight: 'bold',
    },
    jss108: {
        display: 'flex',
        alignItems: 'center',
    },
    iconDock: {
        fontSize: '3.0rem',
        color: 'black',
    },
    jss110: {
        display: 'flex',
        paddingTop: '10px',
        paddingLeft: '8px',
        paddingBottom: '8px',
        fontSize: '16px',
        alignItems: 'center',
        fontWeight: 'bold',
    },
    jss111: {
        display: 'flex',
        alignItems: 'center',
    },
    body1: {
        fontSize: '20px',
    },
    title1: {
        fontSize: '35px',
        margin: '15px',
    },
    primary: {
        fontWeight: 'bold',
    },
    list: {
        width: '100%',
        height: window.innerHeight,
        maxWidth: 360,
        backgroundColor: theme.palette.background.paper,
    },
    list_item: {
        borderBottom: '1px solid #e2e2e1',
    },
    horizontalLine: {
        position: 'fixed',
        display: 'none',
        marginTop: 1,
        borderTop: '2px solid red',
        width: '100%',
        transition: 'transform .2s ease-out, opacity .4s ease-in-out, border-color .4s ease-in, background-color .4s ease-out',
        pointerEvents: 'none',
    },
    verticalLine: {
        position: 'fixed',
        display: 'none',
        borderLeft: '2px solid red',
        height: '100%',
        transition: 'transform .2s ease-out, opacity .4s ease-in-out, border-color .4s ease-in, background-color .4s ease-out',
        pointerEvents: 'none',
    },
}));

export const CustomFormControl = withStyles({
    root: {
        width: '100%',
        paddingLeft: '10px',
    },
    label: {},
})(FormControlLabel);

export const getFieldListTheme = createMuiTheme({
    overrides: {
        MuiPaper: {
            elevation4: {
                boxShadow: 'none',
                height: 'calc(100% - 220px)',
            },
        },
        MUIDataTableHeadCell: {
            root: {
                fontSize: '12px',
            },
        },
        MuiTableHead: {
            root: {
                display: 'none',
            },
        },
        MUIDataTableToolbar: {
            root: {
                fontSize: '20px',
            },
            iconActive: {
                // Hide the search button when open search box
                display: 'none',
            },
        },
        MUIDataTableBodyCell: {
            root: {
                fontSize: '15px',
            },
        },
        MuiTypography: {
            caption: {
                display: 'none',
            },
        },
        MuiTablePagination: {
            input: {
                left: 5,
            },
        },
        MuiInputBase: {
            root: {
                fontSize: '15px',
            },
        },
        MuiSvgIcon: {
            root: {
                transform: 'scale(1.5)',
            },
        },
        MuiTableCell: {
            root: {
                padding: '10px',
            },
        }
    },
});

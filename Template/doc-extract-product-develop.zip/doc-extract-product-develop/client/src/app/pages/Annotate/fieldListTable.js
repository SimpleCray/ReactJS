/* eslint-disable no-return-assign */
/* eslint-disable no-plusplus */
/* eslint-disable react/prop-types */
/* eslint-disable no-unused-expressions */
import React, { useState, useMemo } from 'react';
import MUIDataTable from 'mui-datatables';
import { MuiThemeProvider } from '@material-ui/core/styles';
import AppConstants from 'app/utils/appConstants';
import { getFieldListTheme } from './styles';
import { countSelectedField, makeFieldList } from './annotateFunction';

const FieldListTable = React.memo(
    ({
        data,
        isSortedFields,
        listValueData,
        onRowSelectionChange,
        onRowClick,
        showSearchField,
        isSearchOn,
        isSearchFocus,
        editID,
        items,
        searchText,
        setSearchText,
        setIsSearchOn,
        setIsSearchFocus,
    }) => {
        let onFucus = 0;
        const [columns, setColumns] = useState([
            {
                name: 'fld_nm',
                label: 'Name',
                options: {
                    filter: false,
                    sort: false,
                },
            },
            {
                name: 'count', // set it to props.listValueData
                label: '-',
                options: {
                    filter: false,
                    sort: false,
                },
            },
        ]);

        const OrderedData = useMemo(() => {
            if (items && items.length >= editID - 1) {
                if (items[editID - 1] &&
                    (items[editID - 1].fields.length > 0 || (items[editID - 1].fields.length == 0 && items.length > editID) )
                    && editID != listValueData.length) {
                    onFucus = editID;
                }
            }
            const firstMappedItem = listValueData.filter(item => item.id === editID)[0];
            let fieldSelected = [];
            let typeIndex = [];

            if (editID && firstMappedItem) {
                fieldSelected = firstMappedItem.fields;
                typeIndex = firstMappedItem.typeIndex;
            }
            let output;
            const arr = [];
            const arr2 = [];
            const rowSelected = [];
            let flgN = false;
            if (!isSortedFields) {
                if (fieldSelected.length === 0) {
                    return (output = {
                        rowSelected,
                        data,
                    });
                }
                for (let j = 0; j < data.length; j++) {
                    const fldCd1 = data[j].doc_fld_id;
                    for (let i = 0; i < fieldSelected.length; i++) {
                        const fldCd2 = fieldSelected[i];
                        if (fldCd2 === fldCd1) {
                            arr.push(data[j]);
                            rowSelected.push(i);
                            flgN = true;
                        }
                    }
                    if (flgN) {
                        flgN = false;
                        continue;
                    } else if (data.indexOf(arr[j]) < 0) {
                        arr2.push(data[j]);
                    }
                }
                output = {
                    rowSelected,
                    data: arr.concat(arr2),
                };
            } else {
                output = {
                    rowSelected: typeIndex,
                    data,
                };
            }
            return output;
        }, [data, items, isSortedFields, editID, listValueData]);

        const makeFieldCountList = list => {
            const listFieldCode = makeFieldList(list);
            return countSelectedField(listFieldCode);
        };

        const combineCountValueIntoData = listOrderData => {
            const listFieldCount = makeFieldCountList(listValueData);
            for (let i = 0; i < listOrderData.length; i++) {
                for (let j = 0; j < listFieldCount.length; j++) {
                    if (listFieldCount[j].fieldCode === listOrderData[i].doc_fld_id) {
                        listOrderData[i].count = listFieldCount[j].count;
                        break;
                    } else listOrderData[i].count = 0;
                }
            }
            return listOrderData;
        };

        const fieldListData = useMemo(() => combineCountValueIntoData(OrderedData.data), [
            OrderedData.data,
            editID,
            items,
            isSortedFields,
            listValueData,
        ]);

        const tableOptions = {
            viewColumns: false,
            download: false,
            print: false,
            searchOpen: isSearchOn,
            searchProps: {
                // onBlur: () => showSearchField(false),
                onClick: () => showSearchField(true),
                autoFocus: isSearchOn && isSearchFocus,
            },
            onSearchChange: searchText => {
                setSearchText(searchText);
            },
            onSearchClose: () => {
                setIsSearchOn(false);
                setSearchText('');
                setIsSearchFocus(false);
            },
            searchText,
            filter: false,
            pagination: false,
            fixedHeader: false,
            fixedSelectColumn: false,
            tableBodyMaxHeight: '100%',
            selectToolbarPlacement: 'none',
            rowsSelected: OrderedData.rowSelected,
            selectableRows:
                editID === null ||
                editID === '' ||
                editID === undefined ||
                (items[editID - 1] &&
                    items[editID - 1].extr_type === AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL)
                    ? 'none'
                    : 'multiple',
            isRowSelectable: (dataIndex, selectedRows) => {
                if (
                    items[editID - 1] &&
                    items[editID - 1].extr_type === AppConstants.EXTRACTION_TYPE.HEADER_FOOTER_REMOVAL
                ) {
                    return false;
                }
                return true;
            },
            onRowSelectionChange: (currentRowsSelected, allRowsSelected) => {
                // On clicking checkbox to add field for box
                onRowSelectionChange(allRowsSelected, editID, OrderedData.data);
            },
            onRowClick: (rowData, rowMeta) => {
                // On clicking each field on lists
                onRowClick(rowData);
            },
        };

        return (
            <MuiThemeProvider theme={getFieldListTheme}>
                <MUIDataTable
                    key= {`${onFucus}-${isSearchFocus && isSearchOn}`}
                    title="Annotation Fields"
                    data={fieldListData}
                    columns={columns}
                    options={tableOptions}
                />
            </MuiThemeProvider>
        );
    },
);

export default FieldListTable;

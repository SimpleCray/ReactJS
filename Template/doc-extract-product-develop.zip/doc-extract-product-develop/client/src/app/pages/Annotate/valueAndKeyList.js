import React, { useState, useEffect } from 'react';
import { Drawer, Paper, List, ListItem, ListItemText, IconButton } from '@material-ui/core';
import { Loop } from '@material-ui/icons';
import AppConstants from 'app/utils/appConstants';
import { useStyles } from './styles';

export default function ValueAndKeyBoxList({
    editID,
    items,
    editIdArray,
    boxView,
    handleChangeFocus,
    isSelectOneBox,
    handleChangeBoxView,
}) {
    const classes = useStyles();

    const getStyleOfBox = item => {
        let styleObj = {};
        const styleCondition = isSelectOneBox.current ? editIdArray.includes(item.id) : item.id === editID;
        styleObj = styleCondition ? { backgroundColor: '#c5deed' } : {};
        return styleObj;
    };

    return (
        <Drawer
            open
            className={classes.drawerRight}
            classes={{
                paper: classes.drawerPaperRight,
                paperAnchorDockedRight: classes.paperAnchorDockedRight,
            }}
            variant="permanent"
            anchor="right"
        >
            <div className={classes.headerValueKey}>
                <Paper className={classes.paperHeader}>
                    <div className={classes.jss108}>
                        <IconButton onClick={handleChangeBoxView}>
                            <Loop style={{ fontSize: 18 }} />
                        </IconButton>
                        <div className={classes.jss109}>{boxView.toUpperCase()}</div>
                    </div>
                </Paper>
            </div>
            <Paper className={classes.paperBody}>
                <div className={classes.jss111}>
                    <div className={classes.list}>
                        <List component="nav" aria-label="main mailbox folders">
                            {items
                                .filter(item => item.types[0] === boxView)
                                .map((item, index) => (
                                    <ListItem
                                        button
                                        dense
                                        onClick={() => handleChangeFocus(item.id)}
                                        autoFocus={
                                            isSelectOneBox.current ? editIdArray[0] === item.id : item.id === editID
                                        }
                                        key={index}
                                        style={getStyleOfBox(item)}
                                        className={classes.list_item}
                                    >
                                        <ListItemText primary={`Box ${item.boxName}`} />
                                        <ListItemText primary=" - " />
                                        <ListItemText
                                            primary={
                                                boxView === AppConstants.BOX_VIEW.KEY ? 'Done' : item.fields.length
                                            }
                                        />
                                    </ListItem>
                                ))}
                        </List>
                    </div>
                </div>
            </Paper>
        </Drawer>
    );
}

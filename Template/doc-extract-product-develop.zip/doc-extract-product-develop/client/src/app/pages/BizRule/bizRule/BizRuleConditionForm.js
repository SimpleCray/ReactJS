/* eslint-disable no-nested-ternary */
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MenuItem, TextField, Tooltip, IconButton, ClickAwayListener } from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';
import AddCircleIcon from '@material-ui/icons/AddCircle';
import RemoveCircleIcon from '@material-ui/icons/RemoveCircle';
import withReducer from '../../../store/withReducer';
import AppConstants from 'app/utils/appConstants';

import reducer from '../store/reducers';
import * as Actions from '../store/actions/actions';
import * as CommonDataFunctions from 'app/pages/CommonData/commonDataFunction';
import * as Functions from '../BizRuleFunction';

const BizRuleConditionForm = props => {
    const classes = Functions.useStyles();
    const dispatch = useDispatch();

    const bizRuleConditions = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.bizRuleCondition);
    const commonActCondData = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.commonActCondData);
    const commonData = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.commonData);
    const ruleFieldById = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.ruleFieldById);
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));

    const [fieldTypeOption, setFieldTypeOption] = useState([]);
    const [listComponent, setListComponent] = useState([]);
    const [errorFlag, setErrorFlag] = useState(false);
    const [tempMultipleInput, setTempMultipleInput] = useState('');

    const handleValidateShowError = () => {
        const conditionError =
            !Array.isArray(bizRuleConditions[(props?.index)]['value']) ||
            bizRuleConditions[(props?.index)]['value'].some(item => !item.value || item.value.length === 0) ||
            !bizRuleConditions[(props?.index)]?.field;
        setErrorFlag(conditionError);
    };

    const handleAddCondition = () => {
        props.setConditionHasError(false);
        const newCondition = { index: props?.index + 1, field: '', value: [] };
        const afterAddCondition = Functions.handleAddToArray(bizRuleConditions, newCondition, props?.index + 1);
        const afterAlignArrayCondition = Functions.reOrderNumber(afterAddCondition);
        dispatch(Actions.addBizRuleCondition(afterAlignArrayCondition));
    };

    const handleRemoveCondition = () => {
        const afterRemoveCondition = bizRuleConditions.filter(item => item.index !== props?.index);
        const afterAlignArrayCondition = Functions.reOrderNumber(afterRemoveCondition);
        dispatch(Actions.addBizRuleCondition(afterAlignArrayCondition));
    };

    const handleChangeFieldType = async (currentIndex, currentField) => {
        const renderComponent = fieldTypeOption.find(item => item.key === currentField);
        if (renderComponent?.extend !== 'N') {
            setListComponent(renderComponent.extend);
            const updatedCondition = bizRuleConditions.map((item, index) =>
                index === currentIndex ? { ...item, field: currentField, value: renderComponent.extend } : item,
            );
            await dispatch(Actions.addBizRuleCondition(updatedCondition));
        } else if (renderComponent?.extend === 'N') {
            setListComponent([]);
            const updatedCondition = bizRuleConditions.map((item, index) =>
                index === currentIndex ? { ...item, field: currentField, value: '' } : item,
            );
            await dispatch(Actions.addBizRuleCondition(updatedCondition));
        }
    };

    const handleChangeChildComponent = async (currentIndex, currentVal, detail) => {
        if (['select', 'select-input'].includes(detail.type)) {
            const positionOfDetail = listComponent.findIndex(item => item.key === detail.key);
            const newListComponent = listComponent.slice(0, positionOfDetail + 1);

            if (detail?.extend && Array.isArray(detail.extend)) newListComponent.push(...detail.extend);
            if (detail?.option && Array.isArray(detail.option)) {
                const extendOfOption = detail.option.find(item => item.key === currentVal)?.extend;
                if (extendOfOption && Array.isArray(extendOfOption)) newListComponent.push(...extendOfOption);
            }
            const updatedListComponent = newListComponent.map(item =>
                item.key === detail.key
                    ? { ...detail, value: detail.type === 'select' ? currentVal : [currentVal] }
                    : { ...item },
            );
            setListComponent(updatedListComponent);
            const updatedCondition = bizRuleConditions.map(item =>
                item.index === currentIndex ? { ...item, value: updatedListComponent } : item,
            );
            await dispatch(Actions.addBizRuleCondition(updatedCondition));
        } else {
            const updatedListComponent = listComponent.map(item => {
                if (item.key === detail.key)
                    return { ...detail, value: Array.isArray(currentVal) ? currentVal : [currentVal] };
                return { ...item };
            });
            setListComponent(updatedListComponent);
            const updatedCondition = bizRuleConditions.map(item =>
                item.index === currentIndex ? { ...item, value: updatedListComponent } : item,
            );
            await dispatch(Actions.addBizRuleCondition(updatedCondition));
        }
    };

    const getOptionField = () => {
        return bizRuleConditions[(props?.index)].field === 'extend'
            ? props?.extendField.filter(item => item.doc_fld_id !== props?.defaultExtend.doc_fld_id)
            : props?.extendField;
    };

    // Load all component for render ui
    // If creating, load from common data, else load from saved database
    useEffect(() => {
        props.closeSideBar();
        if (bizRuleConditions && bizRuleConditions[(props?.index)])
            setListComponent(bizRuleConditions[(props?.index)]['value']);
    }, [bizRuleConditions]);

    // Handle common data
    useEffect(() => {
        if (commonActCondData) {
            const commonCondition = commonActCondData.find(item => item.com_dat_cd === 'COND_FLD_TP');
            if (commonCondition) {
                setFieldTypeOption(
                    commonCondition.com_dat_val.data.map(item => ({
                        ...JSON.parse(item.value),
                        deleted: item.deleted,
                    })),
                );
            }
        }
    }, [commonActCondData]);

    useEffect(() => {
        if (props?.conditionHasError) handleValidateShowError();
        else setErrorFlag(false);
    }, [props?.conditionHasError]);

    return (
        <div className={classes.conditionItemContainer}>
            <div className="flex w-2/12">
                <TextField
                    {...Functions.textFieldCommonProps(classes)}
                    select
                    label="Field type"
                    value={bizRuleConditions[(props?.index)]?.field}
                    onChange={e => handleChangeFieldType(props?.index, e.target.value)}
                    error={errorFlag && !bizRuleConditions[(props?.index)]?.field}
                >
                    {fieldTypeOption
                        ?.filter(item => item.deleted === 'No')
                        .map(item => (
                            <MenuItem key={item.key} value={item.key}>
                                {item.label}
                            </MenuItem>
                        ))}
                </TextField>
            </div>

            <div className={classes.gapContainer}>
                {listComponent &&
                    Array.isArray(listComponent) &&
                    listComponent.map(item => {
                        const currentCondition = bizRuleConditions[(props?.index)] || {};

                        if (item.type === 'input' && item.multiple === 'N')
                            return (
                                <div className="flex w-3/12" key={item.key}>
                                    <TextField
                                        {...Functions.textFieldPropsExtend(item, classes)}
                                        error={errorFlag && !item.value}
                                        onChange={e => handleChangeChildComponent(props?.index, e.target.value, item)}
                                    />
                                </div>
                            );

                        if (item.type === 'select') {
                            const isGroupField = ruleFieldById[0]?.AdmDocFld.fld_grp_id;
                            let renderColumnToItem = { ...item };
                            let currentCommonData = {};
                            let columnNameData = [];

                            const optionLoadColumn = Array.isArray(item.option)
                                ? item.option.find(option => option.key === 'common-column-load')
                                : null;

                            // Get column data in case need common data
                            // Return list of mapping item like normal option in JSON define (key and label is column code)
                            if (optionLoadColumn) {
                                const commonInBiz = currentCondition.value.find(
                                    inBiz => inBiz?.value && Array.isArray(inBiz.value) && inBiz.value[0]?.com_dat_id,
                                );

                                currentCommonData =
                                    commonInBiz &&
                                    commonData.find(cmDt => cmDt.com_dat_id === commonInBiz.value[0]?.com_dat_id);

                                if (currentCommonData) {
                                    columnNameData = currentCommonData
                                        ? currentCommonData.com_dat_val.header.slice(0, -1).map(item => ({
                                              ...optionLoadColumn,
                                              key: item,
                                              label: item,
                                          }))
                                        : [];

                                    renderColumnToItem = {
                                        ...item,
                                        option: item.option.flatMap(option =>
                                            option.key === 'common-column-load' ? [...columnNameData] : [option],
                                        ),
                                    };
                                }
                            }

                            return (
                                <div className="flex w-3/12" key={item.key}>
                                    <TextField
                                        {...Functions.textFieldPropsExtend(item, classes)}
                                        select
                                        error={errorFlag && !item.value}
                                        onChange={e =>
                                            handleChangeChildComponent(props?.index, e.target.value, renderColumnToItem)
                                        }
                                    >
                                        {Array.isArray(renderColumnToItem.option) &&
                                            renderColumnToItem.option.flatMap(subItem => {
                                                if (subItem.needGround === 'Y') {
                                                    return isGroupField ? (
                                                        <MenuItem key={subItem.key} value={subItem.key}>
                                                            {subItem.label}
                                                        </MenuItem>
                                                    ) : (
                                                        []
                                                    );
                                                }
                                                return (
                                                    <MenuItem key={subItem.key} value={subItem.key}>
                                                        {subItem.label}
                                                    </MenuItem>
                                                );
                                            })}
                                    </TextField>
                                </div>
                            );
                        }

                        if (item.type === 'input' && item.multiple === 'Y')
                            return (
                                <div className="flex w-3/12" key={item.key}>
                                    <ClickAwayListener
                                        onClickAway={() => {
                                            if (tempMultipleInput.length > 0)
                                                handleChangeChildComponent(
                                                    props?.index,
                                                    [...item.value, tempMultipleInput],
                                                    item,
                                                );
                                            setTempMultipleInput('');
                                        }}
                                    >
                                        <Autocomplete
                                            {...Functions.autoCompleteProps(item, classes)}
                                            multiple
                                            options={[]}
                                            open={false}
                                            value={item.value || []}
                                            renderInput={params => (
                                                <TextField
                                                    {...params}
                                                    error={errorFlag && (!item.value || item.value?.length === 0)}
                                                    label={item.label}
                                                    variant="outlined"
                                                    onKeyDown={e => {
                                                        if (e.keyCode === 13 && e.target.value)
                                                            handleChangeChildComponent(
                                                                props?.index,
                                                                [...item.value, e.target.value],
                                                                item,
                                                            );
                                                    }}
                                                    onBlur={e => setTempMultipleInput(e.target.value)}
                                                />
                                            )}
                                            onChange={(e, value) =>
                                                handleChangeChildComponent(props?.index, value, item)
                                            }
                                        />
                                    </ClickAwayListener>
                                </div>
                            );
                        if (item.type === 'select-input') {
                            let formatCommonData = null;
                            if (
                                Array.isArray(item.option) &&
                                item.option.some(option => option.key === 'common-table-load')
                            ) {
                                formatCommonData = CommonDataFunctions.getCommonByRole(commonData, userInfo);
                            }
                            const getOptions = formatCommonData || getOptionField() || [];
                            const id =
                                getOptions.length > 0 && Object.keys(getOptions[0]).find(el => el.includes('id'));
                            const getValue = id
                                ? getOptions.find(el => item.value[0] && el[id] === item.value[0][id])
                                : '';

                            return (
                                <div className="flex w-3/12" key={item.key}>
                                    <Autocomplete
                                        {...Functions.autoCompleteProps(item, classes)}
                                        disableClearable
                                        options={getOptions}
                                        getOptionLabel={option =>
                                            (formatCommonData ? option.com_dat_nm : option.fld_nm) || ''
                                        }
                                        renderInput={params => (
                                            <TextField
                                                key={item.key}
                                                {...params}
                                                error={errorFlag && !item.value}
                                                label={item.label}
                                                variant="outlined"
                                            />
                                        )}
                                        value={getValue || ''}
                                        onChange={(e, value) => handleChangeChildComponent(props?.index, value, item)}
                                    />
                                </div>
                            );
                        }
                        return <div />;
                    })}
            </div>

            <div className="absolute right-0 flex justify-end w-1/12">
                <Tooltip title="Add">
                    <IconButton aria-label="Add" onClick={handleAddCondition}>
                        <AddCircleIcon />
                    </IconButton>
                </Tooltip>
                <Tooltip title="Remove">
                    <span>
                        <IconButton
                            aria-label="Remove"
                            disabled={bizRuleConditions.length === 1}
                            onClick={handleRemoveCondition}
                        >
                            <RemoveCircleIcon />
                        </IconButton>
                    </span>
                </Tooltip>
            </div>
        </div>
    );
};

export default withReducer('BizRuleReducer', reducer)(BizRuleConditionForm);

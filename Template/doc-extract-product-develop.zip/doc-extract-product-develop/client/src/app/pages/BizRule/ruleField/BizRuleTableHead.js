import React from 'react';
import { TableRow, TableHead, TableCell, Tooltip, TableSortLabel } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import AppConstants from 'app/utils/appConstants';
import * as TableFnc from 'app/utils/tableFunctions';
import * as Constraint from '../BizRuleConstants';

export default function BizRuleTableHead(props) {
    const header = props?.type === 'left-table' ? Constraint.setupBizRuleHead : Constraint.setupBizRuleHeadDetail;
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));
    if (userInfo.usrId !== 'admin' && props?.type === 'left-table') {
        TableFnc.hideColComName(header);
    }
    const createSortHandler = property => event => props.onRequestSort(event, property);
    const StyledTableCell = withStyles(theme => ({
        head: {
            backgroundColor: theme.palette.primary.main,
            color: theme.palette.common.white,
        },
        body: {
            fontSize: 14,
        },
    }))(TableCell);

    return (
        <TableHead>
            <TableRow>
                {header.slice(1).map(item => (
                    <StyledTableCell key={item.id} className={`text-left ${item.width}`}>
                        {item.sort && (
                            <Tooltip
                                title=""
                                placement={item.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                enterDelay={300}
                            >
                                <TableSortLabel
                                    active={props.order.id === item.id}
                                    direction={props.order.direction}
                                    onClick={createSortHandler(item.id)}
                                >
                                    {item.label}
                                </TableSortLabel>
                            </Tooltip>
                        )}
                    </StyledTableCell>
                ))}
            </TableRow>
        </TableHead>
    );
}

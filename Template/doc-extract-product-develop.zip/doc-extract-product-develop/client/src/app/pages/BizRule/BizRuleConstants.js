export const setupBizRuleHead = [
    {
        id: 'biz_rule_id',
        align: 'left',
        disablePadding: false,
        label: 'Id',
        sort: true,
    },
    {
        id: 'AdmDocFld.fld_nm',
        align: 'left',
        disablePadding: false,
        label: 'Field name',
        sort: true,
    },
    {
        id: 'co_nm',
        align: 'left',
        disablePadding: false,
        label: 'Company name',
        sort: true,
    },
    {
        id: 'DexLoc.loc_nm',
        align: 'left',
        disablePadding: false,
        label: 'Location name',
        sort: true,
    },
    {
        id: 'DexLoc.documents.doc_nm',
        align: 'left',
        disablePadding: false,
        label: 'Document name',
        sort: true,
    },
];

export const setupBizRuleHeadDetail = [
    {
        id: 'biz_rule_id',
        align: 'left',
        disablePadding: false,
        label: 'Id',
        sort: true,
    },
    {
        id: 'biz_rule_desc',
        align: 'left',
        disablePadding: false,
        label: 'Description',
        sort: true,
        colSpan: 2,
        width: 'w-8/12',
    },
    {
        id: 'cond_tp_cd',
        align: 'left',
        disablePadding: false,
        label: 'Type',
        sort: true,
        colSpan: 1,
        width: 'w-4/12',
    },
    {
        id: 'ord_no',
        align: 'left',
        disablePadding: false,
        label: 'Order',
        sort: true,
        colSpan: 1,
        width: 'w-4/12',
    },
];

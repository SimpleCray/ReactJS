import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { IconButton, Icon, Typography, TextField } from '@material-ui/core';
import { FuseAnimate } from '../../../../@fuse';
import CustomButton from '../../../components/Button';
import withReducer from '../../../store/withReducer';

import reducer from '../store/reducers';
import * as Actions from '../store/actions';
import * as Functions from '../BizRuleFunction';

const FieldDetail = props => {
    const classes = Functions.useStyles();
    const dispatch = useDispatch();

    const bizRuleById = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.bizRuleById);
    const ruleFieldById = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.ruleFieldById);
    const bizRuleConditions = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.bizRuleCondition);
    const bizRuleActions = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.bizRuleAction);
    const output = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.output);
    const allOrAny = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allOrAny);

    const [extendFieldCondition, setExtendFieldCondition] = useState([]);
    const [extendFieldAction, setExtendFieldAction] = useState([]);
    const [extendFieldActionOutput, setExtendFieldActionOutput] = useState([]);
    const [outputValue, setOutputValue] = useState('');
    const [inputValue, setInputValue] = useState('');
    const [showTitle, setShowTitle] = useState(false);
    const [showTitleOuput, setShowTitleOutput] = useState(false);
    const [allOutputField, setAllOutputField] = useState({});

    const handleRun = () => {
        const extendParam =
            extendFieldCondition &&
            extendFieldAction &&
            Functions.handleUniqueArray([...extendFieldCondition, ...extendFieldAction], 'doc_fld_id').reduce(
                (obj, crr) => ({
                    ...obj,
                    [crr.doc_fld_id]: document.getElementById(`${crr.doc_fld_id}-${ruleFieldById[0].adm_co_doc_fld_id}`)
                        .value,
                }),
                {},
            );

        const extendOuputParam =
            extendFieldActionOutput &&
            Functions.handleUniqueArray(extendFieldActionOutput, 'doc_fld_id').reduce(
                (obj, crr) => ({
                    ...obj,
                    [`${crr.doc_fld_id}-output`]: {
                        [crr.doc_fld_id]: '',
                    },
                }),
                {},
            );

        dispatch(
            Actions.runSingleBiz({
                input: inputValue,
                bizRule: {
                    id: bizRuleById.biz_rule_id,
                    cond_tp_cd: allOrAny,
                    cond_ctnt: JSON.stringify(bizRuleConditions),
                    act_ctnt: JSON.stringify(bizRuleActions),
                },
                extend: extendParam,
                extendOutput: extendOuputParam,
            }),
        );
    };

    useEffect(() => {
        if (bizRuleConditions) {
            const allExtendType = bizRuleConditions
                .filter(item => Array.isArray(item.value) && item.value.some(el => el.key === 'field') && item.value)
                .map(item => item.value[0].value[0])
                .filter(item => item?.doc_fld_id !== ruleFieldById[0]?.doc_fld_id);
            setExtendFieldCondition(allExtendType);
        }
    }, [bizRuleConditions]);

    useEffect(() => {
        if (bizRuleActions) {
            const extendInputs = [];
            const extendOutputs = [];
            const allField = [];

            bizRuleActions.forEach(item => {
                allField.push(...Object.values(item.value).filter(el => el?.doc_fld_id));
            });
            extendInputs.push(
                ...allField.filter(item => item.doc_fld_id !== ruleFieldById[0].doc_fld_id && item.showOutput !== null),
            );
            extendOutputs.push(
                ...allField.filter(item => item.doc_fld_id !== ruleFieldById[0].doc_fld_id && item.showOutput === 'Y'),
            );

            setExtendFieldAction(extendInputs);
            setExtendFieldActionOutput(extendOutputs);
        }
    }, [bizRuleActions]);

    useEffect(() => {
        if (extendFieldCondition && extendFieldCondition)
            setShowTitle(extendFieldAction.length + extendFieldCondition.length > 0);
    }, [extendFieldCondition, extendFieldAction]);

    useEffect(() => {
        if (extendFieldActionOutput) setShowTitleOutput(extendFieldActionOutput.length > 0);
    }, [extendFieldActionOutput]);

    useEffect(() => {
        if (output) {
            const outputConvert = Object.entries(output).reduce(
                (acc, crr) => ({ ...acc, [crr[0]]: Array.isArray(crr[1]) ? `[${crr[1].join(';')}]` : crr[1] }),
                {},
            );
            setOutputValue(outputConvert.mainField);
            setAllOutputField(outputConvert);
        }
    }, [output]);

    return (
        <FuseAnimate animation="transition.fadeIn" delay={100}>
            <div className="p-8 sm:p-8 h-full">
                <div className="flex w-full justify-end">
                    <IconButton onClick={props?.onClose}>
                        <Icon>close</Icon>
                    </IconButton>
                </div>

                {showTitle && (
                    <div className="flex w-full pl-5">
                        <Typography className="normal-case flex items-center font-semibold mr-5" color="inherit">
                            Other input field
                        </Typography>
                    </div>
                )}

                <div className={classes.inputContainer}>
                    {extendFieldCondition &&
                        extendFieldAction &&
                        Functions.handleUniqueArray([...extendFieldCondition, ...extendFieldAction], 'doc_fld_id').map(
                            item => (
                                <div className="flex pb-5 ml-5" key={item.doc_fld_id}>
                                    <TextField
                                        {...Functions.textFieldCommonProps(classes)}
                                        multiline
                                        rowsMax={3}
                                        label={item ? item.fld_nm : ''}
                                        id={item ? `${item.doc_fld_id}-${ruleFieldById[0].adm_co_doc_fld_id}` : ''}
                                    />
                                </div>
                            ),
                        )}
                </div>

                {[
                    {
                        title: 'Input preview',
                        value: inputValue,
                        onChange(e) {
                            setInputValue(e.target.value);
                        },
                    },
                    { title: 'Output preview', value: outputValue, onChange: null },
                ].map(component => (
                    <div key={component.title}>
                        <div className="flex w-full pl-5 mb-5">
                            <Typography className="normal-case flex items-center font-semibold mr-5" color="inherit">
                                {component.title}
                            </Typography>
                        </div>
                        <div className="flex w-full pl-5 mt-5">
                            <TextField
                                {...Functions.textFieldCommonProps(classes)}
                                multiline
                                rows={5}
                                label={ruleFieldById[0] ? ruleFieldById[0].AdmDocFld.fld_nm : ''}
                                id="input-preview"
                                value={component.value}
                                onChange={component?.onChange}
                                inputProps={{
                                    style: {
                                        whiteSpace: 'nowrap',
                                        overflowX: 'auto',
                                        overflowWrap: 'break-word',
                                    },
                                }}
                            />
                        </div>
                    </div>
                ))}

                {showTitleOuput && (
                    <div className="flex w-full pl-5 mt-5">
                        <Typography className="normal-case flex items-center font-semibold mr-5" color="inherit">
                            Other output field
                        </Typography>
                    </div>
                )}

                <div className={classes.inputContainer}>
                    {extendFieldActionOutput &&
                        Functions.handleUniqueArray(extendFieldActionOutput, 'doc_fld_id').map(item => (
                            <div className="flex pb-5 ml-5" key={item.doc_fld_id}>
                                <TextField
                                    {...Functions.textFieldCommonProps(classes)}
                                    multiline
                                    rowsMax={3}
                                    label={item ? item.fld_nm : ''}
                                    id={item ? `${item.doc_fld_id}-output` : ''}
                                    value={allOutputField[`${item.doc_fld_id}-output`] || ''}
                                />
                            </div>
                        ))}
                </div>

                <div className="flex w-full justify-end mr-5 pt-5">
                    <CustomButton
                        className={classes.styleTextField}
                        variant="contained"
                        color="primary"
                        onClick={handleRun}
                    >
                        Run
                    </CustomButton>
                </div>
            </div>
        </FuseAnimate>
    );
};

export default withReducer('BizRuleReducer', reducer)(FieldDetail);

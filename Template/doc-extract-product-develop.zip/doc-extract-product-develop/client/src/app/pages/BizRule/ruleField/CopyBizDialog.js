import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    Dialog,
    DialogActions,
    DialogContent,
    IconButton,
    Typography,
    Toolbar,
    AppBar,
    TextField,
} from '@material-ui/core';
import { Close } from '@material-ui/icons';
import Autocomplete from '@material-ui/lab/Autocomplete';
import CustomButton from 'app/components/Button';
import AppConstants from 'app/utils/appConstants';
import _ from '@lodash';

import * as Functions from '../BizRuleFunction';
import * as Actions from '../store/actions';

const CopyBizDialog = props => {
    const dispatch = useDispatch();
    const classes = Functions.useStyles();

    const allDexLoc = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allDexLoc);
    const allCompanyRef = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allCompanyRef);
    const filter = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.filter);

    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));

    const [locationOption, setLocationOption] = useState([]);
    const [documentOption, setDocumentOption] = useState([]);

    const [currentCompany, setCurrentCompany] = useState(null);
    const [currentLocation, setCurrentLocation] = useState(null);
    const [currentDocument, setCurrentDocument] = useState(null);
    const [toLocation, setToLocation] = useState(null);
    const [error, setError] = useState(false);

    const onCloseClick = () => {
        setError(false);
        props.onClose();
    };

    const onCompanyChange = (e, value) => {
        if (value?.coCd) {
            setCurrentCompany(value.coCd);
            setCurrentLocation(null);
            setError(false);
        }
    };

    const onLocationChange = (e, value) => {
        if (value?.loc_cd) {
            setCurrentLocation(value.loc_cd);
            setError(false);
        }
    };

    const onRunClick = async () => {
        const hasError =
            !currentCompany?.length || !currentLocation?.length || !currentDocument?.length || !toLocation?.length;
        setError(hasError);

        if (!hasError) {
            await dispatch(
                Actions.runCopyBizRule({
                    com_cd: currentCompany,
                    source_loc_cd: currentLocation,
                    target_loc_cd: toLocation,
                    doc_tp_id: currentDocument,
                    usr_id: userInfo.usrId,
                }),
            );
        }
    };

    const renderCompanyOption = () => {
        if (allDexLoc.length) {
            const existCompanyCode = allDexLoc.map(item => item.co_cd);
            return [...new Set(existCompanyCode)].flatMap(
                item => allCompanyRef?.comList?.find(com => com.coCd === item) || [],
            );
        } else if (userInfo.usrId !== 'admin')
            return allCompanyRef?.comList?.filter(item => item.coCd === userInfo.coCd) || [];

        return [];
    };

    const renderLocationOption = (toLocation = false) => {
        const filterByCompanyAndDocument = Array.isArray(allDexLoc)
            ? allDexLoc.flatMap(item => {
                const byCompany = item.co_cd === currentCompany;
                const byFromLocation = toLocation ? !currentLocation || item.loc_cd !== currentLocation : true;
                const byDocument = !currentDocument || currentDocument === item.doc_tp_id;
                return byCompany && byDocument && byFromLocation ? { loc_cd: item.loc_cd, loc_nm: item.loc_nm } : [];
            })
            : [];
        return _.uniqBy(filterByCompanyAndDocument, 'loc_cd');
    };

    const renderDocumentType = () => {
        const filterByCompany = allDexLoc.flatMap(item => {
            const byCompany = !currentCompany || item.co_cd === currentCompany;
            return byCompany
                ? [
                      {
                          doc_tp_id: item.doc_tp_id,
                          doc_nm: item.documents.doc_nm,
                      },
                  ]
                : [];
        });
        return _.uniqBy(filterByCompany, 'doc_tp_id');
    };

    useEffect(() => setDocumentOption(renderDocumentType()), [currentCompany]);

    useEffect(() => setLocationOption(renderLocationOption()), [currentCompany, currentDocument]);

    useEffect(() => {
        if (props.open) {
            setToLocation(null);
            if (filter.company !== 'all') setCurrentCompany(filter.company);
            if (filter.location !== 'all') setCurrentLocation(filter.location);
            if (filter.documentType !== 'all') setCurrentDocument(filter.documentType);
        }
    }, [props.open]);

    const CompanyNameList = props => {
        return (
            <Autocomplete
                size="small"
                className={`mx-2 ${classes.textFieldWidth}`}
                options={renderCompanyOption()}
                getOptionLabel={option => option.coNm || ''}
                value={currentCompany ? renderCompanyOption()?.find(el => el.coCd === currentCompany) : ''}
                renderInput={params => (
                    <TextField
                        {...params}
                        error={error && !currentCompany?.length}
                        label="Company name"
                        variant="outlined"
                    />
                )}
                onChange={onCompanyChange}
                disabled={userInfo.usrId !== 'admin'}
                {...props}
            />
        );
    };

    const DocumentList = props => {
        return (
            <Autocomplete
                size="small"
                className={`mx-2 ${classes.textFieldWidth}`}
                options={documentOption}
                getOptionLabel={option => option.doc_nm || ''}
                value={currentDocument ? documentOption?.find(el => el.doc_tp_id === currentDocument) : ''}
                renderInput={params => (
                    <TextField
                        {...params}
                        error={error && !currentDocument?.length && !props.disabled}
                        label="Document name"
                        variant="outlined"
                    />
                )}
                onChange={(e, value) => value?.doc_tp_id && setCurrentDocument(value.doc_tp_id)}
                {...props}
            />
        );
    };

    const LocationList = props => {
        return (
            <Autocomplete
                size="small"
                className={`mx-2 ${classes.textFieldWidth}`}
                options={locationOption}
                getOptionLabel={option => option.loc_nm || ''}
                value={currentLocation ? locationOption?.find(el => el.loc_cd === currentLocation) : ''}
                renderInput={params => (
                    <TextField
                        {...params}
                        error={props.error || (error && !currentLocation?.length)}
                        label={props.label}
                        variant="outlined"
                    />
                )}
                onChange={onLocationChange}
                {...props}
            />
        );
    };

    return (
        <Dialog
            classes={{
                paper: 'm-24',
            }}
            fullWidth
            maxWidth="sm"
            open={props?.open}
        >
            <AppBar position="static" elevation={1}>
                <Toolbar className="flex flex-row w-full">
                    <div className="flex w-8/12 justify-start">
                        <Typography variant="subtitle1" color="inherit">
                            Copy biz rule
                        </Typography>
                    </div>
                    <div className="flex w-4/12 justify-end">
                        <IconButton onClick={onCloseClick}>
                            <Close className={classes.whiteColor} />
                        </IconButton>
                    </div>
                </Toolbar>
            </AppBar>
            <form className="flex flex-col overflow-hidden">
                <DialogContent classes={{ root: 'p-24' }} className="w-full flex flex-col items-center">
                    <div className="mb-5 text-md font-bold">Select biz rule source</div>
                    <div className="w-full flex flex-row justify-center items-center">
                        <CompanyNameList />
                        <DocumentList />
                    </div>

                    <div className="my-5 text-md font-bold">From location to location</div>
                    <div className="w-full flex flex-row justify-center items-center">
                        <LocationList label="From location" disabled={!currentDocument}/>
                        <LocationList
                            label="To location"
                            options={renderLocationOption(true)}
                            value={toLocation ? renderLocationOption(true)?.find(el => el.loc_cd === toLocation) : ''}
                            onChange={(e, value) => value?.loc_cd && setToLocation(value.loc_cd)}
                            error={error && !toLocation?.length}
                            disabled={!currentLocation}
                        />
                    </div>
                </DialogContent>
                <DialogActions className="justify-right pl-16">
                    <CustomButton variant="contained" color="primary" onClick={onRunClick}>
                        Copy
                    </CustomButton>
                </DialogActions>
            </form>
        </Dialog>
    );
};

export default CopyBizDialog;

import React, { useState, useEffect } from 'react';
import { ThemeProvider } from '@material-ui/styles';
import { useDispatch, useSelector } from 'react-redux';
import { Paper, Input, Icon, FormControlLabel, Checkbox } from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';
import AppConstants from 'app/utils/appConstants';
import SearchTextField from '../../../components/SearchTextField';

import _ from '@lodash';
import * as Actions from '../store/actions';

export default function BizRuleHeader(props) {
    const dispatch = useDispatch();

    const allDexLoc = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allDexLoc);
    const allCompanyRef = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allCompanyRef);
    const allRuleField = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allRuleField);
    const filter = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.filter);
    const mainTheme = useSelector(({ fuse }) => fuse.settings.mainTheme);

    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));

    const [renderCompany, setRenderCompany] = useState('');

    const handleSearch = filter => {
        props.loadDataByCondition(filter.company, filter.location, filter.documentType, filter.documentField);
        props.onClean();
        dispatch(Actions.setPageField(0));
        dispatch(Actions.setPageDescription(0));
    };

    const renderCompanyOption = () => {
        if (allDexLoc.length) {
            const existCompanyCode = allDexLoc.map(item => item.co_cd);
            return [...new Set(existCompanyCode)]
                .flatMap(item => allCompanyRef?.comList?.find(com => com.coCd === item) || [])
                .sort((a, b) => a?.coNm.localeCompare(b?.coNm));
        } else if (userInfo.usrId !== 'admin')
            return allCompanyRef?.comList?.filter(item => item.coCd === userInfo.coCd) || [];

        return [];
    };

    const renderLocationOption = () => {
        if (allDexLoc) {
            const filterByCompanyAndDocType = allDexLoc.flatMap(item => {
                const byCompany = !filter.company || item.co_cd === filter.company;
                const byDocument =
                    !filter.documentType || filter?.documentType === 'all' || filter.documentType === item.doc_tp_id;
                return byCompany && byDocument ? [{ loc_cd: item.loc_cd, loc_nm: item.loc_nm }] : [];
            });
            const optionSetUnique = _.uniqBy(filterByCompanyAndDocType, 'loc_cd').sort((a, b) =>
                a?.loc_nm.localeCompare(b?.loc_nm),
            );
            return [{ loc_cd: 'all', loc_nm: 'All' }, ...optionSetUnique];
        }
        return [{ loc_cd: 'all', loc_nm: 'All' }];
    };

    const renderDocumentType = () => {
        if (allDexLoc) {
            const filterByLocationAndCompany = allDexLoc.flatMap(item => {
                const byCompany = !filter?.company || item.co_cd === filter?.company;
                const byLocation = !filter?.location || filter?.location === 'all' || filter?.location === item.loc_cd;
                return byCompany && byLocation
                    ? [
                          {
                              doc_tp_id: item.doc_tp_id,
                              doc_nm: item.documents.doc_nm,
                          },
                      ]
                    : [];
            });
            const optionSetUnique = _.uniqBy(filterByLocationAndCompany, 'doc_tp_id').sort((a, b) =>
                a?.doc_nm.localeCompare(b?.doc_nm),
            );
            return [{ doc_tp_id: 'all', doc_nm: 'All' }, ...optionSetUnique];
        }
        return [{ doc_tp_id: 'all', doc_nm: 'All' }];
    };

    const renderDocumentField = () => {
        if (allDexLoc) {
            const filterFieldOption = allDexLoc.flatMap(item => {
                const byCompany = !filter?.company || item.co_cd === filter?.company;
                const byLocation = !filter?.location || filter?.location === 'all' || filter?.location === item.loc_cd;
                const byDocument =
                    !filter?.documentType || filter?.documentType === 'all' || filter?.documentType === item.doc_tp_id;
                if (byCompany && byLocation && byDocument) {
                    const parrentField = item.documents?.doc_fields?.map(fld => fld.fld_grp_id);
                    return item.documents?.doc_fields?.flatMap(fld =>
                        !parrentField.includes(fld.doc_fld_id)
                            ? { doc_fld_id: fld.doc_fld_id, fld_nm: fld.fld_nm }
                            : [],
                    );
                }
                return [];
            });
            const optionSetUnique = _.uniqBy(filterFieldOption, 'doc_fld_id')
                .filter(
                    fld =>
                        allRuleField.find(
                            ruleFld =>
                                ruleFld.doc_fld_id === fld.doc_fld_id &&
                                (filter.company ? ruleFld.DexLoc.co_cd === filter.company : true) &&
                                (filter.location ? ruleFld.DexLoc.loc_cd === filter.location : true),
                        )?.DexBizRule.length,
                )
                .sort((a, b) => a?.fld_nm.localeCompare(b?.fld_nm));
            return [{ doc_fld_id: 'all', fld_nm: 'All' }, ...optionSetUnique];
        }
        return [{ doc_fld_id: 'all', fld_nm: 'All' }];
    };

    useEffect(() => {
        if (!filter.company.length) {
            const optionCompany = renderCompanyOption();
            if (optionCompany?.length) {
                dispatch(Actions.saveFilter({ ...filter, company: optionCompany[0]?.coCd }));
                props.loadDataByCondition(optionCompany[0].coCd, '', '', '');
            }
        } else 
            props.loadDataByCondition(filter.company, filter.location, filter.documentType, 'all', true);
    }, [allDexLoc]);

    useEffect(() => setRenderCompany(userInfo.usrId === 'admin' ? filter?.company : userInfo.coCd), [
        filter?.company,
        userInfo.usrId,
    ]);

    const handleShowDeleted = value => {
        dispatch(
            Actions.saveFilter({
                ...filter,
                showDeleted: value,
            }),
        );
    };

    return (
        <div className="flex w-full items-center">
            <div
                style={{ width: props.panelSize.left }}
                className="flex flex-wrap items-center py-10 sm:p-9 md:p-7 lg:py-5 xl:py-2"
            >
                <div className="flex mr-3">
                    <Autocomplete
                        size="small"
                        options={renderCompanyOption()}
                        getOptionLabel={option => option.coNm || ''}
                        value={renderCompany ? renderCompanyOption()?.find(el => el.coCd === renderCompany) : ''}
                        renderInput={params => <SearchTextField {...params} label="Company name" variant="outlined" />}
                        onChange={(e, value) => {
                            const filterValue = {
                                ...filter,
                                company: value ? value.coCd : 'all',
                                location: 'all',
                                documentType: 'all',
                                documentField: 'all',
                            };
                            dispatch(Actions.saveFilter(filterValue));
                            handleSearch(filterValue);
                        }}
                        disabled={userInfo.usrId !== 'admin'}
                    />
                </div>

                <div className="flex mr-3">
                    <Autocomplete
                        size="small"
                        options={renderLocationOption()}
                        getOptionLabel={option => option.loc_nm || ''}
                        value={
                            filter?.location
                                ? renderLocationOption()?.find(el => el.loc_cd === filter?.location)
                                : { loc_cd: 'all', loc_nm: 'All' }
                        }
                        renderInput={params => <SearchTextField {...params} label="Location name" variant="outlined" />}
                        onChange={(e, value) => {
                            const filterValue = {
                                ...filter,
                                location: value ? value.loc_cd : 'all',
                                documentType: value
                                    ? allDexLoc.find(
                                          i =>
                                              i.co_cd === filter.company &&
                                              i.loc_cd === value.loc_cd &&
                                              i?.documents.doc_tp_id === filter.documentType,
                                      )
                                        ? filter.documentType
                                        : 'all'
                                    : 'all',
                                documentField: value
                                    ? allRuleField.find(
                                          i =>
                                              i.DexLoc?.co_cd === filter.company &&
                                              i.DexLoc?.loc_cd === value.loc_cd &&
                                              i.DexLoc?.documents?.doc_tp_id === filter.documentType &&
                                              i.AdmDocFld?.doc_fld_id === filter.documentField &&
                                              i.DexBizRule.length > 0,
                                      )
                                        ? filter.documentField
                                        : 'all'
                                    : 'all',
                            };
                            dispatch(Actions.saveFilter(filterValue));
                            handleSearch(filterValue);
                        }}
                    />
                </div>

                <div className="flex mr-3">
                    <Autocomplete
                        size="small"
                        options={renderDocumentType()}
                        getOptionLabel={option => option.doc_nm || ''}
                        value={
                            filter?.documentType
                                ? renderDocumentType()?.find(el => el.doc_tp_id === filter?.documentType)
                                : { doc_tp_id: 'all', doc_nm: 'All' }
                        }
                        renderInput={params => <SearchTextField {...params} label="Document name" variant="outlined" />}
                        onChange={(e, value) => {
                            const filterValue = {
                                ...filter,
                                documentType: value ? value.doc_tp_id : 'all',
                                documentField: value
                                    ? allRuleField.find(
                                          i =>
                                              i.DexLoc?.co_cd === filter.company &&
                                              i.DexLoc?.loc_cd === filter.location &&
                                              i.DexLoc?.documents?.doc_tp_id === value.doc_tp_id &&
                                              i.AdmDocFld?.doc_fld_id === filter.documentField &&
                                              i.DexBizRule.length > 0,
                                      )
                                        ? filter.documentField
                                        : 'all'
                                    : 'all',
                            };
                            dispatch(Actions.saveFilter(filterValue));
                            handleSearch(filterValue);
                        }}
                    />
                </div>

                <div className="flex mr-3">
                    <Autocomplete
                        size="small"
                        options={renderDocumentField()}
                        getOptionLabel={option => option.fld_nm || ''}
                        value={
                            filter?.documentField
                                ? renderDocumentField()?.find(el => el.doc_fld_id === filter?.documentField)
                                : { doc_fld_id: 'all', fld_nm: 'All' }
                        }
                        renderInput={params => <SearchTextField {...params} label="Field name" variant="outlined" />}
                        onChange={(e, value) => {
                            const filterValue = { ...filter, documentField: value ? value?.doc_fld_id : 'all' };
                            dispatch(Actions.saveFilter(filterValue));
                            handleSearch(filterValue);
                        }}
                        disabled={filter.documentType === 'all' || !filter.documentType}
                    />
                </div>
            </div>

            <div style={{ width: props.panelSize.right*0.9 }} className="flex items-center px-1">
                <ThemeProvider theme={mainTheme}>
                    <Paper className="flex items-center px-8 py-4 rounded-8">
                        <Icon className="mr-8" color="action">
                            search
                        </Icon>
                        <Input
                            placeholder="Search description"
                            className="flex flex-1"
                            disableUnderline
                            fullWidth
                            inputProps={{
                                'aria-label': 'Search',
                            }}
                            onChange={e => {
                                props.onSearch(e.target.value);
                                dispatch(Actions.setPageDescription(0));
                            }}
                        />
                    </Paper>
                </ThemeProvider>

                <div className="flex-none px-15 ml-5">
                    <FormControlLabel
                        key="checkbox"
                        label="Deleted Rules"
                        control={<Checkbox />}
                        checked={filter.showDeleted}
                        onChange={() => handleShowDeleted(!filter.showDeleted)}
                    />
                </div>
            </div>
        </div>
    );
}

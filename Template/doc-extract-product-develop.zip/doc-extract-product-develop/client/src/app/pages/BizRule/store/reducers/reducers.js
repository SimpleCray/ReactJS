import * as Actions from '../actions/actions';

const initialState = {
    allDexLoc: [],
    ruleField: [],
    allRuleField: [],
    allBizRule: [],
    allDocFieldRef: [],
    allCompanyRef: [],
    bizRuleById: {},
    ruleFieldById: {},
    createRuleField: '',
    bizRuleCondition: [{ index: 0, field: '', value: [] }],
    bizRuleAction: [{ index: 0, type: '', value: [] }],
    allOrAny: 'ALL',
    commonActCondData: [],
    commonData: [],
    allCommon: [],
    filter: { company: '', location: '', documentType: '', documentField: '', firstLoadPage: false,  showDeleted: 'N'},
    currentField: {},
    output: '',
    outputByField: '',
    pageField: 0,
    pageDescription: 0,
    userIdAuth: '',
    panelSize: { left: 0, right: 0 },
};

const bizRuleReducers = (state = initialState, action) => {
    switch (action.type) {
        case Actions.GET_RULE_FIELD:
            return {
                ...state,
                ruleField: action.payload,
            };

        case Actions.GET_ALL_RULE_FIELD:
            return {
                ...state,
                allRuleField: action.payload,
            };

        case Actions.GET_RULE_FIELD_BY_ID:
            return {
                ...state,
                ruleFieldById: action.payload,
            };

        case Actions.GET_DOC_FIELD:
            return {
                ...state,
                allDocFieldRef: action.payload,
            };

        case Actions.GET_BIZ_RULE:
            return {
                ...state,
                allBizRule: action.payload,
            };

        case Actions.GET_DEX_LOC:
            return {
                ...state,
                allDexLoc: action.payload,
            };

        case Actions.CREATE_RULE_FIELD:
            return {
                ...state,
                createRuleField: action.payload,
            };

        case Actions.GET_BIZ_RULE_BY_ID:
            return {
                ...state,
                bizRuleById: action.payload,
                bizRuleCondition: action.payload && JSON.parse(action.payload.cond_ctnt),
                bizRuleAction: action.payload && JSON.parse(action.payload.act_ctnt),
            };

        case Actions.GET_COMMON_ACTION_CONDITION_DATA:
            if (action.payload) {
                return {
                    ...state,
                    commonActCondData: action.payload,
                };
            }
            break;

        case Actions.GET_COMMON_DATA_FOR_BIZ:
            if (action.payload) {
                return {
                    ...state,
                    commonData: action.payload,
                };
            }
            break;

        case Actions.CHANGE_FLAG_BIZ_RULE:
            return {
                ...state,
                changeFlagBizRule: action.payload,
            };

        case Actions.UPDATE_RULE_FIELD:
            return {
                ...state,
                currentField: action.ruleField,
            };

        case Actions.ADD_BIZ_RULE_CONDITION:
            return {
                ...state,
                bizRuleCondition: action.bizRuleCondition,
            };

        case Actions.ADD_BIZ_RULE_ACTION:
            return {
                ...state,
                bizRuleAction: action.bizRuleAction,
            };

        case Actions.ADD_ALL_OR_ANY:
            return {
                ...state,
                allOrAny: action.allOrAny,
            };

        case Actions.SAVE_FILTER:
            return {
                ...state,
                filter: action.filter,
            };

        case Actions.CLEAR_STORE:
            return {
                ...state,
                bizRuleCondition: [{ index: 0, field: '', value: [] }],
                bizRuleAction: [{ index: 0, type: '', value: [] }],
                output: '',
            };

        case Actions.GET_COMPANY_NAME:
            return {
                ...state,
                allCompanyRef: action.payload.data,
            };

        case Actions.RUN_SINGLE_BIZ:
            return {
                ...state,
                output: action.payload,
            };

        case Actions.RUN_BIZ_BY_FIELD:
            return {
                ...state,
                outputByField: action.payload,
            };

        case Actions.SET_PAGE_FIELD:
            return {
                ...state,
                pageField: action.pageField,
            };

        case Actions.SET_PAGE_DESCRIPTION:
            return {
                ...state,
                pageDescription: action.pageDescription,
            };

        case Actions.CLEAR_SIDEBAR:
            return {
                ...state,
                output: '',
            };

        case Actions.SET_USER_ROLE:
            return {
                ...state,
                userIdAuth: action.userIdAuth,
            };

        case Actions.UPDATE_PANEL_SIZE:
            return {
                ...state,
                panelSize: {
                    left: action.panelSize ? action.panelSize[0].size : 0,
                    right: action.panelSize ? action.panelSize[1].size : 0,
                },
            };

        default:
            return state;
    }
};
export default bizRuleReducers;

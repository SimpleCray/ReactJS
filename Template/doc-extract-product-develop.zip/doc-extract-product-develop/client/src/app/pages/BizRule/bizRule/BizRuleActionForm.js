/* eslint-disable no-nested-ternary */
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MenuItem, TextField, Tooltip, IconButton, ClickAwayListener } from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';
import AddCircleIcon from '@material-ui/icons/AddCircle';
import RemoveCircleIcon from '@material-ui/icons/RemoveCircle';
import withReducer from '../../../store/withReducer';

import reducer from '../store/reducers';
import * as Actions from '../store/actions';
import * as Functions from '../BizRuleFunction';

const BizRuleActionForm = props => {
    const classes = Functions.useStyles();
    const dispatch = useDispatch();

    const bizRuleActions = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.bizRuleAction);
    const commonActCondData = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.commonActCondData);
    const ruleFieldById = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.ruleFieldById);

    const [allActionType, setAllActionType] = useState([]);
    const [allRenderComponentAction, setAllRenderComponentAction] = useState([]);
    const [listComponent, setListComponent] = useState([]);
    const [errorFlag, setErrorFlag] = useState(false);
    const [tempMultipleInput, setTempMultipleInput] = useState('');
    const [listFieldRefer, setListFieldRefer] = useState([]);

    const handleValidateShowError = () => {
        const currentAction = bizRuleActions[(props?.index)];
        const commonAction = commonActCondData.find(item => item.com_dat_cd === 'ACT_BIZ_RULE');
        const parseCommonAction = commonAction.com_dat_val.data.map(item => ({
            code: item.code,
            value: JSON.parse(item.value),
        }));
        const filterCommonAction = parseCommonAction.reduce(
            (obj, crr) => ({
                ...obj,
                [crr.code]: crr.value.filter(el => el.required === 'Y').map(el => el.key),
            }),
            {},
        );
        const actionError =
            !currentAction.type ||
            Object.keys(currentAction.value).some(
                el =>
                    filterCommonAction[currentAction.type].includes(el) &&
                    (!currentAction.value[el] || currentAction.value[el].length === 0),
            );
        setErrorFlag(actionError);
    };

    const handleAddAction = async () => {
        props.setActionHasError(false);
        const newAction = { index: props?.index + 1, type: '', value: '', crrFldId: props?.defaultExtend.doc_fld_id };
        const afterAddAction = Functions.handleAddToArray(bizRuleActions, newAction, props?.index + 1);
        const afterAlignArrayAction = Functions.reOrderNumber(afterAddAction);
        await dispatch(Actions.addBizRuleAction(afterAlignArrayAction));
    };

    const handleRemoveAction = async () => {
        const afterRemoveAction = bizRuleActions.filter(item => item.index !== props?.index);
        const afterAlignArrayAction = Functions.reOrderNumber(afterRemoveAction);
        await dispatch(Actions.addBizRuleAction(afterAlignArrayAction));
    };

    const handleChangeValue = async (index, value, field) => {
        const checkValue = value && value.doc_fld_id === props?.defaultExtend.doc_fld_id ? '' : value;
        let updateValueActions = bizRuleActions.map(item => ({ ...item }));
        for (let i = 0; i < bizRuleActions.length; i++)
            if (i === index) updateValueActions[i]['value'][field] = checkValue;

        // WHY: some autocomplete component is last item and appearance following before ref selection box.
        // But in case not show, that still appear in sidebar preview
        const thisComponentRenderData = listComponent.find(item => item.key === field);
        if (Array.isArray(thisComponentRenderData.option)) {
            const optionCode = thisComponentRenderData.option.map(item => item.code);
            const needHiddenNextItem = listComponent.flatMap(el =>
                el.showOutput && el.ref && optionCode.includes(el.ref[0]) && !el.ref.includes(value) ? [el.key] : [],
            );
            needHiddenNextItem.forEach(item => {
                if (updateValueActions[index]['value'][item])
                    updateValueActions[index]['value'][item]['showOutput'] = null;
            });
            const resetShowNextItem = listComponent.flatMap(item =>
                !needHiddenNextItem.includes(item.key) && Object.keys(item).includes('showOutput') ? [item.key] : [],
            );
            resetShowNextItem.forEach(item => {
                if (
                    updateValueActions[index]['value'][item] &&
                    Object.keys(updateValueActions[index]['value'][item]).includes('showOutput')
                )
                    updateValueActions[index]['value'][item]['showOutput'] = listComponent.find(
                        el => el.key === item,
                    )?.showOutput;
            });
        }

        await dispatch(Actions.addBizRuleAction(updateValueActions));
    };

    const handleChangeActionType = async (currentIndex, currentType) => {
        const componentsInType = allRenderComponentAction.find(item => item.code === currentType);
        const replaceActionItem = {
            index: currentIndex,
            type: currentType,
            value: componentsInType.value.reduce((obj, current) => ({ ...obj, [current.key]: null }), {}),
        };
        setListComponent(componentsInType.value);
        const updatedActionStore = bizRuleActions.map(item =>
            item.index === props?.index ? { ...replaceActionItem } : item,
        );
        await dispatch(Actions.addBizRuleAction(updatedActionStore));
    };

    const checkRenderComponent = item => {
        // if common data component define has ref to any field
        const checkRef =
            !item.ref || item.ref.some(el => Object.values(bizRuleActions[(props?.index)].value).includes(el));
        if (item.type === 'input' && item.multiple === 'N') return checkRef ? 'input' : 'not-show';
        if (item.type === 'input' && item.multiple === 'Y') return checkRef ? 'multiple-input' : 'not-show';
        if (item.type === 'select') return checkRef ? 'select' : 'not-show';
        return checkRef ? 'choose-field' : 'not-show';
    };

    // Load all component for render ui
    // If creating, load from common data, else load from saved database
    useEffect(() => {
        props.closeSideBar();
        if (bizRuleActions && allRenderComponentAction.length > 0) {
            const componentsInType = allRenderComponentAction.find(
                item => item.code === bizRuleActions[(props?.index)]['type'],
            );
            if (componentsInType) setListComponent(componentsInType.value);
            else setListComponent([]);
        }
    }, [bizRuleActions, allRenderComponentAction]);

    // Handle common data
    useEffect(() => {
        if (commonActCondData) {
            const commonActionType = commonActCondData.find(item => item.com_dat_cd === 'ACT_TYPE');
            const commonActionBizRule = commonActCondData.find(item => item.com_dat_cd === 'ACT_BIZ_RULE');
            if (commonActionBizRule?.com_dat_val && commonActionType?.com_dat_val) {
                setAllActionType(commonActionType.com_dat_val.data);
                setAllRenderComponentAction(
                    commonActionBizRule.com_dat_val.data.map(item => ({
                        code: item.code,
                        value: JSON.parse(item.value),
                    })),
                );
            }
        }
    }, [commonActCondData]);

    useEffect(() => {
        if (props?.actionHasError) handleValidateShowError();
        else setErrorFlag(false);
    }, [props?.actionHasError]);

    useEffect(() => {
        if (props?.extendField && Array.isArray(props?.extendField)) setListFieldRefer(props?.extendField);
        else setListFieldRefer([]);
    }, [props?.extendField]);

    return (
        <div className={classes.conditionItemContainer}>
            <div className="flex w-2/12">
                <TextField
                    {...Functions.textFieldCommonProps(classes)}
                    select
                    label="Action type"
                    value={bizRuleActions[(props?.index)]?.type}
                    onChange={e => handleChangeActionType(props?.index, e.target.value)}
                    error={errorFlag && !bizRuleActions[(props?.index)]?.type}
                >
                    {allActionType &&
                        allActionType
                            .filter(item => item.needGroup !== 'Y' && item.deleted === 'No')
                            .map(item => (
                                <MenuItem key={item.code} value={item.code}>
                                    {item.value}
                                </MenuItem>
                            ))}
                    {ruleFieldById[0] &&
                        ruleFieldById[0].AdmDocFld.fld_grp_id &&
                        allActionType &&
                        allActionType
                            .filter(item => item.needGroup === 'Y' && item.deleted === 'No')
                            .map(item => (
                                <MenuItem key={item.code} value={item.code}>
                                    {item.value}
                                </MenuItem>
                            ))}
                </TextField>
            </div>

            <div className={classes.gapContainer}>
                {listComponent.map(item => {
                    const showFlag = checkRenderComponent(item);
                    const currentBiz = bizRuleActions[(props?.index)];
                    const valueBiz = currentBiz.value[item.key];
                    const valueBizMultiple = valueBiz ? [valueBiz] : [];
                    let singleFieldError = false;
                    if (item.ref) {
                        const refValue = Object.values(bizRuleActions[(props?.index)].value);
                        const hasIncludeInRef = item.ref.some(el => refValue.includes(el));
                        singleFieldError = hasIncludeInRef && errorFlag && !valueBiz && item.required === 'Y';
                    } else singleFieldError = errorFlag && !valueBiz && item.required === 'Y';

                    if (showFlag === 'input')
                        return (
                            <div className="flex w-3/12" key={item.key}>
                                <TextField
                                    {...Functions.textFieldPropsExtend(item, classes)}
                                    value={valueBiz}
                                    error={singleFieldError}
                                    onChange={e => handleChangeValue(props?.index, e.target.value, item.key)}
                                />
                            </div>
                        );
                    if (showFlag === 'select')
                        return (
                            <div className="flex w-3/12" key={item.key}>
                                <TextField
                                    {...Functions.textFieldPropsExtend(item, classes)}
                                    select
                                    value={valueBiz}
                                    error={singleFieldError}
                                    helperText={item.textHelper === 'Y' && `In ${ruleFieldById[0].AdmDocFld.fld_nm}`}
                                    onChange={e => handleChangeValue(props?.index, e.target.value, item.key)}
                                >
                                    {Array.isArray(item.option) &&
                                        item.option.map(subItem => (
                                            <MenuItem key={subItem.code} value={subItem.code}>
                                                {subItem.value}
                                            </MenuItem>
                                        ))}
                                </TextField>
                            </div>
                        );
                    if (showFlag === 'multiple-input')
                        return (
                            <div className="flex w-3/12" key={item.key}>
                                <ClickAwayListener
                                    onClickAway={() => {
                                        if (tempMultipleInput.length > 0 && valueBiz) {
                                            handleChangeValue(props?.index, [...valueBiz, tempMultipleInput], item.key);
                                            setTempMultipleInput('');
                                        }
                                    }}
                                >
                                    <Autocomplete
                                        {...Functions.autoCompleteProps(item, classes)}
                                        multiple
                                        options={[]}
                                        open={false}
                                        value={Array.isArray(valueBiz) ? valueBiz : valueBizMultiple}
                                        renderInput={params => (
                                            <TextField
                                                {...params}
                                                error={
                                                    errorFlag &&
                                                    item.required === 'Y' &&
                                                    (!valueBiz || !valueBiz.length)
                                                }
                                                required={item.required === 'Y'}
                                                label="Value in (Enter to push your input)"
                                                variant="outlined"
                                                onKeyDown={e => {
                                                    if (e.keyCode === 13 && e.target.value && valueBiz)
                                                        handleChangeValue(
                                                            props?.index,
                                                            [...valueBiz, e.target.value],
                                                            item.key,
                                                        );
                                                }}
                                                onBlur={e => setTempMultipleInput(e.target.value)}
                                            />
                                        )}
                                        onChange={(e, val) => handleChangeValue(props?.index, val, item.key)}
                                    />
                                </ClickAwayListener>
                            </div>
                        );
                    if (showFlag === 'choose-field') {
                        const findValue = listFieldRefer.find(el => el.doc_fld_id === valueBiz?.doc_fld_id);
                        let showValue = '';
                        if (findValue) showValue = findValue;
                        else showValue = valueBiz === null || !listFieldRefer.length ? '' : props?.defaultExtend;
                        return (
                            <div className="flex w-3/12" key={item.key}>
                                <Autocomplete
                                    {...Functions.autoCompleteProps(item, classes)}
                                    disableClearable
                                    options={listFieldRefer}
                                    getOptionLabel={option => option.fld_nm || ''}
                                    renderInput={params => (
                                        <TextField
                                            {...params}
                                            required={item.required === 'Y'}
                                            error={errorFlag && !showValue}
                                            label={item.label}
                                            variant="outlined"
                                        />
                                    )}
                                    value={showValue}
                                    onChange={(e, val) =>
                                        handleChangeValue(
                                            props?.index,
                                            { ...val, showOutput: item.showOutput },
                                            item.key,
                                        )
                                    }
                                />
                            </div>
                        );
                    }

                    return <div />;
                })}
            </div>

            <div className="absolute right-0 flex justify-end w-1/12">
                <Tooltip title="Add">
                    <IconButton aria-label="Add" onClick={handleAddAction}>
                        <AddCircleIcon />
                    </IconButton>
                </Tooltip>
                <Tooltip title="Remove">
                    <span>
                        <IconButton
                            aria-label="Remove"
                            disabled={bizRuleActions.length === 1}
                            onClick={handleRemoveAction}
                        >
                            <RemoveCircleIcon />
                        </IconButton>
                    </span>
                </Tooltip>
            </div>
        </div>
    );
};

export default withReducer('BizRuleReducer', reducer)(BizRuleActionForm);

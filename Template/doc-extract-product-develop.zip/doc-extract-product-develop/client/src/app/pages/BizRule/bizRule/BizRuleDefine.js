/* eslint-disable react/prop-types */
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MenuItem, TextField, Typography, List, ListItem } from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import AppConstants from 'app/utils/appConstants';
import _ from '../../../../@lodash';
import withReducer from '../../../store/withReducer';
import CustomButton from '../../../components/Button';
import BizRuleConditionForm from './BizRuleConditionForm';
import BizRuleActionForm from './BizRuleActionForm';
import buttons from '../../../utils/constants/buttonConstants.json';

import reducer from '../store/reducers';
import * as Actions from '../store/actions/actions';
import * as Functions from '../BizRuleFunction';

const BizRuleDefine = props => {
    const classes = Functions.useStyles();
    const dispatch = useDispatch();
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));
    const lastUrlParam = window.location.href.split('/').pop();
    const comDocFldIdFromURL = lastUrlParam.includes('COMDOC') ? lastUrlParam : null;

    const allCompanyRef = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allCompanyRef);
    const allDexLoc = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allDexLoc);
    const filter = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.filter);
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const allRuleField = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allRuleField);
    const ruleFieldById = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.ruleFieldById);
    const bizRuleById = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.bizRuleById);
    const bizRuleConditions = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.bizRuleCondition);
    const bizRuleActions = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.bizRuleAction);
    const allOrAny = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allOrAny);
    const currentField = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.currentField);
    const commonActCondData = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.commonActCondData);

    const [descValue, setDescValue] = useState('');
    const [fieldPropError, setFieldPropError] = useState({
        company: false,
        location: false,
        documentType: false,
        documentField: false,
    });
    const [descEmptyError, setDescEmptyError] = useState(false);
    const [displayOrderError, setDisplayOrderError] = useState(false);
    const [displayOrder, setDisplayOrder] = useState('');
    const [extendField, setExtendField] = useState([]);
    const [conditionHasError, setConditionHasError] = useState(false);
    const [actionHasError, setActionHasError] = useState(false);
    const [allAnyType, setAllAnyType] = useState('');
    const [renderCompany, setRenderCompany] = useState('');
    const [admComDocFldId, setAdmComDocFldId] = useState(props.id);

    useEffect(() => setRenderCompany(userInfo.usrId === 'admin' ? filter.company : userInfo.coCd), [
        filter.company,
        userInfo.usrId,
    ]);

    const renderCompanyOption = () => {
        if (allDexLoc.length) {
            const existCompanyCode = allDexLoc.map(item => item.co_cd);
            return [...new Set(existCompanyCode)].flatMap(
                item => allCompanyRef?.comList?.find(com => com.coCd === item) || [],
            ).sort((a, b) => a?.coNm.localeCompare(b?.coNm));
        } else if (userInfo.usrId !== 'admin')
            return allCompanyRef?.comList?.filter(item => item.coCd === userInfo.coCd) || [];

        return [];
    };

    const renderLocationOption = () => {
        if (allDexLoc) {
            const filterByCompanyAndDocType =
                filter.documentType !== ''
                    ? allDexLoc.flatMap(item => {
                          const byCompany = !filter.company || item.co_cd === filter.company;
                          const byDocument = !filter.documentType || filter.documentType === item.doc_tp_id;
                          return byCompany && byDocument ? [{ loc_cd: item.loc_cd, loc_nm: item.loc_nm }] : [];
                      })
                    : [];
            const optionSetUnique = _.uniqBy(filterByCompanyAndDocType, 'loc_cd').sort((a, b) =>
                a?.loc_nm.localeCompare(b?.loc_nm),
            );
            return [...optionSetUnique];
        }
        return [];
    };

    const renderDocumentType = () => {
        if (allDexLoc) {
            const filterByLocationAndCompany = allDexLoc.flatMap(item => {
                const byCompany = !filter.company || item.co_cd === filter.company;
                // const byLocation = !filter.location || filter.location === item.loc_cd;
                return byCompany ? [{ doc_tp_id: item.doc_tp_id, doc_nm: item.documents.doc_nm }] : [];
            });
            const optionSetUnique = _.uniqBy(filterByLocationAndCompany, 'doc_tp_id').sort((a, b) =>
                a?.doc_nm.localeCompare(b?.doc_nm),
            );
            return [...optionSetUnique];
        }
        return [];
    };

    const renderDocumentField = () => {
        if (allDexLoc) {
            const filterFieldOption = allDexLoc.flatMap(item => {
                const byCompany = !filter.company || item.co_cd === filter.company;
                const byLocation = !filter.location || filter.location === item.loc_cd;
                const byDocument = !filter.documentType || filter.documentType === item.doc_tp_id;
                const byFldGrpFlg = item.fld_grp_flg !== 'Y'; // remove field is group
                if (byCompany && byLocation && byDocument && byFldGrpFlg) {
                    const parrentField = item.documents?.doc_fields?.map(fld => fld.fld_grp_id);
                    return item.documents?.doc_fields?.flatMap(fld =>
                        !parrentField.includes(fld.doc_fld_id) && fld.fld_grp_flg !== 'Y'
                            ? { doc_fld_id: fld.doc_fld_id, fld_nm: fld.fld_nm }
                            : [],
                    );
                }
                return [];
            });
            const optionSetUnique = _.uniqBy(filterFieldOption, 'doc_fld_id').sort((a, b) =>
                a?.fld_nm.localeCompare(b?.fld_nm),
            );
            return [...optionSetUnique];
        }
        return [];
    };

    const reSetDisplayOrder = field => {
        setDisplayOrder('1');
        const bizRules = field?.DexBizRule?.filter(bizRule => bizRule.delt_flg === 'N');
        if (field && bizRules.length > 0) {
            const orderNoCurrent = Math.max(...bizRules.map(a => a.ord_no));
            setDisplayOrder(orderNoCurrent + 1);
        }
    };

    const onFilterChange = (valueOnChange) => {
        let comFilter = filter.company;
        let docTpFilter = filter.documentType;
        let locFilter = filter.location;
        let docFieldFilter = filter.documentField;

        // Company change.
        if (valueOnChange?.coCd && valueOnChange?.coCd !== filter.company) {
            comFilter = valueOnChange?.coCd;
        }
        // Document change.
        else if (valueOnChange?.doc_tp_id && valueOnChange?.doc_tp_id !== filter.documentType) {
            docTpFilter = valueOnChange?.doc_tp_id;
        }
        // Location change.
        else if (valueOnChange?.loc_cd && valueOnChange?.loc_cd !== filter.location) {
            locFilter = valueOnChange?.loc_cd;
        }
        // Document field change.
        else if (valueOnChange?.doc_fld_id && valueOnChange?.doc_fld_id !== filter.documentField) {
            docFieldFilter = valueOnChange?.doc_fld_id;
        }

        let field = allRuleField.find(
            i =>
                i.DexLoc?.co_cd === comFilter &&
                i.DexLoc?.documents?.doc_tp_id === docTpFilter &&
                i.DexLoc?.loc_cd === locFilter &&
                i.AdmDocFld?.doc_fld_id === docFieldFilter,
        );

        reSetDisplayOrder(field);
    }

    useEffect(() => {
        if (!filter.company?.length) {
            const optionCompany = renderCompanyOption();
            if (optionCompany?.length) {
                dispatch(Actions.saveFilter({ ...filter, company: optionCompany[0]?.coCd }));
                loadDataByCondition(optionCompany[0].coCd, '', '', '');
            }
        } else loadDataByCondition(filter.company, filter.location, filter.documentType, filter.documentField, true);
    }, [allDexLoc]);

    const loadDataByCondition = (company, location, document, field) => {
        dispatch(
            Actions.getCompanyDocumentField({
                co_cd: company || userInfo.coCd,
                loc_cd: location,
                doc_tp_id: document,
                doc_fld_id: field,
            }),
        );
    };

    const contentValidate = () => {
        // Validate for condition
        const condHasError = bizRuleConditions.some(
            item =>
                !item.field || (Array.isArray(item.value) && item.value.some(el => !el.value || el.value.length === 0)),
        );
        setConditionHasError(condHasError);
        // Validate for company/location/document/fieldId
        const fieldPropHasError = !!Object.keys(fieldPropError).find(key => fieldPropError[key] === true);
        // Validate for action
        const commonAction = commonActCondData.find(item => item.com_dat_cd === 'ACT_BIZ_RULE');
        const parseCommonAction = commonAction.com_dat_val.data.map(item => ({
            code: item.code,
            value: JSON.parse(item.value),
        }));
        // filter common data and field name is require
        const filterCommonAction = parseCommonAction.reduce(
            (obj, crr) => ({
                ...obj,
                [crr.code]: crr.value.filter(el => el.required === 'Y').map(el => el.key),
            }),
            {},
        );
        const actHasError = bizRuleActions.some(item => {
            // is type value empty ?
            const typeEmpty = !item.type;
            // is tail component value error?
            const valueError = Object.keys(item.value).some(el => {
                // find common define of current component
                const itemCommonDefine = parseCommonAction.find(i => item.type === i.code);
                // get all reference field of current component
                const itemCommonRender = itemCommonDefine ? itemCommonDefine.value.find(i => i.key === el) : null;
                const itemGetRef = itemCommonRender ? itemCommonRender.ref : null;
                // reference field is being selected
                const itemRefActive = itemGetRef && itemGetRef.some(i => Object.values(item.value).includes(i));
                // current component is require
                const itemIsRequiredField = filterCommonAction[item.type].includes(el);
                // current component is empty
                let itemEmpty = false;
                if (itemCommonRender.type === 'select-input') itemEmpty = item.value[el] === null;
                else itemEmpty = !item.value[el] || (Array.isArray(item.value[el]) && !item.value[el].length);
                // return has error when current component value includes three condition
                // is require + is empty + refernce value is being selected
                if (itemRefActive === undefined) return itemIsRequiredField && itemEmpty;
                return itemIsRequiredField && itemEmpty && itemRefActive;
            });
            // return has error when current action has type empty or tail component value is error
            return typeEmpty || valueError;
        });
        setActionHasError(actHasError);
        return !condHasError && !actHasError && !fieldPropHasError;
    };

    const checkFieldPropError = filterValue => {
        // Check error for company/location/document/fieldId
        const fieldPropErrorStatus = {};
        Object.keys(filterValue).forEach(key => {
            fieldPropErrorStatus[key] = !filterValue[key];
        });
        setFieldPropError(fieldPropErrorStatus);
    };

    const saveValid = () => {
        // Validate for title
        const descNotNull = descValue.length !== 0;
        const orderNotNull = displayOrder.length !== 0;
        const contentValiddate = contentValidate();
        setDescEmptyError(!descNotNull);
        setDisplayOrderError(!orderNotNull);

        return descNotNull && orderNotNull && contentValiddate;
    };

    const handleSave = async () => {
        if (saveValid()) {
            const storeData = {
                adm_co_doc_fld_id: admComDocFldId,
                biz_rule_desc: descValue,
                cond_tp_cd: allOrAny,
                ord_no: displayOrder,
                cond_ctnt: JSON.stringify(bizRuleConditions),
                act_ctnt: JSON.stringify(bizRuleActions),
                biz_rule_id: props?.bizRuleId,
                cre_usr_id: JSON.parse(localStorage.getItem('userInfo')).usrId,
                upd_usr_id: JSON.parse(localStorage.getItem('userInfo')).usrId,
            };
            if (props?.typePage !== 'edit') await dispatch(Actions.createBizRule(storeData));
            else await dispatch(Actions.updateBizRule(storeData));
            if (!_.isEmpty(currentField)) dispatch(Actions.getBizRule(currentField.adm_co_doc_fld_id));
            // Page is opened from info-extracted, close tab after save 0.5s
            if (props.history.length === 1 && window.opener) {
                window.opener.postMessage('Reload data biz', '*');
                setTimeout(() => window.close(), 500);
            }

            if (props?.typePage === 'new') {
                dispatch(Actions.clearStore());
                props.history.goBack();
                dispatch(
                    Actions.saveFilter({
                        ...filter,
                        temporaryField: filter.documentField,
                        documentField: 'all',
                        firstLoadPage: true,
                    }),
                );
            }
        } else
            dispatch(
                showMessage({
                    message: 'Empty field',
                    variant: 'warning',
                }),
            );
    };

    const handlePreview = () => {
        if (contentValidate()) props.openSlideBar();
        else
            dispatch(
                showMessage({
                    message: 'Empty field',
                    variant: 'warning',
                }),
            );
    };

    const renderProps = item => ({
        index: item.index,
        defaultExtend: ruleFieldById && ruleFieldById[0]?.AdmDocFld,
        extendField,
        parentId: admComDocFldId,
        closeSideBar() {
            props.onClose();
            dispatch(Actions.clearSidebar());
        },
    });

    useEffect(() => {
        if (bizRuleById && props?.typePage === 'edit') {
            setDescValue(bizRuleById.biz_rule_desc);
            setDisplayOrder(bizRuleById.ord_no);
            dispatch(Actions.setAllOrAny(bizRuleById.cond_tp_cd));
        }
    }, [bizRuleById]);

    useEffect(() => {
        dispatch(Actions.getAllDocField());
        if (props?.typePage === 'edit') dispatch(Actions.getBizRuleById(props?.bizRuleId));
    }, [dispatch]);

    useEffect(() => {
        if (Array.isArray(ruleFieldById) && props?.typePage && props?.typePage === 'new') {
            dispatch(Actions.setAllOrAny('ALL'));
            const allBizRuleOrderNo = ruleFieldById[0]?.DexBizRule.map(item => parseFloat(item.ord_no));
            const currentDefaultOrderNo = allBizRuleOrderNo.length > 0 ? Math.max(...allBizRuleOrderNo) : 0;
            setDisplayOrder(currentDefaultOrderNo + 1);
            setDescValue('');
        }
    }, [props?.typePage, ruleFieldById]);

    useEffect(() => {
        if (Array.isArray(allRuleField) && Array.isArray(ruleFieldById)) {
            const filterField = allRuleField.filter(
                item =>
                    item.DexLoc.co_cd === ruleFieldById[0].DexLoc.co_cd &&
                    item.DexLoc.loc_cd === ruleFieldById[0].DexLoc.loc_cd &&
                    item.DexLoc.doc_tp_id === ruleFieldById[0].DexLoc.doc_tp_id,
            );
            setExtendField(filterField.map(item => item.AdmDocFld));
        }
    }, [allRuleField, ruleFieldById]);

    useEffect(() => setAllAnyType(allOrAny), [allOrAny]);

    const handleChangeFieldProp = fieldProp => {
        // checkFieldPropError(fieldProp);
        dispatch(Actions.saveFilter(fieldProp));
        dispatch(Actions.clearStore());
    };

    const findAdmComDocFieldId = docFieldId => {
        const selectedField = allRuleField.find(
            item =>
                item.AdmDocFld.doc_tp_id === filter.documentType &&
                item.DexLoc.co_cd === filter.company &&
                item.DexLoc.loc_cd === filter.location &&
                item.doc_fld_id === docFieldId,
        );
        setAdmComDocFldId(selectedField?.adm_co_doc_fld_id);
    };

    return (
        <div>
            <div className={`${classes.defineContainer} flex flex-col w-full pl-5 pr-5 pt-5`}>
                <div className="flex flex-row w-full">
                    <div className="flex w-2/12">
                        <Autocomplete
                            size="small"
                            {...Functions.textFieldCommonProps(classes)}
                            options={renderCompanyOption()}
                            getOptionLabel={option => option.coNm || ''}
                            value={
                                renderCompany ? renderCompanyOption().find(el => el.coCd === renderCompany) || '' : ''
                            }
                            renderInput={params => (
                                <TextField
                                    size="small"
                                    error={fieldPropError.company}
                                    label="Company name"
                                    variant="outlined"
                                    required
                                    {...params}
                                />
                            )}
                            onChange={(e, value) =>{
                                handleChangeFieldProp({
                                    ...filter,
                                    company: value?.coCd || '',
                                    documentType: value && filter.documentType != ''
                                        ? allRuleField.find(
                                            i =>
                                                i.DexLoc?.co_cd === value.coCd &&
                                                i.DexLoc?.documents?.doc_tp_id === filter.documentType
                                        )
                                            ? filter.documentType
                                            : ''
                                        : '',
                                    location: value && filter.documentType != '' && filter.location != '' 
                                        ? allRuleField.find(
                                            i =>
                                                i.DexLoc?.co_cd === value.coCd &&
                                                i.DexLoc?.documents?.doc_tp_id === filter.documentType &&
                                                i.DexLoc?.loc_cd === filter.location
                                        )
                                            ? filter.location
                                            : ''
                                        : '',
                                    documentField: value && filter.documentType != '' && filter.documentField != ''
                                        ? allRuleField.find(
                                            i =>
                                                i.DexLoc?.co_cd === value.coCd &&
                                                i.DexLoc?.documents?.doc_tp_id === filter.documentType &&
                                                i.AdmDocFld?.doc_fld_id === filter.documentField,
                                        )
                                            ? filter.documentField
                                            : ''
                                        : '',
                                })
                                onFilterChange(value);
                            }}
                            disabled={userInfo.usrId !== 'admin' || props?.typePage === 'edit' || !!comDocFldIdFromURL}
                        />
                    </div>

                    <div className="flex w-2/12">
                        <Autocomplete
                            size="small"
                            {...Functions.textFieldCommonProps(classes)}
                            options={renderDocumentType()}
                            getOptionLabel={option => option.doc_nm || ''}
                            value={
                                filter.documentType
                                    ? renderDocumentType()?.find(el => el.doc_tp_id === filter.documentType) || ''
                                    : ''
                            }
                            renderInput={params => (
                                <TextField
                                    size="small"
                                    label="Document name"
                                    variant="outlined"
                                    required
                                    error={fieldPropError.documentType}
                                    {...params}
                                />
                            )}
                            onChange={(e, value) => {
                                handleChangeFieldProp({
                                    ...filter,
                                    documentType: value?.doc_tp_id || '',
                                    documentField: value
                                        ? allRuleField.find(
                                              i =>
                                                  i.DexLoc?.co_cd === filter.company &&
                                                  i.DexLoc?.loc_cd === value?.loc_cd &&
                                                  i.DexLoc?.documents?.doc_tp_id === filter.documentType &&
                                                  i.AdmDocFld?.doc_fld_id === filter.documentField,
                                          )
                                            ? filter.documentField
                                            : ''
                                        : '',
                                });
                                onFilterChange(value);
                            }}
                            disabled={!filter.company || props?.typePage === 'edit' || !!comDocFldIdFromURL}
                        />
                    </div>

                    <div className="flex w-2/12">
                        <Autocomplete
                            size="small"
                            {...Functions.textFieldCommonProps(classes)}
                            options={renderLocationOption()}
                            getOptionLabel={option => option.loc_nm || ''}
                            value={
                                filter.location
                                    ? renderLocationOption()?.find(el => el.loc_cd === filter.location) || ''
                                    : ''
                            }
                            renderInput={params => (
                                <TextField
                                    size="small"
                                    label="Location name"
                                    variant="outlined"
                                    required
                                    {...params}
                                    error={fieldPropError.location}
                                />
                            )}
                            onChange={(e, value) => {
                                handleChangeFieldProp({
                                    ...filter,
                                    location: value?.loc_cd || '',
                                });
                                onFilterChange(value);
                            }}
                            disabled={!filter.company || props?.typePage === 'edit' || !!comDocFldIdFromURL}
                        />
                    </div>

                    <div className="flex w-2/12">
                        <Autocomplete
                            size="small"
                            {...Functions.textFieldCommonProps(classes)}
                            options={renderDocumentField()}
                            getOptionLabel={option => option.fld_nm || ''}
                            value={
                                filter.documentField
                                    ? renderDocumentField()?.find(el => el.doc_fld_id === filter.documentField) || ''
                                    : ''
                            }
                            renderInput={params => (
                                <TextField
                                    size="small"
                                    label="Field name"
                                    variant="outlined"
                                    required
                                    error={fieldPropError.documentField}
                                    {...params}
                                />
                            )}
                            onChange={(e, value) => {
                                handleChangeFieldProp({
                                    ...filter,
                                    documentField: value?.doc_fld_id || '',
                                });
                                if (value?.doc_fld_id) findAdmComDocFieldId(value?.doc_fld_id);
                                onFilterChange(value);
                            }}
                            disabled={!filter.documentType || props?.typePage === 'edit' || !!comDocFldIdFromURL}
                        />
                    </div>
                </div>

                <div className="flex flex-row w-full">
                    <div className="flex pt-5 pb-5 w-5/12">
                        <TextField
                            {...Functions.textFieldCommonProps(classes)}
                            label="Biz rule description"
                            error={descEmptyError}
                            value={descValue}
                            onChange={e => setDescValue(e.target.value)}
                        />
                    </div>
                    <div className="flex pt-5 pb-5 w-3/12">
                        <TextField
                            {...Functions.textFieldCommonProps(classes)}
                            label="Display order"
                            type="number"
                            error={displayOrderError}
                            value={displayOrder}
                            onChange={e => setDisplayOrder(e.target.value)}
                        />
                    </div>
                </div>

                <div className="flex flex-row w-full pb-5">
                    <Typography className="normal-case flex items-center font-semibold mr-5" color="inherit">
                        If
                    </Typography>
                    <div className="flex pt-5 pb-5 w-1/24">
                        <TextField
                            {...Functions.textFieldCommonProps(classes)}
                            select
                            value={allAnyType}
                            onChange={e => dispatch(Actions.setAllOrAny(e.target.value))}
                        >
                            <MenuItem value="ALL">ALL</MenuItem>
                            <MenuItem value="ANY">ANY</MenuItem>
                        </TextField>
                    </div>
                    <Typography className="normal-case flex items-center font-semibold ml-5 " color="inherit">
                        of conditions are met
                    </Typography>
                </div>

                <div className={`${classes.listContainer}  flex flex-col w-full overflow-auto border-t border-b`}>
                    <List component="nav" aria-label="secondary mailbox folders">
                        {bizRuleConditions.map(item => (
                            <ListItem key={item.index}>
                                <BizRuleConditionForm
                                    {...renderProps(item)}
                                    conditionHasError={conditionHasError}
                                    setConditionHasError={bool => setConditionHasError(bool)}
                                />
                            </ListItem>
                        ))}
                    </List>
                </div>

                <div className="flex flex-row w-full pb-5 pt-5">
                    <Typography className="normal-case flex items-center font-semibold mr-5" color="inherit">
                        Perform the following actions
                    </Typography>
                </div>

                <div className={`${classes.listContainer}  flex flex-col w-full overflow-auto border-t border-b`}>
                    <List component="nav" aria-label="secondary mailbox folders">
                        {bizRuleActions.map(item => (
                            <ListItem key={item.index}>
                                <BizRuleActionForm
                                    {...renderProps(item)}
                                    actionHasError={actionHasError}
                                    setActionHasError={bool => setActionHasError(bool)}
                                />
                            </ListItem>
                        ))}
                    </List>
                </div>
            </div>
            <div className={classes.footer}>
                {btnList.some(btn => btn.BTN_NO === buttons.BTN_VIEW_REPORT) && (
                    <CustomButton
                        disabled={props?.showButtonPreview}
                        variant="contained"
                        color="primary"
                        onClick={handlePreview}
                    >
                        Preview
                    </CustomButton>
                )}
                {btnList.some(btn => btn.BTN_NO === buttons.BTN_SAVE) && (
                    <CustomButton variant="contained" color="primary" onClick={handleSave}>
                        Save
                    </CustomButton>
                )}
            </div>
        </div>
    );
};

export default withReducer('BizRuleReducer', reducer)(BizRuleDefine);

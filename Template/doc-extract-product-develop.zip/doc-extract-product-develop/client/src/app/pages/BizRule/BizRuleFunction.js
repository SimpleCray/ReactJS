/* eslint-disable no-lonely-if */
/* eslint-disable no-else-return */
import { makeStyles } from '@material-ui/styles';

export const equalObject = (obj1, obj2) => {
    if (Object.keys(obj1).length !== Object.keys(obj2).length) return false;
    const objKey1 = Object.keys(obj1);
    const objKey2 = Object.keys(obj2);
    return !objKey1.some((item, index) => obj1[item] !== obj2[item] || obj1[objKey2[index]] !== obj2[objKey2[index]]);
};

export const handleUniqueArray = (array, key) => {
    const uniqueArray = [];
    if (Array.isArray(array)) {
        array.forEach(item => {
            if (!item) return;
            if (!uniqueArray.find(el => el[key] === item[key])) uniqueArray.push(item);
        });
    }
    return uniqueArray;
};

export const alignCommonData = allCommon => {
    const resultArray = allCommon.map(item => {
        const parseValue = JSON.parse(item.com_dat_val);
        return parseValue.data.map(el => ({
            code: el[parseValue.config.key],
            value: el[parseValue.config.value],
            commonCode: item.com_dat_cd,
            commonName: item.com_dat_nm,
        }));
    });
    return resultArray.reduce((array, current) => [...array, ...current], []).filter(item => item.value.length < 100);
};

export const reOrderNumber = array => array.map((item, i) => ({ ...item, index: i }));

export const handleAddToArray = (array, item, index) => [...array.slice(0, index), item, ...array.slice(index)];

// Group document by location in header selection search
export const groupDocumentByLocation = (allDexLoc, currentCompany, currentLocation) => {
    // Make location array to unique by doc_tp_id column and filter by company code and location code
    const locParam = handleUniqueArray(
        allDexLoc.filter(item =>
            currentLocation !== 'all'
                ? item.co_cd === currentCompany && item.loc_cd === currentLocation
                : item.co_cd === currentCompany,
        ),
        'doc_tp_id',
    );
    const orphanLocation = locParam.filter(item => !item.prnt_loc_id && item.documents.doc_fields.length !== 0);
    const parentLocation = locParam.filter(item => !item.prnt_loc_id && item.documents.doc_fields.length === 0);
    const mapChildToParent = parentLocation.map(item => ({
        ...item,
        child: locParam.filter(el => el.prnt_loc_id === item.loc_id),
    }));
    return [...orphanLocation, ...mapChildToParent];
};

export const textFieldCommonProps = classes => ({
    fullWidth: true,
    required: true,
    size: 'small',
    autoComplete: 'off',
    variant: 'outlined',
    className: `${classes.styleTextField} flex flex-1`,
});

// Use for bizRuleActionForm and bizRuleConditionForm
export const autoCompleteProps = (item, classes) => ({
    freeSolo: true,
    fullWidth: true,
    limitTags: 2,
    className: `${classes.styleTextField} flex flex-1`,
    size: 'small',
    id: item.key,
});

// Use for bizRuleActionForm and bizRuleConditionForm
export const textFieldPropsExtend = (item, classes) => ({
    fullWidth: true,
    required: item.required === 'Y',
    className: `${classes.styleTextField} flex flex-1`,
    id: item.key,
    label: item.label,
    variant: 'outlined',
    size: 'small',
    autoComplete: 'off',
    type: item.number === 'N' ? 'text' : 'number',
    value: item ? item.value : '',
});

export const useStyles = makeStyles({
    styleTextField: {
        marginRight: 20,
    },
    textFieldWidth: {
        width: '200px',
    },
    footer: {
        position: 'relative',
        display: 'flex',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        padding: 20,
    },
    defineContainer: {
        maxHeight: '80%',
    },
    listContainer: {
        height: '28vh',
    },
    inputContainer: {
        paddingTop: 15,
        maxHeight: '30vh',
        overflow: 'auto',
    },
    whiteColor: {
        color: 'white',
    },
    otherExcuteContainer: {
        paddingTop: 15,
        maxHeight: '20vh',
        overflow: 'auto',
    },
    conditionItemContainer: {
        width: '100%',
        display: 'flex',
        flexWrap: 'wrap',
        rowGap: '10px',
    },
    gapContainer: {
        width: '75%',
        display: 'flex',
        flexWrap: 'wrap',
        rowGap: '10px',
    },
});

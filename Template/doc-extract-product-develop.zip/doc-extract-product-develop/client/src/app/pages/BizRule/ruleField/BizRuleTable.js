import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Table, TableBody, TableCell, TablePagination, TableRow, FormControlLabel, Checkbox } from '@material-ui/core';
import { openDialog } from '../../../store/actions/fuse/dialog.actions';
import * as TableFnc from '../../../utils/tableFunctions';
import CustomButton from '../../../components/Button';
import buttons from '../../../utils/constants/buttonConstants.json';
import _ from '../../../../@lodash';
import { FuseScrollbars } from '../../../../@fuse';
import BizRuleTableHead from './BizRuleTableHead';
import ExcuteAllDialog from './ExcuteAllDialog';
import CopyBizDialog from './CopyBizDialog';

import * as Actions from '../store/actions/actions';
import * as Constraint from '../BizRuleConstants';

function BizRuleTable(props) {
    const header = props?.type === 'left-table' ? Constraint.setupBizRuleHead : Constraint.setupBizRuleHeadDetail;
    const dispatch = useDispatch();
    const commonProps = {
        className: 'whitespace-no-wrap h-32 mx-2',
        variant: 'contained',
        color: 'primary',
    };

    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const currentField = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.currentField);
    const allCompanyRef = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allCompanyRef);
    const filter = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.filter);

    const [order, setOrder] = useState({
        direction: 'asc',
        columnId: null,
    });
    const [data, setData] = useState([]);
    const pageField = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.pageField);
    const pageDescription = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.pageDescription);
    const [openExcuteAll, setOpenExcuteAll] = useState(false);
    const [rowsPerPage, setRowsPerPage] = useState(25);
    const [selected, setSelected] = useState([]);
    const [selectedData, setSelectedData] = useState(null);
    const [search, setSearch] = useState('');
    const [openCopyBizDialog, setOpenCopyBizDialog] = useState(false);

    const handleBizRuleDetailAdd = () => {
        dispatch(Actions.clearStore());
        props.history.push({
            pathname: '/biz-rule/new',
            state: {
                currentField,
            },
        });
    };

    const handleBizRuleEdit = () => {
        if (currentField && currentField.adm_co_doc_fld_id) {
            props.history.push({
                pathname: `/biz-rule/edit/${selectedData.biz_rule_id}`,
                state: {
                    currentField,
                    data: { ...selectedData },
                },
            });
        }
    };

    const handleTableRowClick = row => {
        if (props?.type === 'left-table') {
            setSelected([row.adm_co_doc_fld_id]);
            dispatch(Actions.saveRuleField(row));
        } else {
            setSelected([row.biz_rule_id]);
        }
        setSelectedData(row);
        if (props?.type === 'left-table') props.onClick(row);
    };

    const handleTableRowDoubleClick = row => {
        if (props?.type === 'right-table' && currentField.adm_co_doc_fld_id) {
            props.history.push({
                pathname: `/biz-rule/edit/${selectedData.biz_rule_id}`,
                state: {
                    currentField,
                    data: { ...selectedData },
                },
            });
        }
    };

    const handleChangeFlag = isRestoreMode => {
        const newFlag = isRestoreMode ? 'N' : 'Y';
        dispatch(
            openDialog(
                `Do you want to ${isRestoreMode ? 'restore' : 'delete'} this biz rule?`,
                '',
                'Confirm',
                async () => {
                    await dispatch(Actions.changeFlagBizRule(selected, newFlag));
                    props.loadDataByCondition(filter.company, filter.location, filter.documentType, filter.documentField);
                    dispatch(Actions.getBizRule(currentField.adm_co_doc_fld_id));
                    setSelected([]);
                    setSelectedData(null);
                },
            ),
        );
    };

    const joinTableByColumn = (dexLoc, company) =>
        dexLoc.map(item => {
            const companyName = company.find(el => el.coCd === item.DexLoc.co_cd).coNm;
            return { ...item, co_nm: companyName };
        });

    useEffect(() => {
        if (props?.data && allCompanyRef.comList && props?.type === 'left-table') {
            const tableData = joinTableByColumn(props?.data, allCompanyRef.comList) || [];
            if (!tableData.length) dispatch(Actions.saveRuleField({}));
            setData(tableData);
        }

        if (props?.data && props?.type === 'right-table') {
            const deltFlg = filter.showDeleted ? 'Y' : 'N';
            setData(props?.data.map(item => ({ ...item })).filter(item => item.delt_flg === deltFlg));
        }
    }, [props?.data, allCompanyRef, filter]);

    useEffect(() => setSearch(props?.search), [props?.search]);

    return (
        <div className="w-full flex flex-col border-2 p-1 mb-2 mt-2 mr-1 ml-1 column">
            <FuseScrollbars className="flex-grow">
                <Table stickyHeader className="w-full" aria-labelledby="tableTitle" size="small">
                    <BizRuleTableHead
                        type={props?.type}
                        order={order}
                        onRequestSort={(event, property) =>
                            TableFnc.handleRequestSort(event, property, order, setOrder)
                        }
                    />
                    <TableBody>
                        {_.orderBy(data, [order.columnId], [order.direction])
                            .filter(item => !search || item.biz_rule_desc.toLowerCase().includes(search.toLowerCase()))
                            .slice(
                                (props?.type === 'left-table' ? pageField : pageDescription) * rowsPerPage,
                                (props?.type === 'left-table' ? pageField : pageDescription) * rowsPerPage +
                                    rowsPerPage,
                            )
                            .map(n => (
                                <TableRow
                                    key={props?.type === 'left-table' ? n.adm_co_doc_fld_id : n.biz_rule_id}
                                    hover
                                    className="cursor-pointer"
                                    selected={
                                        props?.type === 'left-table'
                                            ? n.adm_co_doc_fld_id === currentField?.adm_co_doc_fld_id
                                            : selected.includes(n.biz_rule_id)
                                    }
                                    onClick={() => handleTableRowClick(n)}
                                    onDoubleClick={() =>
                                        btnList.some(btn => btn.BTN_NO === buttons.BTN_EDIT) &&
                                        handleTableRowDoubleClick(n)
                                    }
                                >
                                    {header.slice(1).map(item => {
                                        let cell = null;
                                        switch (item.id) {
                                            case 'AdmDocFld.fld_nm':
                                                cell = n.AdmDocFld.fld_nm;
                                                break;
                                            case 'DexLoc.documents.doc_nm':
                                                cell = n.DexLoc.documents.doc_nm;
                                                break;
                                            case 'DexLoc.loc_nm':
                                                cell = n.DexLoc.loc_nm;
                                                break;
                                            case 'co_nm':
                                                cell = n.co_nm;
                                                break;
                                            default:
                                                cell = n[item.id];
                                        }
                                        return (
                                            <TableCell key={item.id} className={`text-left ${item.width}`}>
                                                {cell}
                                            </TableCell>
                                        );
                                    })}
                                </TableRow>
                            ))}
                    </TableBody>
                </Table>
            </FuseScrollbars>

            <div className="flex flex-row w-full">
                <div className="flex justify-start w-8/12">
                    <TablePagination
                        labelRowsPerPage=""
                        rowsPerPageOptions={[10, 25, 50]}
                        component="div"
                        count={data.length}
                        rowsPerPage={rowsPerPage}
                        page={props?.type === 'left-table' ? pageField : pageDescription}
                        backIconButtonProps={{
                            'aria-label': 'Previous Page',
                        }}
                        nextIconButtonProps={{
                            'aria-label': 'Next Page',
                        }}
                        onChangePage={(ev, p) => {
                            if (props?.type === 'left-table') dispatch(Actions.setPageField(p));
                            else dispatch(Actions.setPageDescription(p));
                        }}
                        onChangeRowsPerPage={ev => {
                            if (props?.type === 'left-table')
                                TableFnc.handleChangeRowsPerPage(
                                    ev,
                                    pageField,
                                    data,
                                    pageNumber => dispatch(Actions.setPageField(pageNumber)),
                                    setRowsPerPage,
                                );
                            else
                                TableFnc.handleChangeRowsPerPage(
                                    ev,
                                    pageDescription,
                                    data,
                                    pageNumber => dispatch(Actions.setPageDescription(pageNumber)),
                                    setRowsPerPage,
                                );
                        }}
                    />
                </div>
                {props?.type === 'right-table' ? (
                    <div className="flex justify-end w-5/12 items-center">
                        <ExcuteAllDialog open={openExcuteAll} onClose={() => setOpenExcuteAll(false)} />
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_VIEW_REPORT) && (
                            <CustomButton
                                {...commonProps}
                                disabled={!currentField?.adm_co_doc_fld_id || data.length === 0 || filter.showDeleted}
                                onClick={() => setOpenExcuteAll(true)}
                            >
                                PREVIEW
                            </CustomButton>
                        )}
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_ADD) && (
                            <CustomButton {...commonProps} onClick={handleBizRuleDetailAdd}>
                                ADD
                            </CustomButton>
                        )}
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_EDIT) && (
                            <CustomButton {...commonProps} onClick={handleBizRuleEdit} disabled={selected.length === 0}>
                                EDIT
                            </CustomButton>
                        )}
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_DELETE) && (
                            <CustomButton
                                {...commonProps}
                                onClick={e => handleChangeFlag(filter.showDeleted)}
                                disabled={selected.length === 0}
                            >
                                {filter.showDeleted ? 'RESTORE' : 'DELETE'}
                            </CustomButton>
                        )}
                    </div>
                ) : (
                    <div className="flex justify-end w-5/12 items-center">
                        <CopyBizDialog open={openCopyBizDialog} onClose={() => setOpenCopyBizDialog(false)} />
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_COPY) && (
                            <CustomButton {...commonProps} onClick={() => setOpenCopyBizDialog(true)}>
                                COPY
                            </CustomButton>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

export default withRouter(BizRuleTable);

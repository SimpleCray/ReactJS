import EndPointAPI from 'app/utils/endPointAPI';
import { API_EP } from '../../../../utils/commonAPI';
import { showMessage } from '../../../../store/actions/fuse/message.actions';
import { showError, checkResDataAPI } from '../../../../utils/utils';

export const GET_RULE_FIELD_BY_ID = 'GET_RULE_FIELD_BY_ID';
export const GET_BIZ_RULE_BY_ID = 'GET_BIZ_RULE_BY_ID';
export const GET_RULE_FIELD = 'GET_RULE_FIELD';
export const GET_DOC_FIELD = 'GET_DOC_FIELD';
export const GET_BIZ_RULE = 'GET_BIZ_RULE';
export const CREATE_RULE_FIELD = 'CREATE_RULE_FIELD';
export const CHANGE_FLAG_BIZ_RULE = 'CHANGE_FLAG_BIZ_RULE';
export const ADD_BIZ_RULE_CONDITION = 'ADD_BIZ_RULE_CONDITION';
export const ADD_BIZ_RULE_ACTION = 'ADD_BIZ_RULE_ACTION';
export const ADD_ALL_OR_ANY = 'ADD_ALL_OR_ANY';
export const CLEAR_STORE = 'CLEAR_STORE';
export const UPDATE_BIZ_RULE = 'UPDATE_BIZ_RULE';
export const CREATE_BIZ_RULE = 'CREATE_BIZ_RULE';
export const GET_DOCUMENT = 'GET_DOCUMENT';
export const GET_COMMON_ACTION_CONDITION_DATA = 'GET_COMMON_ACTION_CONDITION_DATA';
export const GET_COMMON_DATA_FOR_BIZ = 'GET_COMMON_DATA_FOR_BIZ';
export const SAVE_FILTER = 'SAVE_FILTER';
export const UPDATE_RULE_FIELD = 'UPDATE_RULE_FIELD';
export const CLEAR_SIDEBAR = 'CLEAR_SIDEBAR';

export const GET_COMPANY_NAME = 'GET_COMPANY_NAME';
export const RUN_SINGLE_BIZ = 'RUN_SINGLE_BIZ';
export const RUN_BIZ_BY_FIELD = 'RUN_BIZ_BY_FIELD';
export const GET_ALL_RULE_FIELD = 'GET_ALL_RULE_FIELD';
export const GET_DEX_LOC = 'GET_DEX_LOC';
export const SET_PAGE_FIELD = 'SET_PAGE_BIZ_RULE_FIELD';
export const SET_PAGE_DESCRIPTION = 'SET_PAGE_BIZ_RULE_DESCRIPTION';
export const SET_USER_ROLE = 'SET_USER_ROLE';
export const RUN_COPY_BIZ_RULE = 'RUN_COPY_BIZ_RULE';

export const UPDATE_PANEL_SIZE = 'UPDATE_PANEL_SIZE';

export const callBackFunction = (dispatch, typeParam, urlParam, messageParam) =>
    urlParam
        .then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: typeParam,
                    payload: response.data,
                });
                if (messageParam)
                    dispatch(
                        showMessage({
                            message: messageParam,
                            variant: 'success',
                        }),
                    );
            }
        })
        .catch(error => dispatch(showError(error)));

// Load DB from dex_biz_rule
export const getCompanyDocumentField = conditions => {
    const url = API_EP.get('/biz-rule/get-rule-field', { params: conditions });
    return dispatch => callBackFunction(dispatch, GET_RULE_FIELD, url);
};

export const getCompanyDocumentFieldById = conditions => {
    const url = API_EP.get('/biz-rule/get-rule-field', { params: conditions });
    return dispatch => callBackFunction(dispatch, GET_RULE_FIELD_BY_ID, url);
};

export const getAllCompanyDocumentField = conditions => {
    const url = API_EP.get('/biz-rule/get-rule-field', { params: {} });
    return dispatch => callBackFunction(dispatch, GET_ALL_RULE_FIELD, url);
};

export const getAllCompanyName = () => {
    const url = API_EP.get(EndPointAPI.ENDPOINT.BP.ALL_COM);
    return dispatch => callBackFunction(dispatch, GET_COMPANY_NAME, url);
};

export const getAllDocField = () => {
    const url = API_EP.get('/biz-rule/all-doc-fld');
    return dispatch => callBackFunction(dispatch, GET_DOC_FIELD, url);
};

export const getBizRule = param => {
    const url = API_EP.get('/biz-rule/get-biz-rule', { params: { adm_co_doc_fld_id: param } });
    return dispatch => callBackFunction(dispatch, GET_BIZ_RULE, url);
};

export const getAllLocation = coCdParam => {
    const url = API_EP.get('/biz-rule/all-dex-loc', { params: { co_cd: coCdParam } });
    return dispatch => callBackFunction(dispatch, GET_DEX_LOC, url);
};

export const getBizRuleById = param => {
    const url = API_EP.get('/biz-rule/biz-rule-by-id', { params: { id: param } });
    return dispatch => callBackFunction(dispatch, GET_BIZ_RULE_BY_ID, url);
};

export const changeFlagBizRule = (bizRuleId, newFlag) => {
    const url = API_EP.put('/biz-rule/change-flag-biz-rule', {
        biz_rule_id: bizRuleId,
        upd_usr_id: JSON.parse(localStorage.getItem('userInfo')).usrId,
        newFlag,
    });
    return dispatch => callBackFunction(dispatch, CHANGE_FLAG_BIZ_RULE, url, `${newFlag === 'Y' ? 'Delete' : 'Restore'} successfull`);
};

export const createBizRule = bizRule => {
    const url = API_EP.post('/biz-rule/create-biz-rule', bizRule);
    return dispatch => callBackFunction(dispatch, CREATE_BIZ_RULE, url, 'Create success');
};

export const updateBizRule = bizRule => {
    const url = API_EP.put('/biz-rule/update-biz-rule', bizRule);
    return dispatch => callBackFunction(dispatch, UPDATE_BIZ_RULE, url, 'Save success');
};

export const getCommonActCondData = table => {
    const url = API_EP.post('/common-data/common-data-by-code', {
        codeList: table,
    });
    return dispatch => callBackFunction(dispatch, GET_COMMON_ACTION_CONDITION_DATA, url);
};

export const getCommonDataForBiz = () => {
    const url = API_EP.get('/common-data/common-data-for-biz');
    return dispatch => callBackFunction(dispatch, GET_COMMON_DATA_FOR_BIZ, url);
};

export const runSingleBiz = param => {
    const url = API_EP.put('/biz-rule/run-biz-rule-preview', { ...param });
    return dispatch => callBackFunction(dispatch, RUN_SINGLE_BIZ, url);
};

export const runBizByField = param => {
    const url = API_EP.put('/biz-rule/run-biz-rule-by-field-preview', { ...param });
    return dispatch => callBackFunction(dispatch, RUN_BIZ_BY_FIELD, url);
};

export const runCopyBizRule = param => dispatch => {
    const url = API_EP.put('/biz-rule/run-copy-biz-rule', { ...param });
    url.then(response => {
        if (checkResDataAPI(response)) {
            const { message, variant } = response.data;
            dispatch(showMessage({ message, variant }));
        }
    }).catch(error => {
        dispatch(showError(error));
    });
};

export const saveRuleField = ruleField => dispatch =>
    dispatch({
        type: UPDATE_RULE_FIELD,
        ruleField,
    });

export const addBizRuleCondition = bizRuleCondition => dispatch =>
    dispatch({
        type: ADD_BIZ_RULE_CONDITION,
        bizRuleCondition,
    });

export const addBizRuleAction = bizRuleAction => dispatch =>
    dispatch({
        type: ADD_BIZ_RULE_ACTION,
        bizRuleAction,
    });

export const setAllOrAny = allOrAny => dispatch =>
    dispatch({
        type: ADD_ALL_OR_ANY,
        allOrAny,
    });

export const clearStore = () => dispatch =>
    dispatch({
        type: CLEAR_STORE,
    });

export const saveFilter = filter => dispatch =>
    dispatch({
        type: SAVE_FILTER,
        filter,
    });

export const setPageField = value => dispatch =>
    dispatch({
        type: SET_PAGE_FIELD,
        pageField: value,
    });

export const setPageDescription = value => dispatch =>
    dispatch({
        type: SET_PAGE_DESCRIPTION,
        pageDescription: value,
    });

export const clearSidebar = () => dispatch =>
    dispatch({
        type: CLEAR_SIDEBAR,
    });

export const setAuthhUserId = userIdAuth => dispatch =>
    dispatch({
        type: SET_USER_ROLE,
        userIdAuth: userIdAuth,
    });

export const updatePanelSize = panelList => dispatch =>
    dispatch({
        type: UPDATE_PANEL_SIZE,
        panelList,
    });

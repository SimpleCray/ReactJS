import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    Dialog,
    DialogActions,
    DialogContent,
    TextField,
    IconButton,
    Typography,
    Toolbar,
    AppBar,
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import CustomButton from '../../../components/Button';
import * as Functions from '../BizRuleFunction';
import * as Actions from '../store/actions';

const ExcuteAllDialog = props => {
    const dispatch = useDispatch();
    const classes = Functions.useStyles();

    const allBizRule = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allBizRule);
    const currentField = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.currentField);
    const outputByField = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.outputByField);

    const [renderField, setRenderField] = useState([]);
    const [inputPreview, setInputPreview] = useState('');
    const [extendOutput, setExtendOutput] = useState([]);
    const [allOutputField, setAllOutputField] = useState({});

    const handleExcute = () => {
        if (renderField) {
            const extendParam = renderField.reduce(
                (obj, crr) => ({
                    ...obj,
                    [crr.doc_fld_id]: document.getElementById(`${crr.doc_fld_id}-excute`).value,
                }),
                {},
            );

            const extendOuputParam =
                extendOutput &&
                Functions.handleUniqueArray(extendOutput, 'doc_fld_id').reduce(
                    (obj, crr) => ({
                        ...obj,
                        [`${crr.doc_fld_id}-excute-output`]: {
                            [crr.doc_fld_id]: '',
                        },
                    }),
                    {},
                );
            dispatch(
                Actions.runBizByField({
                    input: inputPreview,
                    adm_co_doc_fld_id: currentField.adm_co_doc_fld_id,
                    extend: extendParam,
                    extendOutput: extendOuputParam,
                }),
            );
        }
    };

    const handleClose = () => {
        setInputPreview('');
        props.onClose();
    };

    useEffect(() => {
        if (allBizRule) {
            const arrayCondition = allBizRule.map(item => JSON.parse(item.cond_ctnt));
            const joinArrayCondition = arrayCondition.reduce((array, current) => [...array, ...current], []);
            const filterExtendCondition = joinArrayCondition.filter(
                item => Array.isArray(item.value) && item.value.some(el => el.key === 'field'),
            );
            const arrayFieldCondition = filterExtendCondition.map(item => item.value[0].value[0]);

            const arrayAction = allBizRule.map(item => JSON.parse(item.act_ctnt));
            const joinArrayAction = arrayAction.reduce((array, current) => [...array, ...current], []);

            const extendInputs = [];
            const extendOutputs = [];
            const allField = [];

            joinArrayAction.forEach(item => {
                allField.push(...Object.values(item.value).filter(el => el?.doc_fld_id));
            });
            extendInputs.push(
                ...allField.filter(item => item.doc_fld_id !== currentField?.doc_fld_id && item.showOutput !== null),
            );
            extendOutputs.push(
                ...allField.filter(item => item.doc_fld_id !== currentField?.doc_fld_id && item.showOutput === 'Y'),
            );

            const unique = Functions.handleUniqueArray([...arrayFieldCondition, ...extendInputs], 'doc_fld_id');
            setRenderField(unique);
            setExtendOutput(extendOutputs);
        }
    }, [allBizRule]);

    useEffect(() => {
        if (outputByField) setAllOutputField(outputByField);
    }, [outputByField]);

    useEffect(() => setAllOutputField([]), [props?.open]);

    return (
        <Dialog
            classes={{
                paper: 'm-24',
            }}
            fullWidth
            maxWidth="xs"
            open={props?.open}
        >
            <AppBar position="static" elevation={1}>
                <Toolbar className="flex flex-row w-full">
                    <div className="flex w-8/12 justify-start">
                        <Typography variant="subtitle1" color="inherit">
                            Excute all biz rule
                        </Typography>
                    </div>
                    <div className="flex w-4/12 justify-end">
                        <IconButton onClick={handleClose}>
                            <CloseIcon className={classes.whiteColor} />
                        </IconButton>
                    </div>
                </Toolbar>
            </AppBar>
            <form className="flex flex-col overflow-hidden">
                <DialogContent classes={{ root: 'p-24' }}>
                    {renderField && renderField.length > 0 && (
                        <div className="flex w-full pl-5">
                            <Typography className="normal-case flex items-center font-semibold mr-5" color="inherit">
                                Other input field
                            </Typography>
                        </div>
                    )}

                    <div className={classes.otherExcuteContainer}>
                        {renderField.map(item => (
                            <div className="flex pl-5 pr-5" key={item.doc_fld_id}>
                                <TextField
                                    {...Functions.textFieldCommonProps(classes)}
                                    multiline
                                    rowsMax={3}
                                    className="mb-5"
                                    label={item.fld_nm}
                                    id={`${item.doc_fld_id}-excute`}
                                />
                            </div>
                        ))}
                    </div>

                    {[
                        {
                            title: 'Input preview',
                            value: inputPreview,
                            onChange(e) {
                                setInputPreview(e.target.value);
                            },
                        },
                        { title: 'Output preview', value: allOutputField.mainField || '', onChange: null },
                    ].map(component => (
                        <div key={component.title}>
                            <div className="flex w-full pl-5 mb-5 mt-5">
                                <Typography
                                    className="normal-case flex items-center font-semibold mr-5"
                                    color="inherit"
                                >
                                    {component.title}
                                </Typography>
                            </div>
                            <div className="flex pl-5 pr-5">
                                <TextField
                                    {...Functions.textFieldCommonProps(classes)}
                                    multiline
                                    rows={4}
                                    className="mb-5"
                                    id={component.title === 'Input preview' ? 'input-excute' : 'output'}
                                    label={currentField?.AdmDocFld ? currentField.AdmDocFld.fld_nm : ''}
                                    value={component.value}
                                    onChange={component?.onChange}
                                    inputProps={{
                                        style: {
                                            whiteSpace: 'nowrap',
                                            overflowX: 'auto',
                                            overflowWrap: 'break-word',
                                        },
                                    }}
                                />
                            </div>
                        </div>
                    ))}

                    {extendOutput && extendOutput.length > 0 && (
                        <div className="flex w-full pl-5">
                            <Typography className="normal-case flex items-center font-semibold mr-5" color="inherit">
                                Other output field
                            </Typography>
                        </div>
                    )}

                    <div className={classes.otherExcuteContainer}>
                        {extendOutput.map(item => (
                            <div className="flex pl-5 pr-5" key={item.doc_fld_id}>
                                <TextField
                                    {...Functions.textFieldCommonProps(classes)}
                                    multiline
                                    rowsMax={3}
                                    className="mb-5"
                                    label={item.fld_nm}
                                    id={`${item.doc_fld_id}-excute-output`}
                                    value={allOutputField[`${item.doc_fld_id}-excute-output`] || ''}
                                />
                            </div>
                        ))}
                    </div>
                </DialogContent>
                <DialogActions className="justify-right pl-16">
                    <CustomButton variant="contained" color="primary" onClick={handleExcute}>
                        Run
                    </CustomButton>
                </DialogActions>
            </form>
        </Dialog>
    );
};

export default ExcuteAllDialog;

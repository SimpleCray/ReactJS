import { combineReducers } from 'redux';
import bizRule from './reducers';

const reducer = combineReducers({
    bizRule,
});

export default reducer;

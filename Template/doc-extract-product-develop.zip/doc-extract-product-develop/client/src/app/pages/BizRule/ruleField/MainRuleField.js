import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PanelGroup from 'react-panelgroup';
import AppConstants from 'app/utils/appConstants';
import { FusePageCarded } from '../../../../@fuse';
import withReducer from '../../../store/withReducer';
import BizRuleTable from './BizRuleTable';
import BizRuleHeader from './BizRuleHeader';

import reducer from '../store/reducers';
import * as Actions from '../store/actions/actions';

let firstLoadPage = true;
let currentField = null;
function BizRule() {
    const dispatch = useDispatch();
    const filter = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.filter);
    const ruleField = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.ruleField);
    const allBizRule = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.allBizRule);
    const userIdAuth = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.userIdAuth);
    
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));

    const [search, setSearch] = useState('');
    const [ruleFieldData, setRuleFieldData] = useState([]);
    const [bizRuleData, setBizRuleData] = useState([]);
    const [panelSize, setPanelSize] = useState({
        left: (document.documentElement.clientWidth * 6.5) / 12,
        right: (document.documentElement.clientWidth * 5.5) / 12,
    });

    const handleOnSearch = text => setSearch(text);

    const handleRuleFieldClick = row => dispatch(Actions.getBizRule(row.adm_co_doc_fld_id));

    const handleCleanRightTable = () => setBizRuleData([]);

    const handleLoadByCondition = (company, location, document, field, preventLoadFirstRow) => {
        firstLoadPage = !preventLoadFirstRow;
        if (company != filter.company || location != filter.location){
            currentField = null;
        }
        dispatch(
            Actions.getCompanyDocumentField({
                co_cd: company || userInfo.coCd,
                loc_cd: location,
                doc_tp_id: document,
                doc_fld_id: field,
            }),
        );
    };

    // Re-load and passing searching condition to left table
    const handleChangeQuery = () => {
        // Show all field has rule then select first row by default
        if (ruleField.length > 0) {
            const filterArrayRuleField = ruleField.filter(
                item => item.DexBizRule.filter(i => i.delt_flg === 'N').length > 0,
            );
            // Somecase we focus in field and click add then we back with doing nothing. 
            // filter.temporaryField is locate which we save temporary of filter?.documentField.
            if (!currentField){
                currentField = ruleField.find(
                    i =>
                        i.DexLoc?.co_cd === filter?.company &&
                        i.DexLoc?.loc_cd === filter?.location &&
                        i.DexLoc?.documents?.doc_tp_id === filter?.documentType &&
                        i.AdmDocFld?.doc_fld_id === filter?.temporaryField &&
                        i.DexBizRule.length > 0,
                );
            }
            setRuleFieldData(filterArrayRuleField.sort((a, b) => a?.AdmDocFld?.fld_nm.localeCompare(b?.AdmDocFld?.fld_nm)));
            // Loading first row by default only apply at the first time load page. After that keeping state of data
            if ((firstLoadPage || filter.firstLoadPage) && filterArrayRuleField[0]) {
                if (currentField){ 
                    dispatch(Actions.getBizRule(currentField.adm_co_doc_fld_id));
                    dispatch(Actions.saveRuleField(filterArrayRuleField.find(i => i.adm_co_doc_fld_id === currentField.adm_co_doc_fld_id)));
                    currentField = null;
                }
                else {
                    handleRuleFieldClick(filterArrayRuleField[0]);
                    dispatch(Actions.saveRuleField(filterArrayRuleField[0]));
                }

                firstLoadPage = false;
                dispatch(
                    Actions.saveFilter({
                        ...filter,
                        firstLoadPage: true,
                    }),
                );
            }
        } else {
            setRuleFieldData([]);
            dispatch(Actions.getBizRule(''));
            dispatch(Actions.saveRuleField({}));
        }
    };

    // Call initial data
    useEffect(() => {
        dispatch(Actions.getCommonActCondData(['ACT_TYPE', 'ACT_BIZ_RULE', 'COND_FLD_TP']));
        dispatch(Actions.getAllDocField());
        dispatch(Actions.getAllCompanyName());
        dispatch(Actions.getAllCompanyDocumentField());
    }, [dispatch]);

    // Set left table data and default load first rule field
    useEffect(() => handleChangeQuery(), [ruleField]);

    // Set right table data
    useEffect(() => {
        if (ruleField.length && ruleFieldData.length && allBizRule) setBizRuleData(allBizRule);
        else setBizRuleData([]);
    }, [allBizRule, ruleField, ruleFieldData]);

    useEffect(() => {
        if (userIdAuth !== userInfo.usrId) {
            firstLoadPage = true;
            dispatch(Actions.setAuthhUserId(userInfo.usrId));
            dispatch(
                Actions.saveFilter({
                    company: '',
                    location: '',
                    documentType: '',
                    documentField: '',
                    showAll: true,
                }),
            );
        }
        dispatch(Actions.getAllLocation(userInfo.usrId !== 'admin' ? userInfo.coCd : null));
    }, [userInfo.usrId, dispatch]);

    return (
        <FusePageCarded
            id="main"
            classes={{
                content: 'flex',
                header: 'h-auto min-h-0 max-h-full',
                contentWrapper: 'pr-0 pl-0',
            }}
            header={
                <BizRuleHeader
                    onSearch={handleOnSearch}
                    loadDataByCondition={handleLoadByCondition}
                    onClean={handleCleanRightTable}
                    panelSize={panelSize}
                />
            }
            content={
                <PanelGroup
                    panelWidths={[
                        { size: panelSize.left, minSize: 400, resize: 'dynamic' },
                        { size: panelSize.right, minSize: 300, resize: 'dynamic' },
                    ]}
                    onResizeEnd={panelList =>
                        setPanelSize({
                            left: panelList[0].size,
                            right: panelList[1].size,
                        })
                    }
                >
                    <BizRuleTable
                        id="left-table"
                        type="left-table"
                        data={ruleFieldData}
                        onClick={handleRuleFieldClick}
                    />
                    <BizRuleTable
                        id="right-table"
                        type="right-table"
                        data={bizRuleData}
                        search={search}
                        loadDataByCondition={handleLoadByCondition}
                    />
                </PanelGroup>
            }
            innerScroll
        />
    );
}

export default withReducer('BizRuleReducer', reducer)(BizRule);

/* eslint-disable camelcase */
import React, { useState, useEffect } from 'react';
import { Icon } from '@material-ui/core';
import { withRouter } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import AppConstants from 'app/utils/appConstants';
import { FusePageCarded } from '../../../../@fuse';
import BizRuleDefine from './BizRuleDefine';
import BizRuleSideBar from './BizRuleSideBar';
import withReducer from '../../../store/withReducer';
import _ from '../../../../@lodash';

import reducer from '../store/reducers';
import * as Actions from '../store/actions/actions';

const MainBizRule = props => {
    const dispatch = useDispatch();
    const lastUrlParam = window.location.href.split('/').pop();
    const comDocFldIdFromURL = lastUrlParam.includes('COMDOC') ? lastUrlParam : null;
    const historyState = props.location.state;
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));

    const filter = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.filter);
    const ruleFieldById = useSelector(({ BizRuleReducer }) => BizRuleReducer.bizRule.ruleFieldById);
    const [openSideBar, setOpenSideBar] = useState(false);

    const onBackClick = () => {
        dispatch(Actions.clearStore());
        dispatch(
            Actions.saveFilter({
                ...filter,
                temporaryField: filter.documentField,
                documentField: 'all',
                firstLoadPage: true,
            }),
        );
        props.history.goBack();
    };

    useEffect(async () => {
        // Only allow user access from biz rule page or biz view
        if (historyState || comDocFldIdFromURL) {
            let admCoDocFldId = '';
            if (historyState) {
                const { adm_co_doc_fld_id } = historyState.currentField || '';
                const { co_cd, loc_cd } = historyState.currentField?.DexLoc || '';
                const { doc_tp_id, doc_fld_id } = historyState.currentField?.AdmDocFld || '';
                dispatch(
                    Actions.saveFilter({
                        company: co_cd || filter.company,
                        location: loc_cd || filter.location,
                        documentType: doc_tp_id || filter.documentType,
                        documentField: doc_fld_id || filter.documentField,
                    }),
                );
                admCoDocFldId = adm_co_doc_fld_id;
            // Component is called from biz view
            } else if (comDocFldIdFromURL) admCoDocFldId = comDocFldIdFromURL;
            dispatch(Actions.getAllCompanyName());
            dispatch(Actions.getAllLocation(userInfo.usrId !== 'admin' ? userInfo.coCd : null));
            dispatch(Actions.getCommonActCondData(['ACT_TYPE', 'ACT_BIZ_RULE', 'COND_FLD_TP']));
            dispatch(Actions.getCommonDataForBiz());
            dispatch(Actions.getAllCompanyDocumentField());
            dispatch(Actions.getCompanyDocumentFieldById({ adm_co_doc_fld_id: admCoDocFldId }));
        } else props.history.push('/biz-rule/'); // Prevent user from access this site directly
    }, [dispatch]);

    useEffect(() => {
        // If get current field prop (com/loc/doc/id) set the state of filter
        if (ruleFieldById[0] && comDocFldIdFromURL) {
            const { co_cd, loc_cd } = ruleFieldById[0].DexLoc;
            const { doc_tp_id, doc_fld_id } = ruleFieldById[0].AdmDocFld;
            dispatch(
                Actions.saveFilter({
                    company: co_cd,
                    location: loc_cd,
                    documentType: doc_tp_id,
                    documentField: doc_fld_id,
                }),
            );
        }
    }, [ruleFieldById]);

    return (
        <FusePageCarded
            classes={{
                header: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
                toolbar: 'px-16 sm:px-24',

                topBg: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
                contentWrapper: 'pr-3 pl-3',
                sidebarWrapper: 'w-2/12',
                rightSidebar: 'w-full',
                sidebarHeader: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
            }}
            header={
                <div className="flex flex-row flex-1 w-full items-center">
                    <div className="flex flex-col items-start max-w-full ml-20">
                        <Icon className="mr-4 text-30 cursor-pointer" onClick={onBackClick}>
                            arrow_back
                        </Icon>
                    </div>
                    {props?.match.params.typePage === 'new' ? (
                        <div className="flex flex-col max-w-full ml-20">
                            <h3>New biz rule</h3>
                        </div>
                    ) : (
                        <div className="flex flex-col max-w-full ml-20">
                            <h3>Edit biz rule</h3>
                        </div>
                    )}
                </div>
            }
            content={
                <BizRuleDefine
                    typePage={props?.match.params.typePage}
                    id={props?.location?.state?.currentField?.adm_co_doc_fld_id || comDocFldIdFromURL}
                    bizRuleId={props?.match.params.bizRuleId}
                    history={props?.history}
                    match={props?.match}
                    openSlideBar={() => setOpenSideBar(true)}
                    onClose={() => setOpenSideBar(false)}
                    showButtonPreview={openSideBar}
                />
            }
            {...openSideBar && {
                rightSidebarHeader: <div />,
                rightSidebarContent: <BizRuleSideBar onClose={() => setOpenSideBar(false)} />,
            }}
            innerScroll
        />
    );
};

export default withRouter(withReducer('BizRuleReducer', reducer)(MainBizRule));

import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TablePagination, Tooltip, Typography, TableRow } from '@material-ui/core';
import { FuseScrollbars } from '@fuse';
import { withRouter } from 'react-router-dom';
import _ from '@lodash';
import { useSelector, useDispatch } from 'react-redux';
import * as TableFnc from 'app/utils/tableFunctions';
import moment from 'moment';
import 'styles/scss/view-doc.scss';
import 'styles/scss/custom-table.scss';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import history from '@history';
import AppConstants from 'app/utils/appConstants';
import 'styles/scss/info-extracted.scss';
import { withStyles } from '@material-ui/core/styles';
import Button from 'app/components/Button';
import buttons from 'app/utils/constants/buttonConstants.json';
import { openDialog } from 'app/store/actions/fuse/dialog.actions';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import ViewTemplateTableHeader from './viewTemplateTableHeader';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import * as Actions from './store/actions/actions';


const IssueToolTip = withStyles(theme => ({
    tooltip: {
        backgroundColor: '#F2EFEA',
        color: '#f16464',
        maxWidth: 300,
        fontSize: theme.typography.pxToRem(13),
        border: '1px solid #dadde9',
        padding: '7px',
    },
}))(Tooltip);

const useStyles = makeStyles(theme => ({
    root: {
        margin: theme.spacing(2),
        textAlign: 'center',
    },
    paper: {
        position: 'absolute',
        backgroundColor: theme.palette.background.paper,
        border: '2px solid #000',
        boxShadow: theme.shadows[5],
        padding: theme.spacing(2),
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    boxIframe: {
        overflow: 'scroll',
        width: '80vh',
        height: '90vh',
    },
    styleBoxImg: {
        width: '100px',
        height: '130px',
        border: '1px solid #22292f',
        objectFit: 'contain',
        alignSelf: 'center',
    },
    buttonClass: {
        padding: '0px 15px 0px 15px',
        margin: '0px 8px 0px 8px',
        fontWeight: 'bold',
        fontSize: '25px',
        background: 'darkgray',
    },
    annotated: {
        color: '#339a33e6',
        background: '#ddf9d9',
    },
    notAnnotated: {
        color: '#ef835c',
        background: '#ecdcc6d6',
    },
    annotating: {
        color: '#039be5',
        background: '#c8d6ecb5',
    },
    iframeCustom: {
        width: '100%',
        height: '100%',
        marginTop: '-56px',
        transformOrigin: '0 0',
    },
    accountIcon: {
        color: 'gray',
        marginLeft: '5px',
        paddingTop: '5px',
        transform: 'translateY(20%)',
    },
}));

function ViewTemplateTable(props) {
    const classes = useStyles();
    const dispatch = useDispatch();
    const searchText = useSelector(({ template }) => template.searchText);
    const companies = useSelector(({ template }) => template.companyData);
    const [data, setData] = useState([]);
    const page = useSelector(({ template }) => template.page);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [order, setOrder] = useState({
        direction: 'asc',
        columnId: null,
    });
    const { userInfo } = props;
    const allTemplate = useSelector(({ template }) => template.allTemplate);
    const documentData = useSelector(({ template }) => template.documentData);
    const filterParams = useSelector(({ template }) => template.filterParams);
    const [imageClick, setImageClick] = React.useState(null);
    const [stateScale, setStateScale] = React.useState(1.1);
    const [open, setOpen] = React.useState(false);
    const [selected, setSelected] = useState(null);
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    function getModalStyle() {
        const top = 50;
        const left = 50;
        return {
            top: `${top}%`,
            left: `${left}%`,
            transform: `translate(-${top}%, -${left}%)`,
            textAlign: 'center',
        };
    }
    const [modalStyle] = React.useState(getModalStyle);
    function handleClick(row) {
        setImageClick(row);
        setOpen(true);
    }
    const handleClose = () => {
        setStateScale(1.1);
        setOpen(false);
    };
    useEffect(() => {
        if (allTemplate && documentData.length > 0 && companies.length > 0) {
            addCoDocStatus();
            setData(allTemplate);
        }
    }, [allTemplate, documentData, companies]);

    function addCoDocStatus() {
        Object.keys(allTemplate).forEach(key => {
            // Map company name
            if (allTemplate[key].dex_tmplt_doc && allTemplate[key].dex_tmplt_doc.length > 0) {
                const foundComData = companies.find(
                    element => element.coCd === allTemplate[key].dex_tmplt_doc[0].co_cd,
                );
                if (foundComData) allTemplate[key].dex_tmplt_doc[0].co_nm = foundComData.coNm;
                let docId = '';
                for (let index = allTemplate[key].dex_tmplt_doc.length - 1; index >= 0; index--) {
                    docId = `${docId}, ${allTemplate[key].dex_tmplt_doc[index].doc_id}`;
                }
                docId = docId.substring(1);
                allTemplate[key].doc_id = docId;
                allTemplate[key].search_data = `${allTemplate[key].tmplt_id} ${allTemplate[key].tp_val} ${docId}`;
                allTemplate[key].template_id_type = `${allTemplate[key].tmplt_id} - ${allTemplate[key].tp_val}`;
            }
            const foundDocName = documentData.find(element => element.doc_tp_id === allTemplate[key].doc_tp_id);
            if (foundDocName) allTemplate[key].doc_nm = foundDocName.doc_nm;
        });
    }

    useEffect(() => {
        if (searchText) {
            const filterTemplate =
                searchText.length > 0
                    ? _.filter(allTemplate, item => item.search_data.toLowerCase().includes(searchText.toLowerCase()))
                    : allTemplate;
            setData(filterTemplate);
        }
    }, [searchText]);

    function handleDoubleClick(row) {
        const url = `/extract/annotation/${row.tp_val}/${row.tmplt_id}`;
        setTimeout(() => {
            history.push({
                pathname: url,
                state: {
                    editOnly: true,
                },
            });
        }, 300);
    }

    const zoomIn = () => {
        setStateScale(stateScale + 0.1);
    };

    const zoomOut = () => {
        setStateScale(stateScale - 0.1);
    };

    const getStatusColor = status => {
        for (const element of AppConstants.TEMPLATE_STATUSES) {
            if (status === element.stsNm) return classes[element.stsClass];
        }
        return null;
    };

    function handleSelect(row) {
        setSelected([row.tmplt_id]);
    }


    const getIssueToolTip = colData => {
        return (
            <IssueToolTip
                title={
                    <React.Fragment>
                        <Typography color="primary" fontSize="13px">
                            User: {colData.sts_flsecondaryg === '1' ? colData.proc_usr_id : colData.upd_usr_id}
                        </Typography>
                    </React.Fragment>
                }
                enterDelay={300}
                placement="bottom-end"
            >
                <AccountCircleIcon className={classes.accountIcon} />
            </IssueToolTip>
        );
    };

    return (
        <div className="w-full flex flex-col border-2 p-1 mb-2 mt-2 mr-1 ml-1">
            <FuseScrollbars className="flex-grow overflow-x-auto">
                <Table stickyHeader size="small" className="w-full" aria-labelledby="tableTitle">
                    <ViewTemplateTableHeader
                        // numSelected={selected.length}
                        order={order}
                        onRequestSort={(event, property) =>
                            TableFnc.handleRequestSort(event, property, order, setOrder)
                        }
                        rowCount={data.length}
                        userInfo={props.userInfo}
                    />

                    <TableBody>
                        {_.orderBy(data, [o => o[order.columnId]], [order.direction])
                            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            .map(n => {
                                const isSelected = selected ? selected.includes(n.tmplt_id) : null;
                                return (
                                    <TableRow
                                        className="cursor-pointer"
                                        hover
                                        aria-checked={isSelected}
                                        tabIndex={-1}
                                        selected={isSelected}
                                        key={n.doc_id}
                                        onClick={() => handleSelect(n)}
                                        onDoubleClick={() => handleDoubleClick(n)}
                                    >
                                        {userInfo.usrId === 'admin' ? (
                                            <TableCell component="th" scope="row">
                                                <div className="textSubContainer">
                                                    {n.dex_tmplt_doc && n.dex_tmplt_doc.length > 0
                                                        ? n.dex_tmplt_doc[0].co_nm
                                                        : 'Unknown'}
                                                </div>
                                            </TableCell>
                                        ) : (
                                            <></>
                                        )}
                                        <TableCell component="th" scope="row">
                                            {n.doc_nm || n.doc_tp_id}
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            {n.template_id_type}
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            <div className="row-table" title={n.doc_id}>
                                                {n.doc_id || 'Unknown'}
                                            </div>
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            <p className={`custom-status ${getStatusColor(n.status)}`}>{n.status}</p>
                                            {getIssueToolTip(n)}
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            {`${moment(moment.utc(n.cre_dt).toDate()).format('YYYY-MM-DD HH:mm:ss')} `}
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            {`${moment(moment.utc(n.upd_dt).toDate()).format('YYYY-MM-DD HH:mm:ss')} `}
                                        </TableCell>
                                        <TableCell component="th" scope="row">
                                            <div onClick={() => handleClick(n)}>
                                                <img
                                                    src={`${process.env.REACT_APP_DOC_LOC}/${n.img_url}`}
                                                    className={classes.styleBoxImg}
                                                    alt=""
                                                />
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                        <div className={classes.root}>
                            <Modal open={open} onClose={handleClose}>
                                <div style={modalStyle} className={classes.paper}>
                                    <div className="container">
                                        <div className={classes.boxIframe}>
                                            <iFrame
                                                className={classes.iframeCustom}
                                                src={`/extract/annotation/${imageClick ? imageClick.tp_val : ''}/${
                                                    imageClick ? imageClick.tmplt_id : ''
                                                }?readonly=iframe`}
                                                style={{ transform: `scale(${stateScale})` }}
                                            />
                                        </div>
                                        <button className={classes.buttonClass} onClick={zoomIn}>
                                            +
                                        </button>
                                        <button className={classes.buttonClass} onClick={zoomOut}>
                                            -
                                        </button>
                                    </div>
                                </div>
                            </Modal>
                        </div>
                    </TableBody>
                </Table>
            </FuseScrollbars>
            <div className="w-full flex flex-row items-center">
                <div className="w-8/12 justify-start flex">
                    <TablePagination
                        component="div"
                        labelRowsPerPage=""
                        rowsPerPageOptions={[10, 25, 50]}
                        count={data.length}
                        rowsPerPage={rowsPerPage}
                        page={page}
                        backIconButtonProps={{
                            'aria-label': 'Previous Page',
                        }}
                        nextIconButtonProps={{
                            'aria-label': 'Next Page',
                        }}
                        onChangePage={(ev, page) => dispatch(Actions.setPage(page))}
                        onChangeRowsPerPage={ev =>
                            TableFnc.handleChangeRowsPerPage(
                                ev,
                                page,
                                data,
                                pageNumber => dispatch(Actions.setPage(pageNumber)),
                                setRowsPerPage,
                            )
                        }
                    />
                </div>
                <div className="w-4/12 justify-end flex">
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_DELETE) && (
                        <Button
                            onClick={() => {
                                if (selected) {
                                    dispatch(
                                        openDialog(`Do you want to delete this template?`, '', 'Confirm', async () => {
                                            dispatch(Actions.deleteTemplate(selected, userInfo, filterParams));
                                        }),
                                    );
                                } else {
                                    dispatch(
                                        showMessage({
                                            message: 'No row selected',
                                            variant: 'warning',
                                        }),
                                    );
                                }
                            }}
                            disabled={!selected}
                            className="whitespace-no-wrap px-13"
                        >
                            <span className="hidden sm:flex">Delete</span>
                        </Button>
                    )}
                </div>
            </div>
        </div>
    );
}

export default withRouter(ViewTemplateTable);

import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ThemeProvider } from '@material-ui/styles';
import { Paper, Input, Icon, FormControl } from '@material-ui/core';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { makeStyles } from '@material-ui/core/styles';
import buttons from 'app/utils/constants/buttonConstants.json';
import CustomButton from 'app/components/Button';
import TextField from 'app/components/SearchTextField';
import DateFnsUtils from '@date-io/date-fns';
import AppConstants from 'app/utils/appConstants';
import _ from '@lodash';

import * as Actions from './store/actions/actions';

const useStyles = makeStyles({
    searchBar: {
        width: '20ch',
        margin: 3,
    },
    searchInput: {
        width: '250px',
    },
});

const ViewTemplateHeader = props => {
    const classes = useStyles();
    const dispatch = useDispatch();

    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const mainTheme = useSelector(({ fuse }) => fuse.settings.mainTheme);
    const companies = useSelector(({ template }) => template.companyData);
    const allComDoc = useSelector(({ template }) => template.allComDoc);
    const searchText = useSelector(({ template }) => template.searchText);
    const filterParams = useSelector(({ template }) => template.filterParams);

    const renderCompany = () => {
        if (companies && Array.isArray(companies)) {
            const parseCompanies = companies.map(item => ({ co_cd: item.coCd, co_nm: item.coNm }));
            return [{ co_cd: 'All', co_nm: 'All' }, ...parseCompanies];
        }
        return [{ co_cd: 'All', co_nm: 'All' }];
    };

    const renderDocument = () => {
        if (allComDoc && Array.isArray(allComDoc)) {
            const parseDocument = allComDoc.flatMap(item => {
                const matchCompany =
                    !filterParams.coCd || filterParams.coCd === 'All' || filterParams.coCd === item.co_cd;
                return matchCompany ? { doc_tp_id: item.doc_tp_id, doc_nm: item.documents.doc_nm } : [];
            });
            return _.uniqBy([{ doc_tp_id: 'All', doc_nm: 'All' }, ...parseDocument], 'doc_tp_id');
        }
        return [{ doc_tp_id: 'All', doc_nm: 'All' }];
    };

    const handleSearch = () => {
        dispatch(Actions.setPage(0));
        dispatch(Actions.getTemplateData(filterParams));
    };

    useEffect(() => {
        dispatch(Actions.getCompanies());
        dispatch(Actions.setSearchText(''));
        dispatch(Actions.getInitCompanyDocuments());
        dispatch(Actions.getAllDocType());
    }, [dispatch]);

    useEffect(() => {
        if (
            props.userInfo &&
            (!filterParams.coCd || (props.userInfo.coCd !== filterParams.coCd && props.userInfo.usrId !== 'admin'))
        ) {
            const initialFilter = {
                coCd: props.userInfo.usrId === 'admin' ? 'All' : props.userInfo.coCd,
                docTpId: 'All',
                stsNm: 'All',
                fromDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toLocaleDateString('en-CA'),
                toDate: new Date().toLocaleDateString('en-CA'),
            };
            dispatch(Actions.getTemplateData(initialFilter));
            dispatch(Actions.setFilter(initialFilter));
        }
    }, [dispatch]);

    return (
        <div className="flex w-full items-center">
            <div className="flex-none px-15">
                <Autocomplete
                    className={classes.searchBar}
                    options={renderCompany()}
                    getOptionLabel={option => option.co_nm || ''}
                    size="small"
                    value={
                        renderCompany()?.find(item => item.co_cd === filterParams.coCd) || {
                            co_cd: 'All',
                            co_nm: 'All',
                        }
                    }
                    renderInput={params => (
                        <TextField {...params} label="Company Name" name="coCd" variant="outlined" />
                    )}
                    onChange={(e, value) =>
                        dispatch(
                            Actions.setFilter({
                                ...filterParams,
                                coCd: value?.co_cd ? value.co_cd : 'All',
                                docTpId: 'All',
                            }),
                        )
                    }
                    disabled={props.userInfo.usrId !== 'admin'}
                />
            </div>

            <div className="flex-none px-15">
                <Autocomplete
                    className={classes.searchBar}
                    options={renderDocument()}
                    getOptionLabel={option => option.doc_nm || ''}
                    size="small"
                    value={
                        renderDocument()?.find(item => item.doc_tp_id === filterParams.docTpId) || {
                            doc_tp_id: 'All',
                            doc_nm: 'All',
                        }
                    }
                    renderInput={params => (
                        <TextField {...params} label="Document Name" name="coCd" variant="outlined" />
                    )}
                    onChange={(e, value) =>
                        dispatch(
                            Actions.setFilter({ ...filterParams, docTpId: value?.doc_tp_id ? value.doc_tp_id : 'All' }),
                        )
                    }
                />
            </div>

            <div className="flex-none px-15">
                <Autocomplete
                    className={classes.searchBar}
                    options={[{ stsNm: 'All', stsClass: 'All' }, ...AppConstants.TEMPLATE_STATUSES]}
                    getOptionLabel={option => option.stsNm || ''}
                    size="small"
                    value={
                        [{ stsNm: 'All', stsClass: 'All' }, ...AppConstants.TEMPLATE_STATUSES].find(
                            item => item.stsNm === filterParams.stsNm,
                        ) || { stsNm: 'All', stsClass: 'All' }
                    }
                    renderInput={params => (
                        <TextField {...params} label="Template Status" name="stsNm" variant="outlined" />
                    )}
                    onChange={(e, value) =>
                        dispatch(Actions.setFilter({ ...filterParams, stsNm: value?.stsNm ? value.stsNm : 'All' }))
                    }
                />
            </div>

            <div className="flex-none px-15">
                <FormControl size="small" variant="outlined" className={`${classes.searchBar} ${classes.formControl}`}>
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <KeyboardDatePicker
                            disableToolbar
                            size="small"
                            label="From Date"
                            value={filterParams.fromDate}
                            onChange={val => dispatch(Actions.setFilter({ ...filterParams, fromDate: val }))}
                            format="dd/MM/yyyy"
                            variant="inline"
                            inputVariant="outlined"
                            KeyboardButtonProps={{
                                'aria-label': 'change date',
                            }}
                        />
                    </MuiPickersUtilsProvider>
                </FormControl>
                <FormControl size="small" variant="outlined" className={classes.searchBar}>
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <KeyboardDatePicker
                            disableToolbar
                            size="small"
                            label="To Date"
                            value={filterParams.toDate}
                            onChange={val => dispatch(Actions.setFilter({ ...filterParams, toDate: val }))}
                            format="dd/MM/yyyy"
                            variant="inline"
                            inputVariant="outlined"
                            KeyboardButtonProps={{
                                'aria-label': 'change date',
                            }}
                        />
                    </MuiPickersUtilsProvider>
                </FormControl>
            </div>

            <div className="flex-none px-15">
                {btnList.some(btn => btn.BTN_NO === buttons.BTN_SEARCH) && (
                    <CustomButton className="whitespace-no-wrap" color="default" onClick={handleSearch}>
                        Search
                    </CustomButton>
                )}
            </div>

            <div className="flex-none px-15">
                <ThemeProvider theme={mainTheme}>
                    <Paper className="flex items-center max-w-600 px-8 py-4 ml-2 rounded-8" elevation={1}>
                        <Icon className="mr-8" color="action">
                            search
                        </Icon>
                        <Input
                            placeholder="Search by Template ID, Document ID"
                            className={`flex flex-1 ${classes.searchInput}`}
                            disableUnderline
                            fullWidth
                            inputProps={{
                                'aria-label': 'Search',
                            }}
                            value={searchText}
                            onChange={ev => {
                                dispatch(Actions.setSearchText(ev.target.value));
                                dispatch(Actions.setPage(0));
                            }}
                        />
                    </Paper>
                </ThemeProvider>
            </div>
        </div>
    );
};

export default ViewTemplateHeader;

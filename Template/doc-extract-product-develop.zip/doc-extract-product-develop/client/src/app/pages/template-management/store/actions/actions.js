import { API_EP } from 'app/utils/commonAPI';
import EndPointAPI from 'app/utils/endPointAPI';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import { showError, checkResDataAPI } from 'app/utils/utils';
import MsgNotifications from 'app/utils/msgNotifications';
export const GET_DEX_DOC_COMPANIES = 'GET_DEX_DOC_COMPANIES';
export const SET_SEARCH_TEXT = 'SET_SEARCH_TEXT';
export const GET_LOCATION_DATA = 'GET_LOCATION_DATA';
export const GET_ALL_DOC_TYPE_SUCCESS = 'GET_ALL_DOC_TYPE_SUCCESS';
export const INIT_UPLOADED_DATA = 'INIT_UPLOADED_DATA';
export const GET_INIT_LOC_DATA = 'GET_INIT_LOC_DATA';
export const SET_PAGE = 'SET_PAGE_VIEW_DOC';
export const GET_INIT_TEMPLATE_DATA = 'GET_INIT_TEMPLATE_DATA';
export const GET_INIT_COMPANY_DOCUMENTS = 'GET_INIT_COMPANY_DOCUMENTS';
export const SET_FILTER_PARAM = 'SET_FILTER_PARAM';

// TODO: All company should be called by API_EP
export function getCompanies() {
    const request = API_EP.get(EndPointAPI.ENDPOINT.BP.ALL_COM);

    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    const listDataCompany = response.data.data.comList;
                    dispatch({
                        type: GET_DEX_DOC_COMPANIES,
                        companyData: listDataCompany,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
}

/**
 * The returned data contains corresponding document data
 */
export const getLocationData = () => {
    const url = API_EP.get(EndPointAPI.ENDPOINT.LOCATION.ALL_LOC);

    return dispatch =>
        url
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_LOCATION_DATA,
                        locationData: response.data,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
};

export function setSearchText(value) {
    return dispatch =>
        dispatch({
            type: SET_SEARCH_TEXT,
            searchText: value,
        });
}

export const getAllDocType = () => {
    const url = API_EP.get(EndPointAPI.ENDPOINT.DOC_SETTING.ALL_DOC_TP, {
        params: { allFlg: true },
    });

    return dispatch =>
        url
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_ALL_DOC_TYPE_SUCCESS,
                        payload: response.data.result,
                    });
                }
            })
            .catch(error => dispatch(showError(error)));
};

export function getInitLocData() {
    const request = API_EP.get(`/location-management/loc-data`);
    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_INIT_LOC_DATA,
                        payload: response.data ? response.data.result : [],
                    });
                }
            })
            .catch(err => dispatch(showError(err)));
}

export function setPage(value) {
    return dispatch =>
        dispatch({
            type: SET_PAGE,
            page: value,
        });
}

export function getTemplateData(data) {
    const request = API_EP.post(`/template/get-template`, data);
    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_INIT_TEMPLATE_DATA,
                        payload: response.data ? response.data : [],
                    });
                }
            })
            .catch(err => dispatch(showError(err)));
}

export function deleteTemplate(tmpltId, usrInfo, searchDate) {
    const data = { tmpltId: tmpltId[0], usrId: usrInfo.usrId };
    const request = API_EP.post(`/template/delete`, data);
    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch(
                        showMessage({
                            message: MsgNotifications.ANNOTATE.DELETE_TEMPLATE_SUCCESSFUL,
                            variant: 'success',
                        }),
                    );
                    const coCd = usrInfo.usrId === 'admin' ? 'All' : usrInfo.coCd;
                    dispatch(
                        getTemplateData({
                            coCd,
                            docTpId: 'All',
                            fromDate: searchDate.fromDate,
                            toDate: searchDate.toDate,
                        }),
                    );
                }
            })
            .catch(err => dispatch(showError(err)));
}

export function getInitCompanyDocuments() {
    const request = API_EP.get('/setup-com-doc/company-document/init-company-document');

    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_INIT_COMPANY_DOCUMENTS,
                        payload: response.data,
                    });
                }
            })
            .catch(err => dispatch(showError(err)));
}

export function setFilter(params) {
    return dispatch =>
        dispatch({
            type: SET_FILTER_PARAM,
            params,
        });
}

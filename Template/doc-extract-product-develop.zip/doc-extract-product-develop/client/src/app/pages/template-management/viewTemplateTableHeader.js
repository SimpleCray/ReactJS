import React from 'react';
import { TableHead, TableSortLabel, TableCell, TableRow, Tooltip } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import * as TableFnc from 'app/utils/tableFunctions';

const useStyles = makeStyles(theme => ({
    actionsButtonWrapper: {
        background: theme.palette.background.paper,
    },
    root: {
        width: '100%',
    },
    container: {
        maxHeight: 440,
    },
    cellHead: {
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.common.white,
    },
    button: {
        margin: theme.spacing(1),
    },
}));

function ViewTemplateTableHeader(props) {
    const rows = [
        {
            id: 'co_nm',
            align: 'left',
            disablePadding: false,
            label: 'Company name',
            sort: true,
        },
        {
            id: 'doc_tp_id',
            align: 'left',
            disablePadding: false,
            label: 'Document name',
            sort: true,
        },
        {
            id: 'tmplt_id',
            align: 'left',
            disablePadding: false,
            label: 'Template',
            sort: true,
        },
        {
            id: 'doc_id',
            align: 'left',
            disablePadding: false,
            label: 'Document ID',
            sort: true,
        },
        {
            id: 'sts',
            align: 'left',
            disablePadding: false,
            label: 'Status',
            sort: true,
        },
        {
            id: 'cre_dt',
            align: 'left',
            disablePadding: false,
            label: 'Create date',
            sort: true,
        },
        {
            id: 'upd_dt',
            align: 'left',
            disablePadding: false,
            label: 'Update date',
            sort: true,
        },
        {
            id: 'root_img',
            align: 'left',
            disablePadding: false,
            label: 'Image',
            sort: true,
        },
    ];

    const classes = useStyles();

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    const { userInfo } = props;

    // Hide column Company Name when login user
    if (userInfo.usrId !== 'admin') {
        TableFnc.hideColComName(rows);
    }

    return (
        <TableHead>
            <TableRow>
                {rows.map(row => (
                    <TableCell
                        key={row.id}
                        align={row.align}
                        padding={row.disablePadding ? 'none' : 'default'}
                        sortDirection={props.order.columnId === row.id ? props.order.direction : false}
                        className={classes.cellHead}
                    >
                        {row.sort && (
                            <Tooltip
                                title="Sort"
                                placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                enterDelay={300}
                            >
                                <TableSortLabel
                                    active={props.order.columnId === row.id}
                                    direction={props.order.direction}
                                    onClick={createSortHandler(row.id)}
                                >
                                    {row.label}
                                </TableSortLabel>
                            </Tooltip>
                        )}
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
}

export default ViewTemplateTableHeader;

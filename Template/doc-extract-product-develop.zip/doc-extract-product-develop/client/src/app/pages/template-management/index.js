import React, { useEffect, useRef } from 'react';
import { FusePageCarded } from '@fuse';
import withReducer from 'app/store/withReducer';
import reducer from './store/reducers/reducers';
import ViewTemplateHeader from './viewTemplateHeader';
import ViewTemplateTable from './viewTemplateTable';
import 'styles/scss/commons.scss';
import AppConstants from 'app/utils/appConstants';

export const Template = () => {
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));
    return (
        <FusePageCarded
            classes={{
                content: 'flex',
                header: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
                topBg: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
                contentWrapper: 'pr-3 pl-3',
            }}
            header={<ViewTemplateHeader userInfo={userInfo} />}
            content={<ViewTemplateTable userInfo={userInfo} />}
            innerScroll
        />
    );
};

export default withReducer('template', reducer)(Template);

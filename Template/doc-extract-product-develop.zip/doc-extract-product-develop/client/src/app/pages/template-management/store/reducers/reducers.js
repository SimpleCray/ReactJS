/* eslint-disable func-names */
import * as Actions from '../actions/actions';

const initialState = {
    companyData: [],
    locationData: [],
    documentData: [],
    allDocTypeByLoc: [],
    searchText: '',
    initLocData: [],
    page: 0,
    allTemplate: [],
    allComDoc: [],
    filterParams: {
        coCd: '',
        docTpId: 'All',
        stsNm: 'All',
        fromDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toLocaleDateString('en-CA'),
        toDate: new Date().toLocaleDateString('en-CA'),
    },
};

export default function viewDocReducer(state = initialState, action) {
    switch (action.type) {
        case Actions.GET_DEX_DOC_COMPANIES: {
            return {
                ...state,
                companyData: action.companyData,
            };
        }
        case Actions.GET_LOCATION_DATA: {
            return {
                ...state,
                allDocTypeByLoc: action.locationData,
            };
        }
        case Actions.SET_SEARCH_TEXT: {
            return {
                ...state,
                searchText: action.searchText,
            };
        }
        case Actions.GET_ALL_DOC_TYPE_SUCCESS: {
            return {
                ...state,
                documentData: action.payload,
            };
        }
        case Actions.GET_INIT_LOC_DATA: {
            return {
                ...state,
                initLocData: action.payload,
            };
        }
        case Actions.SET_PAGE: {
            return {
                ...state,
                page: action.page,
            };
        }
        case Actions.GET_INIT_TEMPLATE_DATA: {
            return {
                ...state,
                allTemplate: action.payload,
            };
        }
        case Actions.GET_INIT_COMPANY_DOCUMENTS: {
            return {
                ...state,
                allComDoc: action.payload,
            };
        }
        case Actions.SET_FILTER_PARAM: {
            return {
                ...state,
                filterParams: action.params,
            };
        }
        default: {
            return state;
        }
    }
}

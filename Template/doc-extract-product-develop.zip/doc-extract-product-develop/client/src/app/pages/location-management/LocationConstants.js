const locationTypes = [
    { name: 'CONTI', label: 'Continent' },
    { name: 'SCONTI', label: 'Sub Continent' },
    {
        name: 'CNT',
        label: 'Country',
    },
    {
        name: 'OFC',
        label: 'Office',
    },
];

export default locationTypes;

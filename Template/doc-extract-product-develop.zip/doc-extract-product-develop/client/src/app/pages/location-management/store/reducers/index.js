import { combineReducers } from 'redux';
import locations from './locations.reducer';

const reducer = combineReducers({
    locations,
});

export default reducer;

/* eslint-disable no-unused-expressions */
/* eslint-disable import/no-unresolved */
/* eslint-disable react/prop-types */
import React, { useEffect, useState } from 'react';
import { FusePageSimple } from '@fuse';
import { Icon, Typography, Tab, Tabs } from '@material-ui/core';
import { useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';

import withReducer from 'app/store/withReducer';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import reducer from './store/reducers';
import LocationBasicInfo from './LocationBasicInfo';
import LocationUploadMethods from './LocationUploadMethods';
import * as Actions from './store/actions';

function LocationDetail(props) {
    const dispatch = useDispatch();

    const [selectedTab, setSelectedTab] = useState(0);

    const handleTabChange = (event, tabId) => {
        if (tabId === 1 && props.match.params.typePage === 'new') {
            dispatch(
                showMessage({
                    message: 'Please create your basic information first!',
                    variant: 'warning',
                }),
            );
        } else setSelectedTab(tabId);
    };
    // Initial data for page location detail
    useEffect(() => {
        dispatch(Actions.getCompanyData());
        dispatch(Actions.getDocumentData());
        dispatch(Actions.getLocationTypeData());
        // get date when type page is edit
        props.match.params.typePage === 'edit' &&
            dispatch(
                Actions.getOneLocation(
                    typeof props.match.params.locationId === 'undefined'
                        ? { locationId: '' }
                        : { locationId: props.match.params.locationId },
                ),
            );

        props.match.params.typePage === 'edit' &&
            dispatch(
                Actions.getLocationUploadMedthod(
                    typeof props.match.params.locationId === 'undefined'
                        ? { locationId: '' }
                        : { locationId: props.match.params.locationId },
                ),
            );
    }, [dispatch]);

    function checkErrors(input, formData, setForm) {
        const index = formData.errors.indexOf(input);
        if (formData[input] == null || formData[input] === '' || formData[input] == undefined) {
            if (index === -1) {
                formData.errors.push(input);
            }
        } else if (index > -1) {
            formData.errors.splice(index);
        }
        setForm(form => ({
            ...form,
        }));
    }

    return (
        <FusePageSimple
            classes={{
                header: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
                toolbar: 'px-16 sm:px-24',
            }}
            header={
                <div className="flex flex-row flex-1 w-full items-center">
                    <div className="flex flex-col items-start max-w-full ml-20">
                        <Typography
                            className="normal-case flex items-center"
                            component={Link}
                            role="button"
                            to="/location-management"
                            color="inherit"
                        >
                            <Icon className="mr-4 text-30">arrow_back</Icon>
                        </Typography>
                    </div>
                    <div className="flex flex-col max-w-full ml-20">
                        <h3>Location Detail</h3>
                    </div>
                </div>
            }
            contentToolbar={
                <Tabs
                    value={selectedTab}
                    onChange={handleTabChange}
                    indicatorColor="primary"
                    textColor="primary"
                    variant="scrollable"
                    scrollButtons="off"
                    className="w-full h-54 border-b-1"
                >
                    <Tab className="h-54" label="Basic Information" />
                    <Tab className="h-54" label="Upload Methods" />
                </Tabs>
            }
            content={
                <div className="p-24">
                    {selectedTab === 0 && (
                        <LocationBasicInfo paramPage={props.match.params} manageErrors={checkErrors} />
                    )}
                    {selectedTab === 1 && (
                        <LocationUploadMethods paramPage={props.match.params} manageErrors={checkErrors} />
                    )}
                </div>
            }
        />
    );
}

export default withReducer('locationsMgmt', reducer)(LocationDetail);

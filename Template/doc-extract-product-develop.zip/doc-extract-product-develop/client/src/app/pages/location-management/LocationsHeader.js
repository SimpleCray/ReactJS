/* eslint-disable import/no-unresolved */
/* eslint-disable no-nested-ternary */
/* eslint-disable no-case-declarations */
/* eslint-disable indent */
import React, { useEffect, useState } from 'react';
import { FormControlLabel, Checkbox, TextField } from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { useDispatch, useSelector } from 'react-redux';
import Button from 'app/components/Button';
import buttons from 'app/utils/constants/buttonConstants.json';
import { useForm } from '@fuse/hooks';
import { makeStyles } from '@material-ui/core/styles';
import AppConstants from 'app/utils/appConstants';
import * as Actions from './store/actions';

const useStyles = makeStyles({
    searchBar: {
        width: '24ch',
        margin: 3,
    },
});

const defaultFormState = {
    coCd: '',
    loc: '',
    docTpId: '',
    deltFlg: false,
};

function LocationsHeader() {
    const classes = useStyles();
    const dispatch = useDispatch();
    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const companies = useSelector(({ locationsMgmt }) => locationsMgmt.locations.companyData);
    const documents = useSelector(({ locationsMgmt }) => locationsMgmt.locations.documentData);
    const locations = useSelector(({ locationsMgmt }) => locationsMgmt.locations.initLocData);
    const { form, handleChange, setForm } = useForm(defaultFormState);
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));
    const defaultValue = {
        company: { coCd: 'All', coNm: 'All' },
        location: 'All',
        documentType: { docTpId: 'All', docNm: 'All' },
    };
    const [dataSearch, setDataSearch] = useState({
        company: [defaultValue.company],
        location: [defaultValue.location],
        documentType: [defaultValue.documentType],
    });
    const [currentSelectedOption, setCurrentSelectedOption] = useState({
        company: defaultValue.company,
        location: defaultValue.location,
        documentType: defaultValue.documentType,
    });
    // Get data for header
    useEffect(() => {
        dispatch(Actions.getCompanyData());
        dispatch(Actions.getDocumentData());
        dispatch(Actions.getInitLocData());
    }, [dispatch]);

    function searchLocation() {
        dispatch(Actions.getLocations(form));
        dispatch(Actions.setSelectedRow(''));
        dispatch(Actions.setPage(0));
        setCurrentSelectedOption(prevSelectOption => ({
            ...prevSelectOption,
            company: prevSelectOption.company || dataSearch.company[0],
            location: prevSelectOption.location || dataSearch.location[0],
            documentType: prevSelectOption.documentType || dataSearch.documentType[0],
        }));
    }

    useEffect(() => {
        // Initial data options of search bar for admin
        if (userInfo.usrId === 'admin') {
            const dataCompany = setDataOptionCompany(form.deltFlg ? 'Y' : 'N');
            const { dataLocation, dataDocumentType } = setDataOptionLocationAndDocumentType(
                form.deltFlg ? 'Y' : 'N',
                defaultValue.company,
                defaultValue.location,
            );
            // set initial data and default selected value
            setChangeState(
                { companyInfo: dataCompany, locationInfo: dataLocation, documentTypeInfo: dataDocumentType },
                {
                    currentCompanyInfo: dataCompany[0],
                    currentLocationInfo: dataLocation[0],
                    currentDocumentTypeInfo: dataDocumentType[0],
                },
            );
            setForm(formData => ({
                ...formData,
                coCd: defaultValue.company.coCd,
                loc: defaultValue.location,
                docTpId: defaultValue.documentType.docTpId,
            }));
        } else {
            // Initial data options of search bar for user
            const companyUser = {
                coCd: userInfo.coCd,
                coNm: companies.length > 0 ? companies.find(com => com.coCd === userInfo.coCd).coNm : '',
            };
            const { dataLocation, dataDocumentType } = setDataOptionLocationAndDocumentType(
                form.deltFlg ? 'Y' : 'N',
                companyUser,
                defaultValue.location,
            );
            // set initial data and default selected value
            setChangeState(
                { companyInfo: [companyUser], locationInfo: dataLocation, documentTypeInfo: dataDocumentType },
                {
                    currentCompanyInfo: companyUser,
                    currentLocationInfo: dataLocation[0],
                    currentDocumentTypeInfo: dataDocumentType[0],
                },
            );
            setForm(formData => ({
                ...formData,
                coCd: companyUser.coCd,
                loc: defaultValue.location,
                docTpId: defaultValue.documentType.docTpId,
            }));
        }
    }, [locations, companies, documents, form.deltFlg]);

    function setDataOptionCompany(deltFlg) {
        const dataCompany =
            locations.length > 0
                ? companies
                      .filter(item =>
                          locations
                              .filter(loc => loc.delt_flg === deltFlg)
                              .map(loc => loc.co_cd)
                              .includes(item.coCd),
                      )
                      .map(com => ({ coCd: com.coCd, coNm: com.coNm }))
                : companies.map(com => ({ coCd: com.coCd, coNm: com.coNm }));
        dataCompany.unshift(defaultValue.company);
        return dataCompany;
    }

    function setDataOptionLocation(deltFlg, companyValue) {
        const locationBaseOnCompany =
            companyValue.coCd && companyValue.coCd !== 'All'
                ? locations.filter(loc => loc.co_cd === companyValue.coCd && loc.delt_flg === deltFlg)
                : locations.filter(loc => loc.delt_flg === deltFlg);

        const dataLocation = [...new Set(locationBaseOnCompany.map(item => item.loc_nm))];
        dataLocation.unshift(defaultValue.location);
        return { dataLocation, locationBaseOnCompany };
    }

    function setDataOptionLocationAndDocumentType(deltFlg, companyValue, locationValue) {
        const { dataLocation, locationBaseOnCompany } = setDataOptionLocation(deltFlg, companyValue);
        const documentTypeBaseOnLocation =
            locationBaseOnCompany.length > 0
                ? locationValue !== 'All'
                    ? documents.filter(
                          item =>
                              locationBaseOnCompany
                                  .filter(loc => loc.loc_nm === locationValue)
                                  .map(doc => doc.doc_tp_id)
                                  .includes(item.doc_tp_id) &&
                              (item.grp_flg === 'Y' || item.grp_doc_id === ''),
                      )
                    : documents.filter(
                          item =>
                              locationBaseOnCompany.map(doc => doc.doc_tp_id).includes(item.doc_tp_id) &&
                              (item.grp_flg === 'Y' || item.grp_doc_id === ''),
                      )
                : [];
        const dataDocumentType = documentTypeBaseOnLocation.map(type => ({
            docTpId: type.doc_tp_id,
            docNm: type.doc_nm,
        }));
        dataDocumentType.unshift(defaultValue.documentType);
        return { dataLocation, dataDocumentType };
    }

    function setChangeState(search, currentOption) {
        // set list data for search bar
        setDataSearch(prevDataSearch => ({
            ...prevDataSearch,
            company: search.companyInfo || prevDataSearch.company,
            location: search.locationInfo || prevDataSearch.location,
            documentType: search.documentTypeInfo || prevDataSearch.documentType,
        }));
        // set current selected option of search bar
        setCurrentSelectedOption(prevSelectOption => ({
            ...prevSelectOption,
            company: currentOption.currentCompanyInfo || prevSelectOption.company,
            location: currentOption.currentLocationInfo || prevSelectOption.location,
            documentType: currentOption.currentDocumentTypeInfo || prevSelectOption.documentType,
        }));
    }

    function handleChangeSearchBars(typeSearch, value) {
        switch (typeSearch) {
            case 'company':
                if (userInfo.usrId === 'admin') {
                    const { dataLocation, dataDocumentType } = setDataOptionLocationAndDocumentType(
                        form.deltFlg ? 'Y' : 'N',
                        value || {},
                        defaultValue.location,
                    );
                    setChangeState(
                        { locationInfo: dataLocation, documentTypeInfo: dataDocumentType },
                        {
                            currentCompanyInfo: value || dataSearch.company[0],
                            currentLocationInfo: dataLocation[0],
                            currentDocumentTypeInfo: dataDocumentType[0],
                        },
                    );
                    setForm(formData => ({
                        ...formData,
                        coCd: !value
                            ? defaultValue.company.coCd
                            : dataSearch.company.filter(item => item.coNm === value.coNm)[0].coCd,
                        loc: defaultValue.location,
                        docTpId: defaultValue.documentType.docTpId,
                    }));
                }
                break;
            case 'location':
                const { dataDocumentType } = setDataOptionLocationAndDocumentType(
                    form.deltFlg ? 'Y' : 'N',
                    userInfo.usrId === 'admin'
                        ? currentSelectedOption.company
                        : { coCd: userInfo.coCd, coNm: companies.find(com => com.coCd === userInfo.coCd).coNm },
                    value || defaultValue.location,
                );
                setChangeState(
                    { documentTypeInfo: dataDocumentType },
                    {
                        currentLocationInfo: value || defaultValue.location,
                        currentDocumentTypeInfo: dataDocumentType[0],
                    },
                );
                setForm(formData => ({
                    ...formData,
                    loc: !value ? defaultValue.location : dataSearch.location.filter(item => item === value)[0],
                    docTpId: defaultValue.documentType.docTpId,
                }));
                break;
            case 'documentType':
                setForm(formData => ({
                    ...formData,
                    docTpId: !value
                        ? defaultValue.documentType.docTpId
                        : dataSearch.documentType.filter(item => item.docNm === value.docNm)[0].docTpId,
                }));
                setCurrentSelectedOption({ ...currentSelectedOption, documentType: value });
                break;
            default:
                break;
        }
    }

    return (
        <div className="flex w-full items-center">
            <div className="flex-none px-15">
                <Autocomplete
                    className={classes.searchBar}
                    options={dataSearch.company}
                    getOptionLabel={option => option.coNm || ''}
                    size="small"
                    value={currentSelectedOption.company}
                    renderInput={params => (
                        <TextField {...params} label="Company Name" name="coCd" variant="outlined" />
                    )}
                    onChange={(event, value) => {
                        handleChangeSearchBars('company', value);
                    }}
                    disabled={userInfo.usrId !== 'admin'}
                />
            </div>

            <div className="flex-none px-15">
                <Autocomplete
                    className={classes.searchBar}
                    options={dataSearch.location}
                    getOptionLabel={option => option || ''}
                    size="small"
                    value={currentSelectedOption.location}
                    renderInput={params => (
                        <TextField {...params} label="Location Name" name="loc" variant="outlined" />
                    )}
                    onChange={(event, value) => {
                        handleChangeSearchBars('location', value);
                    }}
                />
            </div>

            <div className="flex-none px-15">
                <Autocomplete
                    className={classes.searchBar}
                    options={dataSearch.documentType}
                    getOptionLabel={option => option.docNm || ''}
                    size="small"
                    value={currentSelectedOption.documentType}
                    renderInput={params => (
                        <TextField {...params} label="Document Name" name="coCd" variant="outlined" />
                    )}
                    onChange={(event, value) => {
                        handleChangeSearchBars('documentType', value);
                    }}
                />
            </div>

            <div className="flex-none px-12">
                <FormControlLabel
                    control={
                        <Checkbox checked={form.deltFlg} onChange={handleChange} name="deltFlg" color="secondary" />
                    }
                    label="Deleted"
                />
            </div>

            <div className="flex-none">
                {btnList.some(btn => btn.BTN_NO === buttons.BTN_SEARCH) && (
                    <Button className="whitespace-no-wrap" color="default" onClick={searchLocation}>
                        <span className="hidden sm:flex">Search</span>
                    </Button>
                )}
            </div>
        </div>
    );
}

export default LocationsHeader;

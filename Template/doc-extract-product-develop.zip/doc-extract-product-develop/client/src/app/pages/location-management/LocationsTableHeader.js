import React from 'react';
import { TableHead, TableSortLabel, TableCell, TableRow, Tooltip } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import * as TableFnc from 'app/utils/tableFunctions';

const useStyles = makeStyles(theme => ({
    actionsButtonWrapper: {
        background: theme.palette.background.paper,
    },
}));

function LocationsTableHead(props) {
    const classes = useStyles(props);

    const rows = [
        {
            id: 'co_nm',
            align: 'left',
            disablePadding: false,
            label: 'Company Name',
            sort: true,
        },
        {
            id: 'loc_cd',
            align: 'left',
            disablePadding: false,
            label: 'Location Code',
            sort: true,
        },
        {
            id: 'loc_nm',
            align: 'left',
            disablePadding: false,
            label: 'Location Name',
            sort: true,
        },
        {
            id: 'loc_tp_cd',
            align: 'left',
            disablePadding: false,
            label: 'Location Type',
            sort: true,
        },
        {
            id: 'doc_tp_id',
            align: 'left',
            disablePadding: false,
            label: 'Document Type',
            sort: true,
        },
        {
            id: 'fol_loc_url',
            align: 'left',
            disablePadding: false,
            label: 'Folder Location',
            sort: true,
        },
    ];

    const { userInfo } = props;

    // Hide column Company Name when login user
    if (userInfo.usrId !== 'admin') {
        TableFnc.hideColComName(rows);
    }

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className="h-64">
                {rows.map(row => (
                    <TableCell
                        key={row.id}
                        align={row.align}
                        padding={row.disablePadding ? 'none' : 'default'}
                        sortDirection={props.order.id === row.id ? props.order.direction : false}
                    >
                        {row.sort && (
                            <Tooltip
                                title="Sort"
                                placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                enterDelay={300}
                            >
                                <TableSortLabel
                                    active={props.order.id === row.id}
                                    direction={props.order.direction}
                                    onClick={createSortHandler(row.id)}
                                >
                                    {row.label}
                                </TableSortLabel>
                            </Tooltip>
                        )}
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
}

export default LocationsTableHead;

import React from 'react';
import { FusePageCarded } from '@fuse';
import withReducer from 'app/store/withReducer';
import reducer from './store/reducers';
import LocationsHeader from './LocationsHeader';
import LocationsTable from './LocationsTable';

function Locations() {
    return (
        <FusePageCarded
            classes={{
                content: 'flex',
                header: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
                topBg: 'min-h-52 h-52 sm:h-52 sm:min-h-52',
                contentWrapper: 'pr-3 pl-3',
            }}
            header={<LocationsHeader />}
            content={<LocationsTable />}
            innerScroll
        />
    );
}

export default withReducer('locationsMgmt', reducer)(Locations);

/* eslint-disable func-names */
import * as Actions from '../actions';

const initialState = {
    companyData: [],
    documentData: [],
    data: [],
    locationData: {
        type: 'new',
        props: {
            open: false,
        },
        data: null,
        continents: {},
        subContinents: {},
        countries: {},
    },
    dataMethods: '',
    locationDetail: [],
    locationId: '',
    methodDetail: [],
    initLocData: [],
    page: 0,
    rowsPerPage: 10,
    selectedRow: '',
    ggdrivepath: '',
    currentUserId: '',
};

const locationsReducer = function(state = initialState, action) {
    switch (action.type) {
        case Actions.GET_COMPANIES: {
            return {
                ...state,
                companyData: action.payload,
            };
        }

        case Actions.GET_INIT_LOC_DATA: {
            return {
                ...state,
                initLocData: action.payload,
            };
        }

        case Actions.GET_DOC_DATA: {
            return {
                ...state,
                documentData: action.payload,
            };
        }

        case Actions.GET_LOCATION_TYPE_DATA: {
            return {
                ...state,
                locationData: {
                    ...state.locationData,
                    continents: action.contiList.com_dat_val,
                    subContinents: action.scontiList.com_dat_val,
                    countries: action.cntList.com_dat_val,
                },
            };
        }

        case Actions.GET_LOCATIONS: {
            return {
                ...state,
                data: action.payload,
            };
        }

        case Actions.OPEN_EDIT_LOCATION_PAGE: {
            return {
                ...state,
            };
        }
        case Actions.GET_ONE_LOCATION: {
            return {
                ...state,
                locationDetail: action.payload,
            };
        }
        case Actions.UPDATE_LOCATION_UPLOAD_METHOD: {
            return {
                ...state,
            };
        }
        case Actions.GET_LOCATION_UPLOAD_METHOD: {
            return {
                ...state,
                dataMethods: action.payload,
            };
        }
        case Actions.UPLOAD_DRIVE_KEY: {
            return {
                ...state,
            };
        }
        case Actions.SET_PAGE: {
            return {
                ...state,
                page: action.page,
            };
        }
        case Actions.SET_ROWS_PER_PAGE: {
            return {
                ...state,
                rowsPerPage: action.rowsPerPage,
            };
        }
        case Actions.SET_SELECTED_ROW: {
            return {
                ...state,
                selectedRow: action.rowId,
            };
        }
        case Actions.DOWNLOAD_FILE_GOOGLE_DRIVE: {
            return {
                ...state,
            };
        }
        case Actions.SET_USER_ID: {
            return {
                ...state,
                currentUserId: action.currentUserId,
            };
        }
        default: {
            return state;
        }
    }
};

export default locationsReducer;

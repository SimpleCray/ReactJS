/* eslint-disable no-unused-expressions */
/* eslint-disable indent */
/* eslint-disable no-unused-vars */
/* eslint-disable import/no-unresolved */
import { API_EP } from 'app/utils/commonAPI';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import HandleServerErrors from 'app/utils/handleServerErrors';
export const GET_LOCATION_UPLOAD_METHOD = '[LOCATIONS MANAGEMENT] GET_LOCATION_UPLOAD_METHOD';
export const UPDATE_LOCATION_UPLOAD_METHOD = '[LOCATIONS MANAGEMENT] UPDATE_LOCATION_UPLOAD_METHOD';
export const DELETE_LOCATION_UPLOAD_METHOD = '[LOCATIONS MANAGEMENT] DELETE_LOCATION_UPLOAD_METHOD';
export const UPLOAD_DRIVE_KEY = '[LOCATIONS MANAGEMENT] UPLOAD_DRIVE_KEY';
export const DOWNLOAD_FILE_GOOGLE_DRIVE = '[LOCATIONS MANAGEMENT] DOWNLOAD_FILE_GOOGLE_DRIVE';

export function uploadFileFromGDrive(param) {
    const request = API_EP.get('/location-management/upload-from-drive', { params: param });
    return dispatch =>
        request
            .then(response => {
                dispatch({
                    type: DOWNLOAD_FILE_GOOGLE_DRIVE,
                });
                dispatch(
                    showMessage({
                        message: response.data.message,
                        variant: 'success',
                    }),
                );
            })
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function getLocationUploadMedthod(param) {
    const request = API_EP.get('/location-management/upload-method/get', { params: param });
    return dispatch =>
        request
            .then(response =>
                dispatch({
                    type: GET_LOCATION_UPLOAD_METHOD,
                    payload: response.data.result,
                }),
            )
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function updateLocationUploadMedthod(params) {
    const request = API_EP.put('/location-management/upload-method/update', { params });
    return dispatch =>
        request
            .then(response => {
                Promise.all([
                    dispatch({
                        type: UPDATE_LOCATION_UPLOAD_METHOD,
                    }),
                    dispatch(
                        showMessage({
                            message: 'Location upload method updated !!',
                            variant: 'success',
                        }),
                    ),
                ]);
            })
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
}

export function uploadFileData(formData, config) {
    const request = API_EP.post('/location-management/upload-method/upload-file', formData, config);
    return dispatch => {
        request
            .then(response => {
                Promise.all([
                    dispatch({
                        type: UPLOAD_DRIVE_KEY,
                    }),
                    dispatch(
                        showMessage({
                            message: response.data.message,
                            variant: 'success',
                        }),
                    ),
                ]);
            })
            .catch(err => {
                dispatch(
                    showMessage({
                        message: HandleServerErrors.getServerErrorMessage(err),
                        variant: 'error',
                    }),
                );
            });
    };
}

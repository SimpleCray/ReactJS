/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-vars */
/* eslint-disable import/no-unresolved */
import { API_EP } from 'app/utils/commonAPI';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import { showError, checkResDataAPI } from 'app/utils/utils';
import EndPointAPI from 'app/utils/endPointAPI';
export const SET_ROWS_PER_PAGE = 'SET_ROWS_PER_PAGE_LOCATION';
export const SET_PAGE = 'SET_PAGE_LOCATION';
export const SET_SELECTED_ROW = 'SET_SELECTED_LOCATION';

export const GET_COMPANIES = '[LOCATIONS MANAGEMENT] GET COMPANIES';
export const GET_INIT_LOC_DATA = '[LOCATIONS MANAGEMENT] GET INIT LOC DATA';
export const GET_LOCATIONS = '[LOCATIONS MANAGEMENT] GET LOCATIONS';
export const GET_LOCATION_TYPE_DATA = '[LOCATIONS MANAGEMENT] GET LOCATION TYPE DATA';
export const GET_DOC_DATA = '[LOCATIONS MANAGEMENT] GET DOCUMENT DATA';
export const ADD_LOCATION = '[LOCATIONS MANAGEMENT] ADD LOCATION';
export const UPDATE_LOCATION = '[LOCATIONS MANAGEMENT] UPDATE LOCATION';
export const DELETE_LOCATION = '[LOCATIONS MANAGEMENT] DELETE LOCATION';
export const OPEN_EDIT_LOCATION_PAGE = '[LOCATIONS MANAGEMENT] OPEN_EDIT_LOCATION_PAGE';
export const OPEN_NEW_LOCATION_PAGE = '[LOCATIONS MANAGEMENT] OPEN_NEW_LOCATION_PAGE';
export const GET_ONE_LOCATION = '[LOCATIONS MANAGEMENT] GET_ONE_LOCATION';
export const SET_USER_ID = '[LOCATIONS MANAGEMENT] SET_USER_ID';

export function getInitLocData() {
    const request = API_EP.get(`/location-management/loc-data`);
    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_INIT_LOC_DATA,
                        payload: response.data ? response.data.result : [],
                    });
                }
            })
            .catch(err => dispatch(showError(err)));
}

export function getLocations(param) {
    const request = API_EP.get('/location-management/locations', { params: param });
    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_LOCATIONS,
                        payload: response.data.result,
                    });
                }
            })
            .catch(err => dispatch(showError(err)));
}

export function getDocumentData() {
    const request = API_EP.get(`/doc-setting`);
    return dispatch =>
        request.then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: GET_DOC_DATA,
                    payload: response.data.result,
                });
            }
        });
}

export function getLocationTypeData() {
    const request = API_EP.post('/common-data/common-data-by-code', {
        codeList: ['CNT_NM_CD', 'CONTI_NM_CD', 'SCONTI_NM_CD'],
    });
    return dispatch =>
        request.then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: GET_LOCATION_TYPE_DATA,
                    contiList: response.data.find(loc => loc.com_dat_cd === 'CONTI_NM_CD'),
                    scontiList: response.data.find(loc => loc.com_dat_cd === 'SCONTI_NM_CD'),
                    cntList: response.data.find(loc => loc.com_dat_cd === 'CNT_NM_CD'),
                });
            }
        });
}

export function getCompanyData() {
    const request = API_EP.get(EndPointAPI.ENDPOINT.BP.ALL_COM);
    return dispatch =>
        request.then(response => {
            if (checkResDataAPI(response)) {
                dispatch({
                    type: GET_COMPANIES,
                    payload: response.data.data.comList,
                });
            }
        });
}

export function addLocation(params) {
    const request = API_EP.post('/location-management/add', { params });
    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    Promise.all([
                        dispatch(setSelectedRow(response.data.newLocId)),
                        dispatch(
                            showMessage({
                                message: 'Add Location completed',
                                variant: 'success',
                            }),
                        ),
                    ]).then(() => {
                        dispatch(getLocations());
                        dispatch(getInitLocData());
                    });
                }
            })
            .catch(err => dispatch(showError(err)));
}
export function updateLocation(params, locationId) {
    const request = API_EP.put('/location-management/update', { params });
    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    Promise.all([
                        dispatch({
                            type: UPDATE_LOCATION,
                        }),
                        dispatch(
                            showMessage({
                                message: 'Location updated',
                                variant: 'success',
                            }),
                        ),
                    ]).then(() => {
                        dispatch(getLocations());
                        dispatch(getOneLocation({ locationId }));
                    });
                }
            })
            .catch(err => dispatch(showError(err)));
}

export function deleteLocation(params, userId) {
    if (params) {
        params.userId = userId;
        const request = API_EP.put('/location-management/delete', { params });
        return dispatch =>
            request
                .then(response => {
                    if (checkResDataAPI(response)) {
                        Promise.all([
                            dispatch({
                                type: DELETE_LOCATION,
                            }),
                            dispatch(
                                showMessage({
                                    message: 'Location Deleted',
                                    variant: 'success',
                                }),
                            ),
                        ]).then(() => {
                            dispatch(getLocations());
                            dispatch(getInitLocData());
                        });
                    }
                })
                .catch(err => dispatch(showError(err)));
    }
    return dispatch =>
        dispatch(
            showMessage({
                message: 'Please select location',
                variant: 'warning',
            }),
        );
}

export function openEditLocationPage(dataLocation) {
    if (dataLocation) {
        return {
            type: OPEN_EDIT_LOCATION_PAGE,
        };
    }
    return dispatch =>
        dispatch(
            showMessage({
                message: 'Please select an item on the table',
                variant: 'warning',
            }),
        );
}

export function getOneLocation(param) {
    const request = API_EP.get('/location-management/location', { params: param });
    return dispatch =>
        request
            .then(response => {
                if (checkResDataAPI(response)) {
                    dispatch({
                        type: GET_ONE_LOCATION,
                        payload: response.data.result,
                    });
                }
            })
            .catch(err => dispatch(showError(err)));
}

export function setPage(value) {
    return dispatch =>
        dispatch({
            type: SET_PAGE,
            page: value,
        });
}

export function setRowsPerPage(value) {
    return dispatch =>
        dispatch({
            type: SET_ROWS_PER_PAGE,
            rowsPerPage: value,
        });
}

export function setSelectedRow(locId) {
    return dispatch =>
        dispatch({
            type: SET_SELECTED_ROW,
            rowId: locId,
        });
}

export function setUserId(value) {
    return dispatch =>
        dispatch({
            type: SET_USER_ID,
            currentUserId: value,
        });
}

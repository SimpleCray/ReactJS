/* eslint-disable array-callback-return */
/* eslint-disable eqeqeq */
/* eslint-disable react/prop-types */
/* eslint-disable no-continue */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-param-reassign */
/* eslint-disable default-case */
/* eslint-disable no-shadow */
/* eslint-disable consistent-return */
/* eslint-disable no-unused-expressions */
/* eslint-disable import/no-unresolved */
import React, { useEffect, useCallback } from 'react';
import { makeStyles } from '@material-ui/styles';
import { MenuItem, TextField } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from '@fuse/hooks';
import Button from 'app/components/Button';
import { withRouter } from 'react-router-dom';
import buttons from 'app/utils/constants/buttonConstants.json';
import AppConstants from 'app/utils/appConstants';
import * as Actions from './store/actions';
import locationTypes from './LocationConstants';

const useStyles = makeStyles({
    styleTextField: {
        marginRight: 80,
    },
});

function LocationBasicInfo(props) {
    const classes = useStyles();
    const dispatch = useDispatch();

    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const locationData = useSelector(({ locationsMgmt }) => locationsMgmt.locations.locationData);
    const dataLocation = useSelector(({ locationsMgmt }) => locationsMgmt.locations.locationDetail);
    const documents = useSelector(({ locationsMgmt }) => locationsMgmt.locations.documentData);
    const companies = useSelector(({ locationsMgmt }) => locationsMgmt.locations.companyData);
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));
    const dataCompany = userInfo.usrId === 'admin' ? companies : companies.filter(item => userInfo.coCd === item.coCd);

    const defaultFormState = {
        loc_id: '',
        loc_cd: '',
        loc_nm: '',
        co_cd: userInfo.usrId === 'admin' ? '' : userInfo.coCd,
        contiCd: '',
        scontiCd: '',
        cntCd: '',
        ofcCd: '',
        doc_tp_id: '',
        fol_loc_url: '',
        loc_tp_cd: '',
        userId: userInfo.usrId,
        errors: [],
    };

    const { form, handleChange, setForm } = useForm(defaultFormState);
    const filterDocument = documents.filter(
        doc => (doc.grp_doc_id === '' && doc.grp_flg === 'N') || doc.grp_flg === 'Y',
    );

    const initPage = useCallback(() => {
        if (props.paramPage.typePage === 'new') {
            setForm({ ...defaultFormState, errors: [] });
        }

        if (props.paramPage.typePage === 'edit') {
            dataLocation && updateLocationCodeOnType(dataLocation);
            setForm({ ...defaultFormState, ...dataLocation, errors: [] });
        }
    }, [dataLocation, props, setForm]);

    useEffect(() => {
        initPage();
    }, [dataLocation, initPage]);

    useEffect(() => {
        /**
         * set folder url when input change
         */
        setFolderLocation();
    }, [form.co_cd, form.loc_tp_cd, form.contiCd, form.scontiCd, form.cntCd, form.ofcCd, form.doc_tp_id]);

    function displayLocationType(locationTypeData) {
        if (Object.keys(locationTypeData).length !== 0) {
            const listData = locationTypeData.data.map(locTp => {
                if (locTp.deleted === 'No') {
                    const { key } = locationTypeData.config;
                    const label = locationTypeData.config.value;
                    return (
                        <MenuItem
                            key={locTp[key]}
                            value={locTp[key]}
                            onClick={() => {
                                form.loc_nm = locTp[label];
                            }}
                        >
                            {locTp[label]}
                        </MenuItem>
                    );
                }
            });

            return listData;
        }
    }

    function setFolderLocation() {
        let locationCode;
        const selectedDocTp = filterDocument.find(doc => doc.doc_tp_id === form.doc_tp_id);
        const docTypeCd = selectedDocTp ? selectedDocTp.doc_cd : '';
        switch (form.loc_tp_cd) {
            case 'CONTI':
                locationCode = form.contiCd;
                break;
            case 'SCONTI':
                locationCode = form.scontiCd;
                break;
            case 'CNT':
                locationCode = form.cntCd;
                break;
            case 'OFC':
                locationCode = form.ofcCd;
                break;
            default:
                locationCode = '';
                break;
        }

        form.errors.splice(form.errors.indexOf('contiCd'));
        form.errors.splice(form.errors.indexOf('scontiCd'));
        form.errors.splice(form.errors.indexOf('cntCd'));
        form.errors.splice(form.errors.indexOf('ofcCd'));

        setForm(form => ({
            ...form,
            loc_cd: locationCode,
            fol_loc_url: `/${form.co_cd}/${locationCode}/${docTypeCd}`,
        }));
    }

    function updateLocationCodeOnType(location) {
        switch (location.loc_tp_cd) {
            case 'CONTI':
                location.contiCd = location.loc_cd;
                break;
            case 'SCONTI':
                location.scontiCd = location.loc_cd;
                break;
            case 'CNT':
                location.cntCd = location.loc_cd;
                break;
            case 'OFC':
                location.ofcCd = location.loc_cd;
                break;
            default:
                break;
        }
    }

    function validate() {
        let excludeInputs = ['loc_cd', 'loc_id', 'loc_nm', 'prnt_loc_id'];
        const locTpArr = ['contiCd', 'scontiCd', 'cntCd', 'ofcCd'];
        switch (form.loc_tp_cd) {
            case 'CONTI':
                locTpArr.splice(locTpArr.indexOf('contiCd'), 1);
                break;
            case 'SCONTI':
                locTpArr.splice(locTpArr.indexOf('scontiCd'), 1);
                break;
            case 'CNT':
                locTpArr.splice(locTpArr.indexOf('cntCd'), 1);
                break;
            case 'OFC':
                locTpArr.splice(locTpArr.indexOf('ofcCd'), 1);
                break;
            default:
                break;
        }
        excludeInputs = excludeInputs.concat(locTpArr);

        for (const item in form) {
            if (excludeInputs.includes(item)) continue;
            props.manageErrors(item, form, setForm);
        }
        if (form.errors.length > 0) {
            return false;
        }

        return true;
    }

    function handleSubmit(event) {
        event.preventDefault();
        if (validate()) {
            if (props.paramPage.typePage === 'new') {
                dispatch(Actions.addLocation(form));
                props.history.push('/location-management');
            } else {
                dispatch(Actions.updateLocation(form, props.paramPage.locationId));
            }
        }
    }

    return (
        <div>
            <div className="flex pt-5 pb-5">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="Company Name"
                    autoFocus
                    id="co_cd"
                    name="co_cd"
                    value={form.co_cd}
                    onChange={handleChange}
                    variant="outlined"
                    select
                    required
                    fullWidth
                    error={form.errors.includes('co_cd')}
                    helperText={form.errors.includes('co_cd') ? 'Please select company' : ''}
                    size="small"
                    disabled={userInfo.usrId !== 'admin'}
                >
                    {dataCompany.map(com => (
                        <MenuItem key={com.coCd} value={com.coCd}>
                            {com.coNm}
                        </MenuItem>
                    ))}
                </TextField>
            </div>

            <div className="flex pt-5 pb-5">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="Location Name"
                    id="loc_nm"
                    name="loc_nm"
                    value={form.loc_nm}
                    onChange={handleChange}
                    variant="outlined"
                    fullWidth
                    size="small"
                />
            </div>

            <div className="flex pt-5 pb-5">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="Location Type"
                    id="loc_tp_cd"
                    name="loc_tp_cd"
                    value={form.loc_tp_cd}
                    onChange={handleChange}
                    variant="outlined"
                    required
                    select
                    fullWidth
                    error={form.errors.includes('loc_tp_cd')}
                    helperText={form.errors.includes('loc_tp_cd') ? 'Please select location type' : ''}
                    size="small"
                >
                    {locationTypes.map(type => (
                        <MenuItem
                            key={type.name}
                            value={type.name}
                            onClick={() => {
                                form.loc_nm = '';
                                form.contiCd = '';
                                form.scontiCd = '';
                                form.cntCd = '';
                            }}
                        >
                            {type.label}
                        </MenuItem>
                    ))}
                </TextField>
            </div>
            {form.loc_tp_cd === 'CONTI' && (
                <div className="flex pt-5 pb-5">
                    <TextField
                        className={`${classes.styleTextField} flex flex-1`}
                        label="Continent"
                        id="contiCd"
                        name="contiCd"
                        value={form.contiCd}
                        onChange={handleChange}
                        variant="outlined"
                        select
                        fullWidth
                        required
                        error={form.errors.includes('contiCd')}
                        helperText={form.errors.includes('contiCd') ? 'Please select continent' : ''}
                        size="small"
                    >
                        {displayLocationType(locationData.continents)}
                    </TextField>
                </div>
            )}

            {form.loc_tp_cd === 'SCONTI' && (
                <div className="flex pt-5 pb-5">
                    <TextField
                        className={`${classes.styleTextField} flex flex-1`}
                        label="Sub Continent"
                        id="scontiCd"
                        name="scontiCd"
                        value={form.scontiCd}
                        onChange={handleChange}
                        variant="outlined"
                        select
                        fullWidth
                        required
                        error={form.errors.includes('scontiCd')}
                        helperText={form.errors.includes('scontiCd') ? 'Please select  sub continent' : ''}
                        size="small"
                    >
                        {displayLocationType(locationData.subContinents)}
                    </TextField>
                </div>
            )}

            {form.loc_tp_cd === 'CNT' && (
                <div className="flex pt-5 pb-5">
                    <TextField
                        className={`${classes.styleTextField} flex flex-1`}
                        label="Country/ Region"
                        id="cntCd"
                        name="cntCd"
                        value={form.cntCd}
                        onChange={handleChange}
                        variant="outlined"
                        select
                        fullWidth
                        required
                        error={form.errors.includes('cntCd')}
                        helperText={form.errors.includes('cntCd') ? 'Please select country' : ''}
                        size="small"
                    >
                        {displayLocationType(locationData.countries)}
                    </TextField>
                </div>
            )}

            {form.loc_tp_cd === 'OFC' && (
                <div className="flex pt-5 pb-5">
                    <TextField
                        className={`${classes.styleTextField} flex flex-1`}
                        label="Office"
                        id="ofcCd"
                        name="ofcCd"
                        value={form.ofcCd}
                        onChange={handleChange}
                        variant="outlined"
                        fullWidth
                        required
                        error={form.errors.includes('ofcCd')}
                        helperText={form.errors.includes('ofcCd') ? 'Office cannot be blank' : ''}
                        size="small"
                    />
                </div>
            )}

            <div className="flex pt-5 pb-5">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="Document Type"
                    id="doc_tp_id"
                    name="doc_tp_id"
                    value={form.doc_tp_id}
                    onChange={handleChange}
                    variant="outlined"
                    select
                    fullWidth
                    required
                    error={form.errors.includes('doc_tp_id')}
                    helperText={form.errors.includes('doc_tp_id') ? 'Please select document type' : ''}
                    size="small"
                    disabled={props.paramPage.typePage === 'edit'}
                >
                    {filterDocument.map(type => (
                        <MenuItem key={type.doc_tp_id} value={type.doc_tp_id}>
                            {type.doc_nm}
                        </MenuItem>
                    ))}
                </TextField>
            </div>

            <div className="flex pt-5 pb-5">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    id="fol_loc_url"
                    name="fol_loc_url"
                    label="Folder Location"
                    value={form.fol_loc_url}
                    variant="outlined"
                    disabled
                    fullWidth
                    size="small"
                />
            </div>

            <div className="justify-end flex-row float-right pr-72">
                {btnList.some(btn => btn.BTN_NO === buttons.BTN_SAVE) && (
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={handleSubmit}
                        type="submit"
                        // disabled={!canBeSubmitted()}
                    >
                        Save
                    </Button>
                )}
            </div>
        </div>
    );
}

export default withRouter(LocationBasicInfo);

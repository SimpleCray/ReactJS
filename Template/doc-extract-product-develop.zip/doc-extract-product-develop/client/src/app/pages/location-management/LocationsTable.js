/* eslint-disable no-param-reassign */
/* eslint-disable default-case */
/* eslint-disable no-shadow */
/* eslint-disable react/prop-types */
/* eslint-disable no-unused-expressions */
/* eslint-disable import/no-unresolved */
import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TablePagination, TableRow } from '@material-ui/core';
import { FuseScrollbars } from '@fuse';
import { withRouter } from 'react-router-dom';
import _ from '@lodash';
import { useDispatch, useSelector } from 'react-redux';
import Button from 'app/components/Button';
import * as TableFnc from 'app/utils/tableFunctions';
import { openDialog } from 'app/store/actions/fuse/dialog.actions';
import buttons from 'app/utils/constants/buttonConstants.json';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import AppConstants from 'app/utils/appConstants';
import LocationsTableHead from './LocationsTableHeader';
import * as Actions from './store/actions';
import locationTypes from './LocationConstants';

function LocationsTable(props) {
    const dispatch = useDispatch();

    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));

    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const locMgmt = useSelector(({ locationsMgmt }) => locationsMgmt.locations);

    const [selectedRowData, setSelectedRowData] = useState(null);
    const [data, setData] = useState([]);
    const [order, setOrder] = useState({
        direction: 'asc',
        columnId: null,
    });
    const [disableButtons, setDisableButton] = useState(false);
    useEffect(() => {
        dispatch(Actions.getLocations());
        dispatch(Actions.getLocationTypeData());
    }, [dispatch]);

    // Initial data for location table
    useEffect(() => {
        if (locMgmt.data.length > 0) {
            const listCurrentData =
                userInfo.usrId === 'admin'
                    ? locMgmt.data.filter(item => item.prnt_loc_id === '')
                    : locMgmt.data.filter(item => userInfo.coCd === item.co_cd && item.prnt_loc_id === '');
            setData(listCurrentData);
            // Set selected row with rows per page and pagination
            if (locMgmt.selectedRow.length > 0 && locMgmt.currentUserId === userInfo.usrId) {
                const orderList = _.orderBy(listCurrentData, [o => o[order.columnId]], [order.direction]);
                const currentRow = locMgmt.data.find(loc => loc.loc_id === locMgmt.selectedRow);
                const positionOfSelectedRow = orderList.findIndex(loc => loc.loc_id === locMgmt.selectedRow) + 1;
                if (currentRow && positionOfSelectedRow !== -1) {
                    updateLocationCodeOnType(currentRow);
                    setSelectedRowData(currentRow);
                    const { rowsPerPage } = locMgmt;
                    const totalPage = Math.max(1, Math.ceil(orderList.length / rowsPerPage));
                    for (let i = 0; i < totalPage; i += 1) {
                        if (
                            i * rowsPerPage + 1 <= positionOfSelectedRow &&
                            positionOfSelectedRow <= i * rowsPerPage + rowsPerPage
                        ) {
                            dispatch(Actions.setPage(i));
                            break;
                        }
                    }
                } else {
                    setSelectedRowData(null);
                }
            } else {
                dispatch(Actions.setUserId(userInfo.usrId));
                dispatch(Actions.setSelectedRow(''));
                dispatch(Actions.setPage(0));
            }
            setDisableButton(locMgmt.data.every(checkIsDeletedLocation));
        } else setData(locMgmt.data);
    }, [locMgmt.data, locMgmt.selectedRow, locMgmt.rowsPerPage, order]);

    function checkIsDeletedLocation(item) {
        return item.delt_flg === 'Y';
    }

    function handleClick(row) {
        dispatch(Actions.setSelectedRow(row.loc_id));
        updateLocationCodeOnType(row);
        setSelectedRowData(row);
    }

    function handleDoubleClick(row) {
        if (!disableButtons) {
            dispatch(Actions.openEditLocationPage(row));
            props.history.push(`/location-management/${row.loc_id}/edit`);
        }
    }

    function updateLocationCodeOnType(location) {
        switch (location.loc_tp_cd) {
            case 'CONTI':
                location.contiCd = location.loc_cd;
                break;
            case 'SCONTI':
                location.scontiCd = location.loc_cd;
                break;
            case 'CNT':
                location.cntCd = location.loc_cd;
                break;
            case 'OFC':
                location.ofcCd = location.loc_cd;
                break;
        }
    }

    return (
        <div className="w-full flex flex-col">
            <FuseScrollbars className="flex-grow overflow-x-auto">
                <Table stickyHeader size="small" className="min-w-xl" aria-labelledby="tableTitle">
                    <LocationsTableHead
                        order={order}
                        onRequestSort={(event, property) =>
                            TableFnc.handleRequestSort(event, property, order, setOrder)
                        }
                        userInfo={userInfo}
                    />

                    <TableBody>
                        {_.orderBy(data, [o => o[order.columnId]], [order.direction])
                            .slice(
                                locMgmt.page * locMgmt.rowsPerPage,
                                locMgmt.page * locMgmt.rowsPerPage + locMgmt.rowsPerPage,
                            )
                            .map(locData => {
                                const isSelected = locMgmt.selectedRow.includes(locData.loc_id);
                                return (
                                    <TableRow
                                        className="cursor-pointer"
                                        hover
                                        aria-checked={isSelected}
                                        tabIndex={-1}
                                        selected={isSelected}
                                        key={locData.loc_id}
                                        onClick={() => handleClick(locData)}
                                        onDoubleClick={() => {
                                            btnList.some(btn => btn.BTN_NO === buttons.BTN_SCREEN_DETAIL) &&
                                                handleDoubleClick(locData);
                                        }}
                                    >
                                        {userInfo.usrId === 'admin' ? (
                                            <TableCell component="th" scope="row">
                                                {locMgmt.companyData &&
                                                    locMgmt.companyData.map(com =>
                                                        com.coCd === locData.co_cd ? com.coNm : '',
                                                    )}
                                            </TableCell>
                                        ) : (
                                            <></>
                                        )}

                                        <TableCell component="th" scope="row">
                                            {locData.loc_cd}
                                        </TableCell>

                                        <TableCell component="th" scope="row">
                                            {locData.loc_nm}
                                        </TableCell>

                                        <TableCell component="th" scope="row">
                                            {locationTypes.map(type => {
                                                if (locData.loc_tp_cd === type.name) return type.label;
                                                return '';
                                            })}
                                        </TableCell>

                                        <TableCell component="th" scope="row">
                                            {locData.documents.doc_nm}
                                        </TableCell>

                                        <TableCell component="th" scope="row">
                                            {locData.fol_loc_url}
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                    </TableBody>
                </Table>
            </FuseScrollbars>
            <div className="w-full flex flex-row items-center">
                <div className="w-8/12 justify-start flex">
                    {data.length > 0 && (
                        <TablePagination
                            component="div"
                            labelRowsPerPage=""
                            rowsPerPageOptions={[10, 20, 50]}
                            count={data.length}
                            rowsPerPage={locMgmt.rowsPerPage}
                            page={locMgmt.page}
                            backIconButtonProps={{
                                'aria-label': 'Previous Page',
                            }}
                            nextIconButtonProps={{
                                'aria-label': 'Next Page',
                            }}
                            onChangePage={(event, page) => dispatch(Actions.setPage(page))}
                            onChangeRowsPerPage={event => {
                                TableFnc.handleChangeRowsPerPage(
                                    event,
                                    locMgmt.page,
                                    data,
                                    pageNumber => dispatch(Actions.setPage(pageNumber)),
                                    rowsPerPageNumber => dispatch(Actions.setRowsPerPage(rowsPerPageNumber)),
                                );
                            }}
                        />
                    )}
                </div>
                <div className="w-4/12 justify-end flex">
                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_NEW) && (
                        <Button
                            onClick={() => props.history.push('/location-management/new')}
                            className="whitespace-no-wrap px-13"
                            disabled={disableButtons}
                        >
                            <span className="hidden sm:flex">New</span>
                        </Button>
                    )}

                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_SCREEN_DETAIL) && (
                        <Button
                            onClick={() => {
                                dispatch(Actions.openEditLocationPage(selectedRowData));
                                selectedRowData &&
                                    props.history.push(`/location-management/${selectedRowData.loc_id}/edit`);
                            }}
                            disabled={disableButtons}
                            className="whitespace-no-wrap px-13"
                        >
                            <span className="hidden sm:flex">View Detail</span>
                        </Button>
                    )}

                    {btnList.some(btn => btn.BTN_NO === buttons.BTN_DELETE) && (
                        <Button
                            onClick={() => {
                                if (selectedRowData) {
                                    dispatch(
                                        openDialog('Do you want to delete this location?', '', 'Confirm', async () => {
                                            dispatch(Actions.deleteLocation(selectedRowData, userInfo.usrId));
                                            const newPage = Math.max(
                                                0,
                                                Math.ceil((data.length - 1) / locMgmt.rowsPerPage) - 1,
                                            );

                                            if (locMgmt.page > newPage) {
                                                dispatch(Actions.setSelectedRow(''));
                                                dispatch(Actions.setPage(newPage));
                                            }
                                        }),
                                    );
                                } else {
                                    dispatch(
                                        showMessage({
                                            message: 'Please select an item on the table',
                                            variant: 'warning',
                                        }),
                                    );
                                }
                            }}
                            disabled={disableButtons}
                            className="whitespace-no-wrap px-13"
                        >
                            <span className="hidden sm:flex">Delete</span>
                        </Button>
                    )}
                </div>
            </div>
        </div>
    );
}

export default withRouter(LocationsTable);

/* eslint-disable no-empty */
/* eslint-disable no-param-reassign */
/* eslint-disable react/prop-types */
/* eslint-disable no-continue */
/* eslint-disable eqeqeq */
/* eslint-disable no-shadow */
/* eslint-disable no-restricted-syntax */
/* eslint-disable import/no-unresolved */
import React, { useEffect, useState, useCallback, useRef } from 'react';
import { makeStyles } from '@material-ui/styles';
import { Checkbox, FormControlLabel, TextField, RadioGroup, FormControl, Radio } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from '@fuse/hooks';
import Button from 'app/components/Button';
import { showMessage } from 'app/store/actions/fuse/message.actions';
import buttons from 'app/utils/constants/buttonConstants.json';
import AppConstants from 'app/utils/appConstants';
import * as Actions from './store/actions';

const uploadOptions = {
    SERVICE_EMAIL: 'service_email',
    CLIENT_KEY: 'client_key',
};

const useStyles = makeStyles({
    styleTextFolderIDField: {
        width: '36%',
    },
    styleTextField: {
        marginRight: 80,
    },
    styleFileNameField: {
        marginRight: 10,
    },
});

function LocationUploadMethods(props) {
    const userInfo = JSON.parse(localStorage.getItem(AppConstants.BP_USER_INFO));
    const defaultFormState = {
        upld_mzd_id: '',
        eml_tit_val: '',
        host_ip: '',
        usr_id: '',
        usr_pwd: '',
        dir_path: '',
        loc_id: '',
        file_svr_path: '',
        file_gg_drive_path: '',
        userId: userInfo.usrId,
        errors: [],
        upload_option: '', // 1: service email option, 2: client key option
    };

    const { form, handleChange, setForm } = useForm(defaultFormState);
    const classes = useStyles();
    const dispatch = useDispatch();

    const btnList = useSelector(({ shared }) => shared.buttonAuth.btnList);
    const dataMethods = useSelector(({ locationsMgmt }) => locationsMgmt.locations.dataMethods);
    const dataLocation = useSelector(({ locationsMgmt }) => locationsMgmt.locations.locationDetail);

    const [isUseEmail, setIsUseEmail] = useState(false);
    const [isUseFTP, setIsUseFTP] = useState(false);
    const [isUseGoogleDrive, setIsUseGoogleDrive] = useState(false);

    const [uploadOption, setUploadOption] = useState(uploadOptions.SERVICE_EMAIL);

    const [fileData, setFileData] = useState(null);
    const [fileName, setFileName] = useState(null);
    const usedMethods = [];
    const inputFile = useRef(null);

    const [copySuccess, setCopySuccess] = useState(false);

    const initPageMethod = useCallback(() => {
        if (props.paramPage.typePage === 'edit') {
            if (dataMethods != '') {
                const listMethod = dataMethods.usd_mzd_cd.split('-');
                listMethod.forEach(method => {
                    if (method === 'E') setIsUseEmail(true);
                    if (method === 'F') setIsUseFTP(true);
                    if (method === 'G') {
                        setIsUseGoogleDrive(true);
                    }
                });
                setFileName(dataMethods.file_svr_path.split('/')[2]);
            }
            setForm({ ...defaultFormState, ...dataMethods, errors: [] });
        }
    }, [dataMethods, props, setForm]);

    useEffect(() => {
        setUploadOption(fileName ? uploadOptions.CLIENT_KEY : uploadOptions.SERVICE_EMAIL);
    }, [fileName]);

    useEffect(() => {
        initPageMethod();
    }, [dataMethods, initPageMethod]);

    useEffect(() => {
        dispatch(Actions.getLocationUploadMedthod({ locationId: props.paramPage.locationId }));
    }, []);

    function handleChangeUploadOption(event) {
        setUploadOption(event.target.value);
    }

    function handleChangeUseEmail() {
        setIsUseEmail(!isUseEmail);
    }

    function handleChangeUseFTP() {
        setIsUseFTP(!isUseFTP);
    }

    function handleChangeUseGoogleDrive() {
        setIsUseGoogleDrive(!isUseGoogleDrive);
    }

    function validate() {
        let testInputData = [];

        if (isUseEmail) testInputData = testInputData.concat(['eml_tit_val']);
        if (isUseFTP) testInputData = testInputData.concat(['host_ip', 'usr_id', 'usr_pwd', 'dir_path']);
        if (isUseGoogleDrive) testInputData = testInputData.concat(['file_gg_drive_path']);

        if (!isUseEmail && !isUseFTP && !isUseGoogleDrive) {
            dispatch(
                showMessage({
                    message: 'Please choose one method you want!',
                    variant: 'warning',
                }),
            );
            return false;
        }

        for (const item in form) {
            if (testInputData.includes(item)) props.manageErrors(item, form, setForm);
        }

        if (form.errors.length > 0) {
            return false;
        }

        if (isUseGoogleDrive && (!fileData && form.fileSvrPath === '') && uploadOption === uploadOptions.CLIENT_KEY) {
            dispatch(
                showMessage({
                    message: 'Please choose the .json file!',
                    variant: 'warning',
                }),
            );
            return false;
        }

        return true;
    }

    async function handleSubmit(event) {
        event.preventDefault();
        if (isUseEmail) usedMethods.push('E');
        if (isUseFTP) usedMethods.push('F');
        if (isUseGoogleDrive) usedMethods.push('G');
        if (props.paramPage.typePage === 'edit' && validate()) {
            form.loc_id = props.paramPage.locationId;
            form.usedMethods = usedMethods;
            await dispatch(Actions.updateLocationUploadMedthod(form));
            if (isUseGoogleDrive && uploadOption === uploadOptions.SERVICE_EMAIL) {
                setFileName(null);
                uploadFile();
            }
            if (isUseGoogleDrive && fileData) uploadFile();
        }
    }

    async function handleDownload(event) {
        event.preventDefault();
        const locId = props.paramPage.locationId;
        await dispatch(
            Actions.uploadFileFromGDrive({
                folderLocation: dataLocation.fol_loc_url.substring(1),
                locationId: locId,
            }),
        );
    }

    function copyClipboard() {
        const text = document.getElementById('service-email').innerText;
        const elem = document.createElement('textarea');
        document.body.appendChild(elem);
        elem.value = text;
        elem.select();
        document.execCommand('copy');
        document.body.removeChild(elem);

        setCopySuccess(true);
        setTimeout(() => {
            setCopySuccess(false);
        }, 2000);
    }

    function uploadFile() {
        const formData = new FormData();
        formData.append('myFile', uploadOption === uploadOptions.CLIENT_KEY ? fileData : null);
        formData.append('companyCode', userInfo.usrId === 'admin' ? dataLocation.co_cd : userInfo.coCd);
        formData.append('locationId', props.paramPage.locationId);
        formData.append('userId', userInfo.usrId);
        const config = {
            headers: {
                'content-type': 'multipart/form-data',
            },
        };
        dispatch(Actions.uploadFileData(formData, config));
    }

    function chooseFile(event) {
        event.preventDefault();
        inputFile.current.click();
    }

    return (
        <div>
            <div className="flex pb-5">
                <FormControlLabel
                    control={
                        <Checkbox
                            onChange={handleChangeUseEmail}
                            name="email_flg"
                            color="secondary"
                            checked={isUseEmail}
                        />
                    }
                    label="Email"
                />
            </div>
            <div className="flex pb-5">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="Email Title"
                    autoFocus
                    id="eml_tit_val"
                    name="eml_tit_val"
                    value={form.eml_tit_val}
                    onChange={handleChange}
                    variant="outlined"
                    fullWidth
                    disabled={!isUseEmail}
                    size="small"
                    error={form.errors.includes('eml_tit_val')}
                    helperText={form.errors.includes('eml_tit_val') ? 'Please enter email title' : ''}
                />
            </div>
            <div className="flex pb-5">
                <FormControlLabel
                    control={
                        <Checkbox onChange={handleChangeUseFTP} name="ftp_flg" color="secondary" checked={isUseFTP} />
                    }
                    label="FTP"
                />
            </div>
            <div className="flex pb-5">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="Host Ip"
                    autoFocus
                    id="host_ip"
                    name="host_ip"
                    value={form.host_ip}
                    onChange={handleChange}
                    variant="outlined"
                    fullWidth
                    disabled={!isUseFTP}
                    size="small"
                    error={form.errors.includes('host_ip')}
                    helperText={form.errors.includes('host_ip') ? 'Please enter host Ip' : ''}
                />
            </div>
            <div className="flex pb-5">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="User Id"
                    autoFocus
                    id="usr_id"
                    name="usr_id"
                    value={form.usr_id}
                    onChange={handleChange}
                    variant="outlined"
                    fullWidth
                    disabled={!isUseFTP}
                    size="small"
                    error={form.errors.includes('usr_id')}
                    helperText={form.errors.includes('usr_id') ? 'Please enter user id' : ''}
                />
            </div>
            <div className="flex pb-5">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="Password"
                    autoFocus
                    id="usr_pwd"
                    name="usr_pwd"
                    value={form.usr_pwd}
                    onChange={handleChange}
                    variant="outlined"
                    fullWidth
                    type="password"
                    disabled={!isUseFTP}
                    size="small"
                    error={form.errors.includes('usr_pwd')}
                    helperText={form.errors.includes('usr_pwd') ? 'Please enter password' : ''}
                />
            </div>
            <div className="flex pb-5">
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="Directory"
                    autoFocus
                    id="dir_path"
                    name="dir_path"
                    value={form.dir_path}
                    onChange={handleChange}
                    variant="outlined"
                    fullWidth
                    disabled={!isUseFTP}
                    size="small"
                    error={form.errors.includes('dir_path')}
                    helperText={form.errors.includes('dir_path') ? 'Please enter the directory' : ''}
                />
            </div>
            <div className="flex pb-5">
                <FormControlLabel
                    control={
                        <Checkbox
                            onChange={handleChangeUseGoogleDrive}
                            name="gg_drive_flg"
                            color="secondary"
                            checked={isUseGoogleDrive}
                        />
                    }
                    label="Google Drive"
                />
            </div>

            <div className="flex pb-5">
                <div className="justify-end flex-row float-right">
                    <FormControl className="ml-5" component="fieldset" disabled={!isUseGoogleDrive}>
                        <RadioGroup
                            aria-label="option"
                            name="upload_option"
                            value={uploadOption}
                            onChange={handleChangeUploadOption}
                            row
                        >
                            <FormControlLabel
                                value={uploadOptions.SERVICE_EMAIL}
                                control={<Radio />}
                                label="Service account: "
                            />
                        </RadioGroup>
                    </FormControl>
                </div>
                <div className="justify-end flex-row float-right" onClick={e => copyClipboard(e)}>
                    <p className="mt-5">
                        <b id="service-email">{process.env.REACT_APP_GOOGLE_SERVICE_EMAIL}</b>
                        {copySuccess ? (
                            <b id="service-email-copied" className="ml-5" style={{ color: 'green' }}>
                                Copied!
                            </b>
                        ) : null}
                    </p>
                </div>
            </div>

            <div className="flex pb-5">
                <FormControl className="ml-5" component="fieldset" disabled={!isUseGoogleDrive}>
                    <RadioGroup
                        aria-label="option"
                        name="upload_option"
                        value={uploadOption}
                        onChange={handleChangeUploadOption}
                        row
                    >
                        <FormControlLabel value={uploadOptions.CLIENT_KEY} control={<Radio />} label="Client key: " />
                    </RadioGroup>
                </FormControl>

                <div className="flex-none">
                    <TextField
                        className={`${classes.styleFileNameField} flex flex-1`}
                        label="File name"
                        autoFocus
                        id="fileName"
                        name="fileName"
                        value={(fileData != null ? fileData.name : fileName) || ''}
                        variant="outlined"
                        disabled
                        size="small"
                    />
                </div>

                <form encType="multipart/form-data">
                    <div>
                        <input
                            onChange={event => {
                                event.preventDefault();
                                setFileData(event.target.files[0]);
                            }}
                            ref={inputFile}
                            hidden
                            disabled={!isUseGoogleDrive}
                            accept=".json"
                            type="file"
                            name="myFile"
                            id="fileData"
                        />
                        {btnList.some(btn => btn.BTN_NO === buttons.BTN_SELECT_ITEM) && (
                            <Button
                                onClick={event => {
                                    chooseFile(event);
                                }}
                                variant="contained"
                                color="primary"
                                disabled={!isUseGoogleDrive || uploadOption === uploadOptions.SERVICE_EMAIL}
                            >
                                Choose File
                            </Button>
                        )}
                    </div>
                </form>
            </div>

            <div className={`${classes.styleTextFolderIDField} flex pb-5`}>
                <TextField
                    className={`${classes.styleTextField} flex flex-1`}
                    label="Google Drive folder ID"
                    autoFocus
                    id="file_gg_drive_path"
                    name="file_gg_drive_path"
                    value={form.file_gg_drive_path}
                    onChange={handleChange}
                    variant="outlined"
                    fullWidth
                    disabled={!isUseGoogleDrive}
                    size="small"
                    error={form.errors.includes('file_gg_drive_path')}
                    helperText={form.errors.includes('file_gg_drive_path') ? 'Please enter google drive path' : ''}
                />
            </div>

            <div className="justify-end flex-row float-right pr-72">
                {btnList.some(btn => btn.BTN_NO === buttons.BTN_SAVE) && (
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={handleSubmit}
                        type="submit" // disabled={!canBeSubmitted()}
                    >
                        Save
                    </Button>
                )}
            </div>
            <div className="justify-end flex-row float-right">
                {btnList.some(btn => btn.BTN_NO === buttons.BTN_SAVE) && (
                    <Button variant="contained" color="secondary" onClick={handleDownload} type="submit">
                        Download
                    </Button>
                )}
            </div>
        </div>
    );
}

export default LocationUploadMethods;

import axios from 'axios';
import http from 'http';
import AppConstants from './appConstants';
/**
 * Common API to call axios for each system
 * interceptors is used to update token dynamic
 * Ex usage:
 * import { API_EP } from 'app/utils/commonAPI'
 * API_EP.get(requestUrl).then().catch()
 * API_EP.post(requestUrl, data).then().catch()
 *
 */

export const API_BP = axios.create({
    baseURL: process.env.REACT_APP_BP,
    headers: {
        Authorization: localStorage.getItem(AppConstants.BP_TOKEN_NAME),
        Accept: 'application/json',
        'Content-Type': 'application/json',
    },
    timeout: 30000,
});

API_BP.interceptors.request.use(config => {
    const token = localStorage.getItem(AppConstants.BP_TOKEN_NAME);
    if (token != null) {
        config.headers.Authorization = token;
    }
    return config;
});

/**
 * Common Endpoint Axios API
 * Used to call to our Server
 */
export const API_EP = axios.create({
    baseURL: process.env.REACT_APP_END_POINT,
    headers: {
        Authorization: `Bearer ${localStorage.getItem(AppConstants.BP_TOKEN_NAME)}`,
        Accept: 'application/json',
        'Content-Type': 'application/json',
    },
    timeout: 180000, // 3 mins before timeout
});

API_EP.interceptors.request.use(config => {
    const token = localStorage.getItem(AppConstants.BP_TOKEN_NAME);
    if (token != null) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

export const API_TRANSLATE = axios.create({
    baseURL: 'https://translate.googleapis.com/translate_a',
    timeout: 10000,
});

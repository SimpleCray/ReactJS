import HandleServerErrors from 'app/utils/handleServerErrors';
import { showMessage } from '../store/actions/fuse';
import AppConstants from './appConstants';
import { API_EP } from './commonAPI';
import EndPointAPI from './endPointAPI';

export const logoutShine = () => {
    localStorage.clear();
    window.open(process.env.REACT_APP_BP, '_self');
};

/**
 * This is common dispatch to show FUSE error message
 * import and use as
 * dispatch(showError(errorMessage));
 */
export const showError = error => {
    console.error('Err: ', error);
    return showMessage({
        message: HandleServerErrors.getServerErrorMessage(error),
        variant: 'error',
    });
};

/**
 * This is common checking for axios API response
 * It will return true if response is OK
 * An error will be throwed if response is failed
 * @param {Request.response} response
 * @returns
 */
export const checkResDataAPI = response => {
    if (!response) throw new Error('Calling API failed!!!');
    if (response.status === 200 && (response.data || response.data.toString() === '0')) {
        return true;
    }
    const urlReq = response.config ? response.config.url : '';
    const msgReq = response.statusText || '';
    const errorMsg = `Calling API failed from URL: ${urlReq} with msg: ${msgReq}`;
    throw new Error(errorMsg);
};

export const formatDateTimeString = currentdate =>
    `${currentdate.getDate()}/${currentdate.getMonth() +
        1}/${currentdate.getFullYear()} @ ${currentdate.getHours()}:${currentdate.getMinutes()}:${currentdate.getSeconds()}`;

export const getTimingRangeMSec = (endTime, startTime) => {
    let timeInSec = Math.round((endTime - startTime) / 1000);
    const timeRange = {
        day: 0,
        hour: 0,
        minute: 0,
        sec: 0,
    };
    timeRange.day = Math.floor(timeInSec / (24 * 60 * 60));
    timeInSec -= timeRange.day * 24 * 60 * 60;
    timeRange.hour = Math.floor(timeInSec / (60 * 60));
    timeInSec -= timeRange.hour * 60 * 60;
    timeRange.minute = Math.floor(timeInSec / 60);
    timeInSec -= timeRange.minute * 60;
    timeRange.sec = timeInSec;
    return timeRange;
};

export const sumOfArray = array => {
    if (!array || array.length < 1) return 0;
    const totalVal = array.reduce((sum, currentVal) => parseFloat(sum) + parseFloat(currentVal));
    return totalVal;
};

export const removeIPandPort = url =>
    url
        .split('/')
        .slice(3, url.split('/').length)
        .join('/');

export const getUserId = () => localStorage.getItem(AppConstants.BP_USER_ID);

export const getCurrentTimeString = () => {
    const today = new Date();
    const date = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
    const time = `${today.getHours()}:${today.getMinutes()}:${today.getSeconds()}`;
    return `${date}-${time}`;
};

export const getTypeDocFile = fileUrl => {
    const fileExtension = fileUrl
        .split('.')
        .pop()
        .toLowerCase();
    return AppConstants.SUPPORT_DOC_FILE_IMG_EXTENSION.includes(fileExtension)
        ? AppConstants.DOC_FILE_TYPE.IMAGE
        : AppConstants.DOC_FILE_TYPE.PDF;
};

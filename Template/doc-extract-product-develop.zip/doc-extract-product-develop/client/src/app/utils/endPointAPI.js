const EndPointAPI = {
    CORE: {
        MATCHING: {
            SUBMIT: '/core-services/matching',
        },
        TEMPLATE: {
            SUBMIT: '/core-services/submit-template',
        },
        EXTRACTION: {
            SUBMIT: '/core-services/extract',
        },
        OCR_TEXT: {
            SUBMIT: '/core-services/ocr/text',
        },
    },
    ENDPOINT: {
        DOCUMENT: {
            UPLOAD: '/doc-setting/upload-file',
            SAVE_MULTI_DOC: '/doc-setting/save-extract-multi-doc',
        },
        TEMPLATE: {
            CREATE_NEW_TMP: '/template/create',
            SAVE: '/template/update',
            GET_TMP_DATA: '/template/get',
            GET_RULE_BY_TMPL: '/setup-special-rule/get-rule-by-template-id',
            UPDATE_STATUS: '/template/update-status',
            GENERATE_NEW_FORMAT: 'template/generate-new-format',
            GET_ALL_TMP_NOT_ANNOTATED: '/template/get-tmpl-not-annotated',
            UPDATE_TMP_AFTER_MATCHING: '/template/update-tmpl-data-matching',
            GET_TMP_VERSION: '/template/get-version',
            GET_FIELD_BY_COM_DOC: '/doc-field/get-field-by-doc-com',
        },
        DOC_DATA: {
            SAVE_EXTRACTED_DATA: '/doc-data/save-extraction-data',
            UPDATE_EXTRACTED_DATA: '/doc-data/update-extracted-data',
            LATEST_DOC_BY_TMPL: '/doc-data/latest-doc-by-tmpl-id',
            DOC_DATA_BY_DOC_NM: '/doc-data/get-by-doc-name',
            DEX_DOC: '/doc-data/get-dex-doc',
            ADD_DEX_DOC: '/doc-data/add-dex-doc',
            UPDATE_DOC_STATUS: '/doc-data/update-doc-status',
            UPDATE_TEMPLATE_ID_DOC: '/doc-data/update-tmpl-id-doc',
            UPDATE_ISSUE_STATUS_DOC: '/doc-data/update-issue-status',
        },
        DEX_GROUP: {
            CREATE: '/dex-grp/create',
            GET_ALL_GROUP: '/dex-grp/get-all',
        },
        BP: {
            ALL_COM: '/bp-api/get-all-com',
            GET_MENU: '/bp-api/get-menu',
            GET_BTN: '/bp-api/get-btn',
            GET_USER_INFO: '/bp-api/get-user-info',
            BP_LOGIN: '/authentication/bp-login',
            BP_LOGIN_DECRYPT: '/auth/login-bp',
        },
        LOCATION: {
            ALL_LOC: '/location-management/all-data',
        },
        DOC_SETTING: {
            UPLOAD_FILE: '/doc-setting/upload-file',
            ALL_DOC_TP: '/doc-setting/get-all-doc-tp',
            ALL_GRP_DEX_DOC: '/doc-setting/get-all-group-dex-doc',
            ALL_GRP: '/doc-setting/get-all-group',
        },
        BIZ: {
            GET_BIZ_DATA: '/biz-rule/run-biz-rule-by-doc',
            SAVE_BIZ: '/doc-data/update-biz-data',
        },
        TRANSACTION: {
            SAVE_TRANSACTION: '/transaction/save-transaction',
            GET_TRANSACTION_HISTORY: '/transaction/transaction-history',
        },
        EXTRACTION: {
            EXTRACT_DOC: '/extraction/extract-doc',
        },
        EXTRACT_RULE: {
            GET_EXTRACT_RULE_DATA: '/extr-rule/run-extr-rule-by-doc',
        },
    },
};

export default EndPointAPI;

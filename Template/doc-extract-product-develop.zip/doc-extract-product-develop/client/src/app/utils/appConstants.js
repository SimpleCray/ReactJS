const AppConstants = {
    BP_TOKEN_NAME: 'bp_token',
    BP_USER_ROLE_NM: 'usrRoleNm',
    BP_USER_INFO: 'userInfo',
    BP_USER_ID: 'userId_BP',
    BP_TOKEN_PATTERN: 'bptk',
    VIEW_DOC_URL: '/extract/view-doc',
    TEMPLATE_MANAGEMENT: '/extract/template-management',
    MINIMUM_KEY_VALUES_ANNOTATION: 5,
    SHINE_COUNTRY: 'TH',
    SCALE_STEP: 0.2,
    SCALE_DEFAULT: 1.2,
    SCALE_MAX: 3,
    SCALE_MIN: 0.2,

    // Color declaration
    VIEW_EXTR_COLOR: {
        GRAY: '#DCDCDC',
        DARK_YELLOW: '#FFFF00',
        LIGHT_YELLOW: '#FEFCC3',
        GREEN: '#AAD789',
        ORANGE: '#FF8C00',
    },
    MOVE_TYPE: {
        UP: 'move-up',
        DOWN: 'move-down',
    },
    INSERT_TYPE: {
        ABOVE: 'above',
        BELOW: 'below',
    },
    ANNOTATION_COLOR: {
        BOX_ACTIVE_BORDER: 'red',
        BOX_ACTIVE_BACKGROUND: 'rgba(255,250,0,0.5)',
        BOX_DISACTIVE_BORDER: 'rgb(0,191,255)',
        BOX_DISACTIVE_BACKGROUND: 'rgba(102,102,102,0.5)',
        NORMAL_BORDER_SHAPE: 'rgba(17, 32, 49, 0.65)',
        NORMAL_BACKGROUND_SHAPE: 'rgba(197,205,216,0.6)',
    },
    ALLOWED_ANNOTATION_TIME: 1800,
    TABLE_WITH_NO_NAME: 'UN-KNOWN',
    BOX_VIEW: {
        KEY: 'key',
        VALUE: 'value',
    },
    DEFAULT_SELECT_TYPE: {
        ALL: 'all',
        NONE: 'none',
    },
    FIELD_TABLE_TYPE: 'T',
    DOC_RESULT_TYPE: {
        NORMAL: 'normal',
        TABLE: 'table',
    },
    DOC_RESULT_ATT: {
        DATAPOS: 'datapos',
        DATATYPE: 'datatype',
        FIELD_ID: 'fieldid',
        TABLE_NAME: 'tablename',
    },
    KEYS_TYPE: [
        ['STATIC', 'Static'],
        ['DYNAMIC', 'Dynamic'],
        ['AUTO_GEN', 'Auto-Gen'],
        ['DYNAMIC_AUTO_GEN', 'Dynamic Auto-Gen'],
    ],
    INCLUDE_FILE_TYPES:
        '.pdf, .txt, .xls, .xlsx, .csv, .xlsm, .xlsb, .ods, .doc, .docx, .odt, .png, .jpg, .jpeg, .jfif, .pjpeg, .pjp',
    EXTRACTION_TYPE: {
        TICK: 'TICK',
        FIX_HEIGHT: 'FIX-HEIGHT',
        HEADER_FOOTER_REMOVAL: 'HEADER-FOOTER-REMOVAL',
        EMPTY: 'EMPTY',
        KEEP_IN_HEADER: 'KEEP-IN-HEADER',
    },
    DOC_STATUS: {
        A: 'Need annotation', // Doc have template, template is different with default template
        // Status A in case of matching return a template id, user is not submit extract
        E: 'Extracted', // After extraction done
        V: 'Verified', // After user verify the view extraction data
        F: 'Failed', // If matching failed
        N: 'Need annotation', // Doc dont have template, will call matching when open extraction data
        // Status N in case of matching return an empty template id
    },
    DOC_STATUS_CODE: {
        A: 'A',
        E: 'E',
        V: 'V',
        F: 'F',
        N: 'N',
    },
    TEMPLATE: {
        STATUS: {
            ANNOTATED: '3',
            NEW: '2',
            ANNOTATING: '1',
        },
        KEY_SEQ_DEFAULT: '[1.0]',
        GROUPID_DEFAULT: '2',
    },
    SUPPORT_DOC_FILE_IMG_EXTENSION: ['png', 'jpg', 'jpeg', 'bmp'],
    MOVE_FOCUS_BOX_TYPE: {
        PREV: 'prev',
        NEXT: 'next',
    },
    USER_ROLES: {
        MASTER_ADMIN: 'Master Admin',
        SHINE_ADMIN: 'SHINE ADMIN',
        SHINE_USER: 'SHINE USER',
    },
    TIMEOUT_LOADING: 180000, // Change time loading to 3mins
    DOC_ISSUES: {
        PE: 'Partial Extracted',
        BF: 'Biz Applied Failed',
        PB: 'Partial Biz Applied',
        MF: 'Find Matched Template Failed',
        EF: 'Extracted Failed',
        DB: 'Current Database Not Matched',
        SYS: 'System',
    },
    DOC_ISSUES_CODE: {
        PE: 'PE',
        BF: 'BF',
        PB: 'PB',
        MF: 'MF',
        EF: 'EF',
        DB: 'DB',
        SYS: 'SYS',
    },
    MENU_BP: {
        VIEW_DOC: '/extract/view-doc',
        VIEW_BIZ: '/biz-rule',
    },
    TEMPLATE_STATUSES: [
        { stsNm: 'Annotated', stsClass: 'annotated' },
        { stsNm: 'Not Annotate', stsClass: 'notAnnotated' },
        { stsNm: 'Annotating', stsClass: 'annotating' },
    ],
    TRANSACTION_STATUS: {
        ANNOTATE: 'ANNOTATE',
        RE_APPLY_BIZ: 'RE_APPLY_BIZ',
        VERIFY: 'VERIFY',
    },
    TRANSACTION_TYPE: {
        DOC: 'doc',
    },
    CORE_SYS_NM: {
        MAIN: 'main',
        LABEL: 'label',
    },
    DOC_FILE_TYPE: {
        IMAGE: 'img',
        PDF: 'pdf',
    },
};

export default AppConstants;

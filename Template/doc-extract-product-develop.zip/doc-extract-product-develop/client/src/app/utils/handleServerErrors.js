import ErrorCodes from 'app/utils/errorCodes.json';
import MsgNotifications from 'app/utils/msgNotifications';

const HandleServerErrors = {
    getServerErrorMessage: error => {
        if (typeof error === 'string' && ErrorCodes.serverErrorMessages[error])
            return ErrorCodes.serverErrorMessages[error];
        const { genericErrorMessage } = ErrorCodes.serverErrorMessages;
        if (!error || !error.response) return genericErrorMessage;

        const responseError = 
            error.response.data && error.response.data.error ? error.response.data.error : MsgNotifications.GENERAL;
        const errorCode = responseError.includes('{') ? JSON.parse(responseError.split(' ')[1])?.errorCode : '';
        const errorMessage = ErrorCodes.serverErrorMessages[errorCode] || responseError;

        if (errorMessage) {
            return errorMessage.replace('Error: ', '');
        }

        return genericErrorMessage;
    },
};

export default HandleServerErrors;

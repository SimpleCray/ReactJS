export function handleSelectBox(id, selected, setSelected) {
    const selectedIndex = selected.indexOf(id);
    let newSelected = [];

    if (selectedIndex === -1) {
        newSelected = newSelected.concat(selected, id);
    } else if (selectedIndex === 0) {
        newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
        newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
        newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
    }

    setSelected(newSelected);
}

export function handleRequestSort(event, columnId, order, setOrder) {
    let direction = 'desc';

    if (order.columnId === columnId && order.direction === 'desc') {
        direction = 'asc';
    }

    setOrder({
        direction,
        columnId,
    });
}

export function handleSelectAllClick(event, listSelectedItem, setSelected) {
    if (event.target.checked) {
        setSelected(listSelectedItem);
        return;
    }
    setSelected([]);
}

export function handleChangePage(event, page, setPage) {
    setPage(page);
}

export function handleChangeRowsPerPage(event, page, data, setPage, setRowsPerPage) {
    const currentRowsPerPage = event.target.value;
    const totalPage = Math.max(1, Math.ceil(data.length / currentRowsPerPage));
    if (page + 1 > totalPage) setPage(totalPage - 1);
    setRowsPerPage(currentRowsPerPage);
}

export function handleOrderType(item, columnId) {
    return isNaN(parseInt(item[columnId])) ? item[columnId]?.toUpperCase() : parseInt(item[columnId]);
}

export function hideColComName(rows) {
    let indexComName = -1;
    rows.findIndex((element, index) => {
        if (element.id === 'co_nm') {
            indexComName = index;
        }
    });
    if (indexComName !== -1) rows.splice(indexComName, 1);
}

export function parseAndFixedFloatNumber(value, number, multiplier) {
    return multiplier
        ? parseFloat(parseFloat(value * multiplier).toFixed(number))
        : parseFloat(parseFloat(value).toFixed(number));
}

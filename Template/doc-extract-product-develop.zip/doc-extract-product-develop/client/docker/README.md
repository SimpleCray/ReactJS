# Version list

```
node: 12.13.1
yarn: 1.22.5
npm: 6.12.1
```

# Docker build command

```
cd {WORK_DIR_OF_DOCKER_FILE}
docker build . -t <docker_image_name>:<tag>

- Ex: docker build . -t shinev2_client

```

NOTE: Build shinev2_client image first, then build other ENV

# Docker run command

```
docker run -d -p 3000:3000 -v /home/ubuntu/doc-extract-product/client:/home/ubuntu/doc-extract-product/client -v /home/ubuntu/doc-extract-product/client/docker/config:/home/ubuntu/cmd --restart=unless-stopped --name doc-client shinev2_client

```

# Docker exec

```
docker exec -it doc-client bash
```

# Docker restart manually command

## Using when updated the "/home/ubuntu/doc-extract-product/client/docker/config/entrypoint.sh" file

```
docker restart doc-client
```

# Check Docker Logs

```
docker logs -f doc-client
```

# Check Docker images

```
docker images

- We're using this docker image "shinev2_client" for client source
```

# You can change the instance name "react" to whatever you want

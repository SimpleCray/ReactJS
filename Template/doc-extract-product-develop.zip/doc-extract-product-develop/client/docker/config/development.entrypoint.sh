#!/bin/bash
cd /home/ubuntu/doc-extract-product/client && yarn install && yarn start && tail -f /dev/null

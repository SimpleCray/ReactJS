#!/bin/bash
cd /home/ubuntu/doc-extract-product/client && yarn install && yarn run start:factory && tail -f /dev/null

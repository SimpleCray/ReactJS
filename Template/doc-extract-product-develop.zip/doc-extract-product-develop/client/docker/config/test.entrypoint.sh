#!/bin/bash
cd /home/ubuntu/doc-extract-product/client && yarn install && yarn run start:test && tail -f /dev/null

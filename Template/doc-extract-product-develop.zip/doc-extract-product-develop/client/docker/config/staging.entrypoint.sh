#!/bin/bash
cd /home/ubuntu/doc-extract-product/client && yarn install && yarn run start:staging && tail -f /dev/null

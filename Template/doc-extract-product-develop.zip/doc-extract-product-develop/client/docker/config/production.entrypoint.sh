#!/bin/bash
cd /home/ubuntu/doc-extract-product/client && yarn install && yarn run build && serve -s build -p 5000

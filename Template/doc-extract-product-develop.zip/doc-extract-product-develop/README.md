# SHINE V2 PRODUCT RUNNING

# FOR DEVELOPMENT
- Each client/server need to run seperately
- Install VS Code Extensions: ESLint & Prettier ESLint to format your codes
- Install npm, node v12 (strick), yarn
- In server, create an .env file base on other .env at server dir -> Run server by: yarn install & yarn start
    Server will start at {YOUR_IP}:7005
- In client, check .env.development to config client -> Run client by: yarn install & yarn start
    Client will start at {YOUR_IP}:3000 automatically

# FOR DEPLOYMENT

## Requirements:
- Install docker & docker-compose
- Run Blueprint application as a linux service (Read more at Saas dev note)

## Current env:
- Development: Purpose for dev test
    + Branch: demo-shine
    + Current server: 10.0.26.200
    + DB: shinev2_development: 5551
- Factory: Purpose for factory team to optimize core
    + Branch: develop
    + Current server: Label are implementing
    + DB: shinev2_factory: 5552
- Test: Purpose for tester/ local test
    + Branch: develop
    + Current server: 10.0.26.200
    + DB: shinev2_test: 5553
- Staging: Purpose to release to customer
    + Branch: staging
    + Current server: 10.0.26.100
    + DB: shinev2_staging: 5554
- Production: 
    - TBD
    - TBD
    + DB: shinev2_production: 5555

## Deploy guides:
# Config env
- At project dir -> Check and modify your ENV and database information if needed as bellow:
    + Main work dir: .env.{YOUR_NEEDED_DEPLOYMENT_ENV} for ex: .env.test. We will check these env: CLIENT_PORT, SERVER_PORT, CDN_PORT, POSTGRES_PORT and some other DB configurations
    + Client: .env.{YOUR_NEEDED_DEPLOYMENT_ENV} for ex: .env.test. We will check these env: REACT_APP_BP, REACT_APP_END_POINT, REACT_APP_DOC_LOC
    + Server: .env.{YOUR_NEEDED_DEPLOYMENT_ENV} for ex: .env.test. We will check these env: BP_URL, REACT_APP_DOC_LOC, MAIN_CORE, LABEL_CORE, CLIENT_URL
    + Server Database: Modify database information foreach ENV in `server/services/shared/config/config.json`
- Please check the deploy host IP and port foreach service carefully
# Create docker image
- Build all needed docker images by running script create-images.sh: `./create-images.sh`
# Run services
- Run script shine-services.sh to run Client & Server base on ENV by: ./shine-services.sh {ACTION} {ENV_NAME}

## Notes:
- Client and Server: For local APIs/ UI
- Not include others, ex: Blueprint, Core
- System need to authentication/authorization by Blueprint, process documents by Core. Specific these env in corresponding client/server
- System is auto detect code changes after pull new sources, you don't need to restart, just restart if change ENV vars
- Setting for nodemon (SERVER) checking big files (Used when server running with error max watched files):
`sudo sysctl fs.inotify.max_user_watches=582222 && sudo sysctl -p`

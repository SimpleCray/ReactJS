#!/bin/bash
PORT=8804
env FLASK_APP=main.py python -m flask run -p $PORT -h 0.0.0.0
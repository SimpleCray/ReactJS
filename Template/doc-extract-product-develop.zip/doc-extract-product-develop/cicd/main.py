from flask import Flask, request
from subprocess import call
from config import DevConfig


app = Flask(
    __name__,
    static_url_path="/static",
    static_folder="/mnt/2Tdata/data/shinev2-prod/download",
    template_folder="",
)
app.config.from_object(DevConfig)


@app.route("/")
def home():
    return "<h1>Shinev2 Product Project Pipeline</h1>"

@app.route("/exec/pipeline/development", methods=["POST", "GET"])
def exec_pipeline_development():
    print(">>>> On running pipeline for development env")
    ci_commit = request.args.get("ci_commit")
    system_env = request.args.get("sys")
    if ci_commit and system_env:
        print(">>>> AT COMMIT:", ci_commit)
        print(">>>> FOR SERVICE:", system_env)
        call(f"./cd-development.sh {ci_commit} {system_env}", shell=True)
        return "Deploy development completed !"
    return "Ignore Deployment"

@app.route("/exec/pipeline/factory", methods=["POST", "GET"])
def exec_pipeline_factory():
    print(">>>> On running pipeline for factory env")
    ci_commit = request.args.get("ci_commit")
    system_env = request.args.get("sys")
    if ci_commit and system_env:
        print(">>>> AT COMMIT:", ci_commit)
        print(">>>> FOR SERVICE:", system_env)
        call(f"./cd-factory.sh {ci_commit} {system_env}", shell=True)
        return "Deploy factory completed !"
    return "Ignore Deployment"

@app.route("/exec/pipeline/testing", methods=["POST", "GET"])
def exec_pipeline_testing():
    print(">>>> On running pipeline for test env")
    ci_commit = request.args.get("ci_commit")
    system_env = request.args.get("sys")
    if ci_commit and system_env:
        print(">>>> AT COMMIT:", ci_commit)
        print(">>>> FOR SERVICE:", system_env)
        call(f"./cd-test.sh {ci_commit} {system_env}", shell=True)
        return "Deploy test completed !"
    return "Ignore Deployment"


@app.route("/exec/pipeline/staging", methods=["POST", "GET"])
def exec_pipeline_staging():
    print(">>>> On running pipeline for staging env")
    ci_commit = request.args.get("ci_commit")
    system_env = request.args.get("sys")
    if ci_commit and system_env:
        print(">>>> AT COMMIT:", ci_commit)
        print(">>>> FOR SERVICE:", system_env)
        call(f"./cd-staging.sh {ci_commit} {system_env}", shell=True)
        return "Deploy staging completed !"
    return "Ignore Deployment"


@app.route("/exec/pipeline/production", methods=["POST"])
def exec_pipeline_production():
    print(">>>> On running pipeline for production env")
    ci_commit = request.args.get("ci_commit")
    system_env = request.args.get("sys")
    if ci_commit and system_env:
        print(">>>> AT COMMIT:", ci_commit)
        print(">>>> FOR SERVICE:", system_env)
        call(f"./cd-production.sh {ci_commit} {system_env}", shell=True)
        return "Deploy production completed !"
    return "Ignore Deployment"


if __name__ == "__main__":
    app.run()


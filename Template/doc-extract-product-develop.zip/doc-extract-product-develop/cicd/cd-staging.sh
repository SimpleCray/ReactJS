#!/bin/bash
set -e

LOG_FILE=/home/ubuntu/data/cicd/pipeline/logs.log
exec 3>&1 1>>${LOG_FILE} 2>&1

COMMIT_ID=$1
SYS=$2

echo "Deploy task at: $(date)"
echo "CI_COMMIT_SHORT_HASH = $COMMIT_ID for system $SYS"

if [ "$SYS" = "product" ]
  then
    # Deploy product
    ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa ubuntu@10.0.26.100 'bash -s' < scripts/staging.sh $COMMIT_ID
elif [ "$SYS" = "core" ]
  then
    # Deploy core
    ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa ubuntu@10.0.26.100 'bash -s' < scripts/core-staging.sh $COMMIT_ID
fi

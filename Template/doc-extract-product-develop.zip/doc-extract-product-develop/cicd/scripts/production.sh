#!/bin/bash
set -e

LOG_FILE=/home/ubuntu/data/pipeline/production_logs.log
exec 3>&1 1>>${LOG_FILE} 2>&1

echo "Deploy task at: $(date)"
echo "CI_COMMIT_SHORT_HASH = $COMMIT_ID"

PATH_SOURCE=/home/ubuntu/deployment/shinev2_product/production/doc-extract-product
cd $PATH_SOURCE
echo " [*] >>>>>>>>>>> Git pull from target branch"
git checkout .
git fetch
git checkout master
git pull
echo " [*] >>>>>>>>>>> Restart target env"
./shine-services.sh start production
./shine-services.sh restart production
echo " [*] >>>>>>>>>>> Restart target env successful"
#!/bin/bash
set -e

LOG_FILE=/home/ubuntu/data/pipeline/core_test_logs.log
exec 3>&1 1>>${LOG_FILE} 2>&1

COMMIT_ID=$1

echo "Deploy task at: $(date)"
echo "CI_COMMIT_SHORT_HASH = $COMMIT_ID"

PATH_SOURCE=/home/ubuntu/deployment/shinev2_core/test/doc-extract-rd
cd $PATH_SOURCE
echo " [*] >>>>>>>>>>> Git pull from target branch"
git checkout .
git fetch
git checkout test
git pull
echo " [*] >>>>>>>>>>> Restart target env"
./shine-service.sh up test
./shine-service.sh restart test
echo " [*] >>>>>>>>>>> Restart target env successful"
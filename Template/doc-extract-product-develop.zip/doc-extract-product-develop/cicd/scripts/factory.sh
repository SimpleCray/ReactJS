#!/bin/bash
set -e

LOG_FILE=/home/ubuntu/data/pipeline/log/factory_logs.log
exec 3>&1 1>>${LOG_FILE} 2>&1

COMMIT_ID=$1

echo "Deploy task at: $(date)"
echo "CI_COMMIT_SHORT_HASH = $COMMIT_ID"

PATH_SOURCE=/home/ubuntu/deployment/shinev2_product/factory/doc-extract-product
cd $PATH_SOURCE
echo " [*] >>>>>>>>>>> Git pull from target branch"
git checkout .
git fetch
git checkout develop
git pull
echo " [*] >>>>>>>>>>> Restart target env"
./shine-services.sh start factory
./shine-services.sh restart factory
echo " [*] >>>>>>>>>>> Restart target env successful"
#!/bin/bash
set -e

LOG_FILE=/home/ubuntu/data/pipeline/log/test_logs.log
exec 3>&1 1>>${LOG_FILE} 2>&1

COMMIT_ID=$1

echo "Deploy task at: $(date)"
echo "CI_COMMIT_SHORT_HASH = $COMMIT_ID"

PATH_SOURCE=/home/ubuntu/deployment/shinev2_product/test/doc-extract-product
cd $PATH_SOURCE
echo " [*] >>>>>>>>>>> Git pull from target branch"
git checkout .
git fetch
git checkout develop
git pull
echo " [*] >>>>>>>>>>> Restart target env"
./shine-services.sh start test
./shine-services.sh restart test
echo " [*] >>>>>>>>>>> Restart target env successful"
# CD Trigger
This service will trigger action and deploy both shinev2 product and core
## Prerequirements
- Install python build, pm2
- Your target project directory needed to set remote by SSH
`git remote set-url origin git@gitlab.com:cyberlogitec/saas-doc-extract/doc-extract-product.git`
- Create log folder for scripts at target server and log folder at running cicd server
- Modify path source, host, ssh_key in scripts for specific env
## Setting up your virtual env
# Install npm to get pm2
`sudo apt install npm`
# Install pm2
`sudo npm install pm2 -g`
# Install python 3
`sudo apt-get install python3`
# Install package install of Python3 (Strick)
`sudo apt install python3-pip`
# Install virtualenv to create own virtual workspace with local installed package
`sudo pip3 install virtualenv`
# Create local workspace
`virtualenv venv`
# Active virtualenv
`source venv/bin/activate`
# Install all the needed package for service
`pip3 install -r requirements.txt`

## Need to generate ssh at host machine, then add ssh authorize to target env (where contains source deployment)
`ssh-copy-id {USER}@{HOST}`

## Start CICD service by
`pm2 start --name shinev2_cicd "start.sh"`
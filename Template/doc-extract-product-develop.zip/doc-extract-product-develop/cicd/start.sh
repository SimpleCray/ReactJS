#!/bin/bash
source ./venv/bin/activate
LOG_FILE=./logs.log
PORT=8804
exec gunicorn -t 60 --reload --workers=1 -b 0.0.0.0:$PORT --error-logfile - --access-logfile - --log-file $LOG_FILE main:app

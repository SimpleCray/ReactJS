Please see the [Contributing](https://github.com/liferay/alloy-editor/wiki/Contributing) page on [the wiki](https://github.com/liferay/alloy-editor/wiki).
